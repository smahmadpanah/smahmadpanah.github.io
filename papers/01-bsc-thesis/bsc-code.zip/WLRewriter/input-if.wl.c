#include <stdio.h> 
 
#define TRUE 1 
#define true 1 
#define FALSE 0 
#define false 0 


int main() { int l1;  //type: low 
scanf("%d", &l1);
int l2;  //type: low 
scanf("%d", &l2);
; printf("%d\n",l1); // type: low

;  if ((l1 == 0)) { l1 = 2; printf("%d\n",l1); // type: low

;}
; printf("%d\n",l1); // type: low

; l1 = 10
; printf("%d\n",l1); // type: low

; l1 = l1 + 3
; printf("%d\n",l1); // type: low

; printf("%d\n",l2); // type: low

return 0;}