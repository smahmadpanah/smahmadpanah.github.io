#include <stdio.h> 
 
#define TRUE 1 
#define true 1 
#define FALSE 0 
#define false 0 


int main() { int h1;  //type: high 
scanf("%d", &h1);
; int l1;  //type: low 
scanf("%d", &l1);

;  if (l1 <= h1 || l1 < 0) { while (h1 < l1) { ;; h1 = h1 - l1
;
};}
; printf("%d\n",l1); // type: low

return 0;}