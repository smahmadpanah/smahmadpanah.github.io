#include <stdio.h> 
 
#define TRUE 1 
#define true 1 
#define FALSE 0 
#define false 0 


int main() { int h1;  //type: high 
scanf("%d", &h1);
; int l2;  //type: low 
scanf("%d", &l2);

;  if ((l2 <= 0)) { while (h1 >= l2) { h1 = h1 - 1; l2 = l2 + 1
;  if (l2 > 0) { l2 = l2 - 2;}
;
};}
;  if (TRUE) { ;;} else {printf("%d\n",l2); // type: low
;}
return 0;}