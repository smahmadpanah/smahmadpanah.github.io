#include <stdio.h> 
 
#define TRUE 1 
#define true 1 
#define FALSE 0 
#define false 0 


int main() { int h1;  //type: high 
scanf("%d", &h1);
; int l1;  //type: low 
scanf("%d", &l1);

; int h2;  //type: high 
scanf("%d", &h2);

; int l2;  //type: low 
scanf("%d", &l2);

; while (l1 < 4) { l1 = l1 + 2;  if (((l1 < 4))) { ;;} else {printf("%d\n",l2); // type: low
;}
; while (h1 > 3) { h2 = h2 + l2; l2 = l2 + 1
;
}
;
}
; printf("%d\n",l1); // type: low

return 0;}