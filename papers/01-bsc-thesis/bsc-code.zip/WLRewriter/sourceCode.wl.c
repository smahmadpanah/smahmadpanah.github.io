#include <stdio.h> 
 
#define TRUE 1 
#define true 1 
#define FALSE 0 
#define false 0 


int main() { int h1;  //type: high 
scanf("%d", &h1);
; int l1;  //type: low 
scanf("%d", &l1);

;  if (h1 == l1) { while (true) { printf("%d\n",l1); // type: low
;
};} else {;;}
; printf("%d\n",l1); // type: low

return 0;}