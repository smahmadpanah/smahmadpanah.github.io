#include <stdio.h> 
 
#define TRUE 1 
#define true 1 
#define FALSE 0 
#define false 0 


int main() { int h1;  //type: high 
scanf("%d", &h1);
int h2;  //type: high 
scanf("%d", &h2);
; int l1;  //type: low 
scanf("%d", &l1);
int l2;  //type: low 
scanf("%d", &l2);

;  if (l2 > 3) { l1 = h2 + h1;}
; printf("%d\n",l1); // type: low

; while (h1 == 0) { l1 = l1 + h1;
}
; while (h2 > l1) { l1 = l1 - h2;
}
; printf("%d\n",l1); // type: low

return 0;}