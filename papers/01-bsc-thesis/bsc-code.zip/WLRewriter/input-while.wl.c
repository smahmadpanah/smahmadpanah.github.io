#include <stdio.h> 
 
#define TRUE 1 
#define true 1 
#define FALSE 0 
#define false 0 


int main() { int h;  //type: high 
scanf("%d", &h);
; int l1;  //type: low 
scanf("%d", &l1);
int l2;  //type: low 
scanf("%d", &l2);
int l3;  //type: low 
scanf("%d", &l3);

; int k;  //type: high 
scanf("%d", &k);
int m;  //type: high 
scanf("%d", &m);

; while (h > 1) { while (true) { h = h + 1;
}; while (FALSE) { l1 = h;
}
;
}
; while ((m > 0)) { l1 = l2 + 2; l2 = 1
; l3 = 5
;  if (l2 > 3) { ;;} else {l1 = k;}
;
}
; printf("%d\n",l1); // type: low

return 0;}