#include <stdio.h> 
 
#define TRUE 1 
#define true 1 
#define FALSE 0 
#define false 0 


int main() { int r;  //type: high 
scanf("%d", &r);
int k;  //type: high 
scanf("%d", &k);
; int l1;  //type: low 
scanf("%d", &l1);
int l2;  //type: low 
scanf("%d", &l2);

; while (l2 > 0) { l1 = l1 + 1;
}
; while (k > 0) {  if (r > 9 && l1 <= 3) { r = 2 + k; printf("%d\n",r)
;  if (TRUE) { ;;} else {printf("%d\n",l1);}
;}; k = k - r
; printf("%d\n",r)
;
}
return 0;}