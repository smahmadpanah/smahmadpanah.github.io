#include <stdio.h> 
 
#define TRUE 1 
#define true 1 
#define FALSE 0 
#define false 0 


int main() { int p;  //type: low 
scanf("%d", &p);
; int m;  //type: high 
scanf("%d", &m);

; printf("%d\n",p)
; p = m
; printf("%d\n",m)
; printf("%d\n",m)
; printf("%d\n",p)
return 0;}