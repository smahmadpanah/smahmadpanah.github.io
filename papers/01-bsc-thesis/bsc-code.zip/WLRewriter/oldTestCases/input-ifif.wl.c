#include <stdio.h> 
 
#define TRUE 1 
#define true 1 
#define FALSE 0 
#define false 0 


int main() { int l1;  //type: low 
scanf("%d", &l1);
int l2;  //type: low 
scanf("%d", &l2);
; int h1;  //type: high 
scanf("%d", &h1);
int h2;  //type: high 
scanf("%d", &h2);

;  if (!(l1 == 0) && l1 > 0) { l1 = 2 + l1; l2 = h1
;  if (l2 > 5) { l1 = l2;} else {l1 = l2 + 2;}
;}
; printf("%d\n",l1)
return 0;}