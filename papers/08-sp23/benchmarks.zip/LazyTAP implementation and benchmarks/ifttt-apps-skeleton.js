//app configuration 

//trigger
var TriggerService = {
    triggerName: triggerData
}
//query
var QueryService = {
    queryName: queryService(queryUrl, queryInput)
}

//action
var ActionService = { actionName: { skipped: false } };

var actionDefaultValues = {
    ActionService: {
        actionName: {
            field_i: defaultValue_i
        }
    }
}
Object.assign(ActionService.actionName, actionDefaultValues['ActionService']['actionName']);

ActionService.actionName.setField_i = function(value) {
    if (!this.skipped) this.field_i = value;
}

ActionService.actionName.skip = function() {
    this.skipped = true;
}
//end of app configuration  


filterCode;


return ActionService;
// end of app