import express from "express";
import crypto from "crypto";
import chalk from "chalk";

// performance
const timeperformance = false;

var querydata;

export function setQuerydata(data) {
    querydata = data;
}

export function cache(data) {
    let id = crypto.randomBytes(4).toString("hex");
    querydata[id] = data;
    return id;
}

export const query = express();
query.use(express.json());

query.post("/:servicename/:type/:id/*", (req, res) => {
    let path = req.params[0];
    let id = req.params.id;

    log(req.params.servicename, `received query read request for id ${id} and path ${chalk.blue(path)}`);
    let result = querydata[id]

    for (let p of path.split("/")) {
        if (result === undefined) break;
        result = result[p];
    }

    // don't send the whole array/object when accessing inner objects
    // only send if it's a leaf of the object structure
    // if (result instanceof Array) result = []; //doesn't match with this one and it's fine!
    if (result instanceof Object) result = {};
    //

    log(req.params.servicename, `returning ${JSON.stringify(result)}`);
    res.json(result);
    res.end();
});

query.listen(4000);

export function log(servicename) {
    if (timeperformance) return; 
    var arg = Array.prototype.slice.call(arguments, 1);
    process.stdout.write(`[${servicename}] `);
    console.log.apply(console, arg);
}