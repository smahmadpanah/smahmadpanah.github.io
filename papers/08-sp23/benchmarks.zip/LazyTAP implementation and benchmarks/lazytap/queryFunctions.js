import { LazyService, RemoteArray, RemoteObject } from "./tap.js";

export function GoogleCalendarhistoryOfEventFromSearchStarts(Calendar, Query, Offset) {

    let GoogleCalendar = new LazyService("http://localhost:4000/GoogleCalendar/historyOfEventFromSearchStarts", {
        Calendar: Calendar,
        Query: Query,
        Offset: Offset
    });
    return RemoteArray.Create(GoogleCalendar);
}


export function GoogleCalendarsearchEvents(Calendar, Query) {

    let GoogleCalendar = new LazyService("http://localhost:4000/GoogleCalendar/searchEvents", {
        Calendar: Calendar,
        Query: Query
    });
    return RemoteArray.Create(GoogleCalendar);
}


export function GoogleTaskslistAllTasks(CompletedTasks) {
    let GoogleTasks = new LazyService("http://localhost:4000/GoogleTasks/listAllTasks", {
        CompletedTasks: CompletedTasks,
    });
    return RemoteArray.Create(GoogleTasks);
}

export function GoogleCalendarhistoryOfCalendarEventBeginnings(Calendar, Offset) {
    let GoogleCalendar = new LazyService("http://localhost:4000/GoogleCalendar/historyOfCalendarEventBeginnings", {
        Calendar: Calendar,
        Offset: Offset
    });
    return RemoteArray.Create(GoogleCalendar);
}

export function GiphyhistoryOfRandomGifBasedOnKeyword(Term) {
    let Giphy = new LazyService("http://localhost:4000/Giphy/historyOfRandomGifBasedOnKeyword", {
        Term: Term,
    });
    return RemoteArray.Create(Giphy);
}

export function WeathertwoDayForecast(Location) {
    let Weather = new LazyService("http://localhost:4000/Weather/twoDayForecast", {
        Location: Location,
    });
    return RemoteArray.Create(Weather);
}

export function WeathercurrentWeather(Location) {
    let Weather = new LazyService("http://localhost:4000/Weather/currentWeather", {
        Location: Location,
    });
    return RemoteArray.Create(Weather);
}


export function FinancehistoryOfClosingPrices(TickerSymbol) {
    let Finance = new LazyService("http://localhost:4000/Finance/historyOfClosingPrices", {
        TickerSymbol: TickerSymbol,
    });
    return RemoteArray.Create(Finance);
}



export function YelpsearchBusiness(Location, Term) {
    let Yelp = new LazyService("http://localhost:4000/Yelp/searchBusiness", {
        Location: Location,
        Term: Term
    });
    return RemoteArray.Create(Yelp);
}


export function FitbithistoryOfDailyActivitySummaries() {
    let Fitbit = new LazyService("http://localhost:4000/Fitbit/historyOfDailyActivitySummaries", {});
    return RemoteArray.Create(Fitbit);
}



export function YoutuberecentLikedVideos() {
    let Youtube = new LazyService("http://localhost:4000/Youtube/recentLikedVideos", {});
    return RemoteArray.Create(Youtube);
}


export function TraktmostWatchedMovies() {
    let Trakt = new LazyService("http://localhost:4000/Trakt/mostWatchedMovies", {});
    return RemoteArray.Create(Trakt);
}

export function TraktrecommendedMovies() {
    let Trakt = new LazyService("http://localhost:4000/Trakt/recommendedMovies", {});
    return RemoteArray.Create(Trakt);
}