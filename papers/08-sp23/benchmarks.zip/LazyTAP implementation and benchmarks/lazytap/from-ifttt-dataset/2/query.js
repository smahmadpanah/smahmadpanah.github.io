import { log, setQuerydata, query, cache } from '../../queryLib.js'

let triggerdata = { //just for the trigger data and cached data
    "example-03": {
        // change the following
        "OccurredAt": "2022-09-16",
        "LocationMapImageUrl": "dummy",
        "LocationMapUrl": "dummy",
    }
}
setQuerydata(triggerdata)

// the GoogleCalendar query
query.post("/GoogleCalendar/searchEvents", (req, res) => {
    log('GoogleCalendar', `received query with data ${JSON.stringify(req.body)}`);

    // perform dummy query

    let calendardata = {
        "myself": {
            "Weekend at the Dacha": [{
                    "Id": "number",
                    "Title": "string",
                    "Description": "string",
                    "Location": "string",
                    "Start": "2022-09-16",
                    "End": "string",
                    "EventUrl": "string",
                    "HangoutsUrl": "string",
                    "CreatedAt": "string",
                    "Attendees": "string",
                },
                {
                    "Id": "number",
                    "Title": "string",
                    "Description": "string",
                    "Location": "string",
                    "Start": "2022-09-13",
                    "End": "string",
                    "EventUrl": "string",
                    "HangoutsUrl": "string",
                    "CreatedAt": "string",
                    "Attendees": "string",
                },
                {
                    "Id": "number",
                    "Title": "string",
                    "Description": "string",
                    "Location": "string",
                    "Start": "2022-09-12",
                    "End": "string",
                    "EventUrl": "string",
                    "HangoutsUrl": "string",
                    "CreatedAt": "string",
                    "Attendees": "string",
                }
            ],
            "sth": [{
                "Id": "number",
                "Title": "string",
                "Description": "string",
                "Location": "string",
                "Start": "2022-09-20",
                "End": "string",
                "EventUrl": "string",
                "HangoutsUrl": "string",
                "CreatedAt": "string",
                "Attendees": "string",
            }],
        }
    };
    let result = calendardata[req.body.Calendar][req.body.Query]

    // cache the query result

    let id = cache(result);

    res.json({
        id: id,
    });

    res.end();
});
