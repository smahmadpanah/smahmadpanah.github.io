log("##### example example-03 is running... #####")

//preamble 
//trigger
var triggerservice = new LazyService("http://localhost:4000/Location/enterRegionLocation");
triggerservice.id = id;
var Location = { enterRegionLocation: RemoteObject.Create(triggerservice) }

//query
var GoogleCalendar = {
    searchEvents: QueryFunc.GoogleCalendarsearchEvents(
        // [BENCHMARK]: change the query term to "sth" OR "Weekend at the Dacha"
        // 
        () => "myself", () => "Weekend at the Dacha")
}
//action
var actionDefaultValues = {
    "WemoSwitch": {
        "attributeSocketOnDiscrete": {}
    }
}
var WemoSwitch = { attributeSocketOnDiscrete: { skipped: false } };
WemoSwitch.attributeSocketOnDiscrete.skip = function(msg = '') {
    this.skipped = true;
    log("WemoSwitch attributeSocketOnDiscrete skipped ", msg)
}
// filter code
log("** filter code **")
// locationDate will fetch the moment.js date object for the location trigger
// calendarDate will fetch the moment.js date object for the Google Calendar query

let locationDate = new Date(Location.enterRegionLocation.OccurredAt);
let calendarDate = new Date(GoogleCalendar.searchEvents[0].Start);

// The following if statement checks if the date and the month when you enter 
// the location matches the date and the month are the same. If they are the same, 
// then the action should run.

if (locationDate.getDate() !== calendarDate.getDate() || locationDate.getMonth() !== calendarDate.getMonth()) {
    WemoSwitch.attributeSocketOnDiscrete.skip();
}
log("** end of filter code **")

// post app action 
if (!WemoSwitch.attributeSocketOnDiscrete.skipped) {
    var actionfields = actionDefaultValues["WemoSwitch"]["attributeSocketOnDiscrete"];
    for (const field in actionfields) {
        if (!WemoSwitch.attributeSocketOnDiscrete.hasOwnProperty(field)) {
            WemoSwitch.attributeSocketOnDiscrete[field] = Strictify(actionfields[field]);
        }
    }
}
//result
log("action: ", WemoSwitch.attributeSocketOnDiscrete)
log("##### end of example example-03 #####")