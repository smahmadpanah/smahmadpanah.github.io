Applet: 
IF you start traveling to your vacation home →
THEN heat some water for your stay


Trigger service: Location {
Location.enterRegionLocation.OccurredAt,
Location.enterRegionLocation.LocationMapImageUrl
Location.enterRegionLocation.LocationMapUrl
}
Trigger: You enter an area

Query service: Google Calendar
Query: Search events (set Query to “Weekend at the Dacha”)
{
    GoogleCalendar.searchEvents.Id
GoogleCalendar.searchEvents.Title
GoogleCalendar.searchEvents.Description
GoogleCalendar.searchEvents.Location
GoogleCalendar.searchEvents.Start
GoogleCalendar.searchEvents.End
GoogleCalendar.searchEvents.EventUrl
GoogleCalendar.searchEvents.HangoutsUrl
GoogleCalendar.searchEvents.CreatedAt
GoogleCalendar.searchEvents.Attendees

}

Action service: WeMo Smart Plug
Action: Turn On




// locationDate will fetch the moment.js date object for the location trigger
// calendarDate will fetch the moment.js date object for the Google Calendar query

let locationDate = new Date(Location.enterRegionLocation.OccurredAt);
let calendarDate = new Date(GoogleCalendar.searchEvents[0].Start);

// The following if statement checks if the date and the month when you enter 
// the location matches the date and the month are the same. If they are the same, 
// then the action should run.

if (locationDate.getDate() !== calendarDate.getDate() || locationDate.getMonth()!== calendarDate.getMonth()) {
    WemoSwitch.attributeSocketOnDiscrete.skip();
}