import { log, setQuerydata, query, cache } from '../../queryLib.js'

let triggerdata = { //just for the trigger data and cached data
    "YG5HSLvK": {
        "CheckTime": "07:30",
        "DayOfWeek": "['1','2','3','4','5']",
    }
}
setQuerydata(triggerdata)

// the GoogleCalendar query
query.post("/GoogleTasks/listAllTasks", (req, res) => {
    log('GoogleTasks', `received query with data ${JSON.stringify(req.body)}`);

    // perform dummy query

    let calendardata = {
        "true": [{
                "TaskID": "string",
                "Title": "title1",
                "Status": "string",
                "Notes": "note1",
                "CompletedAt": "string",
                "Due": "2020-04-23T18:25:43Z",
                "UpdatedAt": "string",
            },
            {
                "TaskID": "string",
                "Title": "title2",
                "Status": "string",
                "Notes": "note2",
                "CompletedAt": "string",
                "Due": "2020-04-23T18:25:43Z",
                "UpdatedAt": "string",
            },
            {
                "TaskID": "string",
                "Title": "title3",
                "Status": "string",
                "Notes": "note3",
                "CompletedAt": "string",
                "Due": "2020-04-25T18:25:43Z",
                "UpdatedAt": "string",
            }
        ],
        "false": [{
            "TaskID": "string",
            "Title": "title4",
            "Status": "string",
            "Notes": "note4",
            "CompletedAt": "string",
            "Due": "2020-04-23T18:25:43Z",
            "UpdatedAt": "string",
        }]
    };
    let result = calendardata[req.body.CompletedTasks] //[req.body.Query][req.body.Offset];

    // cache the query result

    let id = cache(result);

    res.json({
        id: id,
    });

    res.end();
});