import { log, setQuerydata, query, cache } from '../../queryLib.js'

let triggerdata = { //just for the trigger data and cached data
    "jUy5if7H": {
        "SwitchedOnAt": "string",
        "SwitchName": "string"
    }
}
setQuerydata(triggerdata)

// the GoogleCalendar query
query.post("/Trakt/recommendedMovies", (req, res) => {
    log('Trakt', `received query with data ${JSON.stringify(req.body)}`);

    // perform dummy query

    let calendardata = [{
            "MovieId": "number",
            "MovieTitle": "Mov1",
            "MovieYear": "string",
            "MovieDescription": "string",
            "MovieTrailer": "string",
            "MovieGenre": "string",
            "MovieCertification": "string"
        },
        {
            "MovieId": "number",
            "MovieTitle": "Mov2",
            "MovieYear": "string",
            "MovieDescription": "string",
            "MovieTrailer": "string",
            "MovieGenre": "string",
            "MovieCertification": "string",
        },
        {
            "MovieId": "number",
            "MovieTitle": "Mov3",
            "MovieYear": "string",
            "MovieDescription": "string",
            "MovieTrailer": "string",
            "MovieGenre": "string",
            "MovieCertification": "string",
        },
        {
            "MovieId": "number",
            "MovieTitle": "Mov4",
            "MovieYear": "string",
            "MovieDescription": "string",
            "MovieTrailer": "string",
            "MovieGenre": "string",
            "MovieCertification": "string",
        },
        {
            "MovieId": "number",
            "MovieTitle": "Mov5",
            "MovieYear": "string",
            "MovieDescription": "string",
            "MovieTrailer": "string",
            "MovieGenre": "string",
            "MovieCertification": "string",
        },
        {
            "MovieId": "number",
            "MovieTitle": "Mov6",
            "MovieYear": "string",
            "MovieDescription": "string",
            "MovieTrailer": "string",
            "MovieGenre": "string",
            "MovieCertification": "string",
        }
    ];
    let result = calendardata //[req.body.Calendar][req.body.Query][req.body.Offset];

    // cache the query result

    let id = cache(result);

    res.json({
        id: id,
    });

    res.end();
});

