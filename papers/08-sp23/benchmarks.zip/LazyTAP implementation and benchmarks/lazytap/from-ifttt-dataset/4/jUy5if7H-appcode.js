log("##### example jUy5if7H is running... #####")

//preamble 
//trigger
var triggerservice = new LazyService("http://localhost:4000/Smartthings/switchedOnSmartthings");
triggerservice.id = id;
var Smartthings = { switchedOnSmartthings: RemoteObject.Create(triggerservice) }

// [BENCHMARK]: for skip day=4 and hour=18
// config.currentTime = '2020-04-23T18:25:43.511Z'
config.currentTime = '2020-04-25T19:25:43.511Z'
Meta.currentUserTime = moment(config.currentTime).tz(config.timeZone)

//query
var Trakt = {
    recommendedMovies: QueryFunc.TraktrecommendedMovies()
}
//action
var actionDefaultValues = {
    "IfNotifications": {
        "sendRichNotification": {
            "Title": "Saturday Movie Night!",
            "Message": "Saturday Movie Night!",
            "LinkUrl": "https://trakt.tv/welcome/1",
            "ImageUrl": ""
        }
    }
}

var IfNotifications = { sendRichNotification: { skipped: false } };

IfNotifications.sendRichNotification.setTitle = function(msg = '') {
    if (!this.skipped) {
        this.Title = msg;
        log("IfNotifications setTitle: ", msg)
    }
}

IfNotifications.sendRichNotification.setMessage = function(msg = '') {
    if (!this.skipped) {
        this.Message = msg;
        log("IfNotifications setMessage: ", msg)
    }
}

IfNotifications.sendRichNotification.setLinkUrl = function(msg = '') {
    if (!this.skipped) {
        this.LinkUrl = msg;
        log("IfNotifications setLinkUrl: ", msg)
    }
}

IfNotifications.sendRichNotification.setImageUrl = function(msg = '') {
    if (!this.skipped) {
        this.ImageUrl = msg;
        log("IfNotifications setImageUrl: ", msg)
    }
}

IfNotifications.sendRichNotification.skip = function(msg = '') {
    this.skipped = true;
    log("IfNotifications sendRichNotification skipped ", msg)
}
// filter code
log("** filter code **")
var Day = Meta.currentUserTime.day()
var Hour = Meta.currentUserTime.hour()
var optionOne = Math.floor((Math.random() * Trakt.recommendedMovies.length))
var optionTwo = Math.floor((Math.random() * Trakt.recommendedMovies.length))
var optionThree = Math.floor((Math.random() * Trakt.recommendedMovies.length))
if (Day != 6) {
    IfNotifications.sendRichNotification.skip()
} else if (Hour < 17) {
    IfNotifications.sendRichNotification.skip()
} else if (Hour >= 17) {
    IfNotifications.sendRichNotification.setMessage(`Ready for movie night? here are three movies to pick from: 
                ${Trakt.recommendedMovies[optionOne].MovieTitle}, ${Trakt.recommendedMovies[optionTwo].MovieTitle}, 
                or ${Trakt.recommendedMovies[optionThree].MovieTitle}`)
}

log("** end of filter code **")

// post app action 
if (!IfNotifications.sendRichNotification.skipped) {
    var actionfields = actionDefaultValues["IfNotifications"]["sendRichNotification"];
    for (const field in actionfields) {
        if (!IfNotifications.sendRichNotification.hasOwnProperty(field)) {
            IfNotifications.sendRichNotification[field] = Strictify(actionfields[field]);
        }
    }
} 
//result
log("IfNotifications: ", IfNotifications.sendRichNotification)
log("##### end of example jUy5if7H #####")