let optionOne = Math.floor((Math.random() * Trakt.recommendedMovies.length))
let optionTwo = Math.floor((Math.random() * Yelp.searchBusiness.length))
Email.sendMeEmail.setSubject(`It's night date night!`)
Email.sendMeEmail.setBody(`Tonight you should watch ${Trakt.recommendedMovies[optionOne].MovieTitle}, and order dinner from ${Yelp.searchBusiness[optionTwo].BusinessName}! `)