import fetch from "sync-fetch";



// assuming that all starts by
// 1: TAP polls trigger, (shimmed) trigger answers with an event type and id
// 2: (shimmed) trigger initiates with an event type and id


// email trigger 
let result1 = postJSON("http://localhost:9000/trigger/DateAndTime/everyWeekdayAt", {
    id: "MRm9VBxG"
});
//console.log(result1);



function postJSON(url, data) {
    let result = fetch(url, {
        method: "POST",
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    });
    // console.log(result)

    return result.json();
}

//