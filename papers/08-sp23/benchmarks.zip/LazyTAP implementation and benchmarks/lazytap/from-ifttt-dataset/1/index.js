import fetch from "sync-fetch";



// assuming that all starts by
// 1: TAP polls trigger, (shimmed) trigger answers with an event type and id
// 2: (shimmed) trigger initiates with an event type and id


// trigger 
let result1 = postJSON("http://localhost:9000/trigger/DateAndTime/everyWeekdayAt", {
    id: "AxJSC34d"
});



function postJSON(url, data) {
    let result = fetch(url, {
        method: "POST",
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    });

    return result.json();
}

//