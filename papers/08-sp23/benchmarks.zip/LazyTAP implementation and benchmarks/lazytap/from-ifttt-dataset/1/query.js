import { log, setQuerydata, query, cache } from '../../queryLib.js'

let triggerdata = { //just for the trigger data and cached data
    "AxJSC34d": {
        "CheckTime": "dummy",
        "DayOfWeek": "dummy",
    }
}
setQuerydata(triggerdata)


// the Trakt query
query.post("/Trakt/mostWatchedMovies", (req, res) => {
    log('Trakt', `received query with data ${JSON.stringify(req.body)}`);

    // perform dummy query

    let traktdata = [{
            "MovieId": "1",
            "MovieTitle": "Movie 1",
            "MovieYear": "1991",
            "MoviePlays": "1",
            "LastWatchedAt": "string",
        },
        {
            "MovieId": "2",
            "MovieTitle": "Movie 2",
            "MovieYear": "1992",
            "MoviePlays": "2",
            "LastWatchedAt": "string",
        },
        {
            "MovieId": "3",
            "MovieTitle": "Movie 3",
            "MovieYear": "1993",
            "MoviePlays": "3",
            "LastWatchedAt": "string",
        },
        {
            "MovieId": "4",
            "MovieTitle": "Movie 4",
            "MovieYear": "1994",
            "MoviePlays": "4",
            "LastWatchedAt": "string",
        },
        {
            "MovieId": "5",
            "MovieTitle": "Movie 5",
            "MovieYear": "1995",
            "MoviePlays": "5",
            "LastWatchedAt": "string",
        },
        {
            "MovieId": "6",
            "MovieTitle": "Movie 6",
            "MovieYear": "1996",
            "MoviePlays": "6",
            "LastWatchedAt": "string",
        },
        {
            "MovieId": "7",
            "MovieTitle": "Movie 7",
            "MovieYear": "1997",
            "MoviePlays": "7",
            "LastWatchedAt": "string",
        },
        {
            "MovieId": "8",
            "MovieTitle": "Movie 8",
            "MovieYear": "1998",
            "MoviePlays": "8",
            "LastWatchedAt": "string",
        },
        {
            "MovieId": "9",
            "MovieTitle": "Movie 9",
            "MovieYear": "1999",
            "MoviePlays": "9",
            "LastWatchedAt": "string",
        },
        {
            "MovieId": "10",
            "MovieTitle": "Movie 10",
            "MovieYear": "2000",
            "MoviePlays": "10",
            "LastWatchedAt": "string",
        }
        ];
    let result = traktdata;


    // cache the query result

    let id = cache(result);

    res.json({
        id: id,
    });

    res.end();
});
