import { log, setQuerydata, query, cache } from '../../queryLib.js'

let triggerdata = { //just for the trigger data and cached data
    "VDdNBmiE": {
        "AppearsAt": "11:11",
        "DisappearsAt": "string",
        "DurationSeconds": "50",
        "LocationMapImageUrl": "string",
        "LocationMapUrl": "string",
    }
}
setQuerydata(triggerdata)

// the GoogleCalendar query
query.post("/Weather/currentWeather", (req, res) => {
    log('Weather', `received query with data ${JSON.stringify(req.body)}`);

    // perform dummy query

    let calendardata = {
        "gbg": [{
                "SunriseAt": "2020-04-25T08:25:43.511Z",
                "SunsetAt": "2020-04-25T20:25:43.511Z",
                "CurrentTempFahrenheit": "string",
                "CurrentTempCelsius": "string",
                "CurrentCondition": "Sunny",
                "CurrentConditionImageUrl": "string",
                "TodaysConditionImageUrl": "string",
                "ForecastUrl": "string",
                "TodaysCondition": "string",
                "HighTempFahrenheit": "string",
                "HighTempCelsius": "string",
                "LowTempFahrenheit": "string",
                "LowTempCelsius": "string",
                "UvIndex": "string",
                "Humidity": "string",
                "WindSpeedMph": "string",
                "WindSpeedKph": "string",
                "WindDirection": "string",
                "PollenCount": "string",
                "CheckTime": "string",
            },
            {
                "SunriseAt": "string",
                "SunsetAt": "string",
                "CurrentTempFahrenheit": "string",
                "CurrentTempCelsius": "string",
                "CurrentCondition": "string",
                "CurrentConditionImageUrl": "string",
                "TodaysConditionImageUrl": "string",
                "ForecastUrl": "string",
                "TodaysCondition": "string",
                "HighTempFahrenheit": "string",
                "HighTempCelsius": "string",
                "LowTempFahrenheit": "string",
                "LowTempCelsius": "string",
                "UvIndex": "string",
                "Humidity": "string",
                "WindSpeedMph": "string",
                "WindSpeedKph": "string",
                "WindDirection": "string",
                "PollenCount": "string",
                "CheckTime": "string",
            },
        ],
        "teh": [{
            "SunriseAt": "2020-04-25T06:25:43.511Z",
            "SunsetAt": "2020-04-25T23:25:43.511Z",
            "CurrentTempFahrenheit": "string",
            "CurrentTempCelsius": "string",
            "CurrentCondition": "Cloudy",
            "CurrentConditionImageUrl": "string",
            "TodaysConditionImageUrl": "string",
            "ForecastUrl": "string",
            "TodaysCondition": "string",
            "HighTempFahrenheit": "string",
            "HighTempCelsius": "string",
            "LowTempFahrenheit": "string",
            "LowTempCelsius": "string",
            "UvIndex": "string",
            "Humidity": "string",
            "WindSpeedMph": "string",
            "WindSpeedKph": "string",
            "WindDirection": "string",
            "PollenCount": "string",
            "CheckTime": "string",
        }]
    };

    let result = calendardata[req.body.Location] //[req.body.Query][req.body.Offset];

    // cache the query result

    let id = cache(result);

    res.json({
        id: id,
    });

    res.end();
});
