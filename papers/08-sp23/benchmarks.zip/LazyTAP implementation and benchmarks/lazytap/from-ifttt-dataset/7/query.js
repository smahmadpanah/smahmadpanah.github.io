import { log, setQuerydata, query, cache } from '../../queryLib.js'

let triggerdata = { //just for the trigger data and cached data
    "xvyUBQsh": {
        "Title": "string",
        // "Description": "BUSY is too much NEW year salam ", //[BENCHMARK]: change this
        "Description": "test test",
        "Where": "string",
        "Starts": "string",
        "Ends": "string",
        "EventUrl": "string",
        "VideoCallUrl": "string",
        "CreatedAt": "string",
    }
}
setQuerydata(triggerdata)

// the GoogleCalendar query
query.post("/Giphy/historyOfRandomGifBasedOnKeyword", (req, res) => {
    log('Giphy', `received query with data ${JSON.stringify(req.body)}`);

    // perform dummy query

    let calendardata = {
        "pic1": [{
                "URL": "string",
                "ImageURL": "url/image",
                "TumblrImageURL": "string",
                "EmailHTML": "string",
                "EmbedCode": "string",
                "CreatedDate": "string",
            },
            {
                "URL": "string",
                "ImageURL": "string",
                "TumblrImageURL": "string",
                "EmailHTML": "string",
                "EmbedCode": "string",
                "CreatedDate": "string",
            },
            {
                "URL": "string",
                "ImageURL": "string",
                "TumblrImageURL": "string",
                "EmailHTML": "string",
                "EmbedCode": "string",
                "CreatedDate": "string",
            }
        ],
        "pic2": [{
            "URL": "string",
            "ImageURL": "url2",
            "TumblrImageURL": "string",
            "EmailHTML": "string",
            "EmbedCode": "string",
            "CreatedDate": "string",
        }]
    };
    let result = calendardata[req.body.Term]//[req.body.Query][req.body.Offset];

    // cache the query result

    let id = cache(result);

    res.json({
        id: id,
    });

    res.end();
});
