import { log, setQuerydata, query, cache } from '../../queryLib.js'

let triggerdata = { //just for the trigger data and cached data
    "iqZPNUtR": {
        "CreatedAt": "today",
        "VehicleName": "bmw",
        "FuelEcon": "2",
    }
}
setQuerydata(triggerdata)


// the GoogleCalendar query
query.post("/Finance/historyOfClosingPrices", (req, res) => {
    log('Finance', `received query with data ${JSON.stringify(req.body)}`);

    // perform dummy query
    let calendardata = {
        "OIL": [{
                "StockName": "eventSupervisor",
                "StockTicker": 'dummy',
                "Price": '3',
                "InfoUrl": "string",
                "Date": "string",
            },
            {
                "StockName": "eventSupervisor",
                "StockTicker": 'dummy',
                "Price": "20",
                "InfoUrl": "string",
                "Date": "string",
            },
            {
                "StockName": "eventSupervisor",
                "StockTicker": 'dummy',
                "Price": "string",
                "InfoUrl": "string",
                "Date": "string",
            }
        ],
        "NXT": [{
            "StockName": "eventSupervisor",
                "StockTicker": 'dummy',
                "Price": "90",
                "InfoUrl": "string",
                "Date": "string",
        }]


    };
    let result = calendardata[req.body.TickerSymbol]//[req.body.Query][req.body.Offset];

    // cache the query result

    let id = cache(result);

    res.json({
        id: id,
    });

    res.end();
});
