// 05 - app with two queries on trigger-dependent branch
// if a new email received, if it's from supervisor, check the calendar and post on slack;
//                          if it's from personal trainer, fetch the fitbit daily activity and send it to him

// app config; details below
// trigger: a new Email (Email.sendIftttAnEmail) 
// query1: GoogleCalendar.historyOfEventFromSearchStarts("today", Email.from)
// query2: Fitbit.historyOfDailyActivitySummaries
// action1: Slack.postToChannel.setMessage("something went wrong!")
// action2: Gmail.sendAnEmail.setTo("trainer"); Gmail.sendAnEmail.setSubject('daily summary');



// app filtercode
if (Email.sendIftttAnEmail.From == "supervisor") {
    if (GoogleCalendar.historyOfEventFromSearchStarts.length != 0) {
        Slack.postToChannel.setMessage(
            Email.sendIftttAnEmail.Subject +
            Email.sendIftttAnEmail.Body +
            Email.sendIftttAnEmail.AttachmentUrl +
            GoogleCalendar.historyOfEventFromSearchStarts[0].Title);
    } else {
        Slack.postToChannel.skip();
    }
    Gmail.sendAnEmail.skip();
} else if (Email.sendIftttAnEmail.From == "trainer") {
    if (Fitbit.historyOfDailyActivitySummaries.length != 0) {
        let todaySummary = Fitbit.historyOfDailyActivitySummaries[0];
        Gmail.sendAnEmail.setBody(
            todaySummary.Date +
            todaySummary.TotalCaloriesBurned +
            todaySummary.VeryActiveMinutes);
    } else {
        Gmail.sendAnEmail.skip();
    }
    Slack.postToChannel.skip();
} else {
    Slack.postToChannel.skip();
    Gmail.sendAnEmail.skip();
}

/*
- control flow depends on sensitive query that depends on sensitive trigger
- 
    static minTAP: 10 attributes, can handle arrrays?!
    dynamic minTAP: n/a
    lazyTAP: 1, 2, 5, 6
    no min/ifttt: 7 + (7 * GoogleCalendarLength) + 1 + (12 * FitbitLength) + 1 
*/

/*
"applet": {
            "applet_triggers": [
                {
                "trigger": {
                        "name": "Send IFTTT any email",
                        "ingredients": [
                            {
                                "normalized_name": "Email.sendIftttAnEmail.AttachmentTemporaryUrl"
                            },
                            {
                                "normalized_name": "Email.sendIftttAnEmail.From"
                            },
                            {
                                "normalized_name": "Email.sendIftttAnEmail.Body"
                            },
                            {
                                "normalized_name": "Email.sendIftttAnEmail.BodyHTML"
                            },
                            {
                                "normalized_name": "Email.sendIftttAnEmail.Subject"
                            },
                            {
                                "normalized_name": "Email.sendIftttAnEmail.AttachmentUrl"
                            },
                            {
                                "normalized_name": "Email.sendIftttAnEmail.ReceivedAt"
                            }
                        ]
                    },
                    "fields": []
                }
            ],
            "applet_queries": [
                {
                    "query": {
                        "name": "History of event from search starts",
                        "ingredients": [
                            {
                                "normalized_name": "GoogleCalendar.historyOfEventFromSearchStarts.Title"
                            },
                            {
                                "normalized_name": "GoogleCalendar.historyOfEventFromSearchStarts.Description"
                            },
                            {
                                "normalized_name": "GoogleCalendar.historyOfEventFromSearchStarts.Where"
                            },
                            {
                                "normalized_name": "GoogleCalendar.historyOfEventFromSearchStarts.Starts"
                            },
                            {
                                "normalized_name": "GoogleCalendar.historyOfEventFromSearchStarts.Ends"
                            },
                            {
                                "normalized_name": "GoogleCalendar.historyOfEventFromSearchStarts.EventUrl"
                            },
                            {
                                "normalized_name": "GoogleCalendar.historyOfEventFromSearchStarts.VideoCallUrl"
                            }
                        ]
                    },
                    "fields": [
                        {
                            "label": "Calendar",
                            "default_value_json": "myself"
                        },
                        {
                            "label": "Query",
                            "default_value_json": Email.from
                        },
                        {
                            "label": "Offset",
                            "default_value_json": "11:00"
                        }
                    ]
                },
                {
                    "query": {
                        "name": "History of Daily Activity Summaries",
                        "ingredients": [
                            {
                                "normalized_name": "Fitbit.historyOfDailyActivitySummaries.Date"
                            },
                            {
                                "normalized_name": "Fitbit.historyOfDailyActivitySummaries.TotalSteps"
                            },
                            {
                                "normalized_name": "Fitbit.historyOfDailyActivitySummaries.TotalFloorsClimbed"
                            },
                            {
                                "normalized_name": "Fitbit.historyOfDailyActivitySummaries.TotalCaloriesBurned"
                            },
                            {
                                "normalized_name": "Fitbit.historyOfDailyActivitySummaries.TotalElevationGained"
                            },
                            {
                                "normalized_name": "Fitbit.historyOfDailyActivitySummaries.TotalElevationGainedUnit"
                            },
                            {
                                "normalized_name": "Fitbit.historyOfDailyActivitySummaries.TotalDistanceCovered"
                            },
                            {
                                "normalized_name": "Fitbit.historyOfDailyActivitySummaries.TotalDistanceCoveredUnit"
                            },
                            {
                                "normalized_name": "Fitbit.historyOfDailyActivitySummaries.SedentaryMinutes"
                            },
                            {
                                "normalized_name": "Fitbit.historyOfDailyActivitySummaries.LightlyActiveMinutes"
                            },
                            {
                                "normalized_name": "Fitbit.historyOfDailyActivitySummaries.FairlyActiveMinutes"
                            },
                            {
                                "normalized_name": "Fitbit.historyOfDailyActivitySummaries.VeryActiveMinutes"
                            }
                        ]
                    },
                    "fields": []
                }
            ],
            "applet_actions": [
                {
                    "action": {
                        "name": "Post to channel",
                        "full_normalized_module_name": "Slack.postToChannel",
                        "action_fields": [
                            {
                                "normalized_module_name": "Channel"
                            },
                            {
                                "normalized_module_name": "Message"
                            },
                            {
                                "normalized_module_name": "Title"
                            },
                            {
                                "normalized_module_name": "TitleUrl"
                            },
                            {
                                "normalized_module_name": "ImageUrl"
                            }
                        ]
                    },
                    "fields": [
                        {
                            "label": "Which channel?",
                            "default_value_json": "Myself"
                        },
                        {
                            "label": "Message",
                            "default_value_json": "something went wrong!"
                        },
                        {
                            "label": "Title",
                            "default_value_json": ""
                        },
                        {
                            "label": "Title URL",
                            "default_value_json": ""
                        },
                        {
                            "label": "Thumbnail URL",
                            "default_value_json": ""
                        }
                    ]
                },
                {
                    "action": {
                        "name": "Send an email",
                        "full_normalized_module_name": "Gmail.sendAnEmail",
                        "action_fields": [
                            {
                                "normalized_module_name": "To"
                            },
                            {
                                "normalized_module_name": "Cc"
                            },
                            {
                                "normalized_module_name": "Bcc"
                            },
                            {
                                "normalized_module_name": "Subject"
                            },
                            {
                                "normalized_module_name": "Body"
                            },
                            {
                                "normalized_module_name": "AttachmentUrl"
                            }
                        ]
                    },
                    "fields": [
                        {
                            "label": "To",
                            "default_value_json": "trainer"
                        },
                        {
                            "label": "Cc",
                            "default_value_json": ""
                        },
                        {
                            "label": "Bcc",
                            "default_value_json": ""
                        },
                        {
                            "label": "Subject",
                            "default_value_json": "daily summary"
                        },
                        {
                            "label": "Body",
                            "default_value_json": ""
                        },
                        {
                            "label": "AttachmentUrl",
                            "default_value_json": ""
                        }
                    ]
                }
            ],
*/