import { log, setQuerydata, query, cache } from '../../queryLib.js'

let triggerdata = { //just for the trigger data and cached data
    "005ecfsg": {
        "AttachmentTemporaryUrl": "dummy",
        //
        // [BENCHMARK]: modify WHERE
        // to change the exeuction, pick one of the followings
        "From": "supervisor", // [6 or 2] fetching From, Subject, Body, AttachmentUrl, historyOfEventFromSearchStarts[0].Title
        // "From": "trainer", //fetching From, historyOfDailyActivitySummaries[0].Date/TotalCaloriesBurned/VeryActiveMinutes 
        // "From": "spammer", //fetching From
        //
        "Body": "here's the meeing info",
        "BodyHTML": "dummy",
        "Subject": "meeting",
        "AttachmentUrl": "the url",
        "ReceivedAt": "23:59",
    }
}
setQuerydata(triggerdata)

// the GoogleCalendar query
query.post("/GoogleCalendar/historyOfEventFromSearchStarts", (req, res) => {
    log('GoogleCalendar', `received query with data ${JSON.stringify(req.body)}`);

    // perform dummy query

    let calendardata = {
        "myself": {
            "supervisor": {
                "01:00": 
                // [] // [BENCHMARK] for two attributes
                [{
                        "Title": "eventSupervisor",
                        "Starts": '08:02',
                        "Description": "string",
                        "Where": "gothenburg",
                        "Ends": "string",
                        "EventUrl": "string",
                        "VideoCallUrl": "string",
                    },
                    {
                        "Title": "eventSupervisor2",
                        "Starts": '12:02',
                        "Description": "string",
                        "Where": "string",
                        "Ends": "string",
                        "EventUrl": "string",
                        "VideoCallUrl": "string",
                    },
                    {
                        "Title": "eventSupervisor3",
                        "Starts": '12:10',
                        "Description": "string",
                        "Where": "string",
                        "Ends": "string",
                        "EventUrl": "string",
                        "VideoCallUrl": "string",
                    }
                ]
            },
            "trainer": {
                "01:00": [{
                    "Title": "eventFriend",
                    "Starts": '18:02',
                    "Description": "string",
                    "Where": "tehran",
                    "Ends": "string",
                    "EventUrl": "string",
                    "VideoCallUrl": "string",
                }]
            },
            "spammer": { "01:00": [] },

        }
    };
    let result = calendardata[req.body.Calendar][req.body.Query][req.body.Offset];


    // cache the query result

    let id = cache(result);

    res.json({
        id: id,
    });

    res.end();
});



// the Fitbit query
query.post("/Fitbit/historyOfDailyActivitySummaries", (req, res) => {
    log('Fitbit', `received query with data ${JSON.stringify(req.body)}`);

    // perform dummy query

    var fitbitdata = [{
            "Date": "1/1/2022",
            "TotalSteps": "string",
            "TotalFloorsClimbed": "string",
            "TotalCaloriesBurned": "100",
            "TotalElevationGained": "string",
            "TotalElevationGainedUnit": "string",
            "TotalDistanceCovered": "string",
            "TotalDistanceCoveredUnit": "string",
            "SedentaryMinutes": "string",
            "LightlyActiveMinutes": "string",
            "FairlyActiveMinutes": "string",
            "VeryActiveMinutes": "30",
        },
        {
            "Date": "number",
            "TotalSteps": "string",
            "TotalFloorsClimbed": "string",
            "TotalCaloriesBurned": "string",
            "TotalElevationGained": "string",
            "TotalElevationGainedUnit": "string",
            "TotalDistanceCovered": "string",
            "TotalDistanceCoveredUnit": "string",
            "SedentaryMinutes": "string",
            "LightlyActiveMinutes": "string",
            "FairlyActiveMinutes": "string",
            "VeryActiveMinutes": "string",
        },
    ];
    // fitbitdata = [] //[BENCHMARK]: uncomment this
    let result = fitbitdata


    // cache the query result

    let id = cache(result);

    res.json({
        id: id,
    });

    res.end();
});
