log("##### example 04 is running... #####")

//preamble 
//trigger
var triggerservice = new LazyService("http://localhost:4000/Smartlife/doorClosed");
triggerservice.id = id;
var Smartlife = { doorClosed: RemoteObject.Create(triggerservice) }

//query
var GoogleCalendar = {
    historyOfCalendarEventBeginnings: QueryFunc.GoogleCalendarhistoryOfCalendarEventBeginnings(
        // [BENCHMARK]: modify the offset time to "01:00" or "10:00" or "20:00"
        () => "myself", () => "01:00")
}

var Yelp = {
    searchBusiness: QueryFunc.YelpsearchBusiness(
        // [BENCHMARK]: go to ./4/query and modify .From values
        // new LazyProjection(new LazyProjection(new LazyProjection(GoogleCaldendar, "historyOfCalendarEventBeginnings"), "0"), "Where")
        () => GoogleCalendar.historyOfCalendarEventBeginnings[0].Where,
        () => "parking")
}

//action
var actionDefaultValues = {
    "AndroidDevice": {
        "startNavigation": {
            "NavigationMethod": "simple",
            "Query": () => "navgiation to " + Yelp.searchBusiness[0].BusinessAddress,
        }
    }
}
var AndroidDevice = { startNavigation: { skipped: false } };
AndroidDevice.startNavigation.setNavigationMethod = function(msg = '') {
    if (!this.skipped) {
        this.NavigationMethod = msg;
        log("AndroidDevice setNavigationMethod: ", msg)
    }
}
AndroidDevice.startNavigation.setQuery = function(msg = '') {
    if (!this.skipped) {
        this.Query = msg;
        log("AndroidDevice setQuery: ", msg)
    }
}
AndroidDevice.startNavigation.skip = function(msg = '') {
    this.skipped = true;
    log("AndroidDevice startNavigation skipped ", msg)
}

// filter code
log("** filter code **")
if (GoogleCalendar.historyOfCalendarEventBeginnings.length != 0) {
    if (Yelp.searchBusiness.length != 0) {
        AndroidDevice.startNavigation.setQuery(Yelp.searchBusiness[0].BusinessAddress); //redundant, as the default action value already does the same
    } else {
        AndroidDevice.startNavigation.skip('no parking found');
    }
} else {
    AndroidDevice.startNavigation.skip('no meeting found');
}
log("** end of filter code **")

// post app action 
if (!AndroidDevice.startNavigation.skipped) {
    var actionfields = actionDefaultValues["AndroidDevice"]["startNavigation"];
    for (const field in actionfields) {
        if (!AndroidDevice.startNavigation.hasOwnProperty(field)) {
            AndroidDevice.startNavigation[field] = Strictify(actionfields[field]);
        }
    }
}
//result
log("action: ", AndroidDevice.startNavigation)
log("##### end of example 04 #####")