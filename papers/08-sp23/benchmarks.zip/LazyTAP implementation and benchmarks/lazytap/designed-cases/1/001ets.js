log("##### example 01 is running... #####")

//preamble 
//trigger
var triggerservice = new LazyService("http://localhost:4000/Email/sendIftttAnEmail");
triggerservice.id = id;
var Email = { sendIftttAnEmail: RemoteObject.Create(triggerservice) }
//query
//action
var actionDefaultValues = {
    "Slack": {
        "postToChannel": {
            "Channel": "Myself",
            "Title": "untitled",
            "Message": () => "a new email received at " + Email.sendIftttAnEmail.ReceivedAt,
            //"Message": new LAzyProjection(new LazyProjection(Email.sendIftttAnEmail, "ReceivedAt"), "..."),
            "TitleUrl": "",
            "ImageUrl": "",
        }
    }
}
var Slack = { postToChannel: { skipped: false } };
Slack.postToChannel.setMessage = function(msg = '') {
    if (!this.skipped) {
        this.Message = msg;
        log("SLACK setMessage: ", msg)
    }
}
Slack.postToChannel.setTitle = function(msg = '') {
    if (!this.skipped) {
        this.Title = msg;
        log("SLACK setTitle: ", msg)
    }
}
Slack.postToChannel.skip = function(msg = '') {
    this.skipped = true;
    log("SLACK postToChannel skipped ", msg)
}
// filter code
log("** filter code **")
// [BENCHMARK]: go to ./1/query and modify .From values
if (Email.sendIftttAnEmail.From == "supervisor") {
    Slack.postToChannel.setTitle(Email.sendIftttAnEmail.Subject)
    Slack.postToChannel.setMessage(
        Email.sendIftttAnEmail.Body + '\n' +
        Email.sendIftttAnEmail.AttachmentUrl);
} else if (Email.sendIftttAnEmail.From == 'news') {
    Slack.postToChannel.setTitle("news of the day")
    // Message will be the timestamp of the email, coming from the app config 
} else {
    Slack.postToChannel.skip();
}
log("** end of filter code **")

// post app action 
if (!Slack.postToChannel.skipped) {
    var actionfields = actionDefaultValues["Slack"]["postToChannel"];
    for (const field in actionfields) {
        if (!Slack.postToChannel.hasOwnProperty(field)) {
            Slack.postToChannel[field] = Strictify(actionfields[field]);
        }
    }
}

//result
log("action: ", Slack.postToChannel)
log("##### end of example 01 #####")