import { log, setQuerydata, query, cache } from '../../queryLib.js'

let triggerdata = {
    "001ets": {
        "AttachmentTemporaryUrl": "dummy",
        //
        // to change the exeuction, pick one of the followings
        "From": "supervisor", //fetching From, Subject, Body, AttachmentUrl [4]
        // "From": "spammer", //fetching From [1]
        // "From": "news", //fetching From, ReceivedAt [2]
        //
        "Body": "here's the meeing info",
        "BodyHTML": "dummy",
        "Subject": "meeting",
        "AttachmentUrl": "the url",
        "ReceivedAt": "23:59",
    }
}

setQuerydata(triggerdata)
