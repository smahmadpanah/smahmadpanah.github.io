// 03 - app with trigger-dependent query
// if a new email received from a sender that there's a meeting with them today, it's important to be notified on slack

// app config; details below
// trigger: a new Email (Email.sendIftttAnEmail) 
// query: GoogleCalendar.historyOfEventFromSearchStarts("today", sender)
// action: Slack.postToChannel.setMessage("something went wrong!")



// app filtercode
if (GoogleCalendar.historyOfEventFromSearchStarts.length == 0) {
    Slack.postToChannel.skip();
} else {
    Slack.postToChannel.setTitle(Email.sendIftttAnEmail.Subject)
    Slack.postToChannel.setMessage(
        Email.sendIftttAnEmail.Body +
        Email.sendIftttAnEmail.From +
        GoogleCalendar.historyOfEventFromSearchStarts[0].Title);
}

/*
- control flow depends on sensitive query that depends on sensitive trigger
- 
    static minTAP: 5 attributes, can handle arrrays?!
    dynamic minTAP: n/a
    lazyTAP: 2 (1 Trigger, 1 Query) or 5
    no min: 7 + (7 * length) + 1
*/

/*
"applet": {
            "applet_triggers": [
                {
                "trigger": {
                        "name": "Send IFTTT any email",
                        "ingredients": [
                            {
                                "normalized_name": "Email.sendIftttAnEmail.AttachmentTemporaryUrl"
                            },
                            {
                                "normalized_name": "Email.sendIftttAnEmail.From"
                            },
                            {
                                "normalized_name": "Email.sendIftttAnEmail.Body"
                            },
                            {
                                "normalized_name": "Email.sendIftttAnEmail.BodyHTML"
                            },
                            {
                                "normalized_name": "Email.sendIftttAnEmail.Subject"
                            },
                            {
                                "normalized_name": "Email.sendIftttAnEmail.AttachmentUrl"
                            },
                            {
                                "normalized_name": "Email.sendIftttAnEmail.ReceivedAt"
                            }
                        ]
                    },
                    "fields": []
                }
            ],
            "applet_queries": [
                {
                    "query": {
                        "name": "History of event from search starts",
                        "ingredients": [
                            {
                                "normalized_name": "GoogleCalendar.historyOfEventFromSearchStarts.Title"
                            },
                            {
                                "normalized_name": "GoogleCalendar.historyOfEventFromSearchStarts.Description"
                            },
                            {
                                "normalized_name": "GoogleCalendar.historyOfEventFromSearchStarts.Where"
                            },
                            {
                                "normalized_name": "GoogleCalendar.historyOfEventFromSearchStarts.Starts"
                            },
                            {
                                "normalized_name": "GoogleCalendar.historyOfEventFromSearchStarts.Ends"
                            },
                            {
                                "normalized_name": "GoogleCalendar.historyOfEventFromSearchStarts.EventUrl"
                            },
                            {
                                "normalized_name": "GoogleCalendar.historyOfEventFromSearchStarts.VideoCallUrl"
                            }
                        ]
                    },
                    "fields": [
                        {
                            "label": "Calendar",
                            "default_value_json": "myself"
                        },
                        {
                            "label": "Query",
                            "default_value_json": "{{From}}"
                        },
                        {
                            "label": "Offset",
                            "default_value_json": "11:00"
                        }
                    ]
                }
            ],
            "applet_actions": [
                {
                    "action": {
                        "name": "Post to channel",
                        "full_normalized_module_name": "Slack.postToChannel",
                        "action_fields": [
                            {
                                "normalized_module_name": "Channel"
                            },
                            {
                                "normalized_module_name": "Message"
                            },
                            {
                                "normalized_module_name": "Title"
                            },
                            {
                                "normalized_module_name": "TitleUrl"
                            },
                            {
                                "normalized_module_name": "ImageUrl"
                            }
                        ]
                    },
                    "fields": [
                        {
                            "label": "Which channel?",
                            "default_value_json": "Myself"
                        },
                        {
                            "label": "Message",
                            "default_value_json": "something went wrong!"
                        },
                        {
                            "label": "Title",
                            "default_value_json": ""
                        },
                        {
                            "label": "Title URL",
                            "default_value_json": ""
                        },
                        {
                            "label": "Thumbnail URL",
                            "default_value_json": ""
                        }
                    ]
                }
            ],
*/