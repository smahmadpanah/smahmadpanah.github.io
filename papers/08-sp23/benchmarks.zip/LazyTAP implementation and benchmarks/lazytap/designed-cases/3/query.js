import { log, setQuerydata, query, cache } from '../../queryLib.js'

let triggerdata = { //just for the trigger data and cached data
    "003ecs": {
        "AttachmentTemporaryUrl": "dummy",
        //
        // to change the exeuction, pick one of the followings
        "From": "supervisor", //fetching From, Subject, Body, 0.Title, length [5]
        "From": "spammer", //fetching From, length [2]
        "From": "friend", //fetching From, Subject, Body, 0.Title, length [5]
        //
        "Body": "here's the meeing info",
        "BodyHTML": "dummy",
        "Subject": "meeting",
        "AttachmentUrl": "the url",
        "ReceivedAt": "23:59",
    }
}
setQuerydata(triggerdata)


// the GoogleCalendar query
query.post("/GoogleCalendar/historyOfEventFromSearchStarts", (req, res) => {
    log('GoogleCalendar', `received query with data ${JSON.stringify(req.body)}`);

    // perform dummy query

    let calendardata = {
        "myself": {
            "supervisor": {
                "08:00": [{
                        "Title": "eventSupervisor",
                        "Starts": '08:02',
                        "Description": "string",
                        "Where": "string",
                        "Ends": "string",
                        "EventUrl": "string",
                        "VideoCallUrl": "string",
                    },
                    {
                        "Title": "eventSupervisor2",
                        "Starts": '12:02',
                        "Description": "string",
                        "Where": "string",
                        "Ends": "string",
                        "EventUrl": "string",
                        "VideoCallUrl": "string",
                    },
                    {
                        "Title": "eventSupervisor3",
                        "Starts": '12:10',
                        "Description": "string",
                        "Where": "string",
                        "Ends": "string",
                        "EventUrl": "string",
                        "VideoCallUrl": "string",
                    }
                ]
            },
            "friend": {
                "08:00": [{
                    "Title": "eventFriend",
                    "Starts": '09:02',
                    "Description": "string",
                    "Where": "string",
                    "Ends": "string",
                    "EventUrl": "string",
                    "VideoCallUrl": "string",
                }],
            },
            "spammer": {
                "08:00": [],
            }
        }
    };
    let result = calendardata[req.body.Calendar][req.body.Query][req.body.Offset];

    // cache the query result

    let id = cache(result);

    res.json({
        id: id,
    });

    res.end();
});