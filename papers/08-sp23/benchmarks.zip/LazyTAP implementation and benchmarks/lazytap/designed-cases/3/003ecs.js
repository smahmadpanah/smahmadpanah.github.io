log("##### example 03 is running... #####")

//preamble 
//trigger
var triggerservice = new LazyService("http://localhost:4000/Email/sendIftttAnEmail");
triggerservice.id = id;
var Email = { sendIftttAnEmail: RemoteObject.Create(triggerservice) }

//query
var GoogleCalendar = {
    historyOfEventFromSearchStarts: QueryFunc.GoogleCalendarhistoryOfEventFromSearchStarts(
        // [BENCHMARK]: go to ./3/query and modify .From values
        () => "myself", () => Email.sendIftttAnEmail.From, () => "08:00")
}

//action
var actionDefaultValues = {
    "Slack": {
        "postToChannel": {
            "Channel": "Myself",
            "Message": "went wrong...",
            "Title": "",
            "TitleUrl": "",
            "ImageUrl": "",
        }
    }
}
var Slack = { postToChannel: { skipped: false } };
Slack.postToChannel.setMessage = function(msg = '') {
    if (!this.skipped) {
        this.Message = msg;
        log("SLACK setMessage: ", msg)
    }
}
Slack.postToChannel.setTitle = function(msg = '') {
    if (!this.skipped) {
        this.Title = msg;
        log("SLACK setTitle: ", msg)
    }
}
Slack.postToChannel.skip = function(msg = '') {
    this.skipped = true;
    log("SLACK postToChannel skipped ", msg)
}
// filter code
log("** filter code **")
if (GoogleCalendar.historyOfEventFromSearchStarts.length == 0) {
    Slack.postToChannel.skip();
} else {
    Slack.postToChannel.setTitle(Email.sendIftttAnEmail.Subject)
    Slack.postToChannel.setMessage(
        Email.sendIftttAnEmail.Body + '\n' +
        GoogleCalendar.historyOfEventFromSearchStarts[0].Title + '\n' +
        ' and you have ' + GoogleCalendar.historyOfEventFromSearchStarts.length +
        ' meetings with ' + Email.sendIftttAnEmail.From);
}
log("** end of filter code **")

// post app action 
if (!Slack.postToChannel.skipped) {
    var actionfields = actionDefaultValues["Slack"]["postToChannel"];
    for (const field in actionfields) {
        if (!Slack.postToChannel.hasOwnProperty(field)) {
            Slack.postToChannel[field] = Strictify(actionfields[field]);
        }
    }
}
//result
log("action: ", Slack.postToChannel)
log("##### end of example 03 #####")