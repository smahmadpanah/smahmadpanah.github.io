log("##### example 06 is running... #####")

//preamble 
//trigger
var triggerservice = new LazyService("http://localhost:4000/DateAndTime/everyDayAt");
triggerservice.id = id;
var DateAndTime = { everyDayAt: RemoteObject.Create(triggerservice) }

//query
var Youtube = {
    recentLikedVideos: QueryFunc.YoutuberecentLikedVideos()
}
//action
var actionDefaultValues = {
    "Telegram": {
        "sendMessage": {
            "Chat_id": "my_channel",
            "Text": "went wrong...",
            "IncludeWebPagePreview": "",
        }
    }
}
var Telegram = { sendMessage: { skipped: false } };
Telegram.sendMessage.setText = function(msg = '') {
    if (!this.skipped) {
        this.Text = msg;
        log("Telegram setText: ", msg)
    }
}

Telegram.sendMessage.skip = function(msg = '') {
    this.skipped = true;
    log("Telegram sendMessage skipped ", msg)
}
// filter code
log("** filter code **")
if (Youtube.recentLikedVideos.length != 0) {
    let randomIndex = Math.floor((Math.random() * Youtube.recentLikedVideos.length))
    Telegram.sendMessage.setText(Youtube.recentLikedVideos[randomIndex].Title + "|" +
        Youtube.recentLikedVideos[randomIndex].Url + "|" +
        Youtube.recentLikedVideos[randomIndex].Description)
} else {
    Telegram.sendMessage.skip();
}
log("** end of filter code **")

// post app action 
if (!Telegram.sendMessage.skipped) {
    var actionfields = actionDefaultValues["Telegram"]["sendMessage"];
    for (const field in actionfields) {
        if (!Telegram.sendMessage.hasOwnProperty(field)) {
            Telegram.sendMessage[field] = Strictify(actionfields[field]);
        }
    }
}
//result
log("action: ", Telegram.sendMessage)
log("##### end of example 06 #####")