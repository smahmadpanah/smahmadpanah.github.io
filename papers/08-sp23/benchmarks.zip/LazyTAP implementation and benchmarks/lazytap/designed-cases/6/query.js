import { log, setQuerydata, query, cache } from '../../queryLib.js'

let triggerdata = { //just for the trigger data and cached data
    "006tyt": {
        "CheckTime": "0"
    }
}
setQuerydata(triggerdata)


// the YouTube query
query.post("/Youtube/recentLikedVideos", (req, res) => {
    log('Youtube', `received query with data ${JSON.stringify(req.body)}`);

    // perform dummy query

    let youtubedata = 
        [{
                "Title": "0",
                "Description": "string",
                "Url": "yt.com/0",
                "EmbedCode": "string",
                "LikedAt": "string",
            },
            {
                "Title": "1",
                "Description": "string",
                "Url": "yt.com/1",
                "EmbedCode": "string",
                "LikedAt": "string",
            },
            {
                "Title": "2",
                "Description": "string",
                "Url": "yt.com/2",
                "EmbedCode": "string",
                "LikedAt": "string",
            },
            {
                "Title": "3",
                "Description": "string",
                "Url": "yt.com/3",
                "EmbedCode": "string",
                "LikedAt": "string",
            },
            {
                "Title": "4",
                "Description": "string",
                "Url": "yt.com/4",
                "EmbedCode": "string",
                "LikedAt": "string",
            }
        ]
    ;
    // [BENCHMARK]: uncomment the following line
    // youtubedata = [];

    let result = youtubedata


    // cache the query result

    let id = cache(result);

    res.json({
        id: id,
    });

    res.end();
});
