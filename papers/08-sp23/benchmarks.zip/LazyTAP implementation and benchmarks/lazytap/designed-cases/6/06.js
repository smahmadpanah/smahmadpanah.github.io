// 06 - app with nondeterministic query (similar to MRm9VBxG)
// every day at 9pm, send one of my liked youtube videos to my telegram channel

// app config; details below
// trigger: DateAndTime.everyDayAt
// query: Youtube.recentLikedVideos
// action: Telegram.sendMessage.setChat_id("my_channel"); Telegram.sendMessage.setText("error!")



// app filtercode
if (Youtube.recentLikedVideos.length != 0) {
    let randomIndex = Math.floor((Math.random() * Youtube.recentLikedVideos.length))
    Telegram.sendMessage.setText(Youtube.recentLikedVideos[randomIndex].Url)
} else {
    Telegram.sendMessage.skip();
}

/*
- nondeterministic query
- 
    static minTAP: (YoutubeLength + 1) attributes?! can handle arrays?! all ".Url"s assumed to be available 
    dynamic minTAP: n/a
    lazyTAP: 2 or 1
    no min: 1 + (5 * YoutubeLength) + 1 
*/

/*
"applet": {
            "applet_triggers": [DateAndTime.everyDayAt],
            "applet_queries": [
                {
                    "query": {
                        "name": "History of liked videos",
                        "ingredients": [
                            {
                                "normalized_name": "Youtube.recentLikedVideos.Title"
                            },
                            {
                                "normalized_name": "Youtube.recentLikedVideos.Description"
                            },
                            {
                                "normalized_name": "Youtube.recentLikedVideos.Url"
                            },
                            {
                                "normalized_name": "Youtube.recentLikedVideos.EmbedCode"
                            },
                            {
                                "normalized_name": "Youtube.recentLikedVideos.LikedAt"
                            }
                        ]
                    },
                    "fields": []
                }
            ],
            "applet_actions": [
                {
                    "action": {
                        "name": "Send message",
                        "full_normalized_module_name": "Telegram.sendMessage",
                        "action_fields": [
                            {
                                "normalized_module_name": "Chat_id"
                            },
                            {
                                "normalized_module_name": "Text"
                            },
                            {
                                "normalized_module_name": "IncludeWebPagePreview"
                            }
                        ]
                    },
                    "fields": [
                        {
                            "label": "Target chat",
                            "default_value_json": "my_channel"
                        },
                        {
                            "label": "Message",
                            "default_value_json": "error!"
                        },
                        {
                            "label": "IncludeWebPagePreview",
                            "default_value_json": ""
                        }
                    ]
                }
            ],
*/