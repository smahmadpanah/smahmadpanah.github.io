//app configuration 

//trigger
var TriggerService = { 
    triggerName: RemoteObject.Create(new LazyService(triggerUrl)) 
}

//query
var QueryService = {
    queryName: RemoteArray.Create(new LazyService(queryUrl, () => queryInput))
}

//action
var ActionService = { actionName: { skipped: false } };

var actionDefaultValues = {
    ActionService: {
        actionName: {
            field_i: () => defaultValue_i
        }
    }
}

ActionService.actionName.setField_i = function(value) {
    if (!this.skipped) this.field_i = value;
}

ActionService.actionName.skip = function() {
    this.skipped = true;
}
//end of app configuration  


filterCode;


// post app action 
if (!ActionService.actionName.skipped) {
    var actionfields = actionDefaultValues['ActionService']['actionName'];
    for (const field in actionfields) {
        if (!ActionService.actionName.hasOwnProperty(field)) {
            ActionService.actionName[field] = actionfields[field](); //strictify the thunk value
        }
    }
}

return ActionService;
// end of app