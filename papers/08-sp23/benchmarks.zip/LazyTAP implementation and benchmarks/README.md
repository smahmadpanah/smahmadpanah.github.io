# LazyTAP: On-Demand Data Minimization for Trigger-Action Applications 

In praise of laziness! :) 

## Evaluation 
-  The benchmark evaluation table: [google sheet](https://docs.google.com/spreadsheets/d/1aNXyPmBDZEWjKHD8cGTQfCiTkVT57zUaRvzooJqF7PI/edit?usp=sharing).

- Go to `./lazytap` to run benchmarks under LazyTAP, and `./ifttt` to execute them under our local setup of IFTTT.
- Pass the directory pointing to the benchmark, for example `./script.sh ./designed-cases/2` or `./script.sh ./from-ifttt-dataset/3`.

    - By adding `n` to the end of the command, you get only the number of attributes reported at the end of the execution (`./script.sh ./desgined-cases/2 n`).

    - Use `./script.sh all` to run all the cases (similarly, `./script.sh all n` to see the attribute numbers).

- Search for "[BENCHMARK]" in the js/json files of each case to find out possible executions.
