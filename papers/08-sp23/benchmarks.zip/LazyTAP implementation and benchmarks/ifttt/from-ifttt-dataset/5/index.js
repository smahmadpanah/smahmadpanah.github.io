import fetch from "sync-fetch";



let triggerdata = { //just for the trigger data and cached data
                "CheckTime": "00:00",
                "DayOfWeek": "2"
    
}

// email trigger 
let result1 = postJSON("http://localhost:9000/trigger/DateAndTime/everyWeekdayAt", {
    id: "MRm9VBxG",
    triggerdata: triggerdata
});
//console.log(result1);



function postJSON(url, data) {
    let result = fetch(url, {
        method: "POST",
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    });
    // console.log(result)

    return result.json();
}

//