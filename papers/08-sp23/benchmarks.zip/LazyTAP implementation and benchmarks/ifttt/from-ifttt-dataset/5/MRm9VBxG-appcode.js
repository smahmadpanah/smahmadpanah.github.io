log("##### example MRm9VBxG is running... #####")

//preamble 
//trigger
var DateAndTime = { everyWeekdayAt: triggerdata }
//query
var Trakt = {
    recommendedMovies: QueryFunc.TraktrecommendedMovies()
}
var Yelp = {
    searchBusiness: QueryFunc.YelpsearchBusiness(
        // [BENCHMARK]: go to ./query or change gothenburg to tehran
        "gothenburg",
        "restaurant")
}

//action
var actionDefaultValues = {
    "Email": {
        "sendMeEmail": {
            "Subject": `It's ${DateAndTime.everyWeekdayAt.DayOfWeek} night date night!`,
            "Body": "",
        }
    }
}

var Email = { sendMeEmail: { skipped: false } };
Object.assign(Email.sendMeEmail, actionDefaultValues['Email']['sendMeEmail'])

Email.sendMeEmail.setSubject = function(msg = '') {
    if (!this.skipped) {
        this.Subject = msg;
        log("Email setSubject: ", msg)
    }
}

Email.sendMeEmail.setBody = function(msg = '') {
    if (!this.skipped) {
        this.Body = msg;
        log("Email setBody: ", msg)
    }
}
// filter code
log("** filter code **")
var optionOne = Math.floor((Math.random() * Trakt.recommendedMovies.length))
var optionTwo = Math.floor((Math.random() * Yelp.searchBusiness.length))
Email.sendMeEmail.setSubject(`It's night date night!`)
Email.sendMeEmail.setBody(`Tonight you should watch ${Trakt.recommendedMovies[optionOne].MovieTitle}, 
                and order dinner from ${Yelp.searchBusiness[optionTwo].BusinessName}! `)
log("** end of filter code **")

// post app action 

//result
log("Email: ", Email.sendMeEmail)
log("##### end of example MRm9VBxG #####")