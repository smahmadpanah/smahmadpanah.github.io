import { log, query } from '../../queryLib.js'



// the GoogleCalendar query
query.post("/Trakt/recommendedMovies", (req, res) => {
    log('Trakt', `received query with data ${JSON.stringify(req.body)}`);

    // perform dummy query

    let calendardata = [{
            "MovieId": "number",
            "MovieTitle": "Mov1",
            "MovieYear": "string",
            "MovieDescription": "string",
            "MovieTrailer": "string",
            "MovieGenre": "string",
            "MovieCertification": "string"
        },
        {
            "MovieId": "number",
            "MovieTitle": "Mov2",
            "MovieYear": "string",
            "MovieDescription": "string",
            "MovieTrailer": "string",
            "MovieGenre": "string",
            "MovieCertification": "string",
        },
        {
            "MovieId": "number",
            "MovieTitle": "Mov3",
            "MovieYear": "string",
            "MovieDescription": "string",
            "MovieTrailer": "string",
            "MovieGenre": "string",
            "MovieCertification": "string",
        },
        {
            "MovieId": "number",
            "MovieTitle": "Mov4",
            "MovieYear": "string",
            "MovieDescription": "string",
            "MovieTrailer": "string",
            "MovieGenre": "string",
            "MovieCertification": "string",
        },
        {
            "MovieId": "number",
            "MovieTitle": "Mov5",
            "MovieYear": "string",
            "MovieDescription": "string",
            "MovieTrailer": "string",
            "MovieGenre": "string",
            "MovieCertification": "string",
        },
        {
            "MovieId": "number",
            "MovieTitle": "Mov6",
            "MovieYear": "string",
            "MovieDescription": "string",
            "MovieTrailer": "string",
            "MovieGenre": "string",
            "MovieCertification": "string",
        }
    ];
    let result = calendardata//[req.body.Calendar][req.body.Query][req.body.Offset];

    res.json(result);

    res.end();
});



// the Yelp query
query.post("/Yelp/searchBusiness", (req, res) => {
    log('Yelp', `received query with data ${JSON.stringify(req.body)}`);

    // perform dummy query

    let yelpdata = {
        "gothenburg": {
            "restaurant": [{
                    "BusinessId": "11",
                    "BusinessName": "restaurant1",
                    "BusinessCategory": "string",
                    "BusinessImageUrl": "string",
                    "BusinessPhone": "string",
                    "BusinessAddress": "Johanneberg",
                    "BusinessRating": "string",
                },
                {
                    "BusinessId": "22",
                    "BusinessName": "restaurant2",
                    "BusinessCategory": "string",
                    "BusinessImageUrl": "string",
                    "BusinessPhone": "string",
                    "BusinessAddress": "Avenyn",
                    "BusinessRating": "string",
                },
            ]
        },
        "tehran": {
            "restaurant": [{
                "BusinessId": "44",
                "BusinessName": "restaurant4",
                "BusinessCategory": "string",
                "BusinessImageUrl": "string",
                "BusinessPhone": "string",
                "BusinessAddress": "Azadi",
                "BusinessRating": "string",
            }]
        },
        "nowhere": {
            "restaurant": [],

        }
    };
    let result = yelpdata[req.body.Location][req.body.Term];

    res.json(result);

    res.end();
});
