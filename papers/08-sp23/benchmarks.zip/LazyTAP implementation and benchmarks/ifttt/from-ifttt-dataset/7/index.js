import fetch from "sync-fetch";

let triggerdata = { //just for the trigger data and cached data
        "Title": "string",
        // "Description": "BUSY is too much NEW year salam ", //[BENCHMARK]: change this
        "Description": "test test",
        "Where": "string",
        "Starts": "string",
        "Ends": "string",
        "EventUrl": "string",
        "VideoCallUrl": "string",
        "CreatedAt": "string",
}

// email trigger 
let result1 = postJSON("http://localhost:9000/trigger/GoogleCalendar/newEventAdded", {
    id: "xvyUBQsh",
    triggerdata: triggerdata
});
//console.log(result1);



function postJSON(url, data) {
    let result = fetch(url, {
        method: "POST",
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    });
    // console.log(result)

    return result.json();
}

//