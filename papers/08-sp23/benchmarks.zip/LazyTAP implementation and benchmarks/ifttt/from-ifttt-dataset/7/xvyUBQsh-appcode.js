log("##### example xvyUBQsh is running... #####")

//preamble 
//trigger
var GoogleCalendar = { newEventAdded: triggerdata }
// [BENCHMARK]: go to query and modify trigger values
//query
var Giphy = {
    historyOfRandomGifBasedOnKeyword: QueryFunc.GiphyhistoryOfRandomGifBasedOnKeyword(
        // [BENCHMARK]: pick 'pic1' or 'pic2'
         "pic1")
}
//action
var actionDefaultValues = {
    "Slack": {
        "postToChannel": {
            "Channel": "Myself",
            "Title": "New event added without an agenda",
            "Message":  `A meeting was added that does not appear to contain an agenda: ${GoogleCalendar.newEventAdded.Title}`,
            "TitleUrl":  `${GoogleCalendar.newEventAdded.EventUrl}`,
            "ImageUrl":  `${Giphy.historyOfRandomGifBasedOnKeyword[0].ImageURL}`,
        }
    }
}
var Slack = { postToChannel: { skipped: false } };
Object.assign(Slack.postToChannel, actionDefaultValues['Slack']['postToChannel'])

Slack.postToChannel.setMessage = function(msg = '') {
    if (!this.skipped) {
        this.Message = msg;
        log("SLACK setMessage: ", msg)
    }
}
Slack.postToChannel.setTitle = function(msg = '') {
    if (!this.skipped) {
        this.Title = msg;
        log("SLACK setTitle: ", msg)
    }
}
Slack.postToChannel.skip = function(msg = '') {
    this.skipped = true;
    log("SLACK postToChannel skipped ", msg)
}
// filter code
log("** filter code **")
var minLength = 16; // min description length
var titleExcludeList = ["HOLD", "BUSY", "WORK", "BLOCK", "DO NOT",
    "TEMPORARY", "HOLIDAY", "WFH", "OOO", "SICK", "SICK", "NEW YEAR",
    "MARTIN LUTHER", "MEMORIAL", "INDEPENDENCE", "LABOR DAY", "VETERANS",
    "THANKSGIVING", "CHRISTMAS"
]; // titles containing any of these words are excluded (use uppercase strings only)

var noAgenda = false;
if (!GoogleCalendar.newEventAdded.Description.trim ||
    (GoogleCalendar.newEventAdded.Description.replace(/[^a-zA-Z]/g, '').length < minLength)) {
    noAgenda = true;
}

var titleTestStr = GoogleCalendar.newEventAdded.Title.toUpperCase();
titleExcludeList.forEach(function(word) {
    if (titleTestStr.indexOf(word) !== -1) {
        noAgenda = false;
    }
})

if (!noAgenda) {
    Slack.postToChannel.skip();
}
log("** end of filter code **")

// post app action 

//result
log("Slack: ", Slack.postToChannel)
log("##### end of example xvyUBQsh #####")