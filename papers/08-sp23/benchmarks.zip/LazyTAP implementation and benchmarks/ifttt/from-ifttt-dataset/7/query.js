import { log, query } from '../../queryLib.js'


// the GoogleCalendar query
query.post("/Giphy/historyOfRandomGifBasedOnKeyword", (req, res) => {
    log('Giphy', `received query with data ${JSON.stringify(req.body)}`);

    // perform dummy query

    let calendardata = {
        "pic1": [{
                "URL": "string",
                "ImageURL": "url/image",
                "TumblrImageURL": "string",
                "EmailHTML": "string",
                "EmbedCode": "string",
                "CreatedDate": "string",
            },
            {
                "URL": "string",
                "ImageURL": "string",
                "TumblrImageURL": "string",
                "EmailHTML": "string",
                "EmbedCode": "string",
                "CreatedDate": "string",
            },
            {
                "URL": "string",
                "ImageURL": "string",
                "TumblrImageURL": "string",
                "EmailHTML": "string",
                "EmbedCode": "string",
                "CreatedDate": "string",
            }
        ],
        "pic2": [{
            "URL": "string",
            "ImageURL": "url2",
            "TumblrImageURL": "string",
            "EmailHTML": "string",
            "EmbedCode": "string",
            "CreatedDate": "string",
        }]
    };
    let result = calendardata[req.body.Term]//[req.body.Query][req.body.Offset];

    res.json(result);

    res.end();
});
