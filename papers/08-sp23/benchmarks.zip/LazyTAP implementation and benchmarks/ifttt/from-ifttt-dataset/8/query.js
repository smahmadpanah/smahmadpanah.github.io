import { log, query } from '../../queryLib.js'


// the GoogleCalendar query
query.post("/Weather/twoDayForecast", (req, res) => {
    log('Weather', `received query with data ${JSON.stringify(req.body)}`);

    // perform dummy query

    let weatherdata = {
        "gothenburg": [{
            "SunriseAt": "string",
            "SunsetAt": "string",
            "ForecastUrl": "string",
            "Condition": "string",
            "TodaysConditionImageUrl": "string",
            "HighTempFahrenheit": "string",
            "HighTempCelsius": "string",
            "LowTempFahrenheit": "string",
            "LowTempCelsius": "string",
            "UvIndex": "string",
            "Humidity": "string",
            "WindSpeedMph": "string",
            "WindSpeedKph": "string",
            "WindDirection": "string",
            "Date": "string",
            "CheckTime": "string",
        },
         {
            "SunriseAt": "string",
            "SunsetAt": "string",
            "ForecastUrl": "gbg.se/forecast",
            "Condition": "Rainy",
            "TodaysConditionImageUrl": "gbg.se/image",
            "HighTempFahrenheit": "string",
            "HighTempCelsius": "string",
            "LowTempFahrenheit": "string",
            "LowTempCelsius": "string",
            "UvIndex": "string",
            "Humidity": "string",
            "WindSpeedMph": "string",
            "WindSpeedKph": "string",
            "WindDirection": "string",
            "Date": "string",
            "CheckTime": "string",
        },
        {
            "SunriseAt": "string",
            "SunsetAt": "string",
            "ForecastUrl": "string",
            "Condition": "string",
            "TodaysConditionImageUrl": "string",
            "HighTempFahrenheit": "string",
            "HighTempCelsius": "string",
            "LowTempFahrenheit": "string",
            "LowTempCelsius": "string",
            "UvIndex": "string",
            "Humidity": "string",
            "WindSpeedMph": "string",
            "WindSpeedKph": "string",
            "WindDirection": "string",
            "Date": "string",
            "CheckTime": "string",
        }
        ],
        "tehran": [{
            "SunriseAt": "string",
            "SunsetAt": "string",
            "ForecastUrl": "string",
            "Condition": "string",
            "TodaysConditionImageUrl": "string",
            "HighTempFahrenheit": "string",
            "HighTempCelsius": "string",
            "LowTempFahrenheit": "string",
            "LowTempCelsius": "string",
            "UvIndex": "string",
            "Humidity": "string",
            "WindSpeedMph": "string",
            "WindSpeedKph": "string",
            "WindDirection": "string",
            "Date": "string",
            "CheckTime": "string",
        },
        {
            "SunriseAt": "string",
            "SunsetAt": "string",
            "ForecastUrl": "tehran.ir/forecast",
            "Condition": "Sunny",
            "TodaysConditionImageUrl": "tehran.ir/image",
            "HighTempFahrenheit": "string",
            "HighTempCelsius": "string",
            "LowTempFahrenheit": "string",
            "LowTempCelsius": "string",
            "UvIndex": "string",
            "Humidity": "string",
            "WindSpeedMph": "string",
            "WindSpeedKph": "string",
            "WindDirection": "string",
            "Date": "string",
            "CheckTime": "string",
        }]

    };
    let result = weatherdata[req.body.Location]//[req.body.Query][req.body.Offset];

    res.json(result);

    res.end();
});
