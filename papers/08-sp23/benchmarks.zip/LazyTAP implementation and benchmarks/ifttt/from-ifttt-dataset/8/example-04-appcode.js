log("##### example example-04 is running... #####")

//preamble 
//trigger
var DateAndTime = { everyDayAt: triggerdata }

//query
// [BENCHMARK]: pick a location between "gothenburg" and "tehran"
var Weather = {
    twoDayForecast: QueryFunc.WeathertwoDayForecast(
         "gothenburg") //Location
}

//action
var actionDefaultValues = {
    "GoogleCalendar": {
        "quickAddEvent": {
            "QuickAdd": ""
        }
    },
    "IfNotifications": {
        "sendRichNotification": {
            "Title": "",
            "Message": "",
            "LinkUrl": "",
            "ImageUrl": ""
        }
    }
}

var GoogleCalendar = { quickAddEvent: { skipped: false } };
Object.assign(GoogleCalendar.quickAddEvent, actionDefaultValues['GoogleCalendar']['quickAddEvent'])

GoogleCalendar.quickAddEvent.setQuickAdd = function(msg = '') {
    if (!this.skipped) {
        this.QuickAdd = msg;
        log("GoogleCalendar setQuickAdd: ", msg)
    }
}

var IfNotifications = { sendRichNotification: { skipped: false } };
Object.assign(IfNotifications.sendRichNotification, actionDefaultValues['IfNotifications']['sendRichNotification'])


IfNotifications.sendRichNotification.setTitle = function(msg = '') {
    if (!this.skipped) {
        this.Title = msg;
        log("IfNotifications setTitle: ", msg)
    }
}

IfNotifications.sendRichNotification.setMessage = function(msg = '') {
    if (!this.skipped) {
        this.Message = msg;
        log("IfNotifications setMessage: ", msg)
    }
}

IfNotifications.sendRichNotification.setLinkUrl = function(msg = '') {
    if (!this.skipped) {
        this.LinkUrl = msg;
        log("IfNotifications setLinkUrl: ", msg)
    }
}

IfNotifications.sendRichNotification.setImageUrl = function(msg = '') {
    if (!this.skipped) {
        this.ImageUrl = msg;
        log("IfNotifications setImageUrl: ", msg)
    }
}
// filter code
log("** filter code **")
if (Weather.twoDayForecast[1].Condition == "Sunny") {
    var length_of_run_in_minutes = "90"
    var length_of_run_in_words = "long"
} else {
    var length_of_run_in_minutes = "60"
    var length_of_run_in_words = "short"
}

GoogleCalendar.quickAddEvent.setQuickAdd(`8am tomorrow Go for a run ${length_of_run_in_minutes} minutes`)

IfNotifications.sendRichNotification.setTitle(
    `You're going for a ${length_of_run_in_words} run tomorrow`
)

IfNotifications.sendRichNotification.setMessage(
    `It's going to be ${Weather.twoDayForecast[1].Condition.toLowerCase()} 
                with a high of ${Weather.twoDayForecast[1].HighTempFahrenheit}° F`
)

IfNotifications.sendRichNotification.setLinkUrl(
    Weather.twoDayForecast[1].ForecastUrl
)

IfNotifications.sendRichNotification.setImageUrl(
    Weather.twoDayForecast[1].TodaysConditionImageUrl
)
log("** end of filter code **")

// post app action 

//result
log("GoogleCalendar: ", GoogleCalendar.quickAddEvent)
log("IfNotifications: ", IfNotifications.sendRichNotification)

log("##### end of example example-04 #####")