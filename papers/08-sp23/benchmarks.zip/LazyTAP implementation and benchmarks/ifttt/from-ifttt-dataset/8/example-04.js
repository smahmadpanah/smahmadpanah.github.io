//Applet: IF tomorrow's forecast is clear → THEN schedule a long run

Trigger service: Date and Time
Trigger: Every day at
{DateAndTime.everyDayAt.CheckTime}

Query service: Weather Underground
Query: Two day forecast

Action service: Google Calendar
Action: Quick add event

Action service: Notifications
Action: Send a rich notification from the IFTTT app

/*
Weather.twoDayForecast.1.Condition
Weather.twoDayForecast.1.HighTempFahrenheit
Weather.twoDayForecast.1.ForecastUrl
Weather.twoDayForecast.1.TodaysConditionImageUrl
*/

if (Weather.twoDayForecast[1].Condition == "Sunny") {
  var length_of_run_in_minutes = "90"
  var length_of_run_in_words = "long"
} else {
  var length_of_run_in_minutes = "60"
  var length_of_run_in_words = "short"
}

GoogleCalendar.quickAddEvent.setQuickAdd(`8am tomorrow Go for a run ${length_of_run_in_minutes} minutes`)

IfNotifications.sendRichNotification.setTitle(
  `You're going for a ${length_of_run_in_words} run tomorrow`
)

IfNotifications.sendRichNotification.setMessage(
  `It's going to be ${Weather.twoDayForecast[1].Condition.toLowerCase()} with a high of ${Weather.twoDayForecast[1].HighTempFahrenheit}° F`
)

IfNotifications.sendRichNotification.setLinkUrl(
  Weather.twoDayForecast[1].ForecastUrl
)

IfNotifications.sendRichNotification.setImageUrl(
  Weather.twoDayForecast[1].TodaysConditionImageUrl
)