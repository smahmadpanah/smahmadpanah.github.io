import { log, query } from '../../queryLib.js'


// the GoogleCalendar query
query.post("/Finance/historyOfClosingPrices", (req, res) => {
    log('Finance', `received query with data ${JSON.stringify(req.body)}`);

    // perform dummy query
    let calendardata = {
        "OIL": [{
                "StockName": "eventSupervisor",
                "StockTicker": 'dummy',
                "Price": '3',
                "InfoUrl": "string",
                "Date": "string",
            },
            {
                "StockName": "eventSupervisor",
                "StockTicker": 'dummy',
                "Price": "20",
                "InfoUrl": "string",
                "Date": "string",
            },
            {
                "StockName": "eventSupervisor",
                "StockTicker": 'dummy',
                "Price": "string",
                "InfoUrl": "string",
                "Date": "string",
            }
        ],
        "NXT": [{
            "StockName": "eventSupervisor",
                "StockTicker": 'dummy',
                "Price": "90",
                "InfoUrl": "string",
                "Date": "string",
        }]


    };
    let result = calendardata[req.body.TickerSymbol]//[req.body.Query][req.body.Offset];

    res.json(result);

    res.end();
});
