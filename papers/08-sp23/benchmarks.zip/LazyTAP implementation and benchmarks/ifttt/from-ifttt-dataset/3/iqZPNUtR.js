var treeQuantity = 0;

//strip all other chars from the fuel economy to just get the number of miles per gallon
var fuelEcon = parseFloat(Bouncie.fuelEcon.FuelEcon.replace(/[^\d.-]/g, ''));

//strip all other chars from the last closing price of crude oil to just get the price per barrell in dollars
var oilPrice = parseFloat(Finance.historyOfClosingPrices[0].Price.replace(/[^\d.-]/g, ''));

//add additional trees the worse the fuel economy for the trip was
if (fuelEcon <= 10){
  treeQuantity += 4;
}
else if(fuelEcon <= 20){
  treeQuantity += 3;
}
else if(fuelEcon <= 30){
  treeQuantity += 2;
}
else {
  treeQuantity += 1;
}

//add additional trees if the price of crude oil is low, since that means there are more drivers and less incentives to drive economically and eco-friendly
if (oilPrice <= 10){
  treeQuantity += 6;
}
else if(oilPrice <= 20){
  treeQuantity += 5;
}
else if(oilPrice <= 30){
  treeQuantity += 4;
}
else if(oilPrice <= 40){
  treeQuantity += 3;
}
else if(oilPrice <= 50){
  treeQuantity += 2;
}
else if(oilPrice <= 60){
  treeQuantity += 1;
}

//Set the number of trees we will plant 
Moretrees.plantTreeForSelf.setQuantity(treeQuantity.toString());

//create the message we will send in the notification
var message = "The recent trip in your " + Bouncie.fuelEcon.VehicleName + 
" had a fuel economy of " + Bouncie.fuelEcon.FuelEcon + 
" MPG, which is less than ideal for your vehicle. Don't worry! We planted " + treeQuantity.toString() + 
" new trees to offset all the additional C02 this trip added to our atmosphere.";

//Set the message body
IfNotifications.sendNotification.setMessage(message);














{
  "data": {
    "applet": {
      "applet_triggers": [
        {
          "module_name": "fuel_econ",
          "trigger": {
            "name": "Vehicle had unusual fuel economy",
            "ingredients": [
              {
                "normalized_name": "Bouncie.fuelEcon.CreatedAt"
              },
              {
                "normalized_name": "Bouncie.fuelEcon.VehicleName"
              },
              {
                "normalized_name": "Bouncie.fuelEcon.FuelEcon"
              }
            ]
          },
          "fields": [
            {
              "label": "Which vehicle?",
              "default_value_json": "null"
            }
          ]
        }
      ],
      "applet_queries": [
        {
          "query": {
            "name": "History of closing prices",
            "ingredients": [
              {
                "normalized_name": "Finance.historyOfClosingPrices.StockName"
              },
              {
                "normalized_name": "Finance.historyOfClosingPrices.StockTicker"
              },
              {
                "normalized_name": "Finance.historyOfClosingPrices.Price"
              },
              {
                "normalized_name": "Finance.historyOfClosingPrices.InfoUrl"
              },
              {
                "normalized_name": "Finance.historyOfClosingPrices.Date"
              }
            ]
          },
          "fields": [
            {
              "label": "Ticker symbol",
              "default_value_json": "\"OIL\""
            }
          ]
        }
      ],
      "applet_actions": [
        {
          "action": {
            "name": "Plant tree for self",
            "full_normalized_module_name": "Moretrees.plantTreeForSelf",
            "action_fields": [
              {
                "normalized_module_name": "Quantity"
              }
            ]
          },
          "fields": [
            {
              "label": "Number of trees",
              "default_value_json": "\"1\""
            }
          ]
        },
        {
          "action": {
            "name": "Send a notification from the IFTTT app",
            "full_normalized_module_name": "IfNotifications.sendNotification",
            "action_fields": [
              {
                "normalized_module_name": "Message"
              }
            ]
          },
          "fields": [
            {
              "label": "Message",
              "default_value_json": "\"{{VehicleName}} fuel economy is {{FuelEcon}} MPG\""
            }
          ]
        }
      ],
