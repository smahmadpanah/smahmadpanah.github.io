import { log, query } from '../../queryLib.js'


// the GoogleCalendar query
query.post("/Trakt/recommendedMovies", (req, res) => {
    log('Trakt', `received query with data ${JSON.stringify(req.body)}`);

    // perform dummy query

    let calendardata = [{
            "MovieId": "number",
            "MovieTitle": "Mov1",
            "MovieYear": "string",
            "MovieDescription": "string",
            "MovieTrailer": "string",
            "MovieGenre": "string",
            "MovieCertification": "string"
        },
        {
            "MovieId": "number",
            "MovieTitle": "Mov2",
            "MovieYear": "string",
            "MovieDescription": "string",
            "MovieTrailer": "string",
            "MovieGenre": "string",
            "MovieCertification": "string",
        },
        {
            "MovieId": "number",
            "MovieTitle": "Mov3",
            "MovieYear": "string",
            "MovieDescription": "string",
            "MovieTrailer": "string",
            "MovieGenre": "string",
            "MovieCertification": "string",
        },
        {
            "MovieId": "number",
            "MovieTitle": "Mov4",
            "MovieYear": "string",
            "MovieDescription": "string",
            "MovieTrailer": "string",
            "MovieGenre": "string",
            "MovieCertification": "string",
        },
        {
            "MovieId": "number",
            "MovieTitle": "Mov5",
            "MovieYear": "string",
            "MovieDescription": "string",
            "MovieTrailer": "string",
            "MovieGenre": "string",
            "MovieCertification": "string",
        },
        {
            "MovieId": "number",
            "MovieTitle": "Mov6",
            "MovieYear": "string",
            "MovieDescription": "string",
            "MovieTrailer": "string",
            "MovieGenre": "string",
            "MovieCertification": "string",
        }
    ];
    let result = calendardata //[req.body.Calendar][req.body.Query][req.body.Offset];

    res.json(result);

    res.end();
});

