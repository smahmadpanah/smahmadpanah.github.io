log("##### example YG5HSLvK is running... #####")

//preamble 
//trigger
var DateAndTime = { everyWeekdayAt: triggerdata }

//query
var GoogleTasks = {
    listAllTasks: QueryFunc.GoogleTaskslistAllTasks(
        // [BENCHMARK]: pick 'true' or 'false'
         "true")
}
//action
var actionDefaultValues = {
    "Slack": {
        "postToChannel": {
            "Channel": "Myself",
            "Title": "New event added without an agenda",
            "Message":  `${GoogleTasks.listAllTasks[0].Title} ${GoogleTasks.listAllTasks[0].Due}`,
            "TitleUrl": ``,
            "ImageUrl": ``,
        }
    }
}
var Slack = { postToChannel: { skipped: false } };
Object.assign(Slack.postToChannel, actionDefaultValues['Slack']['postToChannel'])

Slack.postToChannel.setMessage = function(msg = '') {
    if (!this.skipped) {
        this.Message = msg;
        log("SLACK setMessage: ", msg)
    }
}
Slack.postToChannel.setTitle = function(msg = '') {
    if (!this.skipped) {
        this.Title = msg;
        log("SLACK setTitle: ", msg)
    }
}
Slack.postToChannel.skip = function(msg = '') {
    this.skipped = true;
    log("SLACK postToChannel skipped ", msg)
}
// filter code
log("** filter code **")
Slack.postToChannel.setTitle(":inbox_tray: Tasks for today")

var message = "";
let today = Meta.currentUserTime;

GoogleTasks.listAllTasks.forEach(task => {
    let task_due = moment(task.Due);
    if (today.isSame(task_due, 'day')) {
        message = message + `:black_square_button: *${task.Title}*_Notes:_ ${task.Notes}`;
    }
})

if (GoogleTasks.listAllTasks.length === 0) {
    Slack.postToChannel.skip();
}

if (message.length === 0) {
    message = "No tasks are due today :party:"
}

Slack.postToChannel.setMessage(message);
log("** end of filter code **")


// post app action 

//result
log("Slack: ", Slack.postToChannel)
log("##### end of example YG5HSLvK #####")