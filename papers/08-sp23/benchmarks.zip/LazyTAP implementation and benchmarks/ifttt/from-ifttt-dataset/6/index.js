import fetch from "sync-fetch";



let triggerdata = { //just for the trigger data and cached data
        "CheckTime": "07:30",
        "DayOfWeek": "['1','2','3','4','5']",
}

// email trigger 
let result1 = postJSON("http://localhost:9000/trigger/DateAndTime/everyWeekdayAt", {
    id: "YG5HSLvK",
    triggerdata: triggerdata
});
//console.log(result1);



function postJSON(url, data) {
    let result = fetch(url, {
        method: "POST",
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    });
    // console.log(result)

    return result.json();
}

//