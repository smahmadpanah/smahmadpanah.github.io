import fetch from "sync-fetch";

let triggerdata = { //just for the trigger data and cached data
        "AppearsAt": "11:11",
        "DisappearsAt": "string",
        "DurationSeconds": "50",
        "LocationMapImageUrl": "string",
        "LocationMapUrl": "string",
}

// email trigger 
let result1 = postJSON("http://localhost:9000/trigger/Space/spaceStationOverheadSoonNasa", {
    id: "VDdNBmiE",
    triggerdata: triggerdata
});
//console.log(result1);


function postJSON(url, data) {
    let result = fetch(url, {
        method: "POST",
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    });
    // console.log(result)

    return result.json();
}

//