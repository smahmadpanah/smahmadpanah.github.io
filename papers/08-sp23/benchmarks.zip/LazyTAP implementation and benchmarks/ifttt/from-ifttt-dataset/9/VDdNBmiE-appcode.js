log("##### example VDdNBmiE is running... #####")

//preamble 
//trigger
var Space = { spaceStationOverheadSoonNasa: triggerdata }

//query
var Weather = {
    currentWeather: QueryFunc.WeathercurrentWeather(
        // [BENCHMARK]: pick 'gbg' or 'teh'
        // gbg -> no skip, teh -> skip
         "gbg")
}

//action
var actionDefaultValues = {
    "IfNotifications": {
        "sendNotification": {
            "Message":  `The ISS is passing overhead ${Space.spaceStationOverheadSoonNasa.AppearsAt} 
                        for ${Space.spaceStationOverheadSoonNasa.DurationSeconds} seconds`,
        }
    }
}
var IfNotifications = { sendNotification: { skipped: false } };
Object.assign(IfNotifications.sendNotification, actionDefaultValues['IfNotifications']['sendNotification'])


IfNotifications.sendNotification.setMessage = function(msg = '') {
    if (!this.skipped) {
        this.Message = msg;
        log("IfNotifications setMessage: ", msg)
    }
}

IfNotifications.sendNotification.skip = function(msg = '') {
    this.skipped = true;
    log("IfNotifications sendNotification skipped ", msg)
}

// filter code
log("** filter code **")
let weather = Weather.currentWeather[0].CurrentCondition.toLowerCase();
let notClear = ((weather.indexOf('sunny') === -1) && (weather.indexOf('clear') === -1) && (weather.indexOf('fair') === -1));
let sunrise = moment(Weather.currentWeather[0].SunriseAt);
let sunset = moment(Weather.currentWeather[0].SunsetAt);
let currentTime = Meta.currentUserTime;
let afterSunrise = currentTime.isAfter(sunrise);
let beforeSunset = currentTime.isBefore(sunset);
if (notClear) {
    IfNotifications.sendNotification.skip(`ISS passed overhead but you may not see it because it's ${weather}`);
} else if (afterSunrise && beforeSunset) {
    IfNotifications.sendNotification.skip(`ISS passes overhead but the sun is up so you won't spot it`);
}
log("** end of filter code **")

// post app action 

//result
log("IfNotifications: ", IfNotifications.sendNotification)
log("##### end of example VDdNBmiE #####")