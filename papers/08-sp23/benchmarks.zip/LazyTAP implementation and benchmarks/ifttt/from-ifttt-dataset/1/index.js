import fetch from "sync-fetch";

let triggerdata = { //just for the trigger data and cached data
        "CheckTime": "dummy",
        "DayOfWeek": "dummy",
}

// trigger 
let result1 = postJSON("http://localhost:9000/trigger/DateAndTime/everyWeekdayAt", {
    id: "AxJSC34d",
    triggerdata: triggerdata
});


function postJSON(url, data) {
    let result = fetch(url, {
        method: "POST",
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    });

    return result.json();
}

//