Tweet your most watched movies every week!
official applet from Trakt

Let your followers know what your favorite movies are! Each week this Applet will post a tweet with your top ten most-watched movies and how many times you've watched them based on your Trakt most watched movies.

https://ifttt.com/applets/AxJSC34d-tweet-your-most-watched-movies-every-week



const watchedMovies = Trakt.mostWatchedMovies.slice(0, 9)
let tweet = "My top 10 most watched movies: <br/>"

watchedMovies.forEach((movie, index) => {
    tweet += `${index+1}) ${movie.MovieTitle} (${movie.MovieYear})<br/>`
})

Twitter.postNewTweet.setTweet(tweet)






{
    "data": {
        "applet": {
            "applet_triggers": [
                {
                    "module_name": "every_weekday_at",
                    "trigger": {
                        "name": "Every day of the week at",
                        "ingredients": [
                            {
                                "normalized_name": "DateAndTime.everyWeekdayAt.CheckTime"
                            },
                            {
                                "normalized_name": "DateAndTime.everyWeekdayAt.DayOfWeek"
                            }
                        ]
                    },
                    "fields": [
                        {
                            "label": "Time of day",
                            "default_value_json": "\"00:00\""
                        },
                        {
                            "label": "Days of the week",
                            "default_value_json": "[]"
                        }
                    ]
                }
            ],
            "applet_queries": [
                {
                    "query": {
                        "name": "List my most watched movies",
                        "ingredients": [
                            {
                                "normalized_name": "Trakt.mostWatchedMovies.MovieId"
                            },
                            {
                                "normalized_name": "Trakt.mostWatchedMovies.MovieTitle"
                            },
                            {
                                "normalized_name": "Trakt.mostWatchedMovies.MovieYear"
                            },
                            {
                                "normalized_name": "Trakt.mostWatchedMovies.MoviePlays"
                            },
                            {
                                "normalized_name": "Trakt.mostWatchedMovies.LastWatchedAt"
                            }
                        ]
                    },
                    "fields": []
                }
            ],
            "applet_actions": [
                {
                    "action": {
                        "name": "Post a tweet",
                        "full_normalized_module_name": "Twitter.postNewTweet",
                        "action_fields": [
                            {
                                "normalized_module_name": "Tweet"
                            }
                        ]
                    },
                    "fields": [
                        {
                            "label": "Tweet text",
                            "default_value_json": "\"My top watched movie is {{Trakt.mostWatchedMovies[0].MovieTitle}} ( {{Trakt.mostWatchedMovies[0].MovieYear}}). I've watched {{Trakt.mostWatchedMovies[0].MoviePlays}} times.\""
                        }
                    ]
                }
            ],
            "filter_code": "const watchedMovies = Trakt.mostWatchedMovies.slice(0,9)\nlet tweet = \"My top 10 most watched movies: <br/>\"\n\nwatchedMovies.forEach((movie, index) => {\n  tweet += `${index+1}) ${movie.MovieTitle} (${movie.MovieYear})<br/>`\n})\n\nTwitter.postNewTweet.setTweet(tweet)",
            "id": "AxJSC34d"
        }
    }
}