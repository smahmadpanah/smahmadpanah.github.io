log("##### example AxJSC34d is running... #####")

//preamble 
//trigger
var DateAndTime = { everyWeekdayAt: triggerdata }

//query
var Trakt = {
    mostWatchedMovies: QueryFunc.TraktmostWatchedMovies()
}
//action
var actionDefaultValues = {
    "Twitter": {
        "postNewTweet": {
            "Tweet": `My top watched movie is ${Trakt.mostWatchedMovies[0].MovieTitle} ( ${Trakt.mostWatchedMovies[0].MovieYear}). I've watched ${Trakt.mostWatchedMovies[0].MoviePlays} times.`
        }
    }
}
var Twitter = { postNewTweet: { skipped: false } };
Object.assign(Twitter.postNewTweet, actionDefaultValues['Twitter']['postNewTweet'])

Twitter.postNewTweet.setTweet = function(msg = '') {
    if (!this.skipped) {
        this.Tweet = msg;
        log("Twitter setTweet: ", msg)
    }
}


// filter code
log("** filter code **")
const watchedMovies = Trakt.mostWatchedMovies.slice(0, 10)
let tweet = "My top 10 most watched movies: <br/>"

watchedMovies.forEach((movie, index) => {
    tweet += `${index+1}) ${movie.MovieTitle} (${movie.MovieYear})<br/>`
})

Twitter.postNewTweet.setTweet(tweet)
log("** end of filter code **")

// post app action 

//result
log("action: ", Twitter.postNewTweet)
log("##### end of example AxJSC34d #####")