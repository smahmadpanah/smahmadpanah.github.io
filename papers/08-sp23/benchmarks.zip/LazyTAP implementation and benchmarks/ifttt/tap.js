import express from "express";
import fetch from "sync-fetch";
import chalk from "chalk";
import * as fs from 'fs';
import { NodeVM } from 'vm2';

/* performance */
// import sizeof from 'object-sizeof';



/* search for [BENCHMARK] to find out possible executions of different cases */
/* to see the benchmark evaluation table: https://docs.google.com/spreadsheets/d/1aNXyPmBDZEWjKHD8cGTQfCiTkVT57zUaRvzooJqF7PI/edit?usp=sharing */

// TAP

const tap = express();
tap.use(express.json());

// query types
// import { createRequire } from "module";
// const require = createRequire(
//     import.meta.url);
// all proxy, querytypes just for optimization
// const querytypes = require("./querytypes.json");
// for node version 17 and above!
import querytypes from './querytypes.json' assert {type: 'json'};

// query functions 
import * as QueryFunc from './queryFunctions.js'

// [BENCHMARK] note that the trigger/user data is shared between cases
// Meta object (should be a query?)
var config = {
    currentTime: "2020-04-23T18:25:43.511Z",
    timeZone: "GMT",
    triggerTime: "2020-04-23T19:25:43.511Z"
}
import moment from "moment-timezone"
var Meta = {
    currentUserTime: moment(config.currentTime).tz(config.timeZone)
}
Meta.triggerTime = config.triggerTime === null ? null : moment(config.triggerTime).tz(config.timeZone)

// atttribute counter
var fetchedAttributes = [];


// type - the type of event
// id - the id of the specific event
tap.post('/trigger/:servicename/:type', (req, res) => {

    //performance
    timeStart("trigger-to-action");

    let servicename = req.params.servicename;
    let type = req.params.type;
    let id = req.body.id;
    let triggerdata = req.body.triggerdata;

    const vm = new NodeVM({
        console: 'inherit', //default
        sandbox: {
            log,
            servicename,
            type,
            id,
            triggerdata,
            queryService,
            QueryFunc,
            config,
            Meta
        },
        eval: false, //default : true
        require: {
            external: false, //default
            builtin: [], //default
            root: "./",
            mock: {}
        }
    });
    vm.freeze(moment, 'moment');


    log(`from service ${servicename} event type ${type} with id ${id} received`);

    switch (id) {
        //designed cases
        case "001ets":
            vm.run(fs.readFileSync('./designed-cases/1/'.concat(id + ".js"), 'utf8'));
            break;

        case "002tcs":
            vm.run(fs.readFileSync('./designed-cases/2/'.concat(id + ".js"), 'utf8'));
            break;

        case '003ecs':
            vm.run(fs.readFileSync('./designed-cases/3/'.concat(id + ".js"), 'utf8'));
            break;

        case '004scpn':
            vm.run(fs.readFileSync('./designed-cases/4/'.concat(id + ".js"), 'utf8'));
            break;

        case '005ecfsg':
            vm.run(fs.readFileSync('./designed-cases/5/'.concat(id + ".js"), 'utf8'));
            break;

        case '006tyt':
            vm.run(fs.readFileSync('./designed-cases/6/'.concat(id + ".js"), 'utf8'));
            break;




            //ifttt cases
        case 'AxJSC34d':
            vm.run(fs.readFileSync('./from-ifttt-dataset/1/'.concat(id + "-appcode.js"), 'utf8'));
            break;

        case 'example-03':
            vm.run(fs.readFileSync('./from-ifttt-dataset/2/'.concat(id + "-appcode.js"), 'utf8'));
            break;

        case 'iqZPNUtR':
            vm.run(fs.readFileSync('./from-ifttt-dataset/3/'.concat(id + "-appcode.js"), 'utf8'));
            break;

        case 'jUy5if7H':
            vm.run(fs.readFileSync('./from-ifttt-dataset/4/'.concat(id + "-appcode.js"), 'utf8'));
            break;

        case 'MRm9VBxG':
            vm.run(fs.readFileSync('./from-ifttt-dataset/5/'.concat(id + "-appcode.js"), 'utf8'));
            break;

        case 'YG5HSLvK':
            vm.run(fs.readFileSync('./from-ifttt-dataset/6/'.concat(id + "-appcode.js"), 'utf8'));
            break;

        case 'xvyUBQsh':
            vm.run(fs.readFileSync('./from-ifttt-dataset/7/'.concat(id + "-appcode.js"), 'utf8'));
            break;

        case 'example-04':
            vm.run(fs.readFileSync('./from-ifttt-dataset/8/'.concat(id + "-appcode.js"), 'utf8'));
            break;

        case 'VDdNBmiE':
            vm.run(fs.readFileSync('./from-ifttt-dataset/9/'.concat(id + "-appcode.js"), 'utf8'));
            break;





            //skeleton
        case 'skeleton':
            log("##### example XX is running... #####")

            //preamble 
            //trigger

            //query

            //action

            // filter code
            log("** filter code **")

            log("** end of filter code **")

            // post app action 

            //result
            log("action: ", Action)
            log("##### end of example XX #####")

            break;

        default:
            log('error: no apps found!')
            break;
    }

    // performance
    timeEnd("trigger-to-action");

    console.log('\n\n\n')
    log("list of fetched query attributes:\n" + chalk.blue(fetchedAttributes.join('\n')) + '\n' + '#attributes: ' + chalk.blue(fetchedAttributes.length) + '\n')

    // log(chalk.red("Trigger data size", sizeof(triggerdata), "B for", servicename))

    res.json(""); // to make postJSON happy
    res.end();

});

tap.listen(9000);




export function queryService(url, args) {

    log(chalk.black(`asking data from ${url}`))

    // aggregating fetched attributes to report at the end of the execution
    let servicename = url.replace('http://localhost:4000/', '');
    // attribute += `/${id}`
    // attribute = attribute.split('/');
    // attribute.splice(2, 1);
    // fetchedAttributes.push(attribute.join('.'))
    //


    let result = postJSON(url, args);

    // log(chalk.red("Query data size", sizeof(result), "B for ", servicename))
    return result;
}

// ---

function postJSON(url, data) {
    let result = fetch(url, {
        method: "POST",
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    });

    return result.json();
}


function timeStart(){
    console.time.apply(console, arguments);
}

function timeEnd(){
    process.stdout.write(chalk.magenta("[IFTTT] "));
    console.timeEnd.apply(console, arguments);
}

function log() {
    process.stdout.write("[IFTTT] ");
    console.log.apply(console, arguments);
}