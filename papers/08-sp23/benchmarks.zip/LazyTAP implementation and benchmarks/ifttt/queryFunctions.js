import { queryService } from "./tap.js";

export function GoogleCalendarhistoryOfEventFromSearchStarts(Calendar, Query, Offset) {

    let GoogleCalendar = queryService("http://localhost:4000/GoogleCalendar/historyOfEventFromSearchStarts", {
        Calendar: Calendar,
        Query: Query,
        Offset: Offset
    });
    return GoogleCalendar;
}


export function GoogleCalendarsearchEvents(Calendar, Query) {

    let GoogleCalendar = queryService("http://localhost:4000/GoogleCalendar/searchEvents", {
        Calendar: Calendar,
        Query: Query
    });
    return GoogleCalendar;
}


export function GoogleTaskslistAllTasks(CompletedTasks) {
    let GoogleTasks = queryService("http://localhost:4000/GoogleTasks/listAllTasks", {
        CompletedTasks: CompletedTasks,
    });
    return GoogleTasks;
}

export function GoogleCalendarhistoryOfCalendarEventBeginnings(Calendar, Offset) {
    let GoogleCalendar = queryService("http://localhost:4000/GoogleCalendar/historyOfCalendarEventBeginnings", {
        Calendar: Calendar,
        Offset: Offset
    });
    return GoogleCalendar;
}

export function GiphyhistoryOfRandomGifBasedOnKeyword(Term) {
    let Giphy = queryService("http://localhost:4000/Giphy/historyOfRandomGifBasedOnKeyword", {
        Term: Term,
    });
    return Giphy;
}

export function WeathertwoDayForecast(Location) {
    let Weather = queryService("http://localhost:4000/Weather/twoDayForecast", {
        Location: Location,
    });
    return Weather;
}

export function WeathercurrentWeather(Location) {
    let Weather = queryService("http://localhost:4000/Weather/currentWeather", {
        Location: Location,
    });
    return Weather;
}


export function FinancehistoryOfClosingPrices(TickerSymbol) {
    let Finance = queryService("http://localhost:4000/Finance/historyOfClosingPrices", {
        TickerSymbol: TickerSymbol,
    });
    return Finance;
}



export function YelpsearchBusiness(Location, Term) {
    let Yelp = queryService("http://localhost:4000/Yelp/searchBusiness", {
        Location: Location,
        Term: Term
    });
    return Yelp;
}


export function FitbithistoryOfDailyActivitySummaries() {
    let Fitbit = queryService("http://localhost:4000/Fitbit/historyOfDailyActivitySummaries", {});
    return Fitbit;
}



export function YoutuberecentLikedVideos() {
    let Youtube = queryService("http://localhost:4000/Youtube/recentLikedVideos", {});
    return Youtube;
}


export function TraktmostWatchedMovies() {
    let Trakt = queryService("http://localhost:4000/Trakt/mostWatchedMovies", {});
    return Trakt;
}

export function TraktrecommendedMovies() {
    let Trakt = queryService("http://localhost:4000/Trakt/recommendedMovies", {});
    return Trakt;
}