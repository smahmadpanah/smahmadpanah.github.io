#!/bin/sh

# pass the number points to the benchmark example, "./script.sh 2"

clear

run () {
	echo "$(tput setaf 1) --------------------- \n| running benchmark #$1 |\n --------------------- $(tput setaf 0)"

	node --no-warnings tap &
	node --no-warnings $1/query &
	sleep 0.5

	node --no-warnings $1/index

	kill -2 $(lsof -ti:9000,4000)
}

DIR1="./designed-cases"
DIR2="./from-ifttt-dataset"

OPTION=""

# just printing number of attributes
if [ $# -eq 2 ] && [ $2 == "n" ]; then 
	OPTION="| (head -n 3 && tail -n 2)";
fi

if [ $1 == "all" ]; then 
	for dir in $DIR1/*/; do eval "run $dir $OPTION"; done; 
	for dir in $DIR2/*/; do eval "run $dir $OPTION"; done;
else
	eval "run $1 $OPTION";
fi
