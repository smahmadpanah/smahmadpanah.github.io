import express from "express";
import chalk from "chalk";

export const query = express();
query.use(express.json());

query.listen(4000);

export function log(servicename) {
    var arg = Array.prototype.slice.call(arguments, 1);
    process.stdout.write(`[${servicename}] `);
    console.log.apply(console, arg);
}