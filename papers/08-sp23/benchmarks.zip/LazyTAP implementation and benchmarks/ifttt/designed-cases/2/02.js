// 02 - app with independent query
// every day at 7am, send a Slack message with the first important meeting of the day from Google Calendar

// app config; details below
// trigger: DateAndTime.everyDayAt.CheckTime
// query: GoogleCalendar.historyOfEventFromSearchStarts("today", "important")
// action: Slack.postToChannel.setMessage("something went wrong!")



// app filtercode
// if (GoogleCalendar.historyOfEventFromSearchStarts.length == 0) {
//     Slack.postToChannel.setMessage("no important meeting for today...")
// } else {
//     Slack.postToChannel.setTitle(GoogleCalendar.historyOfEventFromSearchStarts[0].Title);
//     Slack.postToChannel.setMessage('the meeting starts at' +
//         GoogleCalendar.historyOfEventFromSearchStarts[0].Starts);
// }

let location = GoogleCalendar.historyOfEventFromSearchStarts[0].Where;
if (location != 'office') {
    Slack.postToChannel.setMessage("First meeting is not in office!");
} else {
    Slack.postToChannel.setTitle(
        GoogleCalendar.historyOfEventFromSearchStarts[0].Title);
    Slack.postToChannel.setMessage("First office meeting starts at" + 
        GoogleCalendar.historyOfEventFromSearchStarts[0].Starts);
}

/*
- control flow depends on sensitive query that doesn't depend on trigger
- 
    static minTAP: 3 attributes, can handle arrrays?!
    dynamic minTAP: n/a
    lazyTAP: 1 or 3
    no min/ifttt: 1 + 7 * length + 1
*/

/*
"applet": {
            "applet_triggers": [DateAndTime.everyDayAt.CheckTime],
            "applet_queries": [
                {
                    "query": {
                        "name": "History of event from search starts",
                        "ingredients": [
                            {
                                "normalized_name": "GoogleCalendar.historyOfEventFromSearchStarts.Title"
                            },
                            {
                                "normalized_name": "GoogleCalendar.historyOfEventFromSearchStarts.Description"
                            },
                            {
                                "normalized_name": "GoogleCalendar.historyOfEventFromSearchStarts.Where"
                            },
                            {
                                "normalized_name": "GoogleCalendar.historyOfEventFromSearchStarts.Starts"
                            },
                            {
                                "normalized_name": "GoogleCalendar.historyOfEventFromSearchStarts.Ends"
                            },
                            {
                                "normalized_name": "GoogleCalendar.historyOfEventFromSearchStarts.EventUrl"
                            },
                            {
                                "normalized_name": "GoogleCalendar.historyOfEventFromSearchStarts.VideoCallUrl"
                            }
                        ]
                    },
                    "fields": [
                        {
                            "label": "Calendar",
                            "default_value_json": "myself"
                        },
                        {
                            "label": "Query",
                            "default_value_json": "important"
                        },
                        {
                            "label": "Offset",
                            "default_value_json": "11:00"
                        }
                    ]
                }
            ],
            "applet_actions": [
                {
                    "action": {
                        "name": "Post to channel",
                        "full_normalized_module_name": "Slack.postToChannel",
                        "action_fields": [
                            {
                                "normalized_module_name": "Channel"
                            },
                            {
                                "normalized_module_name": "Message"
                            },
                            {
                                "normalized_module_name": "Title"
                            },
                            {
                                "normalized_module_name": "TitleUrl"
                            },
                            {
                                "normalized_module_name": "ImageUrl"
                            }
                        ]
                    },
                    "fields": [
                        {
                            "label": "Which channel?",
                            "default_value_json": "Myself"
                        },
                        {
                            "label": "Message",
                            "default_value_json": "something went wrong!"
                        },
                        {
                            "label": "Title",
                            "default_value_json": ""
                        },
                        {
                            "label": "Title URL",
                            "default_value_json": ""
                        },
                        {
                            "label": "Thumbnail URL",
                            "default_value_json": ""
                        }
                    ]
                }
            ],
*/