log("##### example 02 is running... #####")
//preamble 
//trigger
var DateAndTime = { everyDayAt: triggerdata }


//query
// [BENCHMARK]: modify the third argument to "25:00" for zero length or "11:00" for a three-element array 
var GoogleCalendar = {
    historyOfEventFromSearchStarts: QueryFunc.GoogleCalendarhistoryOfEventFromSearchStarts(
        "myself", "important", "11:00") //change 11:00 to 25:00 for the other run
}


//action
var actionDefaultValues = {
    "Slack": {
        "postToChannel": {
            "Channel": "Myself",
            "Message": "went wrong...",
            "Title": "",
            "TitleUrl": "",
            "ImageUrl": "",
        }
    }
}
var Slack = { postToChannel: { skipped: false } };
Object.assign(Slack.postToChannel, actionDefaultValues['Slack']['postToChannel'])

Slack.postToChannel.setMessage = function(msg = '') {
    if (!this.skipped) {
        this.Message = msg;
        log("SLACK setMessage: ", msg)
    }
}
Slack.postToChannel.setTitle = function(msg = '') {
    if (!this.skipped) {
        this.Title = msg;
        log("SLACK setTitle: ", msg)
    }
}
Slack.postToChannel.skip = function(msg = '') {
    this.skipped = true;
    log("SLACK postToChannel skipped ", msg)
}
// filter code
log("** filter code **")


// if (GoogleCalendar.historyOfEventFromSearchStarts.length == 0) {
//     Slack.postToChannel.setMessage("no important meeting for today...")
// } else {
//     Slack.postToChannel.setTitle(GoogleCalendar.historyOfEventFromSearchStarts[0].Title);
//     Slack.postToChannel.setMessage('the meeting starts at ' + '\n' +
//         GoogleCalendar.historyOfEventFromSearchStarts[0].Starts);
// }

let location = GoogleCalendar.historyOfEventFromSearchStarts[0].Where;
if (location != 'office') {
    Slack.postToChannel.setMessage("First meeting is not in office!");
} else {
    Slack.postToChannel.setTitle(
        GoogleCalendar.historyOfEventFromSearchStarts[0].Title);
    Slack.postToChannel.setMessage("First office meeting starts at" + 
        GoogleCalendar.historyOfEventFromSearchStarts[0].Starts);
}
log("** end of filter code **")


// post app action 

//result
log("action: ", Slack.postToChannel)
log("##### end of example 02 #####")