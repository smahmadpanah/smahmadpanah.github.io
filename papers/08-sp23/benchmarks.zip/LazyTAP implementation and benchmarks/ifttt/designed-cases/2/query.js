import { log, query } from '../../queryLib.js'


// the GoogleCalendar query
query.post("/GoogleCalendar/historyOfEventFromSearchStarts", (req, res) => {
    log('GoogleCalendar', `received query with data ${JSON.stringify(req.body)}`);

    // perform dummy query

    let calendardata = {
        "myself": {
            "important": {
                "25:00": [{
                        "Title": "event2",
                        "Starts": '25:02',
                        "Description": "string",
                        "Where": "remote",
                        "Ends": "string",
                        "EventUrl": "string",
                        "VideoCallUrl": "string",
                        // "inner": {
                        //     "sth": "snd sth"
                        // },
                        // "logArr": [{
                        //     "Code": "22"
                        // }]
                    }],
                "11:00": [{
                        "Title": "event1",
                        "Starts": '11:02',
                        "Description": "string",
                        "Where": "office",
                        "Ends": "string",
                        "EventUrl": "string",
                        "VideoCallUrl": "string",
                        "inner": {
                            "sth": "first sth"
                        },
                        "logArr": [{
                            "Code": "11"
                        }, { "Code": '12' }]
                    },
                    {
                        "Title": "event2",
                        "Starts": '12:02',
                        "Description": "string",
                        "Where": "string",
                        "Ends": "string",
                        "EventUrl": "string",
                        "VideoCallUrl": "string",
                        // "inner": {
                        //     "sth": "snd sth"
                        // },
                        // "logArr": [{
                        //     "Code": "22"
                        // }]
                    },
                    {
                        "Title": "event3",
                        "Starts": '12:10',
                        "Description": "string",
                        "Where": "string",
                        "Ends": "string",
                        "EventUrl": "string",
                        "VideoCallUrl": "string",
                        // "inner": {
                        //     "sth": "third sth"
                        // },
                        // "logArr": [{ "Code": "33" }]
                    }
                ]
            }
        }
    };
    let result = calendardata[req.body.Calendar][req.body.Query][req.body.Offset];

    res.json(result);

    res.end();
});