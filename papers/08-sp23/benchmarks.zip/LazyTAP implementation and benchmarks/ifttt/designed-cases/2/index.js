import fetch from "sync-fetch";


var triggerdata = {
    "002tcs": {
        "CheckTime": "0"
    }
}

// time trigger (every day at 7am)
let result1 = postJSON("http://localhost:9000/trigger/DateAndTime/everyDayAt", {
    id: "002tcs",
    triggerdata: triggerdata
});



function postJSON(url, data) {
    let result = fetch(url, {
        method: "POST",
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    });

    return result.json();
}

//