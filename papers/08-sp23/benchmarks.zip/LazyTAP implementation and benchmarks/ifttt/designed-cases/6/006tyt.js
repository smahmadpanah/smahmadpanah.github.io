log("##### example 06 is running... #####")

//preamble 
//trigger
var DateAndTime = { everyDayAt: triggerdata }

//query
var Youtube = {
    recentLikedVideos: QueryFunc.YoutuberecentLikedVideos()
}
//action
var actionDefaultValues = {
    "Telegram": {
        "sendMessage": {
            "Chat_id": "my_channel",
            "Text": "went wrong...",
            "IncludeWebPagePreview": "",
        }
    }
}
var Telegram = { sendMessage: { skipped: false } };
Object.assign(Telegram.sendMessage, actionDefaultValues['Telegram']['sendMessage'])

Telegram.sendMessage.setText = function(msg = '') {
    if (!this.skipped) {
        this.Text = msg;
        log("Telegram setText: ", msg)
    }
}

Telegram.sendMessage.skip = function(msg = '') {
    this.skipped = true;
    log("Telegram sendMessage skipped ", msg)
}
// filter code
log("** filter code **")
if (Youtube.recentLikedVideos.length != 0) {
    let randomIndex = Math.floor((Math.random() * Youtube.recentLikedVideos.length))
    Telegram.sendMessage.setText(Youtube.recentLikedVideos[randomIndex].Title + "|" +
        Youtube.recentLikedVideos[randomIndex].Url + "|" +
        Youtube.recentLikedVideos[randomIndex].Description)
} else {
    Telegram.sendMessage.skip();
}
log("** end of filter code **")

// post app action 

//result
log("action: ", Telegram.sendMessage)
log("##### end of example 06 #####")