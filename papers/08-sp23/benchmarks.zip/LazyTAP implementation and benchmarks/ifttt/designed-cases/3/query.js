import { log, query } from '../../queryLib.js'



// the GoogleCalendar query
query.post("/GoogleCalendar/historyOfEventFromSearchStarts", (req, res) => {
    log('GoogleCalendar', `received query with data ${JSON.stringify(req.body)}`);

    // perform dummy query

    let calendardata = {
        "myself": {
            "supervisor": {
                "08:00": [{
                        "Title": "eventSupervisor",
                        "Starts": '08:02',
                        "Description": "string",
                        "Where": "string",
                        "Ends": "string",
                        "EventUrl": "string",
                        "VideoCallUrl": "string",
                    },
                    {
                        "Title": "eventSupervisor2",
                        "Starts": '12:02',
                        "Description": "string",
                        "Where": "string",
                        "Ends": "string",
                        "EventUrl": "string",
                        "VideoCallUrl": "string",
                    },
                    {
                        "Title": "eventSupervisor3",
                        "Starts": '12:10',
                        "Description": "string",
                        "Where": "string",
                        "Ends": "string",
                        "EventUrl": "string",
                        "VideoCallUrl": "string",
                    }
                ]
            },
            "friend": {
                "08:00": [{
                    "Title": "eventFriend",
                    "Starts": '09:02',
                    "Description": "string",
                    "Where": "string",
                    "Ends": "string",
                    "EventUrl": "string",
                    "VideoCallUrl": "string",
                }],
            },
            "spammer": {
                "08:00": [],
            }
        }
    };
    let result = calendardata[req.body.Calendar][req.body.Query][req.body.Offset];

    res.json(result);

    res.end();
});