import fetch from "sync-fetch";


let triggerdata = { //just for the trigger data and cached data
    "CreatedAt": "12:34",
    "FrontDoor": "dummy text",
}

// smartlife trigger
let result1 = postJSON("http://localhost:9000/trigger/Smartlife/doorClosed", {
    id: "004scpn",
    triggerdata: triggerdata
});


function postJSON(url, data) {
    let result = fetch(url, {
        method: "POST",
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    });

    return result.json();
}

//