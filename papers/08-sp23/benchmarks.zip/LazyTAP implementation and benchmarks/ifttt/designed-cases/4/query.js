import { log, query } from '../../queryLib.js'


// the GoogleCalendar query
query.post("/GoogleCalendar/historyOfCalendarEventBeginnings", (req, res) => {
    log('GoogleCalendar', `received query with data ${JSON.stringify(req.body)}`);

    // perform dummy query

    let calendardata = {
        "myself": {
            "01:00": [{
                    "Title": "eventSupervisor",
                    "Starts": '08:02',
                    "Description": "string",
                    // [BENCHMARK]: modify WHERE 
                    "Where": "gothenburg", //[4]
                    // "Where": "tehran", //[4]
                    // "Where": "nowhere", //[3]
                    "Ends": "string",
                    "EventUrl": "string",
                    "VideoCallUrl": "string",
                },
                {
                    "Title": "eventSupervisor2",
                    "Starts": '12:02',
                    "Description": "string",
                    "Where": "string",
                    "Ends": "string",
                    "EventUrl": "string",
                    "VideoCallUrl": "string",
                },
                {
                    "Title": "eventSupervisor3",
                    "Starts": '12:10',
                    "Description": "string",
                    "Where": "string",
                    "Ends": "string",
                    "EventUrl": "string",
                    "VideoCallUrl": "string",
                }
            ],
            "10:00": [{
                "Title": "eventFriend",
                "Starts": '18:02',
                "Description": "string",
                "Where": "tehran", //[4]
                "Ends": "string",
                "EventUrl": "string",
                "VideoCallUrl": "string",
            }],
            "20:00": [],

        }
    };
    let result = calendardata[req.body.Calendar][req.body.Offset];

    res.json(result);

    res.end();
});



// the Yelp query
query.post("/Yelp/searchBusiness", (req, res) => {
    log('Yelp', `received query with data ${JSON.stringify(req.body)}`);

    // perform dummy query

    let yelpdata = {
        "gothenburg": {
            "parking": [{
                    "BusinessId": "11",
                    "BusinessName": "parking1",
                    "BusinessCategory": "string",
                    "BusinessImageUrl": "string",
                    "BusinessPhone": "string",
                    "BusinessAddress": "Johanneberg",
                    "BusinessRating": "string",
                },
                {
                    "BusinessId": "22",
                    "BusinessName": "parking2",
                    "BusinessCategory": "string",
                    "BusinessImageUrl": "string",
                    "BusinessPhone": "string",
                    "BusinessAddress": "Avenyn",
                    "BusinessRating": "string",
                },
            ]
        },
        "tehran": {
            "parking": [{
                "BusinessId": "44",
                "BusinessName": "parking4",
                "BusinessCategory": "string",
                "BusinessImageUrl": "string",
                "BusinessPhone": "string",
                "BusinessAddress": "Azadi",
                "BusinessRating": "string",
            }]
        },
        "nowhere": {
            "parking": [],

        }
    };
    let result = yelpdata[req.body.Location][req.body.Term];

    res.json(result);

    res.end();
});