// 04 - app with query chain (imaginary)
// not supported by ifttt:  for two reasons: sensitive data from fitbit is not transmitted to ifttt and location query doesn't exist!
/*
trigger: fitbit hearbeat alarm
query1: location
query2: Maps finding nearby hospital ('hospital', location)
action: notification the address

if (fitbit.heartRate > 150 || fitbit.heartRate < 40){
    Notification.setMessage(Maps.places[0].name +
                            Maps.places[0].address + 
                            fitibit.heartRate)
}
*/



// app config; details below
// trigger: door closed (Smartlife.doorClosed)
// query1: GoogleCalendar.historyOfCalendarEventBeginnings (within one hour)
// query2: Find the closet parking space near to the event's location (event.location)
// action: Launch navigator (AndroidDevice.startNavigation)

// if we want to deploy it as an ifttt app, we could config the app as follows:
/*  GoogleCalendar.historyOfCalendarEventBeginnings query fields: 
"fields": [
                        {
                            "label": "Calendar",
                            "default_value_json": "myself"
                        },
                        {
                            "label": "Offset",
                            "default_value_json": "01:00"
                        }
                    ]
    Yelp.searchBusiness query fields:
"fields": [
                        {
                            "label": "Location",
                            "default_value_json": "{{GoogleCalendar.historyOfCalendarEventBeginnings[0].Where}}"
                        },
                        {
                            "label": "Term",
                            "default_value_json": "parking"
                        }
                    ]  
    AndroidDevice.startNavigation action fields:
"fields": [
                        {
                            "label": "NavigationMethod",
                            "default_value_json": ""
                        },
                        {
                            "label": "Query",
                            "default_value_json": "{{Yelp.searchBusiness[0].BusinessAddress}}"
                        }
                    ]        
*/

// corresponding app filtercode
let destination = GoogleCalendar.historyOfCalendarEventBeginnings("myself", "01:00")[0].Where;
let parkingLocation = Yelp.searchBusiness(destination, "parking")[0];
AndroidDevice.startNavigation.setQuery(parkingLocation.BusinessAddress);

/*
- chain of dependent queries, no use of trigger 
- 
    static minTAP: 2 attributes, can handle arrrays?!
    dynamic minTAP: n/a
    lazyTAP: 2
    no min:  16 and more, the whole arrays!

*/

// To beat static minTAP, a variation can be as below:
let events = GoogleCalendar.historyOfCalendarEventBeginnings("myself", "01:00");
if (events.length != 0) {
    let parkingLocation = Yelp.searchBusiness(events[0].Where, "parking");
    if (parkingLocation.length != 0) {
        AndroidDevice.startNavigation.setQuery(parkingLocation[0].BusinessAddress);
    }
} else {
    AndroidDevice.startNavigation.skip();
}

// the final version
if (GoogleCalendar.historyOfCalendarEventBeginnings.length != 0) {
    if (Yelp.searchBusiness.length != 0) {
        AndroidDevice.startNavigation.setQuery(Yelp.searchBusiness[0].BusinessAddress);
    } else {
        AndroidDevice.startNavigation.skip('no parking found');
    }
} else {
    AndroidDevice.startNavigation.skip('no meeting found');
}
/*
   static minTAP: 4 attributes, can handle arrrays?!
   dynamic minTAP: n/a
   lazyTAP: 1 or 3 or 4
   no min: 2 + (7 * GoogleCalendarLength) + 1 + (7 * YelpLength) + 1
   ifttt: doesn't support query chain!
*/

/*
"applet": {
            "applet_triggers": [
                {
                "trigger": {
                        "name": "Door sensor is closed",
                        "ingredients": [
                            {
                                "normalized_name": "Smartlife.doorClosed.CreatedAt"
                            },
                            {
                                "normalized_name": "Smartlife.doorClosed.DeviceName"
                            }
                        ]
                    },
                    "fields": [{
                            "label": "Which device/group?",
                            "default_value_json": "entrance"
                    }]
                }
            ],
            "applet_queries": [
                {
                    "query": {
                        "name": "History of event from search starts",
                        "ingredients": [
                            {
                                "normalized_name": "GoogleCalendar.historyOfCalendarEventBeginnings.Title"
                            },
                            {
                                "normalized_name": "GoogleCalendar.historyOfCalendarEventBeginnings.Description"
                            },
                            {
                                "normalized_name": "GoogleCalendar.historyOfCalendarEventBeginnings.Where"
                            },
                            {
                                "normalized_name": "GoogleCalendar.historyOfCalendarEventBeginnings.Starts"
                            },
                            {
                                "normalized_name": "GoogleCalendar.historyOfCalendarEventBeginnings.Ends"
                            },
                            {
                                "normalized_name": "GoogleCalendar.historyOfCalendarEventBeginnings.EventUrl"
                            },
                            {
                                "normalized_name": "GoogleCalendar.historyOfCalendarEventBeginnings.VideoCallUrl"
                            }
                        ]
                    },
                    "fields": [
                        {
                            "label": "Calendar",
                            "default_value_json": "myself"
                        },
                        {
                            "label": "Offset",
                            "default_value_json": "01:00"
                        }
                    ]
                },
                {
                    "query": {
                        "name": "Search for a business",
                        "ingredients": [
                            {
                                "normalized_name": "Yelp.searchBusiness.BusinessId"
                            },
                            {
                                "normalized_name": "Yelp.searchBusiness.BusinessName"
                            },
                            {
                                "normalized_name": "Yelp.searchBusiness.BusinessCategory"
                            },
                            {
                                "normalized_name": "Yelp.searchBusiness.BusinessImageUrl"
                            },
                            {
                                "normalized_name": "Yelp.searchBusiness.BusinessPhone"
                            },
                            {
                                "normalized_name": "Yelp.searchBusiness.BusinessAddress"
                            },
                            {
                                "normalized_name": "Yelp.searchBusiness.BusinessRating"
                            }
                        ]
                    },
                    "fields": [
                        {
                            "label": "Location",
                            "default_value_json": "{{GoogleCalendar.historyOfCalendarEventBeginnings[0].Where}}"
                        },
                        {
                            "label": "Term",
                            "default_value_json": "parking"
                        }
                    ]
                }
            ],
            "applet_actions": [
                {
                    "action": {
                        "name": "Launch Google Maps Navigation",
                        "full_normalized_module_name": "AndroidDevice.startNavigation",
                        "action_fields": [
                            {
                                "normalized_module_name": "NavigationMethod"
                            },
                            {
                                "normalized_module_name": "Query"
                            }
                        ]
                    },
                    "fields": [
                        {
                            "label": "NavigationMethod",
                            "default_value_json": ""
                        },
                        {
                            "label": "Query",
                            "default_value_json": "{{Yelp.searchBusiness[0].BusinessAddress}}"
                        }
                    ]
                }
            ],
*/