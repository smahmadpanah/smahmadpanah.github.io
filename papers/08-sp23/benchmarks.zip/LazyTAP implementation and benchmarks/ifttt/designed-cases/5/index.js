import fetch from "sync-fetch";


let triggerdata = { //just for the trigger data and cached data
    "AttachmentTemporaryUrl": "dummy",
    //
    // [BENCHMARK]: modify WHERE
    // to change the exeuction, pick one of the followings
    "From": "supervisor", // [6 or 2] fetching From, Subject, Body, AttachmentUrl, historyOfEventFromSearchStarts[0].Title
    // "From": "trainer", //fetching From, historyOfDailyActivitySummaries[0].Date/TotalCaloriesBurned/VeryActiveMinutes 
    // "From": "spammer", //fetching From
    //
    "Body": "here's the meeing info",
    "BodyHTML": "dummy",
    "Subject": "meeting",
    "AttachmentUrl": "the url",
    "ReceivedAt": "23:59",
}


// email trigger
let result1 = postJSON("http://localhost:9000/trigger/Email/sendIftttAnEmail", {
    id: "005ecfsg",
    triggerdata: triggerdata
});



function postJSON(url, data) {
    let result = fetch(url, {
        method: "POST",
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    });

    return result.json();
}

//