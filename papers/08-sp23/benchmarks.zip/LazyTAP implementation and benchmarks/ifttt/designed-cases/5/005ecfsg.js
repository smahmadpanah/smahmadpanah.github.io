log("##### example 05 is running... #####")

//preamble 
//trigger
var Email = { sendIftttAnEmail: triggerdata }

//query
var GoogleCalendar = {
    historyOfEventFromSearchStarts: QueryFunc.GoogleCalendarhistoryOfEventFromSearchStarts(
        // [BENCHMARK]: go to ./5/query and modify .From values
         "myself",  Email.sendIftttAnEmail.From,  "01:00")
}

var Fitbit = {
    historyOfDailyActivitySummaries: QueryFunc.FitbithistoryOfDailyActivitySummaries()
}
//action
var actionDefaultValues = {
    "Slack": {
        "postToChannel": {
            "Channel": "Myself",
            "Message": "went wrong...",
            "Title": "",
            "TitleUrl": "",
            "ImageUrl": "",
        }
    },
    "Gmail": {
        "sendAnEmail": {
            "To":  Email.sendIftttAnEmail.From,
            "Cc": "",
            "Bcc": "",
            "Subject": "daily summary",
            "Body": "",
            "AttachmentUrl": ""
        }
    }
}
var Slack = { postToChannel: { skipped: false } };
Object.assign(Slack.postToChannel, actionDefaultValues['Slack']['postToChannel'])

Slack.postToChannel.setMessage = function(msg = '') {
    if (!this.skipped) {
        this.Message = msg;
        log("SLACK setMessage: ", msg)
    }
}
Slack.postToChannel.setTitle = function(msg = '') {
    if (!this.skipped) {
        this.Title = msg;
        log("SLACK setTitle: ", msg)
    }
}
Slack.postToChannel.skip = function(msg = '') {
    this.skipped = true;
    log("SLACK postToChannel skipped ", msg)
}

var Gmail = { sendAnEmail: { skipped: false } };
Object.assign(Gmail.sendAnEmail, actionDefaultValues['Gmail']['sendAnEmail'])

Gmail.sendAnEmail.setBody = function(msg = '') {
    if (!this.skipped) {
        this.Body = msg;
        log("Gmail setBody: ", msg)
    }
}

Gmail.sendAnEmail.skip = function(msg = '') {
    this.skipped = true;
    log("Gmail sendAnEmail skipped ", msg)
}
// filter code
log("** filter code **")
if (Email.sendIftttAnEmail.From == "supervisor") {
    if (GoogleCalendar.historyOfEventFromSearchStarts.length != 0) {
        Slack.postToChannel.setMessage(
            Email.sendIftttAnEmail.Subject +
            Email.sendIftttAnEmail.Body +
            Email.sendIftttAnEmail.AttachmentUrl +
            GoogleCalendar.historyOfEventFromSearchStarts[0].Title);
    } else {
        Slack.postToChannel.skip();
    }
    Gmail.sendAnEmail.skip();
} else if (Email.sendIftttAnEmail.From == "trainer") {
    if (Fitbit.historyOfDailyActivitySummaries.length != 0) {
        let todaySummary = Fitbit.historyOfDailyActivitySummaries[0];
        Gmail.sendAnEmail.setBody(
            todaySummary.Date +
            todaySummary.TotalCaloriesBurned +
            todaySummary.VeryActiveMinutes);
    } else {
        Gmail.sendAnEmail.skip();
    }
    Slack.postToChannel.skip();
} else {
    Slack.postToChannel.skip();
    Gmail.sendAnEmail.skip();
}
log("** end of filter code **")

// post app action 

//result
log("Slack: ", Slack.postToChannel)
log("Gmail: ", Gmail.sendAnEmail)

log("##### end of example 05 #####")