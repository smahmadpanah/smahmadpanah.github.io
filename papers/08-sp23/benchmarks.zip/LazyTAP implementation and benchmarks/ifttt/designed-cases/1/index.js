import fetch from "sync-fetch";

var triggerdata = {
    "AttachmentTemporaryUrl": "dummy",
    //
    // to change the exeuction, pick one of the followings
    "From": "supervisor", //fetching From, Subject, Body, AttachmentUrl [4]
    "From": "spammer", //fetching From [1]
    // "From": "news", //fetching From, ReceivedAt [2]
    //
    "Body": "here's the meeing info",
    "BodyHTML": "dummy",
    "Subject": "meeting",
    "AttachmentUrl": "the url",
    "ReceivedAt": "23:59",
}

// email trigger 
let result1 = postJSON("http://localhost:9000/trigger/Email/sendIftttAnEmail", {
    id: "001ets",
    triggerdata: triggerdata
});

function postJSON(url, data) {
    let result = fetch(url, {
        method: "POST",
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    });

    return result.json();
}

//