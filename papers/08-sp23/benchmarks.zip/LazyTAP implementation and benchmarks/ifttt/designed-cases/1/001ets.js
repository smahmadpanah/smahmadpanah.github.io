log("##### example 01 is running... #####")

//preamble 
//trigger
var Email = { sendIftttAnEmail: triggerdata }
//query
//action
var actionDefaultValues = {
    "Slack": {
        "postToChannel": {
            "Channel": "Myself",
            "Title": "untitled",
            "Message": "a new email received at " + Email.sendIftttAnEmail.ReceivedAt,
            "TitleUrl": "",
            "ImageUrl": "",
        }
    }
}

var Slack = { postToChannel: { skipped: false } };
Object.assign(Slack.postToChannel, actionDefaultValues['Slack']['postToChannel'])

Slack.postToChannel.setMessage = function(msg = '') {
    if (!this.skipped) {
        this.Message = msg;
        log("SLACK setMessage: ", msg)
    }
}
Slack.postToChannel.setTitle = function(msg = '') {
    if (!this.skipped) {
        this.Title = msg;
        log("SLACK setTitle: ", msg)
    }
}
Slack.postToChannel.skip = function(msg = '') {
    this.skipped = true;
    log("SLACK postToChannel skipped ", msg)
}
// filter code
log("** filter code **")
// [BENCHMARK]: go to ./1/query and modify .From values
if (Email.sendIftttAnEmail.From == "supervisor") {
    Slack.postToChannel.setTitle(Email.sendIftttAnEmail.Subject)
    Slack.postToChannel.setMessage(
        Email.sendIftttAnEmail.Body + '\n' +
        Email.sendIftttAnEmail.AttachmentUrl);
} else if (Email.sendIftttAnEmail.From == 'news') {
    Slack.postToChannel.setTitle("news of the day")
    // Message will be the timestamp of the email, coming from the app config 
} else {
    Slack.postToChannel.skip();
}
log("** end of filter code **")

// post app action 


//result
log("action: ", Slack.postToChannel)
log("##### end of example 01 #####")