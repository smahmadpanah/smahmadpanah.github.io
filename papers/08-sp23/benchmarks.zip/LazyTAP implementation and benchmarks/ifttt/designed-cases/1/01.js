// 01 - app without query (to show our approach works fine and to compare with dynamic minTAP as well) 
// post email to slack if the sender is supervisor/news and skip for spammer

// app config; details below
// trigger: a new Email (Email.sendIftttAnEmail)
// query: -
// action: Slack.postToChannel.setMessage("a new email received at " + Email.sendIftttAnEmail.ReceivedAt)



// app filtercode
if (Email.sendIftttAnEmail.From == "supervisor") {
    Slack.postToChannel.setTitle(Email.sendIftttAnEmail.Subject)
    Slack.postToChannel.setMessage(
        Email.sendIftttAnEmail.Body + '\n' +
        Email.sendIftttAnEmail.AttachmentUrl);
} else if (Email.sendIftttAnEmail.From == 'news') {
    Slack.postToChannel.setTitle("news of the day")
    // Message will be the timestamp of the email, coming from the app config 
} else {
    Slack.postToChannel.skip();
}

/*
- control flow depends on sensitive trigger
- 
    static minTAP: 5 attributes
    dynamic minTAP: zero, 2 or 4 (run independence, skip)
    lazyTAP: 1, 2 or 4 (run indep.)
    no min/ifttt: 7 

*/

/*
"applet": {
            "applet_triggers": [
                {
                "trigger": {
                        "name": "Send IFTTT any email",
                        "ingredients": [
                            {
                                "normalized_name": "Email.sendIftttAnEmail.AttachmentTemporaryUrl"
                            },
                            {
                                "normalized_name": "Email.sendIftttAnEmail.From"
                            },
                            {
                                "normalized_name": "Email.sendIftttAnEmail.Body"
                            },
                            {
                                "normalized_name": "Email.sendIftttAnEmail.BodyHTML"
                            },
                            {
                                "normalized_name": "Email.sendIftttAnEmail.Subject"
                            },
                            {
                                "normalized_name": "Email.sendIftttAnEmail.AttachmentUrl"
                            },
                            {
                                "normalized_name": "Email.sendIftttAnEmail.ReceivedAt"
                            }
                        ]
                    },
                    "fields": []
                }
            ],
            "applet_queries": [],
            "applet_actions": [
                {
                    "action": {
                        "name": "Post to channel",
                        "full_normalized_module_name": "Slack.postToChannel",
                        "action_fields": [
                            {
                                "normalized_module_name": "Channel"
                            },
                            {
                                "normalized_module_name": "Message"
                            },
                            {
                                "normalized_module_name": "Title"
                            },
                            {
                                "normalized_module_name": "TitleUrl"
                            },
                            {
                                "normalized_module_name": "ImageUrl"
                            }
                        ]
                    },
                    "fields": [
                        {
                            "label": "Which channel?",
                            "default_value_json": "Myself"
                        },
                        {
                            "label": "Message",
                            "default_value_json": "a new email received at " + Email.sendIftttAnEmail.ReceivedAt
                        },
                        {
                            "label": "Title",
                            "default_value_json": "untitled"
                        },
                        {
                            "label": "Title URL",
                            "default_value_json": ""
                        },
                        {
                            "label": "Thumbnail URL",
                            "default_value_json": ""
                        }
                    ]
                }
            ],
*/