package com.transpiler;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import spoon.Launcher;
import spoon.reflect.code.CtExpression;
import spoon.reflect.declaration.CtClass;
import spoon.reflect.declaration.CtField;
import spoon.reflect.declaration.CtMethod;
import spoon.reflect.declaration.ModifierKind;
import spoon.reflect.factory.Factory;
import spoon.reflect.reference.CtFieldReference;
import spoon.reflect.reference.CtTypeReference;
import spoon.reflect.code.CtBlock;
import spoon.reflect.code.CtInvocation;
import spoon.reflect.code.CtStatement;
import spoon.support.reflect.code.CtAssignmentImpl;
import spoon.support.reflect.code.CtVariableReadImpl;
import spoon.support.reflect.declaration.CtConstructorImpl;
import spoon.support.reflect.reference.CtFieldReferenceImpl;
import spoon.support.reflect.reference.CtTypeReferenceImpl;

/**
 *
 * @author meseyed
 */
//Assumptions/Limitations:
//- consider JOANA limitations: only primitive fields or user-defined objects
//- the main class must have only one method named "main"
//- no static method in the main method body
//- the main method starts with creation of main objects until it reaches a comment line
//- security labels should be one English letter
//- imports are not preserved in the transformation, must be added manually
//- tested for simple specific programs, not complex ones including different packages
//- an evidence to show it is possible to develop a transformer for transpiling Non-transitive policies into Transitive ones
public class Main {

    private static String pathToProject, mainClass;
    private static ArrayList<String> components = new ArrayList<>();
    private static HashMap<String, ArrayList<String>> fieldOfComponents = new HashMap<>();
    private static HashMap<String, String> componentLabels = new HashMap<>();

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the path to your project: ");
        pathToProject = sc.nextLine();

        File directory = new File(pathToProject);
        File filesList[] = directory.listFiles();
        for (File srcfile : filesList) {
            if (srcfile.isFile() && srcfile.getName().endsWith(".java")) {
                try {
                    transform(srcfile);
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }


        scriptGenerator(directory.getAbsolutePath(), mainClass);

    }

    public static void transform(File srcfile) throws FileNotFoundException {
        String componentName = srcfile.getName().replace(".java", "");
        components.add(componentName);
        fieldOfComponents.put(componentName, new ArrayList<>());

        String src = readFileToString(srcfile);
        System.out.println(srcfile.getName());

        //transformation
        CtClass launcher = Launcher.parseClass(src);
        // it doesn't keep imports!
        Factory factory = launcher.getFactory();
        Collection<CtFieldReference<?>> fields = launcher.getAllFields();
        Iterator<CtFieldReference<?>> iterator = fields.iterator();


        CtStatement initStmt = factory.createInlineComment(
                "initiator"
        );
        //init
        CtMethod initMethod = factory.createMethod();
        initMethod.setSimpleName("initiator");
        initMethod.setType(new CtTypeReferenceImpl().setSimpleName("void"));
        initMethod.setVisibility(ModifierKind.PUBLIC);
        initMethod.setBody(initStmt);
        launcher.addMethod(initMethod);

        //final
        CtStatement finalStmt = factory.createInlineComment(
                "finalizer"
        );
        CtMethod finalMethod = factory.createMethod();
        finalMethod.setSimpleName("finalizer");
        finalMethod.setType(new CtTypeReferenceImpl().setSimpleName("void"));
        finalMethod.setVisibility(ModifierKind.PUBLIC);
        finalMethod.setBody(finalStmt);
        launcher.addMethod(finalMethod);

        while (iterator.hasNext()) {
            CtFieldReference<?> field = iterator.next();

            //for primitive variables
            if (field.getType().isPrimitive()) {

                String varName = field.getSimpleName();
                ArrayList<String> updatedList = fieldOfComponents.get(componentName);
                updatedList.add(varName);
                fieldOfComponents.put(componentName, updatedList);

                CtTypeReference<?> type = field.getType();
                Set<ModifierKind> modifier = field.getModifiers();
                CtExpression<?> assignment = field.getDeclaration().getAssignment();

                CtField<Object> var_source = factory.Core().createField();
                var_source.setType(factory.Code().createCtTypeReference(type.getActualClass()));
                var_source.setModifiers(modifier);
                var_source.setSimpleName(varName + "_source");

                var_source.setAssignment((CtExpression<Object>) assignment);

                CtField<?> var_sink = factory.Core().createField();
                var_sink.setType(factory.Code().createCtTypeReference(type.getActualClass()));
                var_sink.setModifiers(modifier);
                var_sink.setSimpleName(varName + "_sink");

                CtField<?> var_original = factory.Core().createField();
                var_original.setType(factory.Code().createCtTypeReference(type.getActualClass()));
                var_original.setModifiers(modifier);
                var_original.setSimpleName(varName + "");

                launcher.removeField(field.getDeclaration());
                launcher.addField(0, var_sink);
                launcher.addField(0, var_original);
                launcher.addField(0, var_source);

                //init 
                CtAssignmentImpl initAssignment = new CtAssignmentImpl();
                initAssignment.setAssigned(new CtVariableReadImpl().setVariable(var_original.getReference()));
                initAssignment.setAssignment(new CtVariableReadImpl().setVariable(var_source.getReference()));
                initMethod.getBody().addStatement(initAssignment);

                //final
                CtAssignmentImpl finalAssignment = new CtAssignmentImpl();
                finalAssignment.setAssigned(new CtVariableReadImpl().setVariable(var_sink.getReference()));
                finalAssignment.setAssignment(new CtVariableReadImpl().setVariable(var_original.getReference()));
                finalMethod.getBody().addStatement(finalAssignment);
            } else {
                //invoking finalizers for non-primitve fields (objects)
                CtInvocation<Object> finalInvocation = factory.createInvocation();
                CtVariableReadImpl vr = new CtVariableReadImpl();
                vr.setVariable(field);
                finalInvocation.setTarget(vr);
                finalInvocation.setExecutable(finalMethod.getReference());
                finalInvocation.setArguments(new ArrayList<>());
                finalMethod.getBody().addStatement(finalInvocation);
            }

        }

        //invoke init at the beginning of constructor 
        CtConstructorImpl constructor = (CtConstructorImpl) launcher.getConstructors().iterator().next();
        //assumption: only one constructor per class
        CtInvocation<Object> initInvocation = factory.createInvocation();
        initInvocation.setTarget(null);
        initInvocation.setExecutable(initMethod.getReference());
        initInvocation.setArguments(new ArrayList<>());

        constructor.getBody().addStatement(0, initInvocation);

        //if main class, then call finalizer at the end of the main method
        if (!launcher.getMethodsByName("main").isEmpty()) {
            mainClass = launcher.getSimpleName();
            CtMethod mainMethod = (CtMethod) launcher.getMethodsByName("main").get(0);
            CtBlock mainBody = mainMethod.getBody();

            //we assume that the first lines before comment in the main method 
            //initiates the main objects...(otherwise, we had to deal with static
            //methods and objects...
            ArrayList<CtFieldReference<?>> mainObjects = new ArrayList<>();
            boolean commentStmt = false;
            Iterator<CtStatement> stmtIterator = mainBody.getStatements().iterator();
            while (!commentStmt) {
                CtStatement stmt = stmtIterator.next();
                if (!stmt.getComments().isEmpty()) {
                    commentStmt = true;
                    break;
                }
                CtFieldReference<?> varName = new CtFieldReferenceImpl<Object>();
                varName.setSimpleName(stmt.toString().split("=")[0].split(" ")[1]);
                mainObjects.add(varName);

            }
            for (CtFieldReference obj : mainObjects) {
                CtInvocation<Object> finalInvocation = factory.createInvocation();
                CtVariableReadImpl vr = new CtVariableReadImpl();
                vr.setVariable(obj);
                finalInvocation.setTarget(vr);
                finalInvocation.setExecutable(finalMethod.getReference());
                finalInvocation.setArguments(new ArrayList<>());
                mainMethod.getBody().addStatement(finalInvocation);
            }
        }

        String transformedCode = launcher.toString();
        transformedCode = "import java.util.*; \n\n\n" + transformedCode;
        System.out.println(transformedCode);
        writeStringToFile(pathToProject + "-transformed/", srcfile.getName(), transformedCode);
    }

    //read file and return it as string
    public static String readFileToString(File src) {
        BufferedReader reader;
        String content = null;
        try {
            reader = new BufferedReader(new FileReader(src.getAbsolutePath()));

            StringBuilder stringBuilder = new StringBuilder();
            String line = null;
            String ls = System.getProperty("line.separator");
            try {
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line);
                    stringBuilder.append(ls);
                }
            } catch (IOException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }
            // delete the last new line separator
            stringBuilder.deleteCharAt(stringBuilder.length() - 1);
            reader.close();
            content = stringBuilder.toString();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }

        return content;
    }

    //write string to file
    public static void writeStringToFile(String path, String filename, String content) {
        try {
            File file = new File(path);
            file.mkdir();
            String fullpath = path + filename;

            FileWriter myWriter = new FileWriter(fullpath);
            myWriter.write(content);
            myWriter.close();
            System.out.println("Successfully has been written to " + fullpath);
        } catch (IOException e) {
            System.out.println("An error occurred!");
            e.printStackTrace();
        }
    }

    //script generator for JOANA flow-sensitive information-flow control analysis
    //https://pp.ipd.kit.edu/projects/joana/
    public static void scriptGenerator(String path, String mainClass) {
        //script boilerplate

        File f = new File(path);
        path = f.getParentFile().getParentFile().getAbsolutePath();
        String script = "setClasspath " + path + "\n"//-transformed\n"
                + "searchEntries\n"
                + "selectEntry " + mainClass + ".main([Ljava/lang/String;)V\n"
                + "buildSDG\n";
//                + "saveSDG " + path + ".pdg\n";
        Scanner sc = new Scanner(System.in);
        HashMap<String, ArrayList<String>> canFlowTo = new HashMap<>();
        ArrayList<String> labels = new ArrayList<>();
        //labeling components
        for (String cmp : components) {
            System.out.println("enter the security label for component " + cmp + ":");
            String lbl = sc.nextLine();
            labels.add(lbl);
            componentLabels.put(cmp, lbl);
            ArrayList<String> self = new ArrayList<String>();
            self.add(lbl);
            canFlowTo.put(lbl, self);
        }


        //build powerset lattice
        String transitiveFlow = "";
        Set<Set<String>> pwset = buildPowerset(new HashSet<>(labels));
        for (Set<String> set1 : pwset) {
            for (Set<String> set2 : pwset) {
                if (set2.containsAll(set1) && set1.size() == set2.size() - 1) {
                    char[] leftCharArr = String.join("", set1).toCharArray();
                    Arrays.sort(leftCharArr);
                    String left = new String(leftCharArr);

                    if (set1.isEmpty()) {
                        left = "e";
                    }
                    char[] rightCharArr = String.join("", set2).toCharArray();
                    Arrays.sort(rightCharArr);
                    String right = new String(rightCharArr);
                    transitiveFlow += left + "<=" + right + ",";
                }
            }
        }
        transitiveFlow = transitiveFlow.substring(0, transitiveFlow.length() - 1);//delete last ,
        script += "setLattice " + transitiveFlow + "\n";

        //flow specification
        System.out.println("specify the non-transitive security flows: (e.g., A -> B in each line)");
        boolean done = false;
        while (!done) {
            String nextLine = sc.nextLine();
            if (!nextLine.equals("")) {
                String[] flow = nextLine.split("->", 2);
                ArrayList<String> crnt = canFlowTo.get(flow[1]);
                crnt.add(flow[0]);
                canFlowTo.put(flow[1], crnt);
            } else {
                done = true;
            }
        }

        for (Map.Entry<String, ArrayList<String>> entry : canFlowTo.entrySet()) {
            Collections.sort(entry.getValue());
        }

        System.out.println(canFlowTo);

        //labeling source and sink variables for each component
        for (String cmp : components) {
            for (String fld : fieldOfComponents.get(cmp)) {
                script += "source " + cmp + "." + fld + "_source " + componentLabels.get(cmp) + "\n";
                script += "sink " + cmp + "." + fld + "_sink " + String.join("", canFlowTo.get(componentLabels.get(cmp))) + "\n";
            }
        }

        //run analysis
        script += "run classical-ni\n";
        System.out.println(script);
        writeStringToFile(pathToProject, "-script.txt", script);

    }

    public static Set<Set<String>> buildPowerset(Set<String> originalSet) {
        Set<Set<String>> sets = new HashSet<Set<String>>();
        if (originalSet.isEmpty()) {
            sets.add(new HashSet<String>());
            return sets;
        }
        List<String> list = new ArrayList<String>(originalSet);
        Collections.sort(list);
        String head = list.get(0);
        Set<String> rest = new HashSet<String>(list.subList(1, list.size()));
        for (Set<String> set : buildPowerset(rest)) {
            Set<String> newSet = new HashSet<String>();
            newSet.add(head);
            newSet.addAll(set);
            sets.add(newSet);
            sets.add(set);
        }
        return sets;
    }

}
