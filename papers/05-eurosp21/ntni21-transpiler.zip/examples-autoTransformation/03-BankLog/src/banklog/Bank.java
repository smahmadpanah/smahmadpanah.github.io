/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banklog;

/**
 *
 * @author Mohammad
 */
public class Bank {

    private int id = 20;
    private int balance = 100;

    public Bank() {
    }

    public int getBalance(int x) {
        if (x == id) {
            return balance;
        }
        return 0;
    }
}
