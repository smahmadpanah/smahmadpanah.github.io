/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banklog;

/**
 *
 * @author Mohammad
 */
public class BankLog {

    /**
     * @param args the command line arguments
     */
    private int userId = 20, balance;
    private Bank b;
    private Logger l;

    public BankLog() {
        b = new Bank();
        l = new Logger();
    }

    public static void main(String[] args) {
        BankLog bl = new BankLog();
        //
        bl.operation();
    }

    private void operation() {
        balance = b.getBalance(userId);
        if (balance > 0) { //implicit flow
            l.add(userId);
        }
    }

}
