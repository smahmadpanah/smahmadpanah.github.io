/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banklog;

import java.util.ArrayList;

/**
 *
 * @author Mohammad
 */
public class Logger {

    private static int logFile;

    public Logger() {
    }

    public void add(int x) {
        logFile += x;
    }

}
