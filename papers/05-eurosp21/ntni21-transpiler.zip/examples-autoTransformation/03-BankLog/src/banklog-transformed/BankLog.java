import java.util.*; 


/* To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
 */
/**
 *
 *
 * @author Mohammad
 */
public class BankLog {
    private int balance_source;

    private int balance;

    private int balance_sink;

    private int userId_source = 20;

    private int userId;

    private int userId_sink;

    private Bank b;

    private Logger l;

    public BankLog() {
        initiator();
        b = new Bank();
        l = new Logger();
    }

    public static void main(String[] args) {
        BankLog bl = new BankLog();
        // 
        bl.operation();
        bl.finalizer();
    }

    private void operation() {
        balance = b.getBalance(userId);
        if (balance > 0) {
            // implicit flow
            l.add(userId);
        }
    }

    public void initiator() {
        // initiator
        userId = userId_source;
        balance = balance_source;
    }

    public void finalizer() {
        // finalizer
        userId_sink = userId;
        balance_sink = balance;
        b.finalizer();
        l.finalizer();
    }
}