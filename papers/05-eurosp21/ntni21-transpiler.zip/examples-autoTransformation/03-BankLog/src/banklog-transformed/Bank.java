import java.util.*; 


/* To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
 */
/**
 *
 *
 * @author Mohammad
 */
public class Bank {
    private int balance_source = 100;

    private int balance;

    private int balance_sink;

    private int id_source = 20;

    private int id;

    private int id_sink;

    public Bank() {
        initiator();
    }

    public int getBalance(int x) {
        if (x == id) {
            return balance;
        }
        return 0;
    }

    public void initiator() {
        // initiator
        id = id_source;
        balance = balance_source;
    }

    public void finalizer() {
        // finalizer
        id_sink = id;
        balance_sink = balance;
    }
}