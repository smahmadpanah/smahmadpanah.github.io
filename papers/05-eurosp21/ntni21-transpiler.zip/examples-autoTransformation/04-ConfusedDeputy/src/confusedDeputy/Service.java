package confusedDeputy;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mohammad
 */
public class Service {
    private int logFile = 0;
    private Library library;

    public Service() {
        library = new Library();
    }
    
    public void addLog(int x, int y){
        logFile += x + y ;
    }
    
    public void print(int data){
        library.process(data);
    }
    
    public int query(int key){
        return library.retrieve(key);
    }
    
    
}
