package confusedDeputy;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mohammad
 */
public class Library {
    
    private int someValue = 5;
    private int printValue = 0;

    public Library() {
        
    }
    
    
    public void process(int src){
        printValue = src;
    }
    
    public int retrieve(int key){
        return someValue;
    }
    
    
}
