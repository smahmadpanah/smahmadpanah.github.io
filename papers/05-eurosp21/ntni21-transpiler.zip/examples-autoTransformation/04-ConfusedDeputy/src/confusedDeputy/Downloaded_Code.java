package confusedDeputy;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mohammad
 */
public class Downloaded_Code {

    private int data = 7;
    private int key = 4;
    private int result;
    private Service service;

    public Downloaded_Code() {
        service = new Service();
    }

    public static void main(String[] args) {
        Downloaded_Code dc = new Downloaded_Code();
        //
        dc.operation();

    }

    private void operation() {
        service.addLog(data, key);
        service.print(data);
        result = service.query(key);
    }
}
