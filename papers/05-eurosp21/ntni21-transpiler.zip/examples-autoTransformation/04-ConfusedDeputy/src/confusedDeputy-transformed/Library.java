import java.util.*; 


/* To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
 */
/**
 *
 *
 * @author Mohammad
 */
public class Library {
    private int printValue_source = 0;

    private int printValue;

    private int printValue_sink;

    private int someValue_source = 5;

    private int someValue;

    private int someValue_sink;

    public Library() {
        initiator();
    }

    public void process(int src) {
        printValue = src;
    }

    public int retrieve(int key) {
        return someValue;
    }

    public void initiator() {
        // initiator
        someValue = someValue_source;
        printValue = printValue_source;
    }

    public void finalizer() {
        // finalizer
        someValue_sink = someValue;
        printValue_sink = printValue;
    }
}