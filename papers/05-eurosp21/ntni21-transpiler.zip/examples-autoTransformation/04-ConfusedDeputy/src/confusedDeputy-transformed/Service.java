import java.util.*; 


/* To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
 */
/**
 *
 *
 * @author Mohammad
 */
public class Service {
    private int logFile_source = 0;

    private int logFile;

    private int logFile_sink;

    private Library library;

    public Service() {
        initiator();
        library = new Library();
    }

    public void addLog(int x, int y) {
        logFile += x + y;
    }

    public void print(int data) {
        library.process(data);
    }

    public int query(int key) {
        return library.retrieve(key);
    }

    public void initiator() {
        // initiator
        logFile = logFile_source;
    }

    public void finalizer() {
        // finalizer
        logFile_sink = logFile;
        library.finalizer();
    }
}