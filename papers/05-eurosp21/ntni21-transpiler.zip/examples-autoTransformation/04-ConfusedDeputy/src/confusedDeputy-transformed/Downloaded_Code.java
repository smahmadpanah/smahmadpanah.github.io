import java.util.*; 


/* To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
 */
/**
 *
 *
 * @author Mohammad
 */
public class Downloaded_Code {
    private int result_source;

    private int result;

    private int result_sink;

    private int key_source = 4;

    private int key;

    private int key_sink;

    private int data_source = 7;

    private int data;

    private int data_sink;

    private Service service;

    public Downloaded_Code() {
        initiator();
        service = new Service();
    }

    public static void main(String[] args) {
        Downloaded_Code dc = new Downloaded_Code();
        // 
        dc.operation();
        dc.finalizer();
    }

    private void operation() {
        service.addLog(data, key);
        service.print(data);
        result = service.query(key);
    }

    public void initiator() {
        // initiator
        data = data_source;
        key = key_source;
        result = result_source;
    }

    public void finalizer() {
        // finalizer
        data_sink = data;
        key_sink = key;
        result_sink = result;
        service.finalizer();
    }
}