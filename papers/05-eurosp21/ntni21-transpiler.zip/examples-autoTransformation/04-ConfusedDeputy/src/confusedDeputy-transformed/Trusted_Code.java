import java.util.*; 


/* To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
 */
/**
 *
 *
 * @author Mohammad
 */
public class Trusted_Code {
    public void initiator() {
        // initiator
    }

    public void finalizer() {
        // finalizer
    }
}