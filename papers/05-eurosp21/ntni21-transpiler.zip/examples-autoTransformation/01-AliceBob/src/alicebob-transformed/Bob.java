import java.util.*; 


/* To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
 */
/**
 *
 *
 * @author Mohammad
 */
public class Bob {
    private int data_source;

    private int data;

    private int data_sink;

    private int secret_source = 100;

    private int secret;

    private int secret_sink;

    public Bob() {
        initiator();
    }

    public void receive(int x) {
        data = x;
        // System.out.println("Bob.receive: " + data);
        // res = data1 + "";
    }

    public int getSecret() {
        return secret;
    }

    public void initiator() {
        // initiator
        secret = secret_source;
        data = data_source;
    }

    public void finalizer() {
        // finalizer
        secret_sink = secret;
        data_sink = data;
    }
}