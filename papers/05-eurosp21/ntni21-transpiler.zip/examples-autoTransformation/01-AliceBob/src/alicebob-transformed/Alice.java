import java.util.*; 


/* To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
 */
/**
 *
 *
 * @author Mohammad
 */
public class Alice {
    private int data_source = 10;

    private int data;

    private int data_sink;

    private Bob bob;

    public Alice() {
        initiator();
        bob = new Bob();
    }

    public static void main(String[] args) {
        Alice a = new Alice();
        // 
        a.sendDataToBob();
        a.finalizer();
    }

    public void sendDataToBob() {
        bob.receive(data);
        if (bob.getSecret() > data) {
            data++;
        }
    }

    public void initiator() {
        // initiator
        data = data_source;
    }

    public void finalizer() {
        // finalizer
        data_sink = data;
        bob.finalizer();
    }
}