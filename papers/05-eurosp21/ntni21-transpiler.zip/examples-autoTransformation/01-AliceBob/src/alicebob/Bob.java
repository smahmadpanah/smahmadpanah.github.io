/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alicebob;

/**
 *
 * @author Mohammad
 */
public class Bob {

    private int secret = 100;
    private int data;

    public Bob() {
    }

    public void receive(int x) {
        data = x;
//        System.out.println("Bob.receive: " + data);
//        res = data1 + "";
    }

    public int getSecret() {
        return secret;
    }
}
