import java.util.*; 


/* To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
 */
/**
 *
 *
 * @author Mohammad
 */
public class Charlie {
    private int data_source;

    private int data;

    private int data_sink;

    public Charlie() {
        initiator();
    }

    public void receive(int x) {
        data = x;
    }

    public void initiator() {
        // initiator
        data = data_source;
    }

    public void finalizer() {
        // finalizer
        data_sink = data;
    }
}