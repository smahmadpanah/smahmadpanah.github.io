import java.util.*; 


/* To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
 */
/**
 *
 *
 * @author Mohammad
 */
public class Bob {
    private int data2_source = 42;

    private int data2;

    private int data2_sink;

    private int data1_source = 0;

    private int data1;

    private int data1_sink;

    private Charlie c;

    public Bob() {
        initiator();
        c = new Charlie();
    }

    public void receive(int x) {
        data1 = x;
    }

    public void good() {
        c.receive(data2);
    }

    public void bad() {
        c.receive(data1);
    }

    public void initiator() {
        // initiator
        data1 = data1_source;
        data2 = data2_source;
    }

    public void finalizer() {
        // finalizer
        data1_sink = data1;
        data2_sink = data2;
        c.finalizer();
    }
}