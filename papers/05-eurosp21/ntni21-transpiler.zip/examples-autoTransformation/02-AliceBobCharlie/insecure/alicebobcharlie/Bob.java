/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alicebobcharlie;

/**
 *
 * @author Mohammad
 */
public class Bob {
    private int data1 = 0, data2 = 42;
    
    private Charlie c;
    public Bob() {
        c = new Charlie();
    }
    
    public void receive(int x){
        data1 = x;
    }
    
    public void good(){
        c.receive(data2);
    }
    
    public void bad(){
        c.receive(data1);
    }   
    
}
