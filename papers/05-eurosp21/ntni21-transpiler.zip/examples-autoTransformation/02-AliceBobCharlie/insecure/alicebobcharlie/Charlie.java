/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alicebobcharlie;

/**
 *
 * @author Mohammad
 */
public class Charlie {
    
    private int data;
    public Charlie() {
    }
    
    public void receive(int x){
        data = x;
    }  
}
