import java.util.*; 


/* To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
 */
// import java.util.Scanner;
/**
 *
 *
 * @author Mohammad
 */
public class Alice {
    private int data_source = 13;

    private int data;

    private int data_sink;

    private Bob bob;

    public Alice() {
        initiator();
        bob = new Bob();
    }

    /**
     *
     *
     * @param args
     * 		the command line arguments
     */
    public static void main(String[] args) {
        Alice a = new Alice();
        // 
        a.operation();
        a.finalizer();
    }

    private void operation() {
        bob.receive(data);
        bob.good();
        // bob.bad();
    }

    public void initiator() {
        // initiator
        data = data_source;
    }

    public void finalizer() {
        // finalizer
        data_sink = data;
        bob.finalizer();
    }
}