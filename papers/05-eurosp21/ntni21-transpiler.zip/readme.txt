• Transpiler: the source code of the transpiler, written in Java
	- When you run the program, it gets a path to the Java project you want to analyze. Then, it transforms the program into the canonical version.
	- Next, you define the security labels for the components (classes), and it builds the power-lattice. 
	- Then, you specify the nontransitive flows in the form of "A->B" line by line. 
	- After that, you can find the transformed version and the JOANA script next to the program's source code. 
	- Finally, you run the script in JOANA and will see the result of the flow-sensitive analysis. 

• examples-autoTransformation: contains the following items per case:
	- the source code, 
	- the nontransitive policy, 
	- the canonical version, 
	- the generated script, and 
	- the analysis result
