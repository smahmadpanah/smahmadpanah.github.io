//simplest digest of the snippet
var input = document.getElementById("search-input");
var url = "https://search-engine.com/q=?"
url = encodeURIComponent(url + input)
window.open(url);


// snippets from the source code
var input = document.getElementById("search-input");
var form = document.getElementById("search-form");

var isExtension = (window.chrome && chrome.runtime);


// various search sinks...
var openURL = function(url, newTab) {
		if (newTab) {
			if (isExtension) {
				chrome.runtime.sendMessage({openURL: url});
			} else {
				window.open(url);
			}

		} else {
			location.href = url;
		}
	};

	var serializeForm = function() {
		var url = form.action;
		url += (form.action.indexOf('?') >= 0) ? '&' : '?';
		var inputs = form.getElementsByTagName('input');
		var params = [];
		for (var i = 0; i < inputs.length; i++) {
			params.push(encodeURIComponent(inputs[i].name) + '=' + encodeURIComponent(inputs[i].value));
		}
		url += params.join('&');
		return url;
	};

	var submitForm = function(newTab) {
		var url = serializeForm();
		openURL(url, newTab);
	};
