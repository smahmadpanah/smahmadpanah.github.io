function getRandomInt(_min, _max) {
  const min = Math.ceil(_min);
  const max = Math.floor(_max);
  return Math.floor(Math.random() * (max - min)) + min;
}

const hours = new Date().getHours();
let time = 'morning';
if (hours >= 9 && hours < 16) time = 'day';
if (hours < 3 || hours >= 16) time = 'night';

$('#bg-img').attr('src', `backgrounds/${time}/${getRandomInt(1, 5)}.jpg`);

const searchSubmit = () => {
  const urlquery = encodeURIComponent($('#q').val());
  if (urlquery !== '') {
    window.location.href = `https://search.akordis.net/search?q=${urlquery}`;
  }
  return false;
};

function updDate() {
  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const acceptUi = function () {
    const date = new Date();
    const minutes = (date.getMinutes()).toString();
    const hours = date.getHours();
    $('#clock').text(`${hours}:${minutes.length === 1 ? `0${minutes}` : minutes}`);
    $('#date').html(`${days[date.getDay()]}, ${months[date.getMonth()]} ${date.getDate()}`);
  };
  acceptUi();
  setInterval(() => {
    acceptUi();
  }, 29e3);
}

$('#search').submit(searchSubmit);
$('#search-button').click(searchSubmit);
updDate();