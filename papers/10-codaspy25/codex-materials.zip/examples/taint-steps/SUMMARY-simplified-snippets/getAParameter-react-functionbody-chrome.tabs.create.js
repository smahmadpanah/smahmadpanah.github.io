// getAParameter
// extension: bkiakepgpgfibglghlhdpacjdglfpbnn.0_0_4_0
// file: popup.js


// simplest
// taint step: succ = pred.(DataFlow::FunctionNode).getAParameter()
const searchInput = (event) => {
    if (event.key === "Enter") {
        chrome.tabs.create({url: `https://www.google.com/search?q=${event.target.value}`});
    }
};

react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", {
  type: "text",
  placeholder: "Search Google",
  className: "search-input",
  onKeyDown: searchInput
})


// CodeQL path
/*
1. (event) => {
        if (event.key === "Enter") {
            chrome.tabs.create({
                url: `https://www.google.com/search?q=${event.target.value}`,
            });
            event.target.value = "";
        }
    }

2. event

3. event.target

4. event.target.value

5. `https://www.google.com/search?q=${event.target.value}`

6. {url: `https://www.google.com/search?q=${event.target.value}`,} // the arg of chrome.tabs.create
*/


// snippet
const searchInput = (event) => {
    if (event.key === "Enter") {
        chrome.tabs.create({
            url: `https://www.google.com/search?q=${event.target.value}`,
        });
        event.target.value = "";
    }
};

react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", {
  type: "text",
  placeholder: "Search Google",
  className: "search-input",
  onKeyDown: searchInput
})


// -------------------------------------------------- //


// another example
// extension: ccodppdikeappapgcfaikfnnljpgkgcm.0_1_8_0
// file: background.js

chrome.history.search( { text: "mytensai.com/install-ext?pid=" }, function(historyItems) {
      if(historyItems.length>0){
        for (var i = 0; i < historyItems.length; ++i) {
          if(null!==getParameterByName('pid', historyItems[i].url) && getParameterByName('clickid', historyItems[i].url) ){
            
            var pid = getParameterByName('pid', historyItems[i].url);
            var clickid = getParameterByName('clickid', historyItems[i].url);
            chrome.storage.sync.set({'pid':pid,'clickid': clickid});
            //_gaq.push(['_trackEvent', clickid, 'clicked']);

            var url = 'https://mytensai.com/mth/installTrack.php?pid='+pid+'&clickid='+clickid;
            fetch(url).then(function(response) {
                          return response.json();
                        }).then(function(data) {
                          console.log(data);
                        }).catch(function() {
                          console.log("Booo");
                        });
            //HttpRequest(pid,clickid);
            return;
          }
        }
      }else{
        chrome.storage.sync.set({'pid':'pid','clickid': 'clickid'});
      }
    });
