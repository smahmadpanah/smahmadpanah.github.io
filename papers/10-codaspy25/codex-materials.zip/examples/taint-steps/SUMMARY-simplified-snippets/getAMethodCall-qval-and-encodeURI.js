// getAMethodCall-and-getAnArgument
// extension: agpoehmhgoieigdbjhgphpagmloehamn.2_0_0_0
// file: newtab.js


// simplest
// taint step: succ = pred.(DataFlow::InvokeNode).getAMethodCall()
const searchInputValue = $('#search-input').val()
// taint step: pred = succ.(DataFlow::InvokeNode).getAnArgument()
const urlSearchTerm = encodeURIComponent(searchInputValue);
// url taint contextual flows merged
const searchEngineURL = `https://search.akordis.net/search?q=${urlquery}`
// taint sink: exists(DataFlow::PropWrite w | w.(DataFlow::PropWrite).getPropertyName() = "href") and sink = w.getRhs()
window.location.href = searchEngineURL;


// snippet
const searchSubmit = () => {
  const urlquery = encodeURIComponent($('#q').val());
  if (urlquery !== '') {
    window.location.href = `https://search.akordis.net/search?q=${urlquery}`;
  }
  return false;
};

$('#search').submit(searchSubmit);
$('#search-button').click(searchSubmit);


// -------------------------------------------------- //


// another example
// extension: dpngnogjeefnipdphklffjmcnohjdoln.0_65_0_0
// file: js/content.js

function handleEnterKey() {
  var text = $("#uniq0").val();
  _gaq.push(['send', 'event', 'Search Field', 'Search', $("#uniq0").val()]);
  if (!(popupSelectedItem < 0 || $("#popup").css("display") == "none"))
  {
    if ($("#hints-list").children().eq(popupSelectedItem).attr("url").length > 0) {
      window.location.href = $("#hints-list").children().eq(popupSelectedItem).attr("url");
      return;
    }

    text = $("#hints-list").children().eq(popupSelectedItem).text();
  }
  window.location.href = "https://yandex.ru/search/?text=" + encodeURIComponent(text) + "&clid=2258262";
}
