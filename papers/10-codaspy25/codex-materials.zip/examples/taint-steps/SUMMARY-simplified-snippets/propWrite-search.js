// propWrite
// extension: cfmnkhhioonhiehehedmnjibmampjiab.7_3_0_0
// file: js/background.js


// simplest
var STARTME_SEARCH_PAGE_PATTERN = 'https://start.me/search/google-startme?q={query}';

chrome.omnibox.onInputEntered.addListener(function (text) {
    url = STARTME_SEARCH_PAGE_PATTERN.replace('{query}', encodeURIComponent(text));
    chrome.tabs.update(tabs[0].id, { url: url });
}

// if we remove the line below from Additional Taint Steps, the flow will not be detected anymore!
// exists(DataFlow::PropWrite propWrite |
//       propWrite.writes(succ, _, pred)
// )
// because the argument of the sink chrome.tabs.update is an object {url: url}, that only the property url of the object is tainted. so we assume the whole object is tainted to find the flow...


// snippet
var STARTME_SEARCH_PAGE_PATTERN = 'https://start.me/search/google-startme?q={query}';

...

chrome.omnibox.onInputEntered.addListener(function (text) {
  chrome.tabs.query({
    active: true,
    currentWindow: true
  }).then(function (tabs) {
    if (tabs.length != 1) return;
    var url;
    if (SM_HTTP_URL_PATTERN.test(text)) url = text;else url = STARTME_SEARCH_PAGE_PATTERN.replace('{query}', encodeURIComponent(text));
    chrome.tabs.update(tabs[0].id, {
      url: url
    });
  });
});
