/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/css-loader/dist/cjs.js!./src/popup/components/ChatGpt/index.css":
/*!**************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/popup/components/ChatGpt/index.css ***!
  \**************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".chat-gpt-tab-container {\r\n  height: 98.5vh;\r\n  width: 380px;\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n  align-items: center;\r\n  margin-left: 5.5px;\r\n  margin-top: 5.5px;\r\n  background: rgba(0, 0, 0, 0.75);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(3.5px);\r\n  -webkit-backdrop-filter: blur(3.5px);\r\n  border-radius: 10px;\r\n}\r\n.chat-gpt-tab-container-error-msg {\r\n  background: rgba(0, 0, 0, 0.75);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(3.5px);\r\n  -webkit-backdrop-filter: blur(3.5px);\r\n  border-radius: 10px;\r\n  height: 98.5vh;\r\n  width: 380px;\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n  align-items: center;\r\n  padding: 10px;\r\n  margin-left: 5.5px;\r\n  margin-top: 5.5px;\r\n}\r\n.error-msg-iframe {\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 15px;\r\n  color: #fff;\r\n  padding: 11px;\r\n  text-align: center;\r\n  margin-top: 15px;\r\n}\r\n.chat-gpt-error-img {\r\n  width: 200px;\r\n  height: 200px;\r\n}\r\n.chat-gpt-link {\r\n  color: #c1b7ff;\r\n  text-decoration: underline;\r\n  text-decoration-color: #c1b7ff;\r\n}\r\n", "",{"version":3,"sources":["webpack://./src/popup/components/ChatGpt/index.css"],"names":[],"mappings":"AAAA;EACE,cAAc;EACd,YAAY;EACZ,aAAa;EACb,sBAAsB;EACtB,uBAAuB;EACvB,mBAAmB;EACnB,kBAAkB;EAClB,iBAAiB;EACjB,+BAA+B;EAC/B,gDAAgD;EAChD,4BAA4B;EAC5B,oCAAoC;EACpC,mBAAmB;AACrB;AACA;EACE,+BAA+B;EAC/B,gDAAgD;EAChD,4BAA4B;EAC5B,oCAAoC;EACpC,mBAAmB;EACnB,cAAc;EACd,YAAY;EACZ,aAAa;EACb,sBAAsB;EACtB,uBAAuB;EACvB,mBAAmB;EACnB,aAAa;EACb,kBAAkB;EAClB,iBAAiB;AACnB;AACA;EACE,qBAAqB;EACrB,gBAAgB;EAChB,eAAe;EACf,WAAW;EACX,aAAa;EACb,kBAAkB;EAClB,gBAAgB;AAClB;AACA;EACE,YAAY;EACZ,aAAa;AACf;AACA;EACE,cAAc;EACd,0BAA0B;EAC1B,8BAA8B;AAChC","sourcesContent":[".chat-gpt-tab-container {\r\n  height: 98.5vh;\r\n  width: 380px;\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n  align-items: center;\r\n  margin-left: 5.5px;\r\n  margin-top: 5.5px;\r\n  background: rgba(0, 0, 0, 0.75);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(3.5px);\r\n  -webkit-backdrop-filter: blur(3.5px);\r\n  border-radius: 10px;\r\n}\r\n.chat-gpt-tab-container-error-msg {\r\n  background: rgba(0, 0, 0, 0.75);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(3.5px);\r\n  -webkit-backdrop-filter: blur(3.5px);\r\n  border-radius: 10px;\r\n  height: 98.5vh;\r\n  width: 380px;\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n  align-items: center;\r\n  padding: 10px;\r\n  margin-left: 5.5px;\r\n  margin-top: 5.5px;\r\n}\r\n.error-msg-iframe {\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 15px;\r\n  color: #fff;\r\n  padding: 11px;\r\n  text-align: center;\r\n  margin-top: 15px;\r\n}\r\n.chat-gpt-error-img {\r\n  width: 200px;\r\n  height: 200px;\r\n}\r\n.chat-gpt-link {\r\n  color: #c1b7ff;\r\n  text-decoration: underline;\r\n  text-decoration-color: #c1b7ff;\r\n}\r\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/popup/components/History/index.css":
/*!**************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/popup/components/History/index.css ***!
  \**************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".history-tab-container {\r\n  width: 380px;\r\n  background: rgba(0, 0, 0, 0.75);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(3.5px);\r\n  -webkit-backdrop-filter: blur(3.5px);\r\n  border-radius: 10px;\r\n  height: 98.5vh;\r\n  border-radius: 12px;\r\n  margin-left: 5.5px;\r\n  overflow-y: scroll;\r\n  margin-top: 5.5px;\r\n}\r\n.search-history-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  justify-content: space-around;\r\n  box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;\r\n  border-radius: 10px;\r\n  margin-top: 10px;\r\n  border: 1px solid rgba(255, 255, 255, 0.18);\r\n}\r\n\r\n.search-icon {\r\n  width: 20px;\r\n  height: 20px;\r\n  font-weight: 600;\r\n  margin-left: 10px;\r\n  color: #fff;\r\n}\r\n\r\n.history-search-input {\r\n  width: 280px;\r\n  height: 42px;\r\n  outline: none;\r\n  border: none;\r\n  background-color: transparent;\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 16px;\r\n  color: #fff;\r\n}\r\n.while-searching {\r\n  opacity: 0.5;\r\n  transition: opacity 0.5s ease-in-out;\r\n}\r\n.history-suggestions-container {\r\n  padding-left: 10px;\r\n}\r\n.show-history {\r\n  box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;\r\n  border-radius: 10px;\r\n  padding-top: 10px;\r\n  padding-bottom: 10px;\r\n}\r\n.history-suggestion-icon {\r\n  width: 19px;\r\n  height: 19px;\r\n  margin-right: 12px;\r\n}\r\n.history-suggestion-link {\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 14px;\r\n  color: #fff;\r\n  text-decoration: none;\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\r\n}\r\n.each-history-suggestion {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  margin-top: 10px;\r\n  width: 300px;\r\n}\r\n.history-bottom-bar {\r\n  padding: 12px;\r\n}\r\n\r\n.recently-closed-container {\r\n  margin-top: 20px;\r\n}\r\n.recently-closed-heading {\r\n  font-family: \"roboto\";\r\n  font-weight: 600;\r\n  font-size: 15px;\r\n  color: #fff;\r\n}\r\n.recent-history {\r\n  padding-left: 10px;\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  margin-top: 10px;\r\n}\r\n.recent-history-icon {\r\n  width: 18px;\r\n  height: 18px;\r\n  margin-right: 12px;\r\n}\r\n.recent-history-title {\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 14.8px;\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\r\n}\r\n.history-container {\r\n  margin-top: 22px;\r\n}\r\n.history-header {\r\n  font-family: \"roboto\";\r\n  font-weight: 600;\r\n  font-size: 15px;\r\n  color: #fff;\r\n}\r\n.history {\r\n  padding-left: 10px;\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  margin-top: 11.5px;\r\n}\r\n.history-icon {\r\n  width: 18px;\r\n  height: 18px;\r\n  margin-right: 12px;\r\n}\r\n.history-title {\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 14.8px;\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\r\n}\r\n.open-full-history-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  padding: 8px;\r\n  justify-content: space-between;\r\n  align-items: center;\r\n  border-radius: 8px;\r\n  border: 1px solid #626363;\r\n  margin-top: 20px;\r\n  margin-bottom: 12px;\r\n  cursor: pointer;\r\n}\r\n.open-full-history {\r\n  outline: none;\r\n  border: none;\r\n  font-family: \"roboto\";\r\n  font-weight: 600;\r\n  font-size: 17px;\r\n  background-color: transparent;\r\n  color: #fff;\r\n}\r\n.open-full-history-icon {\r\n  width: 18px;\r\n  height: 18px;\r\n  color: #fff;\r\n}\r\na {\r\n  color: #fff;\r\n  text-decoration: none;\r\n}\r\n.history-tab-container::-webkit-scrollbar {\r\n  width: 14px;\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n}\r\n\r\n.history-tab-container::-webkit-scrollbar-thumb {\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n  border-radius: 10px;\r\n}\r\n\r\n.history-tab-container::-webkit-scrollbar-track {\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n  border-radius: 10px;\r\n}\r\n", "",{"version":3,"sources":["webpack://./src/popup/components/History/index.css"],"names":[],"mappings":"AAAA;EACE,YAAY;EACZ,+BAA+B;EAC/B,gDAAgD;EAChD,4BAA4B;EAC5B,oCAAoC;EACpC,mBAAmB;EACnB,cAAc;EACd,mBAAmB;EACnB,kBAAkB;EAClB,kBAAkB;EAClB,iBAAiB;AACnB;AACA;EACE,aAAa;EACb,mBAAmB;EACnB,mBAAmB;EACnB,6BAA6B;EAC7B,iDAAiD;EACjD,mBAAmB;EACnB,gBAAgB;EAChB,2CAA2C;AAC7C;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,gBAAgB;EAChB,iBAAiB;EACjB,WAAW;AACb;;AAEA;EACE,YAAY;EACZ,YAAY;EACZ,aAAa;EACb,YAAY;EACZ,6BAA6B;EAC7B,qBAAqB;EACrB,gBAAgB;EAChB,eAAe;EACf,WAAW;AACb;AACA;EACE,YAAY;EACZ,oCAAoC;AACtC;AACA;EACE,kBAAkB;AACpB;AACA;EACE,iDAAiD;EACjD,mBAAmB;EACnB,iBAAiB;EACjB,oBAAoB;AACtB;AACA;EACE,WAAW;EACX,YAAY;EACZ,kBAAkB;AACpB;AACA;EACE,qBAAqB;EACrB,gBAAgB;EAChB,eAAe;EACf,WAAW;EACX,qBAAqB;EACrB,gBAAgB;EAChB,uBAAuB;EACvB,mBAAmB;AACrB;AACA;EACE,aAAa;EACb,mBAAmB;EACnB,mBAAmB;EACnB,gBAAgB;EAChB,YAAY;AACd;AACA;EACE,aAAa;AACf;;AAEA;EACE,gBAAgB;AAClB;AACA;EACE,qBAAqB;EACrB,gBAAgB;EAChB,eAAe;EACf,WAAW;AACb;AACA;EACE,kBAAkB;EAClB,aAAa;EACb,mBAAmB;EACnB,mBAAmB;EACnB,gBAAgB;AAClB;AACA;EACE,WAAW;EACX,YAAY;EACZ,kBAAkB;AACpB;AACA;EACE,qBAAqB;EACrB,gBAAgB;EAChB,iBAAiB;EACjB,gBAAgB;EAChB,uBAAuB;EACvB,mBAAmB;AACrB;AACA;EACE,gBAAgB;AAClB;AACA;EACE,qBAAqB;EACrB,gBAAgB;EAChB,eAAe;EACf,WAAW;AACb;AACA;EACE,kBAAkB;EAClB,aAAa;EACb,mBAAmB;EACnB,mBAAmB;EACnB,kBAAkB;AACpB;AACA;EACE,WAAW;EACX,YAAY;EACZ,kBAAkB;AACpB;AACA;EACE,qBAAqB;EACrB,gBAAgB;EAChB,iBAAiB;EACjB,gBAAgB;EAChB,uBAAuB;EACvB,mBAAmB;AACrB;AACA;EACE,aAAa;EACb,mBAAmB;EACnB,YAAY;EACZ,8BAA8B;EAC9B,mBAAmB;EACnB,kBAAkB;EAClB,yBAAyB;EACzB,gBAAgB;EAChB,mBAAmB;EACnB,eAAe;AACjB;AACA;EACE,aAAa;EACb,YAAY;EACZ,qBAAqB;EACrB,gBAAgB;EAChB,eAAe;EACf,6BAA6B;EAC7B,WAAW;AACb;AACA;EACE,WAAW;EACX,YAAY;EACZ,WAAW;AACb;AACA;EACE,WAAW;EACX,qBAAqB;AACvB;AACA;EACE,WAAW;EACX,qCAAqC;EACrC,gDAAgD;EAChD,0BAA0B;EAC1B,kCAAkC;EAClC,mBAAmB;AACrB;;AAEA;EACE,qCAAqC;EACrC,gDAAgD;EAChD,0BAA0B;EAC1B,kCAAkC;EAClC,mBAAmB;EACnB,mBAAmB;AACrB;;AAEA;EACE,qCAAqC;EACrC,gDAAgD;EAChD,0BAA0B;EAC1B,kCAAkC;EAClC,mBAAmB;EACnB,mBAAmB;AACrB","sourcesContent":[".history-tab-container {\r\n  width: 380px;\r\n  background: rgba(0, 0, 0, 0.75);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(3.5px);\r\n  -webkit-backdrop-filter: blur(3.5px);\r\n  border-radius: 10px;\r\n  height: 98.5vh;\r\n  border-radius: 12px;\r\n  margin-left: 5.5px;\r\n  overflow-y: scroll;\r\n  margin-top: 5.5px;\r\n}\r\n.search-history-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  justify-content: space-around;\r\n  box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;\r\n  border-radius: 10px;\r\n  margin-top: 10px;\r\n  border: 1px solid rgba(255, 255, 255, 0.18);\r\n}\r\n\r\n.search-icon {\r\n  width: 20px;\r\n  height: 20px;\r\n  font-weight: 600;\r\n  margin-left: 10px;\r\n  color: #fff;\r\n}\r\n\r\n.history-search-input {\r\n  width: 280px;\r\n  height: 42px;\r\n  outline: none;\r\n  border: none;\r\n  background-color: transparent;\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 16px;\r\n  color: #fff;\r\n}\r\n.while-searching {\r\n  opacity: 0.5;\r\n  transition: opacity 0.5s ease-in-out;\r\n}\r\n.history-suggestions-container {\r\n  padding-left: 10px;\r\n}\r\n.show-history {\r\n  box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;\r\n  border-radius: 10px;\r\n  padding-top: 10px;\r\n  padding-bottom: 10px;\r\n}\r\n.history-suggestion-icon {\r\n  width: 19px;\r\n  height: 19px;\r\n  margin-right: 12px;\r\n}\r\n.history-suggestion-link {\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 14px;\r\n  color: #fff;\r\n  text-decoration: none;\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\r\n}\r\n.each-history-suggestion {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  margin-top: 10px;\r\n  width: 300px;\r\n}\r\n.history-bottom-bar {\r\n  padding: 12px;\r\n}\r\n\r\n.recently-closed-container {\r\n  margin-top: 20px;\r\n}\r\n.recently-closed-heading {\r\n  font-family: \"roboto\";\r\n  font-weight: 600;\r\n  font-size: 15px;\r\n  color: #fff;\r\n}\r\n.recent-history {\r\n  padding-left: 10px;\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  margin-top: 10px;\r\n}\r\n.recent-history-icon {\r\n  width: 18px;\r\n  height: 18px;\r\n  margin-right: 12px;\r\n}\r\n.recent-history-title {\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 14.8px;\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\r\n}\r\n.history-container {\r\n  margin-top: 22px;\r\n}\r\n.history-header {\r\n  font-family: \"roboto\";\r\n  font-weight: 600;\r\n  font-size: 15px;\r\n  color: #fff;\r\n}\r\n.history {\r\n  padding-left: 10px;\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  margin-top: 11.5px;\r\n}\r\n.history-icon {\r\n  width: 18px;\r\n  height: 18px;\r\n  margin-right: 12px;\r\n}\r\n.history-title {\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 14.8px;\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\r\n}\r\n.open-full-history-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  padding: 8px;\r\n  justify-content: space-between;\r\n  align-items: center;\r\n  border-radius: 8px;\r\n  border: 1px solid #626363;\r\n  margin-top: 20px;\r\n  margin-bottom: 12px;\r\n  cursor: pointer;\r\n}\r\n.open-full-history {\r\n  outline: none;\r\n  border: none;\r\n  font-family: \"roboto\";\r\n  font-weight: 600;\r\n  font-size: 17px;\r\n  background-color: transparent;\r\n  color: #fff;\r\n}\r\n.open-full-history-icon {\r\n  width: 18px;\r\n  height: 18px;\r\n  color: #fff;\r\n}\r\na {\r\n  color: #fff;\r\n  text-decoration: none;\r\n}\r\n.history-tab-container::-webkit-scrollbar {\r\n  width: 14px;\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n}\r\n\r\n.history-tab-container::-webkit-scrollbar-thumb {\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n  border-radius: 10px;\r\n}\r\n\r\n.history-tab-container::-webkit-scrollbar-track {\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n  border-radius: 10px;\r\n}\r\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/popup/components/HomeScreen/index.css":
/*!*****************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/popup/components/HomeScreen/index.css ***!
  \*****************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "* {\r\n  margin: 0;\r\n  padding: 0;\r\n  box-sizing: border-box;\r\n}\r\n/* .home-screen-container {\r\n  height: 100vh;\r\n  background-size: cover;\r\n  display: flex;\r\n  flex-direction: row;\r\n  justify-content: space-between;\r\n  align-items: flex-start;\r\n} */\r\n\r\n.bg-container-thumbnails {\r\n  /* background: rgba(83, 83, 83, 0.8);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(4px);\r\n  -webkit-backdrop-filter: blur(4px);\r\n  border-radius: 10px; */\r\n  /* box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37); */\r\n  /* backdrop-filter: blur(3.5px);\r\n  -webkit-backdrop-filter: blur(3.5px);\r\n  border-radius: 10px; */\r\n  background: rgba(0, 0, 0, 0.75);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(3.5px);\r\n  -webkit-backdrop-filter: blur(3.5px);\r\n  border-radius: 10px;\r\n  border: 1px solid rgba(255, 255, 255, 0.18);\r\n  border-radius: 5.5px;\r\n  align-self: flex-end;\r\n  margin-right: 5.5px;\r\n  margin-bottom: 6px;\r\n  width: 620px;\r\n  height: 400px;\r\n}\r\n\r\n.left-side-containers {\r\n  display: flex;\r\n  height: 99vh;\r\n  flex-direction: column;\r\n  justify-content: space-between;\r\n  align-items: flex-end;\r\n}\r\n.spotify-container {\r\n  display: flex;\r\n  flex-direction: column;\r\n  align-items: center;\r\n  justify-content: center;\r\n}\r\n\r\n.background-image-icon-container {\r\n  background: rgba(83, 83, 83, 0.8);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(4px);\r\n  -webkit-backdrop-filter: blur(4px);\r\n  border-radius: 5px;\r\n  border: 1px solid rgba(255, 255, 255, 0.18);\r\n  padding: 8px;\r\n  margin-right: 5.5px;\r\n  align-self: flex-end;\r\n}\r\n.background-image-icon {\r\n  color: #f4f4f4;\r\n  width: 25px;\r\n  height: 25px;\r\n  cursor: pointer;\r\n}\r\n.bg-container {\r\n  align-self: flex-end;\r\n  display: flex;\r\n  flex-direction: column;\r\n}\r\n.default-gallery {\r\n  color: #d6d6d6;\r\n  font-family: \"roboto\";\r\n  font-weight: 600;\r\n  font-size: 17px;\r\n  letter-spacing: 0.05ch;\r\n  margin-right: 25px;\r\n  cursor: pointer;\r\n}\r\n.gallery-title-nav-bar {\r\n  display: flex;\r\n  flex-direction: row;\r\n  justify-content: space-between;\r\n  align-items: center;\r\n  border-bottom: 1px solid #b5b5b5;\r\n  margin-bottom: 10px;\r\n  padding-top: 10px;\r\n  padding-bottom: 10px;\r\n  padding-left: 10px;\r\n}\r\n.gallery-titles-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n}\r\n.thumbnails-list-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  flex-wrap: wrap;\r\n  justify-content: center;\r\n  align-items: center;\r\n}\r\n.upload-new-bg-container {\r\n  border: 2px dashed rgb(218, 217, 217);\r\n  width: 250px;\r\n  height: 170px;\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n  align-items: center;\r\n  cursor: pointer;\r\n  margin-top: 25%;\r\n}\r\n.my-background-container {\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n  align-items: center;\r\n}\r\n.upload-bg-title {\r\n  color: #fff;\r\n  font-size: 16px;\r\n  font-weight: 500;\r\n  font-family: \"roboto\";\r\n}\r\n.upload-bg {\r\n  color: #fff;\r\n  width: 42px;\r\n  height: 42px;\r\n  margin-bottom: 7px;\r\n}\r\n.my-bg-image {\r\n  width: 500px;\r\n  height: 250px;\r\n  display: flex;\r\n  justify-content: center;\r\n  align-items: center;\r\n}\r\n.change-my-bg {\r\n  margin-top: 10px;\r\n}\r\n.change-my-bg-container {\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n}\r\n.change-bg-button {\r\n  outline: none;\r\n  border: none;\r\n  border: 1px solid #dfdfdf;\r\n  padding: 6px;\r\n}\r\n.close-bg-popup {\r\n  align-self: flex-end;\r\n  color: #fff;\r\n  width: 18px;\r\n  height: 18px;\r\n  cursor: pointer;\r\n  margin-right: 20px;\r\n}\r\n.bottom-features-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-self: flex-end;\r\n  align-items: center;\r\n}\r\n.add-widgets-container {\r\n  /* background: rgba(83, 83, 83, 0.8);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(4px);\r\n  -webkit-backdrop-filter: blur(4px);\r\n  border-radius: 10px; */\r\n  background: rgba(0, 0, 0, 0.75);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(3.5px);\r\n  -webkit-backdrop-filter: blur(3.5px);\r\n  border-radius: 10px;\r\n  border: 1px solid rgba(255, 255, 255, 0.18);\r\n  border-radius: 5.5px;\r\n  display: flex;\r\n  flex-direction: column;\r\n  align-self: flex-end;\r\n  margin-right: 5.5px;\r\n  margin-bottom: 6px;\r\n  width: 400px;\r\n  height: 350px;\r\n  padding: 20px;\r\n}\r\n.widgets-main-heading {\r\n  color: #d6d6d6;\r\n  font-weight: 600;\r\n  font-size: 18px;\r\n  font-family: \"roboto\";\r\n  text-align: center;\r\n  margin-right: 19px;\r\n  cursor: pointer;\r\n}\r\n.is-active {\r\n  opacity: 0.38;\r\n}\r\n.widget-form-container {\r\n  display: flex;\r\n  flex-direction: column;\r\n  margin-top: 20px;\r\n  justify-content: center;\r\n  align-items: center;\r\n  height: 220px;\r\n  /* border: 1px solid #000; */\r\n  padding: 12px;\r\n}\r\n.input-widget-url {\r\n  background-color: transparent;\r\n  height: 47px;\r\n  width: 100%;\r\n  outline: none;\r\n  border-radius: 6px;\r\n  padding-left: 10px;\r\n  font-family: \"roboto\";\r\n  font-size: 14px;\r\n  color: #fff;\r\n  border: 1px solid #8f8f8f;\r\n  /* box-shadow: 0 0 4px #848484; */\r\n  outline-offset: 0px;\r\n  outline: none;\r\n  border-radius: 11px;\r\n  backdrop-filter: blur(6px);\r\n  -webkit-backdrop-filter: blur(6px);\r\n}\r\n.input-widget-url::placeholder {\r\n  font-family: \"roboto\";\r\n  font-size: 14px;\r\n  color: #c3c3c3;\r\n}\r\n.add-widget-button {\r\n  color: #d6d6d6;\r\n  background: rgba(84, 84, 84, 0.85);\r\n  backdrop-filter: blur(9.5px);\r\n  -webkit-backdrop-filter: blur(9.5px);\r\n  border-radius: 10px;\r\n  height: 36px;\r\n  width: 90px;\r\n  margin-top: 15px;\r\n  outline: none;\r\n  border: none;\r\n  border-radius: 8px;\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 15px;\r\n  cursor: pointer;\r\n  border: 1px solid rgba(255, 255, 255, 0.18);\r\n}\r\n.widget-url-error-msg {\r\n  color: rgb(255, 159, 159);\r\n  font-family: \"roboto\";\r\n  font-size: 13.5px;\r\n  font-weight: 400;\r\n  margin-top: 6px;\r\n  align-self: flex-start;\r\n}\r\n.widgets-navbar {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n  border-bottom: 1px solid #fff;\r\n  padding-bottom: 10px;\r\n}\r\n.widgets-title-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n}\r\n.widgets-hr {\r\n  background-color: #fff;\r\n  height: 25px;\r\n  width: 1.5px;\r\n  margin-right: 19px;\r\n}\r\n.widget-from-msg {\r\n  align-self: flex-start;\r\n  color: #d6d6d6;\r\n  font-size: 15px;\r\n  font-weight: 500;\r\n  margin-bottom: 14px;\r\n}\r\n.my-widgets-container {\r\n  display: flex;\r\n  flex-direction: column;\r\n  padding: 12px;\r\n}\r\n.each-my-widget-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  margin-top: 8.6px;\r\n  margin-bottom: 8.5px;\r\n}\r\n.widget-logo-title {\r\n  width: 180px;\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n}\r\n.my-widget-icon {\r\n  width: 20px;\r\n  height: 20px;\r\n  margin-right: 12px;\r\n}\r\n.my-widget-title {\r\n  color: #d6d6d6;\r\n  font-size: 18px;\r\n  font-weight: 500;\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\r\n}\r\n.delete-my-widget {\r\n  width: 22px;\r\n  height: 22px;\r\n  color: #d6d6d6;\r\n  margin-left: 10px;\r\n}\r\n.close-widget-popup {\r\n  height: 18px;\r\n  width: 18px;\r\n  color: #fff;\r\n  cursor: pointer;\r\n  align-self: flex-end;\r\n}\r\n", "",{"version":3,"sources":["webpack://./src/popup/components/HomeScreen/index.css"],"names":[],"mappings":"AAAA;EACE,SAAS;EACT,UAAU;EACV,sBAAsB;AACxB;AACA;;;;;;;GAOG;;AAEH;EACE;;;;wBAIsB;EACtB,sDAAsD;EACtD;;wBAEsB;EACtB,+BAA+B;EAC/B,gDAAgD;EAChD,4BAA4B;EAC5B,oCAAoC;EACpC,mBAAmB;EACnB,2CAA2C;EAC3C,oBAAoB;EACpB,oBAAoB;EACpB,mBAAmB;EACnB,kBAAkB;EAClB,YAAY;EACZ,aAAa;AACf;;AAEA;EACE,aAAa;EACb,YAAY;EACZ,sBAAsB;EACtB,8BAA8B;EAC9B,qBAAqB;AACvB;AACA;EACE,aAAa;EACb,sBAAsB;EACtB,mBAAmB;EACnB,uBAAuB;AACzB;;AAEA;EACE,iCAAiC;EACjC,gDAAgD;EAChD,0BAA0B;EAC1B,kCAAkC;EAClC,kBAAkB;EAClB,2CAA2C;EAC3C,YAAY;EACZ,mBAAmB;EACnB,oBAAoB;AACtB;AACA;EACE,cAAc;EACd,WAAW;EACX,YAAY;EACZ,eAAe;AACjB;AACA;EACE,oBAAoB;EACpB,aAAa;EACb,sBAAsB;AACxB;AACA;EACE,cAAc;EACd,qBAAqB;EACrB,gBAAgB;EAChB,eAAe;EACf,sBAAsB;EACtB,kBAAkB;EAClB,eAAe;AACjB;AACA;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,mBAAmB;EACnB,gCAAgC;EAChC,mBAAmB;EACnB,iBAAiB;EACjB,oBAAoB;EACpB,kBAAkB;AACpB;AACA;EACE,aAAa;EACb,mBAAmB;EACnB,mBAAmB;AACrB;AACA;EACE,aAAa;EACb,mBAAmB;EACnB,eAAe;EACf,uBAAuB;EACvB,mBAAmB;AACrB;AACA;EACE,qCAAqC;EACrC,YAAY;EACZ,aAAa;EACb,aAAa;EACb,sBAAsB;EACtB,uBAAuB;EACvB,mBAAmB;EACnB,eAAe;EACf,eAAe;AACjB;AACA;EACE,aAAa;EACb,sBAAsB;EACtB,uBAAuB;EACvB,mBAAmB;AACrB;AACA;EACE,WAAW;EACX,eAAe;EACf,gBAAgB;EAChB,qBAAqB;AACvB;AACA;EACE,WAAW;EACX,WAAW;EACX,YAAY;EACZ,kBAAkB;AACpB;AACA;EACE,YAAY;EACZ,aAAa;EACb,aAAa;EACb,uBAAuB;EACvB,mBAAmB;AACrB;AACA;EACE,gBAAgB;AAClB;AACA;EACE,aAAa;EACb,sBAAsB;EACtB,uBAAuB;AACzB;AACA;EACE,aAAa;EACb,YAAY;EACZ,yBAAyB;EACzB,YAAY;AACd;AACA;EACE,oBAAoB;EACpB,WAAW;EACX,WAAW;EACX,YAAY;EACZ,eAAe;EACf,kBAAkB;AACpB;AACA;EACE,aAAa;EACb,mBAAmB;EACnB,oBAAoB;EACpB,mBAAmB;AACrB;AACA;EACE;;;;wBAIsB;EACtB,+BAA+B;EAC/B,gDAAgD;EAChD,4BAA4B;EAC5B,oCAAoC;EACpC,mBAAmB;EACnB,2CAA2C;EAC3C,oBAAoB;EACpB,aAAa;EACb,sBAAsB;EACtB,oBAAoB;EACpB,mBAAmB;EACnB,kBAAkB;EAClB,YAAY;EACZ,aAAa;EACb,aAAa;AACf;AACA;EACE,cAAc;EACd,gBAAgB;EAChB,eAAe;EACf,qBAAqB;EACrB,kBAAkB;EAClB,kBAAkB;EAClB,eAAe;AACjB;AACA;EACE,aAAa;AACf;AACA;EACE,aAAa;EACb,sBAAsB;EACtB,gBAAgB;EAChB,uBAAuB;EACvB,mBAAmB;EACnB,aAAa;EACb,4BAA4B;EAC5B,aAAa;AACf;AACA;EACE,6BAA6B;EAC7B,YAAY;EACZ,WAAW;EACX,aAAa;EACb,kBAAkB;EAClB,kBAAkB;EAClB,qBAAqB;EACrB,eAAe;EACf,WAAW;EACX,yBAAyB;EACzB,iCAAiC;EACjC,mBAAmB;EACnB,aAAa;EACb,mBAAmB;EACnB,0BAA0B;EAC1B,kCAAkC;AACpC;AACA;EACE,qBAAqB;EACrB,eAAe;EACf,cAAc;AAChB;AACA;EACE,cAAc;EACd,kCAAkC;EAClC,4BAA4B;EAC5B,oCAAoC;EACpC,mBAAmB;EACnB,YAAY;EACZ,WAAW;EACX,gBAAgB;EAChB,aAAa;EACb,YAAY;EACZ,kBAAkB;EAClB,qBAAqB;EACrB,gBAAgB;EAChB,eAAe;EACf,eAAe;EACf,2CAA2C;AAC7C;AACA;EACE,yBAAyB;EACzB,qBAAqB;EACrB,iBAAiB;EACjB,gBAAgB;EAChB,eAAe;EACf,sBAAsB;AACxB;AACA;EACE,aAAa;EACb,mBAAmB;EACnB,mBAAmB;EACnB,8BAA8B;EAC9B,6BAA6B;EAC7B,oBAAoB;AACtB;AACA;EACE,aAAa;EACb,mBAAmB;EACnB,mBAAmB;AACrB;AACA;EACE,sBAAsB;EACtB,YAAY;EACZ,YAAY;EACZ,kBAAkB;AACpB;AACA;EACE,sBAAsB;EACtB,cAAc;EACd,eAAe;EACf,gBAAgB;EAChB,mBAAmB;AACrB;AACA;EACE,aAAa;EACb,sBAAsB;EACtB,aAAa;AACf;AACA;EACE,aAAa;EACb,mBAAmB;EACnB,mBAAmB;EACnB,iBAAiB;EACjB,oBAAoB;AACtB;AACA;EACE,YAAY;EACZ,aAAa;EACb,mBAAmB;EACnB,mBAAmB;AACrB;AACA;EACE,WAAW;EACX,YAAY;EACZ,kBAAkB;AACpB;AACA;EACE,cAAc;EACd,eAAe;EACf,gBAAgB;EAChB,gBAAgB;EAChB,uBAAuB;EACvB,mBAAmB;AACrB;AACA;EACE,WAAW;EACX,YAAY;EACZ,cAAc;EACd,iBAAiB;AACnB;AACA;EACE,YAAY;EACZ,WAAW;EACX,WAAW;EACX,eAAe;EACf,oBAAoB;AACtB","sourcesContent":["* {\r\n  margin: 0;\r\n  padding: 0;\r\n  box-sizing: border-box;\r\n}\r\n/* .home-screen-container {\r\n  height: 100vh;\r\n  background-size: cover;\r\n  display: flex;\r\n  flex-direction: row;\r\n  justify-content: space-between;\r\n  align-items: flex-start;\r\n} */\r\n\r\n.bg-container-thumbnails {\r\n  /* background: rgba(83, 83, 83, 0.8);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(4px);\r\n  -webkit-backdrop-filter: blur(4px);\r\n  border-radius: 10px; */\r\n  /* box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37); */\r\n  /* backdrop-filter: blur(3.5px);\r\n  -webkit-backdrop-filter: blur(3.5px);\r\n  border-radius: 10px; */\r\n  background: rgba(0, 0, 0, 0.75);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(3.5px);\r\n  -webkit-backdrop-filter: blur(3.5px);\r\n  border-radius: 10px;\r\n  border: 1px solid rgba(255, 255, 255, 0.18);\r\n  border-radius: 5.5px;\r\n  align-self: flex-end;\r\n  margin-right: 5.5px;\r\n  margin-bottom: 6px;\r\n  width: 620px;\r\n  height: 400px;\r\n}\r\n\r\n.left-side-containers {\r\n  display: flex;\r\n  height: 99vh;\r\n  flex-direction: column;\r\n  justify-content: space-between;\r\n  align-items: flex-end;\r\n}\r\n.spotify-container {\r\n  display: flex;\r\n  flex-direction: column;\r\n  align-items: center;\r\n  justify-content: center;\r\n}\r\n\r\n.background-image-icon-container {\r\n  background: rgba(83, 83, 83, 0.8);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(4px);\r\n  -webkit-backdrop-filter: blur(4px);\r\n  border-radius: 5px;\r\n  border: 1px solid rgba(255, 255, 255, 0.18);\r\n  padding: 8px;\r\n  margin-right: 5.5px;\r\n  align-self: flex-end;\r\n}\r\n.background-image-icon {\r\n  color: #f4f4f4;\r\n  width: 25px;\r\n  height: 25px;\r\n  cursor: pointer;\r\n}\r\n.bg-container {\r\n  align-self: flex-end;\r\n  display: flex;\r\n  flex-direction: column;\r\n}\r\n.default-gallery {\r\n  color: #d6d6d6;\r\n  font-family: \"roboto\";\r\n  font-weight: 600;\r\n  font-size: 17px;\r\n  letter-spacing: 0.05ch;\r\n  margin-right: 25px;\r\n  cursor: pointer;\r\n}\r\n.gallery-title-nav-bar {\r\n  display: flex;\r\n  flex-direction: row;\r\n  justify-content: space-between;\r\n  align-items: center;\r\n  border-bottom: 1px solid #b5b5b5;\r\n  margin-bottom: 10px;\r\n  padding-top: 10px;\r\n  padding-bottom: 10px;\r\n  padding-left: 10px;\r\n}\r\n.gallery-titles-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n}\r\n.thumbnails-list-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  flex-wrap: wrap;\r\n  justify-content: center;\r\n  align-items: center;\r\n}\r\n.upload-new-bg-container {\r\n  border: 2px dashed rgb(218, 217, 217);\r\n  width: 250px;\r\n  height: 170px;\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n  align-items: center;\r\n  cursor: pointer;\r\n  margin-top: 25%;\r\n}\r\n.my-background-container {\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n  align-items: center;\r\n}\r\n.upload-bg-title {\r\n  color: #fff;\r\n  font-size: 16px;\r\n  font-weight: 500;\r\n  font-family: \"roboto\";\r\n}\r\n.upload-bg {\r\n  color: #fff;\r\n  width: 42px;\r\n  height: 42px;\r\n  margin-bottom: 7px;\r\n}\r\n.my-bg-image {\r\n  width: 500px;\r\n  height: 250px;\r\n  display: flex;\r\n  justify-content: center;\r\n  align-items: center;\r\n}\r\n.change-my-bg {\r\n  margin-top: 10px;\r\n}\r\n.change-my-bg-container {\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n}\r\n.change-bg-button {\r\n  outline: none;\r\n  border: none;\r\n  border: 1px solid #dfdfdf;\r\n  padding: 6px;\r\n}\r\n.close-bg-popup {\r\n  align-self: flex-end;\r\n  color: #fff;\r\n  width: 18px;\r\n  height: 18px;\r\n  cursor: pointer;\r\n  margin-right: 20px;\r\n}\r\n.bottom-features-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-self: flex-end;\r\n  align-items: center;\r\n}\r\n.add-widgets-container {\r\n  /* background: rgba(83, 83, 83, 0.8);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(4px);\r\n  -webkit-backdrop-filter: blur(4px);\r\n  border-radius: 10px; */\r\n  background: rgba(0, 0, 0, 0.75);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(3.5px);\r\n  -webkit-backdrop-filter: blur(3.5px);\r\n  border-radius: 10px;\r\n  border: 1px solid rgba(255, 255, 255, 0.18);\r\n  border-radius: 5.5px;\r\n  display: flex;\r\n  flex-direction: column;\r\n  align-self: flex-end;\r\n  margin-right: 5.5px;\r\n  margin-bottom: 6px;\r\n  width: 400px;\r\n  height: 350px;\r\n  padding: 20px;\r\n}\r\n.widgets-main-heading {\r\n  color: #d6d6d6;\r\n  font-weight: 600;\r\n  font-size: 18px;\r\n  font-family: \"roboto\";\r\n  text-align: center;\r\n  margin-right: 19px;\r\n  cursor: pointer;\r\n}\r\n.is-active {\r\n  opacity: 0.38;\r\n}\r\n.widget-form-container {\r\n  display: flex;\r\n  flex-direction: column;\r\n  margin-top: 20px;\r\n  justify-content: center;\r\n  align-items: center;\r\n  height: 220px;\r\n  /* border: 1px solid #000; */\r\n  padding: 12px;\r\n}\r\n.input-widget-url {\r\n  background-color: transparent;\r\n  height: 47px;\r\n  width: 100%;\r\n  outline: none;\r\n  border-radius: 6px;\r\n  padding-left: 10px;\r\n  font-family: \"roboto\";\r\n  font-size: 14px;\r\n  color: #fff;\r\n  border: 1px solid #8f8f8f;\r\n  /* box-shadow: 0 0 4px #848484; */\r\n  outline-offset: 0px;\r\n  outline: none;\r\n  border-radius: 11px;\r\n  backdrop-filter: blur(6px);\r\n  -webkit-backdrop-filter: blur(6px);\r\n}\r\n.input-widget-url::placeholder {\r\n  font-family: \"roboto\";\r\n  font-size: 14px;\r\n  color: #c3c3c3;\r\n}\r\n.add-widget-button {\r\n  color: #d6d6d6;\r\n  background: rgba(84, 84, 84, 0.85);\r\n  backdrop-filter: blur(9.5px);\r\n  -webkit-backdrop-filter: blur(9.5px);\r\n  border-radius: 10px;\r\n  height: 36px;\r\n  width: 90px;\r\n  margin-top: 15px;\r\n  outline: none;\r\n  border: none;\r\n  border-radius: 8px;\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 15px;\r\n  cursor: pointer;\r\n  border: 1px solid rgba(255, 255, 255, 0.18);\r\n}\r\n.widget-url-error-msg {\r\n  color: rgb(255, 159, 159);\r\n  font-family: \"roboto\";\r\n  font-size: 13.5px;\r\n  font-weight: 400;\r\n  margin-top: 6px;\r\n  align-self: flex-start;\r\n}\r\n.widgets-navbar {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n  border-bottom: 1px solid #fff;\r\n  padding-bottom: 10px;\r\n}\r\n.widgets-title-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n}\r\n.widgets-hr {\r\n  background-color: #fff;\r\n  height: 25px;\r\n  width: 1.5px;\r\n  margin-right: 19px;\r\n}\r\n.widget-from-msg {\r\n  align-self: flex-start;\r\n  color: #d6d6d6;\r\n  font-size: 15px;\r\n  font-weight: 500;\r\n  margin-bottom: 14px;\r\n}\r\n.my-widgets-container {\r\n  display: flex;\r\n  flex-direction: column;\r\n  padding: 12px;\r\n}\r\n.each-my-widget-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  margin-top: 8.6px;\r\n  margin-bottom: 8.5px;\r\n}\r\n.widget-logo-title {\r\n  width: 180px;\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n}\r\n.my-widget-icon {\r\n  width: 20px;\r\n  height: 20px;\r\n  margin-right: 12px;\r\n}\r\n.my-widget-title {\r\n  color: #d6d6d6;\r\n  font-size: 18px;\r\n  font-weight: 500;\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\r\n}\r\n.delete-my-widget {\r\n  width: 22px;\r\n  height: 22px;\r\n  color: #d6d6d6;\r\n  margin-left: 10px;\r\n}\r\n.close-widget-popup {\r\n  height: 18px;\r\n  width: 18px;\r\n  color: #fff;\r\n  cursor: pointer;\r\n  align-self: flex-end;\r\n}\r\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/popup/components/LaunchPad/index.css":
/*!****************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/popup/components/LaunchPad/index.css ***!
  \****************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".launchpad-container {\r\n  width: 380px;\r\n  background: rgba(0, 0, 0, 0.75);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(3.5px);\r\n  -webkit-backdrop-filter: blur(3.5px);\r\n  border-radius: 10px;\r\n  height: 98.5vh;\r\n  border-radius: 12px;\r\n  margin-left: 5.5px;\r\n  overflow-y: scroll;\r\n  margin-top: 5.5px;\r\n}\r\n.top-bar {\r\n  background: rgba(0, 0, 0, 0.8);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n  height: 33px;\r\n  display: flex;\r\n  flex-direction: row;\r\n  justify-content: space-between;\r\n  align-items: center;\r\n  padding: 4px;\r\n  border-top-left-radius: 12px;\r\n  border-top-right-radius: 12px;\r\n  padding: 12px;\r\n}\r\n.tab-icon {\r\n  height: 14px;\r\n  width: 14px;\r\n  color: #fff;\r\n}\r\n.tab-title {\r\n  font-family: \"roboto\";\r\n  font-size: 14.3px;\r\n  font-weight: 500;\r\n  color: #fff;\r\n  margin-left: 10px;\r\n}\r\n.settings-icon {\r\n  height: 18px;\r\n  width: 18px;\r\n  margin-right: 8px;\r\n  cursor: pointer;\r\n  color: #fff;\r\n}\r\n.clear-icon {\r\n  height: 21px;\r\n  width: 21px;\r\n  cursor: pointer;\r\n  color: #fff;\r\n  margin-left: 8px;\r\n}\r\n.title-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n}\r\n.settings-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n}\r\n.bottom-bar {\r\n  padding: 12px;\r\n}\r\n.search-engine-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  justify-content: space-around;\r\n  box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;\r\n  margin-bottom: 14px;\r\n  border-radius: 10px;\r\n  border: 1px solid rgba(255, 255, 255, 0.18);\r\n}\r\n.google-icon {\r\n  width: 25px;\r\n  height: 25px;\r\n}\r\n.search-input {\r\n  width: 250px;\r\n  height: 42px;\r\n  background-color: transparent;\r\n  outline: none;\r\n  border: none;\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 17px;\r\n  color: #fff;\r\n}\r\n.search-engine-container:hover {\r\n  border: 1.5px solid #ffffff;\r\n  box-shadow: 0 0 5px #ffffff;\r\n  outline-offset: 0px;\r\n  outline: none;\r\n  border-radius: 11px;\r\n  background: rgba(0, 0, 0, 0.75);\r\n  backdrop-filter: blur(6px);\r\n  -webkit-backdrop-filter: blur(6px);\r\n}\r\n.most-visited-card-container {\r\n  background: rgba(18, 18, 18, 0.9);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  /* backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px); */\r\n  border-radius: 10px;\r\n\r\n  margin-top: 12px;\r\n  margin-bottom: 12px;\r\n  padding: 10px;\r\n  border-radius: 10px;\r\n}\r\n.most-visited-title {\r\n  font-family: \"roboto\";\r\n  font-size: 15.5px;\r\n  font-weight: 600;\r\n  color: #fff;\r\n}\r\n.visited-sites-container {\r\n  display: flex;\r\n  flex-wrap: wrap;\r\n  flex-direction: row;\r\n  align-items: center;\r\n}\r\n.most-visited-name-and-logo-container {\r\n  display: flex;\r\n  flex-direction: column;\r\n  align-items: center;\r\n}\r\n.most-visited-logo-container {\r\n  background: rgba(45, 45, 45, 0.85);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(9.5px);\r\n  -webkit-backdrop-filter: blur(9.5px);\r\n  border-radius: 10px;\r\n  height: 45px;\r\n  width: 45px;\r\n  border-radius: 10px;\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n  align-items: center;\r\n  margin-left: 8px;\r\n  margin-bottom: 8px;\r\n  margin-top: 10px;\r\n}\r\n.most-visited-logo {\r\n  width: 21px;\r\n  height: 21px;\r\n}\r\n.site-name {\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 12px;\r\n  color: #fff;\r\n}\r\n.favourite-sites-header-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n}\r\n.add-favourite {\r\n  font-family: \"roboto\";\r\n  font-weight: 600;\r\n  font-size: 14.5px;\r\n  color: #fff;\r\n  cursor: pointer;\r\n}\r\n.bookmarks-container {\r\n  background: rgba(18, 18, 18, 0.9);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  border-radius: 10px;\r\n  margin-bottom: 12px;\r\n  padding: 11px;\r\n  border-radius: 10px;\r\n}\r\n.bookmarks-header {\r\n  font-family: \"roboto\";\r\n  font-size: 15px;\r\n  font-weight: 600;\r\n  color: #fff;\r\n  margin-bottom: 14px;\r\n}\r\n.bookmark {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  margin-bottom: 14px;\r\n  padding-left: 8px;\r\n}\r\n.bookmarks-icon {\r\n  height: 18px;\r\n  width: 18px;\r\n  margin-right: 13px;\r\n}\r\n.bookmarks-title {\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 14.5px;\r\n  color: #fff;\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\r\n}\r\n.add-favourites-input-container {\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n  align-items: center;\r\n  width: 100%;\r\n}\r\n.popup-container {\r\n  position: absolute;\r\n  background-color: #000;\r\n\r\n  border-radius: 10px;\r\n  border: 1px solid rgba(255, 255, 255, 0.18);\r\n  width: 320px;\r\n  height: 230px;\r\n  border-radius: 8px;\r\n  margin-top: -25px;\r\n  display: flex;\r\n  flex-direction: row;\r\n  justify-content: space-between;\r\n  align-items: center;\r\n  z-index: 1;\r\n}\r\n.label-container {\r\n  display: flex;\r\n  flex-direction: column;\r\n  margin-top: 12px;\r\n  padding-left: 15px;\r\n}\r\n.add-favourite-url-label {\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 16px;\r\n  color: #dddddd;\r\n  margin-bottom: 5px;\r\n  padding-left: 4px;\r\n}\r\n.add-fav-name-url {\r\n  width: 280px;\r\n  height: 40px;\r\n  outline: none;\r\n  border: 1px solid #f4f4f4;\r\n  border-radius: 8px;\r\n  padding-left: 10px;\r\n  background-color: transparent;\r\n}\r\n.add-button-container {\r\n  padding-left: 15px;\r\n  margin-top: 14px;\r\n}\r\n.close-add-fav-popup {\r\n  width: 20px;\r\n  height: 20px;\r\n  padding-top: 10px;\r\n  padding-right: 5px;\r\n  align-self: flex-start;\r\n}\r\n.add-button {\r\n  height: 30px;\r\n  width: 110px;\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 16px;\r\n}\r\n\r\n.back-icon {\r\n  width: 30px;\r\n  height: 15px;\r\n  float: left;\r\n  cursor: pointer;\r\n  color: #fff;\r\n}\r\n.settings-title-container {\r\n  display: flex;\r\n  align-items: center;\r\n  background: rgba(0, 0, 0, 0.8);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n  margin-top: 15px;\r\n  margin-bottom: 15px;\r\n  width: 100%;\r\n  height: 40px;\r\n  padding-left: 0;\r\n  padding-right: 0;\r\n  border: 1px solid rgba(255, 255, 255, 0.18);\r\n}\r\n.settings-title {\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 17.6px;\r\n  color: #fff;\r\n  margin-left: 120px;\r\n}\r\n.sections-container {\r\n  margin-top: 30px;\r\n}\r\n.sections-title {\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 16px;\r\n  color: #fff;\r\n  margin-bottom: 12px;\r\n  margin-left: 30px;\r\n}\r\n.toggles {\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n  align-items: center;\r\n}\r\n.toggle-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  justify-content: space-around;\r\n\r\n  padding: 10px;\r\n  width: 70%;\r\n  margin-top: 14px;\r\n  border: 1px solid rgba(255, 255, 255, 0.18);\r\n}\r\n.toggle-title {\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 15px;\r\n  color: #fff;\r\n}\r\n.toggle-btn {\r\n  width: 25px;\r\n  height: 25px;\r\n  cursor: pointer;\r\n  color: #fff;\r\n}\r\na {\r\n  text-decoration: none;\r\n  color: none;\r\n}\r\n.launchpad-container::-webkit-scrollbar {\r\n  width: 14px;\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n}\r\n\r\n.launchpad-container::-webkit-scrollbar-thumb {\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n  border-radius: 10px;\r\n}\r\n\r\n.launchpad-container::-webkit-scrollbar-track {\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n  border-radius: 10px;\r\n}\r\n", "",{"version":3,"sources":["webpack://./src/popup/components/LaunchPad/index.css"],"names":[],"mappings":"AAAA;EACE,YAAY;EACZ,+BAA+B;EAC/B,gDAAgD;EAChD,4BAA4B;EAC5B,oCAAoC;EACpC,mBAAmB;EACnB,cAAc;EACd,mBAAmB;EACnB,kBAAkB;EAClB,kBAAkB;EAClB,iBAAiB;AACnB;AACA;EACE,8BAA8B;EAC9B,gDAAgD;EAChD,0BAA0B;EAC1B,kCAAkC;EAClC,mBAAmB;EACnB,YAAY;EACZ,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,mBAAmB;EACnB,YAAY;EACZ,4BAA4B;EAC5B,6BAA6B;EAC7B,aAAa;AACf;AACA;EACE,YAAY;EACZ,WAAW;EACX,WAAW;AACb;AACA;EACE,qBAAqB;EACrB,iBAAiB;EACjB,gBAAgB;EAChB,WAAW;EACX,iBAAiB;AACnB;AACA;EACE,YAAY;EACZ,WAAW;EACX,iBAAiB;EACjB,eAAe;EACf,WAAW;AACb;AACA;EACE,YAAY;EACZ,WAAW;EACX,eAAe;EACf,WAAW;EACX,gBAAgB;AAClB;AACA;EACE,aAAa;EACb,mBAAmB;EACnB,mBAAmB;AACrB;AACA;EACE,aAAa;EACb,mBAAmB;EACnB,mBAAmB;AACrB;AACA;EACE,aAAa;AACf;AACA;EACE,aAAa;EACb,mBAAmB;EACnB,mBAAmB;EACnB,6BAA6B;EAC7B,qDAAqD;EACrD,mBAAmB;EACnB,mBAAmB;EACnB,2CAA2C;AAC7C;AACA;EACE,WAAW;EACX,YAAY;AACd;AACA;EACE,YAAY;EACZ,YAAY;EACZ,6BAA6B;EAC7B,aAAa;EACb,YAAY;EACZ,qBAAqB;EACrB,gBAAgB;EAChB,eAAe;EACf,WAAW;AACb;AACA;EACE,2BAA2B;EAC3B,2BAA2B;EAC3B,mBAAmB;EACnB,aAAa;EACb,mBAAmB;EACnB,+BAA+B;EAC/B,0BAA0B;EAC1B,kCAAkC;AACpC;AACA;EACE,iCAAiC;EACjC,gDAAgD;EAChD;uCACqC;EACrC,mBAAmB;;EAEnB,gBAAgB;EAChB,mBAAmB;EACnB,aAAa;EACb,mBAAmB;AACrB;AACA;EACE,qBAAqB;EACrB,iBAAiB;EACjB,gBAAgB;EAChB,WAAW;AACb;AACA;EACE,aAAa;EACb,eAAe;EACf,mBAAmB;EACnB,mBAAmB;AACrB;AACA;EACE,aAAa;EACb,sBAAsB;EACtB,mBAAmB;AACrB;AACA;EACE,kCAAkC;EAClC,gDAAgD;EAChD,4BAA4B;EAC5B,oCAAoC;EACpC,mBAAmB;EACnB,YAAY;EACZ,WAAW;EACX,mBAAmB;EACnB,aAAa;EACb,sBAAsB;EACtB,uBAAuB;EACvB,mBAAmB;EACnB,gBAAgB;EAChB,kBAAkB;EAClB,gBAAgB;AAClB;AACA;EACE,WAAW;EACX,YAAY;AACd;AACA;EACE,qBAAqB;EACrB,gBAAgB;EAChB,eAAe;EACf,WAAW;AACb;AACA;EACE,aAAa;EACb,mBAAmB;EACnB,mBAAmB;EACnB,8BAA8B;AAChC;AACA;EACE,qBAAqB;EACrB,gBAAgB;EAChB,iBAAiB;EACjB,WAAW;EACX,eAAe;AACjB;AACA;EACE,iCAAiC;EACjC,gDAAgD;EAChD,mBAAmB;EACnB,mBAAmB;EACnB,aAAa;EACb,mBAAmB;AACrB;AACA;EACE,qBAAqB;EACrB,eAAe;EACf,gBAAgB;EAChB,WAAW;EACX,mBAAmB;AACrB;AACA;EACE,aAAa;EACb,mBAAmB;EACnB,mBAAmB;EACnB,mBAAmB;EACnB,iBAAiB;AACnB;AACA;EACE,YAAY;EACZ,WAAW;EACX,kBAAkB;AACpB;AACA;EACE,qBAAqB;EACrB,gBAAgB;EAChB,iBAAiB;EACjB,WAAW;EACX,gBAAgB;EAChB,uBAAuB;EACvB,mBAAmB;AACrB;AACA;EACE,aAAa;EACb,sBAAsB;EACtB,uBAAuB;EACvB,mBAAmB;EACnB,WAAW;AACb;AACA;EACE,kBAAkB;EAClB,sBAAsB;;EAEtB,mBAAmB;EACnB,2CAA2C;EAC3C,YAAY;EACZ,aAAa;EACb,kBAAkB;EAClB,iBAAiB;EACjB,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,mBAAmB;EACnB,UAAU;AACZ;AACA;EACE,aAAa;EACb,sBAAsB;EACtB,gBAAgB;EAChB,kBAAkB;AACpB;AACA;EACE,qBAAqB;EACrB,gBAAgB;EAChB,eAAe;EACf,cAAc;EACd,kBAAkB;EAClB,iBAAiB;AACnB;AACA;EACE,YAAY;EACZ,YAAY;EACZ,aAAa;EACb,yBAAyB;EACzB,kBAAkB;EAClB,kBAAkB;EAClB,6BAA6B;AAC/B;AACA;EACE,kBAAkB;EAClB,gBAAgB;AAClB;AACA;EACE,WAAW;EACX,YAAY;EACZ,iBAAiB;EACjB,kBAAkB;EAClB,sBAAsB;AACxB;AACA;EACE,YAAY;EACZ,YAAY;EACZ,qBAAqB;EACrB,gBAAgB;EAChB,eAAe;AACjB;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,WAAW;EACX,eAAe;EACf,WAAW;AACb;AACA;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;EAC9B,gDAAgD;EAChD,0BAA0B;EAC1B,kCAAkC;EAClC,mBAAmB;EACnB,gBAAgB;EAChB,mBAAmB;EACnB,WAAW;EACX,YAAY;EACZ,eAAe;EACf,gBAAgB;EAChB,2CAA2C;AAC7C;AACA;EACE,qBAAqB;EACrB,gBAAgB;EAChB,iBAAiB;EACjB,WAAW;EACX,kBAAkB;AACpB;AACA;EACE,gBAAgB;AAClB;AACA;EACE,qBAAqB;EACrB,gBAAgB;EAChB,eAAe;EACf,WAAW;EACX,mBAAmB;EACnB,iBAAiB;AACnB;AACA;EACE,aAAa;EACb,sBAAsB;EACtB,uBAAuB;EACvB,mBAAmB;AACrB;AACA;EACE,aAAa;EACb,mBAAmB;EACnB,mBAAmB;EACnB,6BAA6B;;EAE7B,aAAa;EACb,UAAU;EACV,gBAAgB;EAChB,2CAA2C;AAC7C;AACA;EACE,qBAAqB;EACrB,gBAAgB;EAChB,eAAe;EACf,WAAW;AACb;AACA;EACE,WAAW;EACX,YAAY;EACZ,eAAe;EACf,WAAW;AACb;AACA;EACE,qBAAqB;EACrB,WAAW;AACb;AACA;EACE,WAAW;EACX,qCAAqC;EACrC,gDAAgD;EAChD,0BAA0B;EAC1B,kCAAkC;EAClC,mBAAmB;AACrB;;AAEA;EACE,qCAAqC;EACrC,gDAAgD;EAChD,0BAA0B;EAC1B,kCAAkC;EAClC,mBAAmB;EACnB,mBAAmB;AACrB;;AAEA;EACE,qCAAqC;EACrC,gDAAgD;EAChD,0BAA0B;EAC1B,kCAAkC;EAClC,mBAAmB;EACnB,mBAAmB;AACrB","sourcesContent":[".launchpad-container {\r\n  width: 380px;\r\n  background: rgba(0, 0, 0, 0.75);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(3.5px);\r\n  -webkit-backdrop-filter: blur(3.5px);\r\n  border-radius: 10px;\r\n  height: 98.5vh;\r\n  border-radius: 12px;\r\n  margin-left: 5.5px;\r\n  overflow-y: scroll;\r\n  margin-top: 5.5px;\r\n}\r\n.top-bar {\r\n  background: rgba(0, 0, 0, 0.8);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n  height: 33px;\r\n  display: flex;\r\n  flex-direction: row;\r\n  justify-content: space-between;\r\n  align-items: center;\r\n  padding: 4px;\r\n  border-top-left-radius: 12px;\r\n  border-top-right-radius: 12px;\r\n  padding: 12px;\r\n}\r\n.tab-icon {\r\n  height: 14px;\r\n  width: 14px;\r\n  color: #fff;\r\n}\r\n.tab-title {\r\n  font-family: \"roboto\";\r\n  font-size: 14.3px;\r\n  font-weight: 500;\r\n  color: #fff;\r\n  margin-left: 10px;\r\n}\r\n.settings-icon {\r\n  height: 18px;\r\n  width: 18px;\r\n  margin-right: 8px;\r\n  cursor: pointer;\r\n  color: #fff;\r\n}\r\n.clear-icon {\r\n  height: 21px;\r\n  width: 21px;\r\n  cursor: pointer;\r\n  color: #fff;\r\n  margin-left: 8px;\r\n}\r\n.title-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n}\r\n.settings-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n}\r\n.bottom-bar {\r\n  padding: 12px;\r\n}\r\n.search-engine-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  justify-content: space-around;\r\n  box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;\r\n  margin-bottom: 14px;\r\n  border-radius: 10px;\r\n  border: 1px solid rgba(255, 255, 255, 0.18);\r\n}\r\n.google-icon {\r\n  width: 25px;\r\n  height: 25px;\r\n}\r\n.search-input {\r\n  width: 250px;\r\n  height: 42px;\r\n  background-color: transparent;\r\n  outline: none;\r\n  border: none;\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 17px;\r\n  color: #fff;\r\n}\r\n.search-engine-container:hover {\r\n  border: 1.5px solid #ffffff;\r\n  box-shadow: 0 0 5px #ffffff;\r\n  outline-offset: 0px;\r\n  outline: none;\r\n  border-radius: 11px;\r\n  background: rgba(0, 0, 0, 0.75);\r\n  backdrop-filter: blur(6px);\r\n  -webkit-backdrop-filter: blur(6px);\r\n}\r\n.most-visited-card-container {\r\n  background: rgba(18, 18, 18, 0.9);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  /* backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px); */\r\n  border-radius: 10px;\r\n\r\n  margin-top: 12px;\r\n  margin-bottom: 12px;\r\n  padding: 10px;\r\n  border-radius: 10px;\r\n}\r\n.most-visited-title {\r\n  font-family: \"roboto\";\r\n  font-size: 15.5px;\r\n  font-weight: 600;\r\n  color: #fff;\r\n}\r\n.visited-sites-container {\r\n  display: flex;\r\n  flex-wrap: wrap;\r\n  flex-direction: row;\r\n  align-items: center;\r\n}\r\n.most-visited-name-and-logo-container {\r\n  display: flex;\r\n  flex-direction: column;\r\n  align-items: center;\r\n}\r\n.most-visited-logo-container {\r\n  background: rgba(45, 45, 45, 0.85);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(9.5px);\r\n  -webkit-backdrop-filter: blur(9.5px);\r\n  border-radius: 10px;\r\n  height: 45px;\r\n  width: 45px;\r\n  border-radius: 10px;\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n  align-items: center;\r\n  margin-left: 8px;\r\n  margin-bottom: 8px;\r\n  margin-top: 10px;\r\n}\r\n.most-visited-logo {\r\n  width: 21px;\r\n  height: 21px;\r\n}\r\n.site-name {\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 12px;\r\n  color: #fff;\r\n}\r\n.favourite-sites-header-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  justify-content: space-between;\r\n}\r\n.add-favourite {\r\n  font-family: \"roboto\";\r\n  font-weight: 600;\r\n  font-size: 14.5px;\r\n  color: #fff;\r\n  cursor: pointer;\r\n}\r\n.bookmarks-container {\r\n  background: rgba(18, 18, 18, 0.9);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  border-radius: 10px;\r\n  margin-bottom: 12px;\r\n  padding: 11px;\r\n  border-radius: 10px;\r\n}\r\n.bookmarks-header {\r\n  font-family: \"roboto\";\r\n  font-size: 15px;\r\n  font-weight: 600;\r\n  color: #fff;\r\n  margin-bottom: 14px;\r\n}\r\n.bookmark {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  margin-bottom: 14px;\r\n  padding-left: 8px;\r\n}\r\n.bookmarks-icon {\r\n  height: 18px;\r\n  width: 18px;\r\n  margin-right: 13px;\r\n}\r\n.bookmarks-title {\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 14.5px;\r\n  color: #fff;\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\r\n}\r\n.add-favourites-input-container {\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n  align-items: center;\r\n  width: 100%;\r\n}\r\n.popup-container {\r\n  position: absolute;\r\n  background-color: #000;\r\n\r\n  border-radius: 10px;\r\n  border: 1px solid rgba(255, 255, 255, 0.18);\r\n  width: 320px;\r\n  height: 230px;\r\n  border-radius: 8px;\r\n  margin-top: -25px;\r\n  display: flex;\r\n  flex-direction: row;\r\n  justify-content: space-between;\r\n  align-items: center;\r\n  z-index: 1;\r\n}\r\n.label-container {\r\n  display: flex;\r\n  flex-direction: column;\r\n  margin-top: 12px;\r\n  padding-left: 15px;\r\n}\r\n.add-favourite-url-label {\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 16px;\r\n  color: #dddddd;\r\n  margin-bottom: 5px;\r\n  padding-left: 4px;\r\n}\r\n.add-fav-name-url {\r\n  width: 280px;\r\n  height: 40px;\r\n  outline: none;\r\n  border: 1px solid #f4f4f4;\r\n  border-radius: 8px;\r\n  padding-left: 10px;\r\n  background-color: transparent;\r\n}\r\n.add-button-container {\r\n  padding-left: 15px;\r\n  margin-top: 14px;\r\n}\r\n.close-add-fav-popup {\r\n  width: 20px;\r\n  height: 20px;\r\n  padding-top: 10px;\r\n  padding-right: 5px;\r\n  align-self: flex-start;\r\n}\r\n.add-button {\r\n  height: 30px;\r\n  width: 110px;\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 16px;\r\n}\r\n\r\n.back-icon {\r\n  width: 30px;\r\n  height: 15px;\r\n  float: left;\r\n  cursor: pointer;\r\n  color: #fff;\r\n}\r\n.settings-title-container {\r\n  display: flex;\r\n  align-items: center;\r\n  background: rgba(0, 0, 0, 0.8);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n  margin-top: 15px;\r\n  margin-bottom: 15px;\r\n  width: 100%;\r\n  height: 40px;\r\n  padding-left: 0;\r\n  padding-right: 0;\r\n  border: 1px solid rgba(255, 255, 255, 0.18);\r\n}\r\n.settings-title {\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 17.6px;\r\n  color: #fff;\r\n  margin-left: 120px;\r\n}\r\n.sections-container {\r\n  margin-top: 30px;\r\n}\r\n.sections-title {\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 16px;\r\n  color: #fff;\r\n  margin-bottom: 12px;\r\n  margin-left: 30px;\r\n}\r\n.toggles {\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n  align-items: center;\r\n}\r\n.toggle-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  justify-content: space-around;\r\n\r\n  padding: 10px;\r\n  width: 70%;\r\n  margin-top: 14px;\r\n  border: 1px solid rgba(255, 255, 255, 0.18);\r\n}\r\n.toggle-title {\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 15px;\r\n  color: #fff;\r\n}\r\n.toggle-btn {\r\n  width: 25px;\r\n  height: 25px;\r\n  cursor: pointer;\r\n  color: #fff;\r\n}\r\na {\r\n  text-decoration: none;\r\n  color: none;\r\n}\r\n.launchpad-container::-webkit-scrollbar {\r\n  width: 14px;\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n}\r\n\r\n.launchpad-container::-webkit-scrollbar-thumb {\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n  border-radius: 10px;\r\n}\r\n\r\n.launchpad-container::-webkit-scrollbar-track {\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n  border-radius: 10px;\r\n}\r\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/popup/components/Store/index.css":
/*!************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/popup/components/Store/index.css ***!
  \************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".store {\r\n  display: flex;\r\n  flex-direction: row;\r\n}\r\n.store-icons-container {\r\n  background: rgba(0, 0, 0, 0.75);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(3.5px);\r\n  -webkit-backdrop-filter: blur(3.5px);\r\n  border-radius: 10px;\r\n\r\n  width: 125px;\r\n  \r\n  height: 98.5vh;\r\n  display: flex;\r\n  flex-direction: column;\r\n  align-items: center;\r\n  align-items: center;\r\n  margin-left: 5.5px;\r\n  margin-top: 5.5px;\r\n  margin-bottom: 5.5px;\r\n}\r\n.store-icon {\r\n  width: 17px;\r\n  height: 17px;\r\n  cursor: pointer;\r\n  margin-top: 9px;\r\n  margin-bottom: 8px;\r\n  color: #fff;\r\n}\r\n\r\n.store-iocn-translator {\r\n  width: 17px;\r\n  height: 17px;\r\n  cursor: pointer;\r\n  margin-top: 8px;\r\n  margin-bottom: 8px;\r\n  color: #fff;\r\n}\r\n.store-icon-chat-gpt {\r\n  width: 17px;\r\n  height: 14px;\r\n  cursor: pointer;\r\n  margin-top: 8px;\r\n  margin-bottom: 8px;\r\n  color: #fff;\r\n}\r\n.each-store-iocn-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  justify-content: start;\r\n  height: 37px;\r\n  width: 100%;\r\n  padding-left: 10px;\r\n  cursor: pointer;\r\n  margin-top: 10px;\r\n}\r\n.active-each-store-iocn-container {\r\n  background: rgba(45, 45, 45, 0.85);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(9.5px);\r\n  -webkit-backdrop-filter: blur(9.5px);\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  justify-content: start;\r\n  height: 37px;\r\n  width: 100%;\r\n  padding-left: 10px;\r\n  cursor: pointer;\r\n  margin-top: 10px;\r\n}\r\n.store-icon-name {\r\n  font-family: \"roboto\";\r\n  font-weight: 600;\r\n  font-size: 15px;\r\n  color: #fff;\r\n  margin-left: 8px;\r\n}\r\n.widget-anchor-link {\r\n  color: #000;\r\n  text-decoration: none;\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n}\r\n.widget-icon {\r\n  width: 22px;\r\n  height: 22px;\r\n  border-radius: 4px;\r\n}\r\n.widget-title {\r\n  font-family: \"roboto\";\r\n  font-weight: 600;\r\n  font-size: 15.5px;\r\n  color: #fff;\r\n  margin-left: 8px;\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\r\n  width: 66px;\r\n}\r\n.delete-widget {\r\n  color: #fff;\r\n  margin-left: 8px;\r\n  height: 18px;\r\n  width: 18px;\r\n}\r\n.widget-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  justify-content: start;\r\n  height: 37px;\r\n  width: 100%;\r\n  padding-left: 10px;\r\n  cursor: pointer;\r\n  margin-top: 10px;\r\n}\r\n", "",{"version":3,"sources":["webpack://./src/popup/components/Store/index.css"],"names":[],"mappings":"AAAA;EACE,aAAa;EACb,mBAAmB;AACrB;AACA;EACE,+BAA+B;EAC/B,gDAAgD;EAChD,4BAA4B;EAC5B,oCAAoC;EACpC,mBAAmB;;EAEnB,YAAY;;EAEZ,cAAc;EACd,aAAa;EACb,sBAAsB;EACtB,mBAAmB;EACnB,mBAAmB;EACnB,kBAAkB;EAClB,iBAAiB;EACjB,oBAAoB;AACtB;AACA;EACE,WAAW;EACX,YAAY;EACZ,eAAe;EACf,eAAe;EACf,kBAAkB;EAClB,WAAW;AACb;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,eAAe;EACf,eAAe;EACf,kBAAkB;EAClB,WAAW;AACb;AACA;EACE,WAAW;EACX,YAAY;EACZ,eAAe;EACf,eAAe;EACf,kBAAkB;EAClB,WAAW;AACb;AACA;EACE,aAAa;EACb,mBAAmB;EACnB,mBAAmB;EACnB,sBAAsB;EACtB,YAAY;EACZ,WAAW;EACX,kBAAkB;EAClB,eAAe;EACf,gBAAgB;AAClB;AACA;EACE,kCAAkC;EAClC,gDAAgD;EAChD,4BAA4B;EAC5B,oCAAoC;EACpC,aAAa;EACb,mBAAmB;EACnB,mBAAmB;EACnB,sBAAsB;EACtB,YAAY;EACZ,WAAW;EACX,kBAAkB;EAClB,eAAe;EACf,gBAAgB;AAClB;AACA;EACE,qBAAqB;EACrB,gBAAgB;EAChB,eAAe;EACf,WAAW;EACX,gBAAgB;AAClB;AACA;EACE,WAAW;EACX,qBAAqB;EACrB,aAAa;EACb,mBAAmB;EACnB,mBAAmB;AACrB;AACA;EACE,WAAW;EACX,YAAY;EACZ,kBAAkB;AACpB;AACA;EACE,qBAAqB;EACrB,gBAAgB;EAChB,iBAAiB;EACjB,WAAW;EACX,gBAAgB;EAChB,gBAAgB;EAChB,uBAAuB;EACvB,mBAAmB;EACnB,WAAW;AACb;AACA;EACE,WAAW;EACX,gBAAgB;EAChB,YAAY;EACZ,WAAW;AACb;AACA;EACE,aAAa;EACb,mBAAmB;EACnB,mBAAmB;EACnB,sBAAsB;EACtB,YAAY;EACZ,WAAW;EACX,kBAAkB;EAClB,eAAe;EACf,gBAAgB;AAClB","sourcesContent":[".store {\r\n  display: flex;\r\n  flex-direction: row;\r\n}\r\n.store-icons-container {\r\n  background: rgba(0, 0, 0, 0.75);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(3.5px);\r\n  -webkit-backdrop-filter: blur(3.5px);\r\n  border-radius: 10px;\r\n\r\n  width: 125px;\r\n  \r\n  height: 98.5vh;\r\n  display: flex;\r\n  flex-direction: column;\r\n  align-items: center;\r\n  align-items: center;\r\n  margin-left: 5.5px;\r\n  margin-top: 5.5px;\r\n  margin-bottom: 5.5px;\r\n}\r\n.store-icon {\r\n  width: 17px;\r\n  height: 17px;\r\n  cursor: pointer;\r\n  margin-top: 9px;\r\n  margin-bottom: 8px;\r\n  color: #fff;\r\n}\r\n\r\n.store-iocn-translator {\r\n  width: 17px;\r\n  height: 17px;\r\n  cursor: pointer;\r\n  margin-top: 8px;\r\n  margin-bottom: 8px;\r\n  color: #fff;\r\n}\r\n.store-icon-chat-gpt {\r\n  width: 17px;\r\n  height: 14px;\r\n  cursor: pointer;\r\n  margin-top: 8px;\r\n  margin-bottom: 8px;\r\n  color: #fff;\r\n}\r\n.each-store-iocn-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  justify-content: start;\r\n  height: 37px;\r\n  width: 100%;\r\n  padding-left: 10px;\r\n  cursor: pointer;\r\n  margin-top: 10px;\r\n}\r\n.active-each-store-iocn-container {\r\n  background: rgba(45, 45, 45, 0.85);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(9.5px);\r\n  -webkit-backdrop-filter: blur(9.5px);\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  justify-content: start;\r\n  height: 37px;\r\n  width: 100%;\r\n  padding-left: 10px;\r\n  cursor: pointer;\r\n  margin-top: 10px;\r\n}\r\n.store-icon-name {\r\n  font-family: \"roboto\";\r\n  font-weight: 600;\r\n  font-size: 15px;\r\n  color: #fff;\r\n  margin-left: 8px;\r\n}\r\n.widget-anchor-link {\r\n  color: #000;\r\n  text-decoration: none;\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n}\r\n.widget-icon {\r\n  width: 22px;\r\n  height: 22px;\r\n  border-radius: 4px;\r\n}\r\n.widget-title {\r\n  font-family: \"roboto\";\r\n  font-weight: 600;\r\n  font-size: 15.5px;\r\n  color: #fff;\r\n  margin-left: 8px;\r\n  overflow: hidden;\r\n  text-overflow: ellipsis;\r\n  white-space: nowrap;\r\n  width: 66px;\r\n}\r\n.delete-widget {\r\n  color: #fff;\r\n  margin-left: 8px;\r\n  height: 18px;\r\n  width: 18px;\r\n}\r\n.widget-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  justify-content: start;\r\n  height: 37px;\r\n  width: 100%;\r\n  padding-left: 10px;\r\n  cursor: pointer;\r\n  margin-top: 10px;\r\n}\r\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/popup/components/Todo/index.css":
/*!***********************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/popup/components/Todo/index.css ***!
  \***********************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".todo-container {\r\n  width: 480px;\r\n  background: rgba(255, 254, 254, 0.75);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(3.5px);\r\n  -webkit-backdrop-filter: blur(3.5px);\r\n  border-radius: 10px;\r\n  height: 98.5vh;\r\n  border-radius: 12px;\r\n  margin-left: 5.5px;\r\n  overflow-y: scroll;\r\n  margin-top: 5.5px;\r\n}\r\n.login-todoist-button {\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n  align-items: center;\r\n  height: 100vh;\r\n  width: 100%;\r\n}\r\n.todoist-iframe {\r\n  height: 100vh;\r\n  width: 100%;\r\n  border: none;\r\n  outline: none;\r\n}\r\n.bottom-bar-todoist {\r\n  width: 100%;\r\n  height: 100vh;\r\n}\r\n.todo-container::-webkit-scrollbar {\r\n  width: 14px;\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n}\r\n\r\n.todo-container::-webkit-scrollbar-thumb {\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n  border-radius: 10px;\r\n}\r\n\r\n.todo-container::-webkit-scrollbar-track {\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n  border-radius: 10px;\r\n}\r\n", "",{"version":3,"sources":["webpack://./src/popup/components/Todo/index.css"],"names":[],"mappings":"AAAA;EACE,YAAY;EACZ,qCAAqC;EACrC,gDAAgD;EAChD,4BAA4B;EAC5B,oCAAoC;EACpC,mBAAmB;EACnB,cAAc;EACd,mBAAmB;EACnB,kBAAkB;EAClB,kBAAkB;EAClB,iBAAiB;AACnB;AACA;EACE,aAAa;EACb,sBAAsB;EACtB,uBAAuB;EACvB,mBAAmB;EACnB,aAAa;EACb,WAAW;AACb;AACA;EACE,aAAa;EACb,WAAW;EACX,YAAY;EACZ,aAAa;AACf;AACA;EACE,WAAW;EACX,aAAa;AACf;AACA;EACE,WAAW;EACX,qCAAqC;EACrC,gDAAgD;EAChD,0BAA0B;EAC1B,kCAAkC;EAClC,mBAAmB;AACrB;;AAEA;EACE,qCAAqC;EACrC,gDAAgD;EAChD,0BAA0B;EAC1B,kCAAkC;EAClC,mBAAmB;EACnB,mBAAmB;AACrB;;AAEA;EACE,qCAAqC;EACrC,gDAAgD;EAChD,0BAA0B;EAC1B,kCAAkC;EAClC,mBAAmB;EACnB,mBAAmB;AACrB","sourcesContent":[".todo-container {\r\n  width: 480px;\r\n  background: rgba(255, 254, 254, 0.75);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(3.5px);\r\n  -webkit-backdrop-filter: blur(3.5px);\r\n  border-radius: 10px;\r\n  height: 98.5vh;\r\n  border-radius: 12px;\r\n  margin-left: 5.5px;\r\n  overflow-y: scroll;\r\n  margin-top: 5.5px;\r\n}\r\n.login-todoist-button {\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n  align-items: center;\r\n  height: 100vh;\r\n  width: 100%;\r\n}\r\n.todoist-iframe {\r\n  height: 100vh;\r\n  width: 100%;\r\n  border: none;\r\n  outline: none;\r\n}\r\n.bottom-bar-todoist {\r\n  width: 100%;\r\n  height: 100vh;\r\n}\r\n.todo-container::-webkit-scrollbar {\r\n  width: 14px;\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n}\r\n\r\n.todo-container::-webkit-scrollbar-thumb {\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n  border-radius: 10px;\r\n}\r\n\r\n.todo-container::-webkit-scrollbar-track {\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n  border-radius: 10px;\r\n}\r\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/popup/components/Translator/index.css":
/*!*****************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/popup/components/Translator/index.css ***!
  \*****************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".translator-tab-container {\r\n  width: 380px;\r\n  background: rgba(0, 0, 0, 0.75);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(3.5px);\r\n  -webkit-backdrop-filter: blur(3.5px);\r\n  border-radius: 10px;\r\n  height: 98.5vh;\r\n  border-radius: 12px;\r\n  margin-left: 5.5px;\r\n  overflow-y: scroll;\r\n  margin-top: 5.5px;\r\n}\r\n.bottom-container {\r\n  padding: 15px;\r\n}\r\n.translate-btn {\r\n  background: rgba(0, 0, 0, 0.85);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(4px);\r\n  -webkit-backdrop-filter: blur(4px);\r\n  border-radius: 4px;\r\n  border: 1px solid rgba(255, 255, 255, 0.18);\r\n\r\n  height: 40px;\r\n  width: 125px;\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 15px;\r\n  color: #fff;\r\n  outline: none;\r\n  padding-left: 5px;\r\n}\r\n.translate-btn::-webkit-scrollbar {\r\n  width: 14px;\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n}\r\n\r\n.translate-btn::-webkit-scrollbar-thumb {\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n  border-radius: 10px;\r\n}\r\n\r\n.translate-btn::-webkit-scrollbar-track {\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n  border-radius: 10px;\r\n}\r\n.translate-icon {\r\n  width: 20px;\r\n  height: 20px;\r\n}\r\n.translate-btns-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  justify-content: space-around;\r\n  margin-top: 10px;\r\n}\r\n.input-text-container {\r\n  display: flex;\r\n  flex-direction: column;\r\n  border: 1.5px solid #ffffff;\r\n  box-shadow: 0 0 5px #ffffff;\r\n  margin-top: 19px;\r\n  border: 1px solid #262727;\r\n  padding: 0;\r\n  width: 100%;\r\n}\r\n.textarea-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  justify-content: space-between;\r\n}\r\ntextarea {\r\n  outline: none;\r\n  border: none;\r\n  resize: none;\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 14.4px;\r\n  padding-top: 4px;\r\n  width: 100%;\r\n  background-color: transparent;\r\n  margin-left: 4px;\r\n  margin-top: 3px;\r\n  color: #fff;\r\n  border-radius: 10px;\r\n}\r\n.clear-text-icon {\r\n  width: 24px;\r\n  height: 24px;\r\n  padding-top: 6px;\r\n  padding-right: 6px;\r\n  cursor: pointer;\r\n  color: #fff;\r\n}\r\n.textarea-bottom-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  margin-left: 10px;\r\n  align-items: center;\r\n  width: 100%;\r\n}\r\n.copy-button {\r\n  width: 60px;\r\n  height: 28px;\r\n  margin-bottom: 5px;\r\n  cursor: pointer;\r\n  color: #d7d7d7;\r\n  background-color: transparent;\r\n  border: 1px dashed #fff;\r\n}\r\n.textarea-length {\r\n  font-family: \"roboto\";\r\n  font-size: 13px;\r\n  font-weight: 500;\r\n}\r\n.on-translate-btn-container {\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n  align-items: center;\r\n  margin-top: 10px;\r\n}\r\n.on-translate-btn {\r\n  outline: none;\r\n  border: none;\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 17px;\r\n  color: #fff;\r\n  background: rgba(225, 225, 225, 0.5);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(4px);\r\n  -webkit-backdrop-filter: blur(4px);\r\n  border-radius: 6px;\r\n  border: 1px solid rgba(255, 255, 255, 0.18);\r\n  width: 100%;\r\n  height: 38px;\r\n\r\n  cursor: pointer;\r\n}\r\n.show-translated-text-container {\r\n  display: flex;\r\n  flex-direction: column;\r\n  width: 100%;\r\n  margin-top: 13px;\r\n  padding: 10px;\r\n}\r\n.translated-text {\r\n  color: #fff;\r\n  font-weight: 500;\r\n  font-size: 14px;\r\n}\r\n.loader {\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n  align-items: center;\r\n  margin-top: 18px;\r\n}\r\n.translator-tab-container::-webkit-scrollbar {\r\n  width: 14px;\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n}\r\n\r\n.translator-tab-container::-webkit-scrollbar-thumb {\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n  border-radius: 10px;\r\n}\r\n\r\n.translator-tab-container::-webkit-scrollbar-track {\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n  border-radius: 10px;\r\n}\r\n", "",{"version":3,"sources":["webpack://./src/popup/components/Translator/index.css"],"names":[],"mappings":"AAAA;EACE,YAAY;EACZ,+BAA+B;EAC/B,gDAAgD;EAChD,4BAA4B;EAC5B,oCAAoC;EACpC,mBAAmB;EACnB,cAAc;EACd,mBAAmB;EACnB,kBAAkB;EAClB,kBAAkB;EAClB,iBAAiB;AACnB;AACA;EACE,aAAa;AACf;AACA;EACE,+BAA+B;EAC/B,gDAAgD;EAChD,0BAA0B;EAC1B,kCAAkC;EAClC,kBAAkB;EAClB,2CAA2C;;EAE3C,YAAY;EACZ,YAAY;EACZ,qBAAqB;EACrB,gBAAgB;EAChB,eAAe;EACf,WAAW;EACX,aAAa;EACb,iBAAiB;AACnB;AACA;EACE,WAAW;EACX,qCAAqC;EACrC,gDAAgD;EAChD,0BAA0B;EAC1B,kCAAkC;EAClC,mBAAmB;AACrB;;AAEA;EACE,qCAAqC;EACrC,gDAAgD;EAChD,0BAA0B;EAC1B,kCAAkC;EAClC,mBAAmB;EACnB,mBAAmB;AACrB;;AAEA;EACE,qCAAqC;EACrC,gDAAgD;EAChD,0BAA0B;EAC1B,kCAAkC;EAClC,mBAAmB;EACnB,mBAAmB;AACrB;AACA;EACE,WAAW;EACX,YAAY;AACd;AACA;EACE,aAAa;EACb,mBAAmB;EACnB,mBAAmB;EACnB,6BAA6B;EAC7B,gBAAgB;AAClB;AACA;EACE,aAAa;EACb,sBAAsB;EACtB,2BAA2B;EAC3B,2BAA2B;EAC3B,gBAAgB;EAChB,yBAAyB;EACzB,UAAU;EACV,WAAW;AACb;AACA;EACE,aAAa;EACb,mBAAmB;EACnB,8BAA8B;AAChC;AACA;EACE,aAAa;EACb,YAAY;EACZ,YAAY;EACZ,qBAAqB;EACrB,gBAAgB;EAChB,iBAAiB;EACjB,gBAAgB;EAChB,WAAW;EACX,6BAA6B;EAC7B,gBAAgB;EAChB,eAAe;EACf,WAAW;EACX,mBAAmB;AACrB;AACA;EACE,WAAW;EACX,YAAY;EACZ,gBAAgB;EAChB,kBAAkB;EAClB,eAAe;EACf,WAAW;AACb;AACA;EACE,aAAa;EACb,mBAAmB;EACnB,iBAAiB;EACjB,mBAAmB;EACnB,WAAW;AACb;AACA;EACE,WAAW;EACX,YAAY;EACZ,kBAAkB;EAClB,eAAe;EACf,cAAc;EACd,6BAA6B;EAC7B,uBAAuB;AACzB;AACA;EACE,qBAAqB;EACrB,eAAe;EACf,gBAAgB;AAClB;AACA;EACE,aAAa;EACb,sBAAsB;EACtB,uBAAuB;EACvB,mBAAmB;EACnB,gBAAgB;AAClB;AACA;EACE,aAAa;EACb,YAAY;EACZ,qBAAqB;EACrB,gBAAgB;EAChB,eAAe;EACf,WAAW;EACX,oCAAoC;EACpC,gDAAgD;EAChD,0BAA0B;EAC1B,kCAAkC;EAClC,kBAAkB;EAClB,2CAA2C;EAC3C,WAAW;EACX,YAAY;;EAEZ,eAAe;AACjB;AACA;EACE,aAAa;EACb,sBAAsB;EACtB,WAAW;EACX,gBAAgB;EAChB,aAAa;AACf;AACA;EACE,WAAW;EACX,gBAAgB;EAChB,eAAe;AACjB;AACA;EACE,aAAa;EACb,sBAAsB;EACtB,uBAAuB;EACvB,mBAAmB;EACnB,gBAAgB;AAClB;AACA;EACE,WAAW;EACX,qCAAqC;EACrC,gDAAgD;EAChD,0BAA0B;EAC1B,kCAAkC;EAClC,mBAAmB;AACrB;;AAEA;EACE,qCAAqC;EACrC,gDAAgD;EAChD,0BAA0B;EAC1B,kCAAkC;EAClC,mBAAmB;EACnB,mBAAmB;AACrB;;AAEA;EACE,qCAAqC;EACrC,gDAAgD;EAChD,0BAA0B;EAC1B,kCAAkC;EAClC,mBAAmB;EACnB,mBAAmB;AACrB","sourcesContent":[".translator-tab-container {\r\n  width: 380px;\r\n  background: rgba(0, 0, 0, 0.75);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(3.5px);\r\n  -webkit-backdrop-filter: blur(3.5px);\r\n  border-radius: 10px;\r\n  height: 98.5vh;\r\n  border-radius: 12px;\r\n  margin-left: 5.5px;\r\n  overflow-y: scroll;\r\n  margin-top: 5.5px;\r\n}\r\n.bottom-container {\r\n  padding: 15px;\r\n}\r\n.translate-btn {\r\n  background: rgba(0, 0, 0, 0.85);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(4px);\r\n  -webkit-backdrop-filter: blur(4px);\r\n  border-radius: 4px;\r\n  border: 1px solid rgba(255, 255, 255, 0.18);\r\n\r\n  height: 40px;\r\n  width: 125px;\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 15px;\r\n  color: #fff;\r\n  outline: none;\r\n  padding-left: 5px;\r\n}\r\n.translate-btn::-webkit-scrollbar {\r\n  width: 14px;\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n}\r\n\r\n.translate-btn::-webkit-scrollbar-thumb {\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n  border-radius: 10px;\r\n}\r\n\r\n.translate-btn::-webkit-scrollbar-track {\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n  border-radius: 10px;\r\n}\r\n.translate-icon {\r\n  width: 20px;\r\n  height: 20px;\r\n}\r\n.translate-btns-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  justify-content: space-around;\r\n  margin-top: 10px;\r\n}\r\n.input-text-container {\r\n  display: flex;\r\n  flex-direction: column;\r\n  border: 1.5px solid #ffffff;\r\n  box-shadow: 0 0 5px #ffffff;\r\n  margin-top: 19px;\r\n  border: 1px solid #262727;\r\n  padding: 0;\r\n  width: 100%;\r\n}\r\n.textarea-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  justify-content: space-between;\r\n}\r\ntextarea {\r\n  outline: none;\r\n  border: none;\r\n  resize: none;\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 14.4px;\r\n  padding-top: 4px;\r\n  width: 100%;\r\n  background-color: transparent;\r\n  margin-left: 4px;\r\n  margin-top: 3px;\r\n  color: #fff;\r\n  border-radius: 10px;\r\n}\r\n.clear-text-icon {\r\n  width: 24px;\r\n  height: 24px;\r\n  padding-top: 6px;\r\n  padding-right: 6px;\r\n  cursor: pointer;\r\n  color: #fff;\r\n}\r\n.textarea-bottom-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  margin-left: 10px;\r\n  align-items: center;\r\n  width: 100%;\r\n}\r\n.copy-button {\r\n  width: 60px;\r\n  height: 28px;\r\n  margin-bottom: 5px;\r\n  cursor: pointer;\r\n  color: #d7d7d7;\r\n  background-color: transparent;\r\n  border: 1px dashed #fff;\r\n}\r\n.textarea-length {\r\n  font-family: \"roboto\";\r\n  font-size: 13px;\r\n  font-weight: 500;\r\n}\r\n.on-translate-btn-container {\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n  align-items: center;\r\n  margin-top: 10px;\r\n}\r\n.on-translate-btn {\r\n  outline: none;\r\n  border: none;\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 17px;\r\n  color: #fff;\r\n  background: rgba(225, 225, 225, 0.5);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(4px);\r\n  -webkit-backdrop-filter: blur(4px);\r\n  border-radius: 6px;\r\n  border: 1px solid rgba(255, 255, 255, 0.18);\r\n  width: 100%;\r\n  height: 38px;\r\n\r\n  cursor: pointer;\r\n}\r\n.show-translated-text-container {\r\n  display: flex;\r\n  flex-direction: column;\r\n  width: 100%;\r\n  margin-top: 13px;\r\n  padding: 10px;\r\n}\r\n.translated-text {\r\n  color: #fff;\r\n  font-weight: 500;\r\n  font-size: 14px;\r\n}\r\n.loader {\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n  align-items: center;\r\n  margin-top: 18px;\r\n}\r\n.translator-tab-container::-webkit-scrollbar {\r\n  width: 14px;\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n}\r\n\r\n.translator-tab-container::-webkit-scrollbar-thumb {\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n  border-radius: 10px;\r\n}\r\n\r\n.translator-tab-container::-webkit-scrollbar-track {\r\n  background: rgba(255, 245, 245, 0.25);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n  border-radius: 10px;\r\n}\r\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/popup/components/WeatherCard/index.css":
/*!******************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/popup/components/WeatherCard/index.css ***!
  \******************************************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
___CSS_LOADER_EXPORT___.push([module.id, "@import url(https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap);"]);
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".weather-datetime-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  justify-content: space-evenly;\r\n  background: rgba(0, 0, 0, 0.6);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n  border: 1px solid rgba(255, 255, 255, 0.18);\r\n  width: 280px;\r\n  height: 85px;\r\n  border-radius: 10px;\r\n  margin-top: 5px;\r\n  margin-right: 5.5px;\r\n  align-self: flex-end;\r\n}\r\n\r\n.climate-loader {\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n  align-items: center;\r\n}\r\n.temperature-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  color: #fff;\r\n}\r\n.temperature {\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 19px;\r\n  color: #fff;\r\n}\r\n.temperatureIcon {\r\n  margin-top: 0;\r\n  width: 35px;\r\n  height: 35px;\r\n  margin-right: 5px;\r\n  color: #fff;\r\n}\r\n.location {\r\n  font-family: \"roboto\";\r\n  font-weight: 400;\r\n  font-size: 15px;\r\n  color: #fff;\r\n}\r\n.time {\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 19px;\r\n  color: #fff;\r\n}\r\n.toDay {\r\n  font-family: \"roboto\";\r\n  font-weight: 400;\r\n  font-size: 15px;\r\n  color: #fff;\r\n  margin-top: 8px;\r\n}\r\n.horizonat-line-datetime {\r\n  height: 20px;\r\n  width: 0;\r\n  border: 1px solid #fff;\r\n}\r\n.datetime-container {\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n  align-items: center;\r\n}\r\n.weather-container {\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n  align-items: center;\r\n}\r\n.weather-datetime-container:hover {\r\n  background: rgba(0, 0, 0, 0.8);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n}\r\n.weather-updating-title {\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 14px;\r\n  color: #fff;\r\n  margin-top: 8px;\r\n}\r\n", "",{"version":3,"sources":["webpack://./src/popup/components/WeatherCard/index.css"],"names":[],"mappings":"AACA;EACE,aAAa;EACb,mBAAmB;EACnB,mBAAmB;EACnB,6BAA6B;EAC7B,8BAA8B;EAC9B,gDAAgD;EAChD,0BAA0B;EAC1B,kCAAkC;EAClC,mBAAmB;EACnB,2CAA2C;EAC3C,YAAY;EACZ,YAAY;EACZ,mBAAmB;EACnB,eAAe;EACf,mBAAmB;EACnB,oBAAoB;AACtB;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,uBAAuB;EACvB,mBAAmB;AACrB;AACA;EACE,aAAa;EACb,mBAAmB;EACnB,mBAAmB;EACnB,WAAW;AACb;AACA;EACE,qBAAqB;EACrB,gBAAgB;EAChB,eAAe;EACf,WAAW;AACb;AACA;EACE,aAAa;EACb,WAAW;EACX,YAAY;EACZ,iBAAiB;EACjB,WAAW;AACb;AACA;EACE,qBAAqB;EACrB,gBAAgB;EAChB,eAAe;EACf,WAAW;AACb;AACA;EACE,qBAAqB;EACrB,gBAAgB;EAChB,eAAe;EACf,WAAW;AACb;AACA;EACE,qBAAqB;EACrB,gBAAgB;EAChB,eAAe;EACf,WAAW;EACX,eAAe;AACjB;AACA;EACE,YAAY;EACZ,QAAQ;EACR,sBAAsB;AACxB;AACA;EACE,aAAa;EACb,sBAAsB;EACtB,uBAAuB;EACvB,mBAAmB;AACrB;AACA;EACE,aAAa;EACb,sBAAsB;EACtB,uBAAuB;EACvB,mBAAmB;AACrB;AACA;EACE,8BAA8B;EAC9B,gDAAgD;EAChD,0BAA0B;EAC1B,kCAAkC;AACpC;AACA;EACE,qBAAqB;EACrB,gBAAgB;EAChB,eAAe;EACf,WAAW;EACX,eAAe;AACjB","sourcesContent":["@import url(\"https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap\");\r\n.weather-datetime-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  justify-content: space-evenly;\r\n  background: rgba(0, 0, 0, 0.6);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n  border-radius: 10px;\r\n  border: 1px solid rgba(255, 255, 255, 0.18);\r\n  width: 280px;\r\n  height: 85px;\r\n  border-radius: 10px;\r\n  margin-top: 5px;\r\n  margin-right: 5.5px;\r\n  align-self: flex-end;\r\n}\r\n\r\n.climate-loader {\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n  align-items: center;\r\n}\r\n.temperature-container {\r\n  display: flex;\r\n  flex-direction: row;\r\n  align-items: center;\r\n  color: #fff;\r\n}\r\n.temperature {\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 19px;\r\n  color: #fff;\r\n}\r\n.temperatureIcon {\r\n  margin-top: 0;\r\n  width: 35px;\r\n  height: 35px;\r\n  margin-right: 5px;\r\n  color: #fff;\r\n}\r\n.location {\r\n  font-family: \"roboto\";\r\n  font-weight: 400;\r\n  font-size: 15px;\r\n  color: #fff;\r\n}\r\n.time {\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 19px;\r\n  color: #fff;\r\n}\r\n.toDay {\r\n  font-family: \"roboto\";\r\n  font-weight: 400;\r\n  font-size: 15px;\r\n  color: #fff;\r\n  margin-top: 8px;\r\n}\r\n.horizonat-line-datetime {\r\n  height: 20px;\r\n  width: 0;\r\n  border: 1px solid #fff;\r\n}\r\n.datetime-container {\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n  align-items: center;\r\n}\r\n.weather-container {\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-content: center;\r\n  align-items: center;\r\n}\r\n.weather-datetime-container:hover {\r\n  background: rgba(0, 0, 0, 0.8);\r\n  box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);\r\n  backdrop-filter: blur(0px);\r\n  -webkit-backdrop-filter: blur(0px);\r\n}\r\n.weather-updating-title {\r\n  font-family: \"roboto\";\r\n  font-weight: 500;\r\n  font-size: 14px;\r\n  color: #fff;\r\n  margin-top: 8px;\r\n}\r\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./src/popup/popup.css":
/*!*******************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/popup/popup.css ***!
  \*******************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
___CSS_LOADER_EXPORT___.push([module.id, "@import url(https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap);"]);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "* {\r\n  margin: 0;\r\n  padding: 0;\r\n}\r\n\r\n.back {\r\n  position: absolute;\r\n  right: 0;\r\n  bottom: 0;\r\n  z-index: -1;\r\n}\r\n\r\n@media (min-aspect-ratio: 16/9) {\r\n  .back {\r\n    width: 100%;\r\n    height: auto;\r\n  }\r\n}\r\n@media (max-aspect-ratio: 16/9) {\r\n  .back {\r\n    width: auto;\r\n    height: 100%;\r\n  }\r\n}\r\n", "",{"version":3,"sources":["webpack://./src/popup/popup.css"],"names":[],"mappings":"AACA;EACE,SAAS;EACT,UAAU;AACZ;;AAEA;EACE,kBAAkB;EAClB,QAAQ;EACR,SAAS;EACT,WAAW;AACb;;AAEA;EACE;IACE,WAAW;IACX,YAAY;EACd;AACF;AACA;EACE;IACE,WAAW;IACX,YAAY;EACd;AACF","sourcesContent":["@import url(\"https://fonts.googleapis.com/css2?family=Bree+Serif&family=Caveat:wght@400;700&family=Lobster&family=Monoton&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Playfair+Display+SC:ital,wght@0,400;0,700;1,700&family=Playfair+Display:ital,wght@0,400;0,700;1,700&family=Roboto:ital,wght@0,400;0,700;1,400;1,700&family=Source+Sans+Pro:ital,wght@0,400;0,700;1,700&family=Work+Sans:ital,wght@0,400;0,700;1,700&display=swap\");\r\n* {\r\n  margin: 0;\r\n  padding: 0;\r\n}\r\n\r\n.back {\r\n  position: absolute;\r\n  right: 0;\r\n  bottom: 0;\r\n  z-index: -1;\r\n}\r\n\r\n@media (min-aspect-ratio: 16/9) {\r\n  .back {\r\n    width: 100%;\r\n    height: auto;\r\n  }\r\n}\r\n@media (max-aspect-ratio: 16/9) {\r\n  .back {\r\n    width: auto;\r\n    height: 100%;\r\n  }\r\n}\r\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./src/popup/components/ChatGpt/index.css":
/*!************************************************!*\
  !*** ./src/popup/components/ChatGpt/index.css ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js!./index.css */ "./node_modules/css-loader/dist/cjs.js!./src/popup/components/ChatGpt/index.css");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__.default, options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__.default.locals || {});

/***/ }),

/***/ "./src/popup/components/History/index.css":
/*!************************************************!*\
  !*** ./src/popup/components/History/index.css ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js!./index.css */ "./node_modules/css-loader/dist/cjs.js!./src/popup/components/History/index.css");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__.default, options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__.default.locals || {});

/***/ }),

/***/ "./src/popup/components/HomeScreen/index.css":
/*!***************************************************!*\
  !*** ./src/popup/components/HomeScreen/index.css ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js!./index.css */ "./node_modules/css-loader/dist/cjs.js!./src/popup/components/HomeScreen/index.css");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__.default, options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__.default.locals || {});

/***/ }),

/***/ "./src/popup/components/LaunchPad/index.css":
/*!**************************************************!*\
  !*** ./src/popup/components/LaunchPad/index.css ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js!./index.css */ "./node_modules/css-loader/dist/cjs.js!./src/popup/components/LaunchPad/index.css");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__.default, options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__.default.locals || {});

/***/ }),

/***/ "./src/popup/components/Store/index.css":
/*!**********************************************!*\
  !*** ./src/popup/components/Store/index.css ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js!./index.css */ "./node_modules/css-loader/dist/cjs.js!./src/popup/components/Store/index.css");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__.default, options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__.default.locals || {});

/***/ }),

/***/ "./src/popup/components/Todo/index.css":
/*!*********************************************!*\
  !*** ./src/popup/components/Todo/index.css ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js!./index.css */ "./node_modules/css-loader/dist/cjs.js!./src/popup/components/Todo/index.css");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__.default, options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__.default.locals || {});

/***/ }),

/***/ "./src/popup/components/Translator/index.css":
/*!***************************************************!*\
  !*** ./src/popup/components/Translator/index.css ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js!./index.css */ "./node_modules/css-loader/dist/cjs.js!./src/popup/components/Translator/index.css");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__.default, options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__.default.locals || {});

/***/ }),

/***/ "./src/popup/components/WeatherCard/index.css":
/*!****************************************************!*\
  !*** ./src/popup/components/WeatherCard/index.css ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../../../node_modules/css-loader/dist/cjs.js!./index.css */ "./node_modules/css-loader/dist/cjs.js!./src/popup/components/WeatherCard/index.css");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__.default, options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__.default.locals || {});

/***/ }),

/***/ "./src/popup/popup.css":
/*!*****************************!*\
  !*** ./src/popup/popup.css ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_popup_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../node_modules/css-loader/dist/cjs.js!./popup.css */ "./node_modules/css-loader/dist/cjs.js!./src/popup/popup.css");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_popup_css__WEBPACK_IMPORTED_MODULE_1__.default, options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_popup_css__WEBPACK_IMPORTED_MODULE_1__.default.locals || {});

/***/ }),

/***/ "./src/popup/components/ChatGpt/index.tsx":
/*!************************************************!*\
  !*** ./src/popup/components/ChatGpt/index.tsx ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-spinners/ClipLoader */ "./node_modules/react-spinners/ClipLoader.js");
/* harmony import */ var react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _index_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index.css */ "./src/popup/components/ChatGpt/index.css");



const ChatGpt = (props) => {
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const { openChatGpt, isChatGptOpen } = props;
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const uniqueId = setInterval(() => {
            if (openChatGpt === false) {
                setError(!error);
            }
        }, 8000);
        if (openChatGpt === true) {
            setError(false);
        }
        if (openChatGpt === true) {
            clearInterval(uniqueId);
        }
    }, [openChatGpt]);
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        openChatGpt === false && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "chat-gpt-tab-container-error-msg" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement((react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_2___default()), { color: "white", className: "chat-gpt-error-img", loading: openChatGpt === false, size: 30 }),
            error && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("h1", { className: "error-msg-iframe" },
                "Cloudflare Security check required",
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("br", null),
                "Please login",
                " ",
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { className: "chat-gpt-link", href: "https://chat.openai.com/", target: "_blank" }, "chat.openai.com"),
                " ",
                "once and come back and refresh")))),
        openChatGpt && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("iframe", { className: "chat-gpt-tab-container", src: "https://chat.openai.com/chat", frameBorder: "0", allowTransparency: true }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChatGpt);


/***/ }),

/***/ "./src/popup/components/History/index.tsx":
/*!************************************************!*\
  !*** ./src/popup/components/History/index.tsx ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-icons/ai */ "./node_modules/react-icons/ai/index.esm.js");
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-icons/md */ "./node_modules/react-icons/md/index.esm.js");
/* harmony import */ var react_icons_ti__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-icons/ti */ "./node_modules/react-icons/ti/index.esm.js");
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-icons/fi */ "./node_modules/react-icons/fi/index.esm.js");
/* harmony import */ var _index_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index.css */ "./src/popup/components/History/index.css");






const History = (props) => {
    const { closeHistoryTab, isHistoryTabOpen } = props;
    const [recentlyClosedTabs, setRecentlyClosedTabs] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [todayHistory, setTodaysHistory] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [yesterdayHistory, setYesterdayHistory] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [suggestHistory, setSuggestHistory] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [showSuggestions, setShowsuggestions] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [userSearchValue, setUserSearchValue] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
    var today = new Date();
    var yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    var startTimeToday = today.setHours(0, 0, 0, 0);
    var endTimeToday = today.setHours(23, 59, 59, 999);
    var startTimeYesterday = yesterday.setHours(0, 0, 0, 0);
    var endTimeYesterday = yesterday.setHours(23, 59, 59, 999);
    const openFullHistory = () => {
        chrome.tabs.create({
            url: "chrome://history",
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        chrome.sessions.getRecentlyClosed({ maxResults: 7 }, (sessions) => {
            const closedTabs = [];
            sessions.forEach(function (session) {
                if (session.tab) {
                    closedTabs.push({
                        title: session.tab.title,
                        url: session.tab.url,
                    });
                }
                else if (session.window) {
                    session.window.tabs.forEach(function (tab) {
                        closedTabs.push({
                            title: tab.title,
                            url: tab.url,
                        });
                    });
                }
            });
            setRecentlyClosedTabs(closedTabs);
        });
        chrome.history.search({
            text: "",
            startTime: startTimeToday,
            endTime: endTimeToday,
        }, (data) => {
            setTodaysHistory(data);
        });
        chrome.history.search({
            text: "",
            startTime: startTimeYesterday,
            endTime: endTimeYesterday,
        }, (data) => {
            setYesterdayHistory(data);
        });
        chrome.history.search({ text: "" }, (data) => {
            setSuggestHistory(data);
        });
    }, []);
    const historyTab = () => {
        closeHistoryTab();
    };
    const getUserSearchedHistory = (event) => setShowsuggestions((prevStatus) => suggestHistory.filter((each) => each.title.toLowerCase().includes(event.target.value.toLowerCase())));
    const clearBrowsingHistory = () => {
        chrome.tabs.create({
            url: "chrome://settings/clearBrowserData",
        });
    };
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "history-tab-container" },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "top-bar" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "title-container" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "History.png", className: "tab-icon" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tab-title" }, "HISTORY")),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "settings-container" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(react_icons_ai__WEBPACK_IMPORTED_MODULE_2__.AiOutlineClear, { className: "clear-icon", onClick: clearBrowsingHistory }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(react_icons_md__WEBPACK_IMPORTED_MODULE_3__.MdOutlineOpenInNew, { className: "clear-icon", onClick: () => {
                        chrome.tabs.create({
                            url: "chrome://history/",
                        });
                    } }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(react_icons_ti__WEBPACK_IMPORTED_MODULE_4__.TiDeleteOutline, { className: "clear-icon", onClick: historyTab }))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "history-bottom-bar" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "search-history-container" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(react_icons_fi__WEBPACK_IMPORTED_MODULE_5__.FiSearch, { className: "search-icon" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { placeholder: "Search History", className: "history-search-input", type: "text", onChange: getUserSearchedHistory })),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "history-suggestions-container" }, showSuggestions.map((eachSuggestion) => (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "each-history-suggestion", key: eachSuggestion.id },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { target: "_blank", href: eachSuggestion.url, className: "history-suggestion-link" }, eachSuggestion.title))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "recently-closed-container" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("h1", { className: "recently-closed-heading" }, "Recently Closed"),
                recentlyClosedTabs.map((eachTab, id) => (react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { href: eachTab.url, target: "_blank", className: "recent-history", key: id },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: `https://www.google.com/s2/favicons?domain=${eachTab.url}&sz=128`, className: "recent-history-icon" }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "recent-history-title" }, eachTab.title))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "history-container" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("h1", { className: "history-header" }, "Today"),
                todayHistory.map((eachHistory) => (react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { href: eachHistory.url, target: "_blank", className: "history", key: eachHistory.id },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: `https://www.google.com/s2/favicons?domain=${eachHistory.url}&sz=128`, className: "history-icon" }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "history-title" }, eachHistory.title))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "history-container" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("h1", { className: "history-header" }, "Yesterday"),
                yesterdayHistory.map((eachHistory) => (react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { href: eachHistory.url, target: "_blank", className: "history", key: eachHistory.id },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: `https://www.google.com/s2/favicons?domain=${eachHistory.url}&sz=128`, className: "history-icon" }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "history-title" }, eachHistory.title))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "open-full-history-container", onClick: openFullHistory },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { type: "button", className: "open-full-history" }, "Open Full History"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("sup", null,
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(react_icons_md__WEBPACK_IMPORTED_MODULE_3__.MdOutlineOpenInNew, { className: "open-full-history-icon" }))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (History);


/***/ }),

/***/ "./src/popup/components/HomeScreen/StyledComponents.tsx":
/*!**************************************************************!*\
  !*** ./src/popup/components/HomeScreen/StyledComponents.tsx ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomeScreenContainer": () => (/* binding */ HomeScreenContainer),
/* harmony export */   "ThumbnailImg": () => (/* binding */ ThumbnailImg)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");

const HomeScreenContainer = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.div `
  background-image: url(${(props) => props.backgroundImage});
  height: 100vh;
  background-size: cover;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
`;
const ThumbnailImg = styled_components__WEBPACK_IMPORTED_MODULE_0__.default.img `
  opacity: ${(props) => (props.isActive ? "" : "0.3")};
  width: 180px;
  height: 150px;
  cursor: pointer;
  margin: 6px;
  border-radius: 7px;
`;


/***/ }),

/***/ "./src/popup/components/HomeScreen/index.tsx":
/*!***************************************************!*\
  !*** ./src/popup/components/HomeScreen/index.tsx ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react_uuid__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-uuid */ "./node_modules/react-uuid/uuid.js");
/* harmony import */ var react_uuid__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_uuid__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _WeatherCard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../WeatherCard */ "./src/popup/components/WeatherCard/index.tsx");
/* harmony import */ var _Store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Store */ "./src/popup/components/Store/index.tsx");
/* harmony import */ var _index_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./index.css */ "./src/popup/components/HomeScreen/index.css");
/* harmony import */ var _StyledComponents__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./StyledComponents */ "./src/popup/components/HomeScreen/StyledComponents.tsx");
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-icons/bs */ "./node_modules/react-icons/bs/index.esm.js");
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-icons/bi */ "./node_modules/react-icons/bi/index.esm.js");
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-icons/ai */ "./node_modules/react-icons/ai/index.esm.js");
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-icons/md */ "./node_modules/react-icons/md/index.esm.js");
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};










const initialBackgroundImages = [
    {
        id: 0,
        imageUrl: "https://res.cloudinary.com/dxnwg4dyz/image/upload/v1676978248/hd6_sizu2s.jpg",
    },
    {
        id: 2,
        imageUrl: "https://res.cloudinary.com/dxnwg4dyz/image/upload/v1676978247/hd5_qatadg.jpg",
    },
    {
        id: 3,
        imageUrl: "https://res.cloudinary.com/dxnwg4dyz/image/upload/v1676978247/hd1_k0ttep.jpg",
    },
    {
        id: 5,
        imageUrl: "https://res.cloudinary.com/dxnwg4dyz/image/upload/v1676978248/hd3_wgfedv.jpg",
    },
    {
        id: 6,
        imageUrl: "https://res.cloudinary.com/dxnwg4dyz/image/upload/v1676978739/hd7_khc4q5.jpg",
    },
    {
        id: 7,
        imageUrl: "https://res.cloudinary.com/dxnwg4dyz/image/upload/v1676978248/hd4_babkxk.jpg",
    },
];
const HomeScreen = () => {
    const [userWidgetsList, setUserWidgetsList] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(JSON.parse(localStorage.getItem("widgetsList")) || []);
    const [stateBackgroundImages, setBackgroundImages] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(JSON.parse(localStorage.getItem("backgroundImages")) ||
        initialBackgroundImages);
    const [addOrOpenWidgetsConatiner, setAddOrOpenWidgetsContainer] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [openBgContainer, setOpenBgContainer] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [openAddWidgetsContainer, setOpenAddWidgetsContainer] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [widgetUrlFromUser, setWidgetUrlFromUser] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
    const [widgetUrlErrorMsg, setWidgetUrlErrorMsg] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
    const [widgetUrlError, setWidgetUrlError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    let [defaultBg, setDefaultBg] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    let [loadedMyBg, setLoadedMyBg] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const fileInputRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const [compressedImage, setCompressedImage] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(JSON.parse(localStorage.getItem("userSettedBgImage")) || "");
    const [activeBg, setActiveBg] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(localStorage.getItem("activeBg") || stateBackgroundImages[0].imageUrl);
    const [activeId, setActiveId] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(localStorage.getItem("activeBgId") || stateBackgroundImages[0].id);
    const fileSelectedHandler = (event) => {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = (event) => {
                const img = new Image();
                img.src = `${event.target.result}`;
                img.onload = () => {
                    const canvas = document.createElement("canvas");
                    const ctx = canvas.getContext("2d");
                    canvas.width = img.width;
                    canvas.height = img.height;
                    ctx.drawImage(img, 0, 0);
                    const compressed = canvas.toDataURL("image/jpeg", 0.5);
                    setActiveBg(compressed);
                    setCompressedImage(compressed);
                    setActiveId(react_uuid__WEBPACK_IMPORTED_MODULE_1___default()());
                    const userSettedImage = JSON.parse(localStorage.getItem("userSettedBgImage"));
                    if (userSettedImage == undefined) {
                        localStorage.setItem("userSettedBgImage", JSON.stringify(compressed));
                    }
                    localStorage.setItem("userSettedBgImage", JSON.stringify(compressed));
                    const bg = localStorage.getItem("activeBg");
                    if (bg === undefined) {
                        localStorage.setItem("activeBg", JSON.stringify(compressed));
                    }
                    localStorage.setItem("activeBg", JSON.stringify(compressed));
                    var id = JSON.parse(localStorage.getItem("activeBgId"));
                    if (id === undefined) {
                        localStorage.setItem("activeBgId", JSON.stringify(react_uuid__WEBPACK_IMPORTED_MODULE_1___default()()));
                    }
                    localStorage.setItem("activeBgId", JSON.stringify(react_uuid__WEBPACK_IMPORTED_MODULE_1___default()()));
                    setOpenBgContainer(!openBgContainer);
                };
            };
        }
    };
    const customAddWidgets = () => {
        setOpenAddWidgetsContainer(true);
        if (openBgContainer === true) {
            setOpenBgContainer(false);
        }
    };
    const customOpenBgContainer = () => {
        setOpenBgContainer(true);
        if (openAddWidgetsContainer === true) {
            setOpenAddWidgetsContainer(false);
        }
    };
    let widgetsListLength = 0;
    let isUrlExits = false;
    const onSubmitWidget = (event) => __awaiter(void 0, void 0, void 0, function* () {
        event.preventDefault();
        function isValidUrl(url) {
            const regex = /^(ftp|http|https):\/\/[^ "]+$/;
            return regex.test(url);
        }
        if (isValidUrl(widgetUrlFromUser)) {
            setWidgetUrlError(false);
            setWidgetUrlErrorMsg("");
            setWidgetUrlFromUser("");
            const widgetIconResponse = yield fetch(`https://www.google.com/s2/favicons?domain=${widgetUrlFromUser}&sz=128`);
            const widgets = JSON.parse(localStorage.getItem("widgetsList"));
            if (widgets !== null) {
                widgetsListLength = widgets.length;
                widgets.forEach((each) => {
                    if (each.widgetUrl === widgetUrlFromUser) {
                        widgetsListLength = 10;
                        isUrlExits = true;
                    }
                });
            }
            if (widgetsListLength + 1 <= 5) {
                if (widgetIconResponse.ok) {
                    const newWidget = {
                        id: react_uuid__WEBPACK_IMPORTED_MODULE_1___default()(),
                        widgetName: new URL(widgetUrlFromUser).hostname.split(".")[0],
                        widgetIcon: widgetIconResponse.url,
                        widgetUrl: widgetUrlFromUser,
                    };
                    if (widgets === null || widgets === undefined) {
                        localStorage.setItem("widgetsList", JSON.stringify([newWidget]));
                        setUserWidgetsList(JSON.parse(localStorage.getItem("widgetsList")));
                    }
                    else {
                        localStorage.setItem("widgetsList", JSON.stringify([
                            ...JSON.parse(localStorage.getItem("widgetsList")),
                            newWidget,
                        ]));
                        setUserWidgetsList(JSON.parse(localStorage.getItem("widgetsList")));
                    }
                }
                else {
                    const newWidget = {
                        id: react_uuid__WEBPACK_IMPORTED_MODULE_1___default()(),
                        widgetName: new URL(widgetUrlFromUser).hostname.split(".")[0],
                        widgetIcon: "https://res.cloudinary.com/dxnwg4dyz/image/upload/v1676972773/default_oftrtq.png",
                        widgetUrl: widgetUrlFromUser,
                    };
                    if (widgets === null || widgets === undefined) {
                        localStorage.setItem("widgetsList", JSON.stringify([newWidget]));
                        setUserWidgetsList(JSON.parse(localStorage.getItem("widgetsList")));
                    }
                    else {
                        localStorage.setItem("widgetsList", JSON.stringify([
                            ...JSON.parse(localStorage.getItem("widgetsList")),
                            newWidget,
                        ]));
                        setUserWidgetsList(JSON.parse(localStorage.getItem("widgetsList")));
                    }
                }
            }
            else {
                setWidgetUrlError(true);
                if (isUrlExits) {
                    setWidgetUrlErrorMsg("This widgets is already exits in My Widgets Tab");
                }
                else {
                    setWidgetUrlErrorMsg("Not exceded more than 5 widgets");
                }
            }
        }
        else {
            setWidgetUrlError(true);
            setWidgetUrlErrorMsg("*Please check provided Url");
        }
    });
    const deleteCustomWidget = (id) => {
        const initilWidgetsList = JSON.parse(localStorage.getItem("widgetsList"));
        const filteredWidgetsList = initilWidgetsList.filter((each) => each.id !== id);
        localStorage.setItem("widgetsList", JSON.stringify(filteredWidgetsList));
        setUserWidgetsList(filteredWidgetsList);
    };
    const [activeWidget, setActiveWidget] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("addWidgets");
    const [activeBackground, setActiveBackground] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("defaultBackground");
    const handleActiveWidgetTab = (activetab) => {
        setActiveWidget(activetab);
    };
    const handleActiveBackgroundTab = (activetab) => {
        setActiveBackground(activetab);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_StyledComponents__WEBPACK_IMPORTED_MODULE_5__.HomeScreenContainer, { backgroundImage: activeBg },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Store__WEBPACK_IMPORTED_MODULE_3__.default, { userWidgetsList: userWidgetsList }),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "left-side-containers" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_WeatherCard__WEBPACK_IMPORTED_MODULE_2__.default, null),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "bg-container" },
                openBgContainer && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "bg-container-thumbnails" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "gallery-title-nav-bar" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "gallery-titles-container" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("h1", { className: "default-gallery", onClick: () => {
                                    setDefaultBg(true);
                                    handleActiveBackgroundTab("defaultBackground");
                                }, style: {
                                    opacity: activeBackground === "defaultBackground" ? 1 : 0.4,
                                } }, "Default Gallery"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", { className: "widgets-hr" }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("h1", { className: "default-gallery", onClick: () => {
                                    setDefaultBg(false);
                                    handleActiveBackgroundTab("myBackground");
                                }, style: {
                                    opacity: activeBackground === "myBackground" ? 1 : 0.4,
                                } }, "My Background")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(react_icons_ai__WEBPACK_IMPORTED_MODULE_6__.AiOutlineCloseCircle, { className: "close-bg-popup", onClick: () => {
                                setOpenBgContainer(!openBgContainer);
                            } })),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "thumbnails-list-container" },
                        defaultBg &&
                            stateBackgroundImages.map((each) => (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_StyledComponents__WEBPACK_IMPORTED_MODULE_5__.ThumbnailImg, { onClick: () => {
                                    setActiveBg(each.imageUrl);
                                    setActiveId(each.id);
                                    const bg = localStorage.getItem("activeBg");
                                    if (bg === undefined) {
                                        localStorage.setItem("activeBg", each.imageUrl);
                                    }
                                    localStorage.setItem("activeBg", each.imageUrl);
                                    var id = JSON.parse(localStorage.getItem("activeBgId"));
                                    if (id === undefined) {
                                        localStorage.setItem("activeBgId", JSON.stringify(each.id));
                                    }
                                    localStorage.setItem("activeBgId", JSON.stringify(each.id));
                                }, className: "thumbnail-img", src: each.imageUrl, key: each.id, isActive: each.id ===
                                    JSON.parse(localStorage.getItem("activeBgId")) }))),
                        defaultBg === false && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "my-background-container" }, loadedMyBg && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("form", { className: "upload-new-bg-container", action: "#", onClick: () => {
                                fileInputRef.current.click();
                            }, onChange: (e) => {
                                fileSelectedHandler(e);
                            } },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { ref: fileInputRef, type: "file", accept: "image/*", hidden: true }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement(react_icons_bi__WEBPACK_IMPORTED_MODULE_7__.BiCloudUpload, { className: "upload-bg" }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "upload-bg-title" }, "Upload Background Image")))))))),
                openAddWidgetsContainer && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "add-widgets-container" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "widgets-navbar" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "widgets-title-container" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("h1", { className: "widgets-main-heading", onClick: () => {
                                    setAddOrOpenWidgetsContainer(true);
                                    handleActiveWidgetTab("addWidgets");
                                }, style: {
                                    opacity: activeWidget === "addWidgets" ? 1 : 0.4,
                                } }, "Add Widgets"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", { className: "widgets-hr" }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("h1", { className: "widgets-main-heading", onClick: () => {
                                    setAddOrOpenWidgetsContainer(false);
                                    handleActiveWidgetTab("myWidgets");
                                }, style: { opacity: activeWidget === "myWidgets" ? 1 : 0.4 } }, "My Widgets")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(react_icons_ai__WEBPACK_IMPORTED_MODULE_6__.AiOutlineCloseCircle, { className: "close-widget-popup", onClick: () => {
                                setOpenAddWidgetsContainer(false);
                            } })),
                    addOrOpenWidgetsConatiner ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("form", { className: "widget-form-container", onSubmit: onSubmitWidget },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "widget-from-msg" }, "You can add limited widgets Upto 5"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { type: "text", placeholder: "Enter the Url", className: "input-widget-url", value: widgetUrlFromUser, onChange: (e) => {
                                setWidgetUrlFromUser(e.target.value);
                                setWidgetUrlErrorMsg("");
                            } }),
                        widgetUrlError && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "widget-url-error-msg" }, widgetUrlErrorMsg)),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: "add-widget-button", type: "submit" }, "Add"))) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "my-widgets-container" }, userWidgetsList.map((each) => (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "each-my-widget-container", key: each.id, id: "widget-container" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "widget-logo-title" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: each.widgetIcon, className: "my-widget-icon" }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "my-widget-title" }, each.widgetName)),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(react_icons_md__WEBPACK_IMPORTED_MODULE_8__.MdOutlineDelete, { className: "delete-my-widget", onClick: () => {
                                deleteCustomWidget(each.id);
                            } })))))))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "bottom-features-container" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "background-image-icon-container" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(react_icons_md__WEBPACK_IMPORTED_MODULE_8__.MdOutlineWidgets, { className: "background-image-icon", onClick: customAddWidgets })),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "background-image-icon-container" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(react_icons_bs__WEBPACK_IMPORTED_MODULE_9__.BsImages, { className: "background-image-icon", onClick: customOpenBgContainer })))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeScreen);


/***/ }),

/***/ "./src/popup/components/LaunchPad/index.tsx":
/*!**************************************************!*\
  !*** ./src/popup/components/LaunchPad/index.tsx ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-icons/bi */ "./node_modules/react-icons/bi/index.esm.js");
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-icons/bs */ "./node_modules/react-icons/bs/index.esm.js");
/* harmony import */ var reactjs_popup_dist_index_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! reactjs-popup/dist/index.css */ "./node_modules/reactjs-popup/dist/index.css");
/* harmony import */ var react_uuid__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-uuid */ "./node_modules/react-uuid/uuid.js");
/* harmony import */ var react_uuid__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_uuid__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_Fi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-icons/Fi */ "./node_modules/react-icons/Fi/index.esm.js");
/* harmony import */ var react_icons_Ti__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-icons/Ti */ "./node_modules/react-icons/Ti/index.esm.js");
/* harmony import */ var _index_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./index.css */ "./src/popup/components/LaunchPad/index.css");








const LaunchPad = (props) => {
    var _a, _b, _c;
    const [mostVisitedSites, setMostVisitedSites] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [bookmarks, setBookmarks] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const [popup, setPopup] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [name, setName] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
    const [url, setUrl] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
    const [isSettingsOpen, setIsSettingsOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [mostVisitedToggle, setMostVisitedToggle] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)((_a = JSON.parse(localStorage.getItem("mostVisitedToggle"))) !== null && _a !== void 0 ? _a : true);
    const [favoritesToggle, setFavouritesToggle] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)((_b = JSON.parse(localStorage.getItem("favouriteToggle"))) !== null && _b !== void 0 ? _b : true);
    const [bookmarksToggle, setBookmarksToggle] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)((_c = JSON.parse(localStorage.getItem("bookmarksToggle"))) !== null && _c !== void 0 ? _c : true);
    const [favSitesList, setFavSitesList] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(JSON.parse(localStorage.getItem("launchpadFavourites")) || [
        { id: react_uuid__WEBPACK_IMPORTED_MODULE_2___default()(), name: "Youtube", url: "https://youtube.com/" },
        { id: react_uuid__WEBPACK_IMPORTED_MODULE_2___default()(), name: "Gmail", url: "https://mail.google.com/" },
        { id: react_uuid__WEBPACK_IMPORTED_MODULE_2___default()(), name: "Maps", url: "https://maps.google.com/" },
        { id: react_uuid__WEBPACK_IMPORTED_MODULE_2___default()(), name: "Facebook", url: "https://www.facebook.com/" },
        { id: react_uuid__WEBPACK_IMPORTED_MODULE_2___default()(), name: "Drive", url: "https://drive.google.com/" },
        { id: react_uuid__WEBPACK_IMPORTED_MODULE_2___default()(), name: "Amazon", url: "https://www.amazon.in/" },
        { id: react_uuid__WEBPACK_IMPORTED_MODULE_2___default()(), name: "Meet", url: "https://meet.google.com/" },
        { id: react_uuid__WEBPACK_IMPORTED_MODULE_2___default()(), name: "Calender", url: "https://calendar.google.com/" },
    ]);
    const { closeLaunchPad } = props;
    const closeIconCLicked = () => {
        closeLaunchPad();
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        chrome.topSites.get((data) => {
            let urls = [];
            data.map((each) => {
                const visitedUrl = new URL(each.url).hostname;
                urls.push({ id: react_uuid__WEBPACK_IMPORTED_MODULE_2___default()(), url: visitedUrl });
            });
            setMostVisitedSites(urls);
        });
        chrome.bookmarks.getTree((res) => {
            setBookmarks(res[0].children[0].children);
        });
    }, []);
    const searchInput = (event) => {
        if (event.key === "Enter") {
            chrome.tabs.create({
                url: `https://www.google.com/search?q=${event.target.value}`,
            });
            event.target.value = "";
        }
    };
    const closePopup = () => {
        setPopup((prevStatus) => !prevStatus);
    };
    const customAddFavouritesToList = () => {
        setPopup((prevStatus) => !prevStatus);
        const newFav = {
            id: react_uuid__WEBPACK_IMPORTED_MODULE_2___default()(),
            name,
            url,
        };
        setFavSitesList([...favSitesList, newFav]);
        localStorage.setItem("launchpadFavourites", JSON.stringify([...favSitesList, newFav]));
    };
    const customSettings = () => {
        setIsSettingsOpen((prevStatus) => !prevStatus);
    };
    const customToggleMostVisited = () => {
        let toggleMostVisited = JSON.parse(localStorage.getItem("mostVisitedToggle"));
        if (toggleMostVisited === undefined) {
            localStorage.setItem("mostVisitedToggle", JSON.stringify(!mostVisitedToggle));
        }
        localStorage.setItem("mostVisitedToggle", JSON.stringify(!mostVisitedToggle));
        setMostVisitedToggle(JSON.parse(localStorage.getItem("mostVisitedToggle")));
    };
    const customToggleFavourites = () => {
        let toggleFavourite = JSON.parse(localStorage.getItem("favouriteToggle"));
        if (toggleFavourite === undefined) {
            localStorage.setItem("favouriteToggle", JSON.stringify(!favoritesToggle));
        }
        localStorage.setItem("favouriteToggle", JSON.stringify(!favoritesToggle));
        setFavouritesToggle(JSON.parse(localStorage.getItem("favouriteToggle")));
    };
    const customToggleBookmarks = () => {
        let toggleBookmarks = JSON.parse(localStorage.getItem("bookmarksToggle"));
        if (toggleBookmarks === undefined) {
            localStorage.setItem("bookmarksToggle", JSON.stringify(!bookmarksToggle));
        }
        localStorage.setItem("bookmarksToggle", JSON.stringify(!bookmarksToggle));
        setBookmarksToggle(JSON.parse(localStorage.getItem("bookmarksToggle")));
    };
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "launchpad-container " },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "top-bar" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "title-container" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "Launchpad.png", className: "tab-icon" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tab-title" }, "LAUNCHPAD")),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "settings-container" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(react_icons_Fi__WEBPACK_IMPORTED_MODULE_4__.FiSettings, { className: "settings-icon", onClick: customSettings }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(react_icons_Ti__WEBPACK_IMPORTED_MODULE_5__.TiDeleteOutline, { className: "clear-icon", onClick: closeIconCLicked }))),
        isSettingsOpen ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "bottom-bar" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "settings-title-container" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(react_icons_bi__WEBPACK_IMPORTED_MODULE_6__.BiArrowBack, { className: "back-icon", onClick: () => setIsSettingsOpen((prevStatus) => !prevStatus) }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("h1", { className: "settings-title" }, "Settings")),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "sections-container" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("h1", { className: "sections-title" }, "Sections"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "toggles" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "toggle-container" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "toggle-title" }, "Most Visited"),
                        mostVisitedToggle ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react_icons_bs__WEBPACK_IMPORTED_MODULE_7__.BsToggle2On, { className: "toggle-btn", onClick: customToggleMostVisited })) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react_icons_bs__WEBPACK_IMPORTED_MODULE_7__.BsToggle2Off, { className: "toggle-btn", onClick: customToggleMostVisited }))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "toggle-container" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "toggle-title" }, "Favourites"),
                        favoritesToggle ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react_icons_bs__WEBPACK_IMPORTED_MODULE_7__.BsToggle2On, { className: "toggle-btn", onClick: customToggleFavourites })) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react_icons_bs__WEBPACK_IMPORTED_MODULE_7__.BsToggle2Off, { className: "toggle-btn", onClick: customToggleFavourites }))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "toggle-container" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "toggle-title" }, "Bookmarks"),
                        bookmarksToggle ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react_icons_bs__WEBPACK_IMPORTED_MODULE_7__.BsToggle2On, { className: "toggle-btn", onClick: customToggleBookmarks })) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react_icons_bs__WEBPACK_IMPORTED_MODULE_7__.BsToggle2Off, { className: "toggle-btn", onClick: customToggleBookmarks }))))))) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "bottom-bar" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "search-engine-container" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://res.cloudinary.com/dxnwg4dyz/image/upload/v1675245613/5a35540277d9e6.8445514415134443544909_ymq9xw.png", className: "google-icon" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { type: "text", placeholder: "Search Google", className: "search-input", onKeyDown: searchInput })),
            mostVisitedToggle && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "most-visited-card-container" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("h1", { className: "most-visited-title" }, "Most Visited"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "visited-sites-container" }, mostVisitedSites.map((eachSite) => (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "most-visited-logo-container", key: eachSite.id },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { href: `https://${eachSite.url}`, target: "_blank" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "most-visited-logo", src: `https://www.google.com/s2/favicons?domain=${eachSite.url}&sz=128` })))))))),
            favoritesToggle && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "most-visited-card-container" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "favourite-sites-header-container" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("h1", { className: "most-visited-title" }, "Favourites"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "add-favourite", onClick: () => setPopup((prevStatus) => !prevStatus) })),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "visited-sites-container" }, favSitesList.map((eachSite) => (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "most-visited-name-and-logo-container", key: eachSite.id },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "most-visited-logo-container" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { href: eachSite.url, target: "_blank" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "most-visited-logo", src: `https://www.google.com/s2/favicons?domain=${eachSite.url}&sz=128` }))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "site-name" }, eachSite.name))))))),
            bookmarksToggle && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "bookmarks-container" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("h1", { className: "bookmarks-header" }, "Bookmarks"),
                bookmarks.map((eachBookmark) => (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { key: eachBookmark.id },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { href: eachBookmark.url, target: "_blank", className: "bookmark" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "bookmarks-icon", src: `https://www.google.com/s2/favicons?domain=${eachBookmark.url}&sz=128` }),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "bookmarks-title" }, eachBookmark.title)))))))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LaunchPad);


/***/ }),

/***/ "./src/popup/components/Store/index.tsx":
/*!**********************************************!*\
  !*** ./src/popup/components/Store/index.tsx ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react_icons_si__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-icons/si */ "./node_modules/react-icons/si/index.esm.js");
/* harmony import */ var _LaunchPad__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../LaunchPad */ "./src/popup/components/LaunchPad/index.tsx");
/* harmony import */ var _History__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../History */ "./src/popup/components/History/index.tsx");
/* harmony import */ var _Translator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Translator */ "./src/popup/components/Translator/index.tsx");
/* harmony import */ var _index_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./index.css */ "./src/popup/components/Store/index.css");
/* harmony import */ var _ChatGpt__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../ChatGpt */ "./src/popup/components/ChatGpt/index.tsx");
/* harmony import */ var _Todo__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../Todo */ "./src/popup/components/Todo/index.tsx");
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};








const Store = (props) => {
    const { userWidgetsList, deleteWidget } = props;
    const [isLauchPadOpen, setIsLaunchPadOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [isHistoryOpen, setIsHistoryOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [isTranslatorOpen, setIsTranslatorOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [isChatGptOpen, setIsChatGptOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [openChatGpt, setOpenChatGpt] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [isTodoOpen, setIsTodoOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [activeBgStoreIcon, setActiveBgStoreIcon] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
    const [isWidgetsInLocalStorage, setIsWidgetsInLocalStorage] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [showDeleteIcon, setShowDeleteIcon] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(-1);
    const [initialWidgetsList, setInitialWidgetsList] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(userWidgetsList);
    const customLaunchPad = () => {
        setIsLaunchPadOpen((prevStatus) => !prevStatus);
        if (isHistoryOpen || isTranslatorOpen || isChatGptOpen || isTodoOpen) {
            setIsHistoryOpen(false);
            setIsTranslatorOpen(false);
            setIsChatGptOpen(false);
            setIsTodoOpen(false);
        }
    };
    const customHistory = () => {
        setIsHistoryOpen((prevStatus) => !prevStatus);
        if (isLauchPadOpen || isTranslatorOpen || isChatGptOpen || isTodoOpen) {
            setIsLaunchPadOpen(false);
            setIsTranslatorOpen(false);
            setIsChatGptOpen(false);
            setIsTodoOpen(false);
        }
    };
    const customeTranslator = () => {
        setIsTranslatorOpen((prevStatus) => !prevStatus);
        if (isHistoryOpen || isLauchPadOpen || isChatGptOpen || isTodoOpen) {
            setIsHistoryOpen(false);
            setIsLaunchPadOpen(false);
            setIsChatGptOpen(false);
            setIsTodoOpen(false);
        }
    };
    const customChatGpt = () => __awaiter(void 0, void 0, void 0, function* () {
        setIsChatGptOpen((prevStatus) => !prevStatus);
        if (isHistoryOpen || isLauchPadOpen || isTranslatorOpen || isTodoOpen) {
            setIsHistoryOpen(false);
            setIsLaunchPadOpen(false);
            setIsTranslatorOpen(false);
            setIsTodoOpen(false);
        }
        const response = yield fetch("https://chat.openai.com/chat");
        console.log(response);
        if (response.ok) {
            setOpenChatGpt(!openChatGpt);
            console.log(response.statusText);
        }
    });
    const customTodo = () => {
        setIsTodoOpen((prevStatus) => !prevStatus);
        if (isHistoryOpen || isLauchPadOpen || isTranslatorOpen || isChatGptOpen) {
            setIsHistoryOpen(false);
            setIsLaunchPadOpen(false);
            setIsTranslatorOpen(false);
            setIsChatGptOpen(false);
        }
    };
    const closeLaunchPad = () => {
        setIsLaunchPadOpen((prevStatus) => !prevStatus);
    };
    const closeHistoryTab = () => {
        setIsHistoryOpen((prevStatus) => !prevStatus);
    };
    const closeTranslatorTab = () => {
        setIsTranslatorOpen((prevStatus) => !prevStatus);
    };
    const activeStoreLaunchPad = isLauchPadOpen
        ? "active-each-store-iocn-container"
        : "each-store-iocn-container";
    const activeStoreHistory = isHistoryOpen
        ? "active-each-store-iocn-container"
        : "each-store-iocn-container";
    const activeStoreTranslator = isTranslatorOpen
        ? "active-each-store-iocn-container"
        : "each-store-iocn-container";
    const activeStoreChatGpt = isChatGptOpen
        ? "active-each-store-iocn-container"
        : "each-store-iocn-container";
    const activeStoreTodo = isTodoOpen
        ? "active-each-store-iocn-container"
        : "each-store-iocn-container";
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const widgetsFromStorage = JSON.parse(localStorage.getItem("widgetsList"));
        setInitialWidgetsList(widgetsFromStorage);
        if (userWidgetsList.length !== 0) {
            setIsWidgetsInLocalStorage(true);
        }
    }, []);
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "store" },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "store-icons-container" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { onClick: customLaunchPad, className: `${activeStoreLaunchPad}` },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "Launchpad.png", className: "store-icon" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "store-icon-name" }, "LaunchPad")),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { onClick: customHistory, className: activeStoreHistory },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "History.png", className: "store-icon" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "store-icon-name" }, "History")),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { onClick: customeTranslator, className: activeStoreTranslator },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "Translate.png", className: "store-iocn-translator" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "store-icon-name" }, "Translator")),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { onClick: customChatGpt, className: activeStoreChatGpt },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "chatgpt.png", className: "store-icon-chat-gpt" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "store-icon-name" }, "ChatGpt")),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { onClick: customTodo, className: activeStoreTodo },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(react_icons_si__WEBPACK_IMPORTED_MODULE_7__.SiTodoist, { className: "store-icon" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "store-icon-name" }, "Todo")),
            userWidgetsList.length !== 0 &&
                userWidgetsList.map((each) => (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "widget-container", key: each.id, id: "widget-container" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("a", { href: each.widgetUrl, target: "_blank", className: "widget-anchor-link" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: each.widgetIcon, className: "widget-icon" }),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "widget-title" }, each.widgetName)))))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
            isLauchPadOpen && (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_LaunchPad__WEBPACK_IMPORTED_MODULE_1__.default, { closeLaunchPad: closeLaunchPad, isLauchPadOpen: isLauchPadOpen })),
            isHistoryOpen && (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_History__WEBPACK_IMPORTED_MODULE_2__.default, { isHistoryTabOpen: isHistoryOpen, closeHistoryTab: closeHistoryTab })),
            isTranslatorOpen && (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Translator__WEBPACK_IMPORTED_MODULE_3__.default, { closeTranslatorTab: closeTranslatorTab })),
            isChatGptOpen && (react__WEBPACK_IMPORTED_MODULE_0__.createElement(_ChatGpt__WEBPACK_IMPORTED_MODULE_5__.default, { openChatGpt: openChatGpt, isChatGptOpen: isChatGptOpen })),
            isTodoOpen && react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Todo__WEBPACK_IMPORTED_MODULE_6__.default, null))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Store);


/***/ }),

/***/ "./src/popup/components/Todo/index.tsx":
/*!*********************************************!*\
  !*** ./src/popup/components/Todo/index.tsx ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var _index_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index.css */ "./src/popup/components/Todo/index.css");


const Todo = () => {
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "todo-container " },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("iframe", { className: "todoist-iframe", frameBorder: "0", src: "https://todoist.com/app/today" })));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Todo);


/***/ }),

/***/ "./src/popup/components/Translator/index.tsx":
/*!***************************************************!*\
  !*** ./src/popup/components/Translator/index.tsx ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-spinners/ClipLoader */ "./node_modules/react-spinners/ClipLoader.js");
/* harmony import */ var react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_icons_ti__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-icons/ti */ "./node_modules/react-icons/ti/index.esm.js");
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-icons/io */ "./node_modules/react-icons/io/index.esm.js");
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-icons/bi */ "./node_modules/react-icons/bi/index.esm.js");
/* harmony import */ var react_icons_rx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-icons/rx */ "./node_modules/react-icons/rx/index.esm.js");
/* harmony import */ var _index_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index.css */ "./src/popup/components/Translator/index.css");
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};







const countries = [
    { code: "am", name: "Amharic" },
    { code: "ar", name: "Arabic" },
    { code: "be", name: "Bielarus" },
    { code: "bem", name: "Bemba" },
    { code: "bi", name: "Bislama" },
    { code: "bjs", name: "Bajan" },
    { code: "bn", name: "Bengali" },
    { code: "bo", name: "Tibetan" },
    { code: "br", name: "Breton" },
    { code: "bs", name: "Bosnian" },
    { code: "ca", name: "Catalan" },
    { code: "cop", name: "Coptic" },
    { code: "cs", name: "Czech" },
    { code: "cy", name: "Welsh" },
    { code: "da", name: "Danish" },
    { code: "dz", name: "Dzongkha" },
    { code: "de", name: "German" },
    { code: "dv", name: "Maldivian" },
    { code: "el", name: "Greek" },
    { code: "en", name: "English" },
    { code: "es", name: "Spanish" },
    { code: "et", name: "Estonian" },
    { code: "eu", name: "Basque" },
    { code: "fa", name: "Persian" },
    { code: "fi", name: "Finnish" },
    { code: "fn", name: "Fanagalo" },
    { code: "fo", name: "Faroese" },
    { code: "fr", name: "French" },
    { code: "gl", name: "Galician" },
    { code: "gu", name: "Gujarati" },
    { code: "ha", name: "Hausa" },
    { code: "he", name: "Hebrew" },
    { code: "hi", name: "Hindi" },
    { code: "hr", name: "Croatian" },
    { code: "hu", name: "Hungarian" },
    { code: "id", name: "Indonesian" },
    { code: "is", name: "Icelandic" },
    { code: "it", name: "Italian" },
    { code: "ja", name: "Japanese" },
    { code: "kk", name: "Kazakh" },
    { code: "km", name: "Khmer" },
    { code: "kn", name: "Kannada" },
    { code: "ko", name: "Korean" },
    { code: "ku", name: "Kurdish" },
    { code: "ky", name: "Kyrgyz" },
    { code: "la", name: "Latin" },
    { code: "lo", name: "Lao" },
    { code: "lv", name: "Latvian" },
    { code: "men", name: "Mende" },
    { code: "mg", name: "Malagasy" },
    { code: "mi", name: "Maori" },
    { code: "ms", name: "Malay" },
    { code: "mt", name: "Maltese" },
    { code: "my", name: "Burmese" },
    { code: "ne", name: "Nepali" },
    { code: "niu", name: "Niuean" },
    { code: "nl", name: "Dutch" },
    { code: "no", name: "Norwegian" },
    { code: "ny", name: "Nyanja" },
    { code: "ur", name: "Pakistani" },
    { code: "pau", name: "Palauan" },
    { code: "pa", name: "Panjabi" },
    { code: "ps", name: "Pashto" },
    { code: "pis", name: "Pijin" },
    { code: "pl", name: "Polish" },
    { code: "pt", name: "Portuguese" },
    { code: "rn", name: "Kirundi" },
    { code: "ro", name: "Romanian" },
    { code: "ru", name: "Russian" },
    { code: "sg", name: "Sango" },
    { code: "si", name: "Sinhala" },
    { code: "sk", name: "Slovak" },
    { code: "sm", name: "Samoan" },
    { code: "sn", name: "Shona" },
    { code: "so", name: "Somali" },
    { code: "sq", name: "Albanian" },
    { code: "sr", name: "Serbian" },
    { code: "sv", name: "Swedish" },
    { code: "sw", name: "Swahili" },
    { code: "ta", name: "Tamil" },
    { code: "te", name: "Telugu" },
    { code: "tet", name: "Tetum" },
    { code: "tg", name: "Tajik" },
    { code: "th", name: "Thai" },
    { code: "ti", name: "Tigrinya" },
    { code: "tk", name: "Turkmen" },
    { code: "tl", name: "Tagalog" },
    { code: "tn", name: "Tswana" },
    { code: "to", name: "Tongan" },
    { code: "tr", name: "Turkish" },
    { code: "uk", name: "Ukrainian" },
    { code: "uz", name: "Uzbek" },
    { code: "vi", name: "Vietnamese" },
    { code: "wo", name: "Wolof" },
    { code: "xh", name: "Xhosa" },
    { code: "yi", name: "Yiddish" },
    { code: "zu", name: "Zulu" },
];
const Translator = (props) => {
    const { closeTranslatorTab } = props;
    const [fromCountry, setFromCountry] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
    const [toCountry, setToCountry] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
    const [fromCountryCode, setFromCountryCode] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
    const [toCountryCode, setToCountryCode] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
    const userEnterValue = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const [translatedText, setTranslatedText] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
    const copyText = () => {
        userEnterValue.current.select();
        document.execCommand("copy");
    };
    const clearTextarea = () => {
        userEnterValue.current.value = "";
    };
    const getFromCountry = (event) => {
        setFromCountry(event.target.value);
        countries.forEach((each) => {
            if (event.target.value === each.name) {
                setFromCountryCode(each.code);
            }
        });
    };
    const getTOCountry = (event) => {
        setToCountry(event.target.value);
        countries.forEach((each) => {
            if (event.target.value === each.name) {
                setToCountryCode(each.code);
            }
        });
    };
    const customTranslate = () => __awaiter(void 0, void 0, void 0, function* () {
        setLoading(true);
        setTranslatedText("");
        const url = `https://api.mymemory.translated.net/get?q=${userEnterValue.current.value}&langpair=${fromCountryCode}|${toCountryCode}`;
        const response = yield fetch(url);
        if (response.ok) {
            const data = yield response.json();
            const text = data.responseData.translatedText;
            if (text ===
                "NO QUERY SPECIFIED. EXAMPLE REQUEST: GET?Q=HELLO&LANGPAIR=EN|IT") {
                setTranslatedText("Enter the specified words to translate");
                setLoading(false);
            }
            else {
                setTranslatedText(text);
                setLoading(false);
            }
        }
    });
    const closeTranslator = () => {
        closeTranslatorTab();
    };
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "translator-tab-container" },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "top-bar" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "title-container" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "Translate.png", className: "tab-icon" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "tab-title" }, "TRANSLATOR")),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "settings-container" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(react_icons_io__WEBPACK_IMPORTED_MODULE_2__.IoMdOpen, { className: "clear-icon" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(react_icons_ti__WEBPACK_IMPORTED_MODULE_3__.TiDeleteOutline, { className: "clear-icon", onClick: closeTranslator }))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "bottom-container" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "translate-btns-container" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("select", { name: "countries", className: "translate-btn", onChange: getFromCountry }, countries.map((each) => (react__WEBPACK_IMPORTED_MODULE_0__.createElement("option", { value: each.name, key: each.code }, each.name)))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(react_icons_bi__WEBPACK_IMPORTED_MODULE_4__.BiTransfer, { className: "translate-icon" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("select", { name: "countries", className: "translate-btn", onChange: getTOCountry }, countries.map((each) => (react__WEBPACK_IMPORTED_MODULE_0__.createElement("option", { value: each.name, key: each.code }, each.name))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "input-text-container" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "textarea-container" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("textarea", { rows: 9, ref: userEnterValue }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(react_icons_rx__WEBPACK_IMPORTED_MODULE_5__.RxCross2, { className: "clear-text-icon", onClick: clearTextarea }))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "on-translate-btn-container" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { type: "button", className: "on-translate-btn", onClick: customTranslate }, "Translate")),
            loading && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "loader" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement((react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_6___default()), { color: "white", loading: loading, size: 35 }))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "show-translated-text-container" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "translated-text" }, translatedText)))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Translator);


/***/ }),

/***/ "./src/popup/components/WeatherCard/index.tsx":
/*!****************************************************!*\
  !*** ./src/popup/components/WeatherCard/index.tsx ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-spinners/ClipLoader */ "./node_modules/react-spinners/ClipLoader.js");
/* harmony import */ var react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _index_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./index.css */ "./src/popup/components/WeatherCard/index.css");
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};




class WeatherCard extends react__WEBPACK_IMPORTED_MODULE_0__.Component {
    constructor() {
        super(...arguments);
        this.state = {
            currentCity: "",
            temp: "",
            day: "",
            time: "",
            icon: "",
            loading: true,
        };
        this.getDateTime = () => {
            const now = new Date();
            const hours = `${now.getHours()}`.padStart(2, "0");
            const minutes = `${now.getMinutes()}`.padStart(2, "0");
            this.setState({ time: `${hours}:${minutes}` });
            const weekday = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
            const months = [
                "Jan",
                "Feb",
                "Mar",
                "Apr",
                "May",
                "June",
                "July",
                "Aug",
                "Sep",
                "Oct",
                "Nov",
                "De",
            ];
            const day = weekday[now.getDay()];
            const date = now.getDate();
            const month = months[now.getMonth()];
            this.setState({ day: `${day}, ${date} ${month}` });
        };
        this.getWeatherReport = () => __awaiter(this, void 0, void 0, function* () {
            const lat = localStorage.getItem("latitude");
            const lon = localStorage.getItem("longitude");
            const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=e4f273e6c4c93188f9964501de66d735&units=metric`;
            const options = {
                method: "GET",
            };
            const response = yield fetch(url, options);
            if (response.ok) {
                const fetchedData = yield response.json();
                const temp = Math.round(fetchedData.main.temp);
                const location = fetchedData.name;
                const icon = fetchedData.weather[0].icon;
                this.setState({ loading: false });
                this.setState({ currentCity: location, temp: temp });
                const iconImg = yield fetch(`https://openweathermap.org/img/wn/${icon}.png`);
                const fetchedImg = yield iconImg.blob();
                const imgUrl = URL.createObjectURL(fetchedImg);
                this.setState({ icon: imgUrl });
            }
        });
    }
    componentDidMount() {
        navigator.geolocation.getCurrentPosition((position) => {
            localStorage.setItem("latitude", `${position.coords.latitude}`);
            localStorage.setItem("longitude", `${position.coords.longitude}`);
        });
        this.getWeatherReport();
        this.getDateTime();
    }
    render() {
        const { temp, currentCity, time, day, icon, loading } = this.state;
        return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "weather-datetime-container" },
            loading ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "weather-container" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement((react_spinners_ClipLoader__WEBPACK_IMPORTED_MODULE_2___default()), { color: "white", loading: loading, size: 15 }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "weather-updating-title" }, "Updating..."))) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "weather-container" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "temperature-container" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { className: "temperatureIcon", src: icon }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "temperature" }, temp)),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "location" }, currentCity))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("hr", { className: "horizonat-line-datetime" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "datetime-container" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "time" }, time),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", { className: "toDay" }, day))));
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WeatherCard);


/***/ }),

/***/ "./src/popup/popup.tsx":
/*!*****************************!*\
  !*** ./src/popup/popup.tsx ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom */ "./node_modules/react-dom/index.js");
/* harmony import */ var _popup_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./popup.css */ "./src/popup/popup.css");
/* harmony import */ var _components_HomeScreen__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/HomeScreen */ "./src/popup/components/HomeScreen/index.tsx");




const App = () => {
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement(_components_HomeScreen__WEBPACK_IMPORTED_MODULE_3__.default, null)));
};
const root = document.createElement("div");
document.body.appendChild(root);
react_dom__WEBPACK_IMPORTED_MODULE_1__.render(react__WEBPACK_IMPORTED_MODULE_0__.createElement(App, null), root);
document.title = "New Tab";
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (App);


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					result = fn();
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"popup": 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			for(moduleId in moreModules) {
/******/ 				if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 					__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 				}
/******/ 			}
/******/ 			if(runtime) var result = runtime(__webpack_require__);
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkIds[i]] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkreact_extension_boilerplate"] = self["webpackChunkreact_extension_boilerplate"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, ["vendors-node_modules_react-dom_index_js-node_modules_react-icons_Fi_index_esm_js-node_modules-ff2ca7"], () => (__webpack_require__("./src/popup/popup.tsx")))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;
//# sourceMappingURL=popup.js.map