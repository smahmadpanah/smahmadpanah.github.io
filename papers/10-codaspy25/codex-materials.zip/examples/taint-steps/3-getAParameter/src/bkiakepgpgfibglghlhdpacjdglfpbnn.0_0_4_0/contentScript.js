/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!********************************************!*\
  !*** ./src/contentScript/contentScript.js ***!
  \********************************************/
console.log("Hello");

/******/ })()
;
//# sourceMappingURL=contentScript.js.map