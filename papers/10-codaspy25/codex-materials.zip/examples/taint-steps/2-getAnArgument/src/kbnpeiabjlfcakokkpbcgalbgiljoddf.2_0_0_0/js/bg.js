const AppSW = () => {
	// ======= constants
	if (
		!chrome.tabs.create ||
		!chrome.tabs.remove ||
		!chrome.tabs.onCreated.addListener ||
		!chrome.runtime.onInstalled.addListener ||
		!chrome.runtime.setUninstallURL
	) {
		throw new Error('some of the required permissions is not provided');
	}

	if (
		!chrome.action.onClicked.addListener ||
		!chrome.runtime.onMessage.addListener
	) {
		console.warn('some of the required permissions is not provided');
	}


	var newTabURL = chrome.runtime.getURL('index.html');
	var aboutURLs = ["about:newtab", "chrome://newtab"];
	var thanksPageURL = "https://charming-tab.com/search/a0302/thanks.php";
	var uninstallURL  = "https://charming-tab.com/search/a0302/uninstall.php";
	var autoFocus = false;


// ======= helper functions

	Array.prototype.hasItemStartsWith = function(str) {
		return this.reduce(function(acc, val) {
			return acc || (str.indexOf(val) == 0);
		}, false);
	};

// ======= initializing

	var createTab			   = chrome.tabs.create;
	var removeTab              = chrome.tabs.remove;
	var addOnCreatedListener   = chrome.tabs.onCreated.addListener;

// ======= main code

	function openNewTab() {
		createTab({url: newTabURL});
	}

	autoFocus && addOnCreatedListener(function(tab) {
		if (tab && tab.id && aboutURLs.hasItemStartsWith(tab.url)) {
			openNewTab();
			removeTab(tab.id);
		}
	});

	chrome.action.onClicked.addListener(() => {
		openNewTab();
	})

	thanksPageURL && chrome.tabs.onCreated.addListener(function(details) {
		if (details.reason === 'install') {
			createTab({url: thanksPageURL, active: false});
		}
	});
	uninstallURL && chrome.runtime.setUninstallURL(uninstallURL);

	chrome.runtime.onMessage.addListener(function(request) {
		if (request && request.openURL)
			createTab({url: request.openURL});
	});
}


AppSW();