const ex$1 = chrome || browser,
  wait = t => new Promise(e => setTimeout(e, t));
var Helper = {
  wait: wait,
  closeTab: closeTab,
  openTab: openTab,
  openPopup: openPopup,
  getURL: getURL,
  sendMsg: sendMsg,
  onMsg: onMsg,
  isRTL: isRTL,
  blobToBase64: blobToBase64,
  detectLanguage: detectLanguage,
  setPopupBadge: setPopupBadge,
  isIframe: isIframe
};

function closeTab() {
  ex$1.tabs.getCurrent(function (e) {
    ex$1.tabs.remove(e.id, function () {})
  })
}

function openTab(e) {
  ex$1.tabs.create({
    url: e
  })
}

function openPopup(e) {
  ex$1.windows.create({
    url: e,
    type: "popup",
    height: 800,
    width: 800
  })
}

function getURL(e) {
  return ex$1.runtime.getURL(e)
}

function sendMsg(e, t) {
  ex$1.runtime.sendMessage(e, t)
}

function onMsg(e) {
  ex$1.runtime.onMessage.addListener(e)
}

function isRTL(e) {
  return -1 < ["ar", "fa", "iw", "yi", "ur", "pa"].indexOf(e)
}

function blobToBase64(o) {
  return new Promise((e, t) => {
    const n = new FileReader;
    n.onloadend = () => e(n.result), n.readAsDataURL(o)
  })
}

function detectLanguage() {
  return navigator ? navigator.languages ? reviseLocale(navigator.languages[0]) : reviseLocale(navigator.language) : null
}

function reviseLocale(e) {
  return e.split("-")[0]
}

function setPopupBadge(e) {
  ex$1.action.setBadgeText({
    text: e
  }), ex$1.action.setBadgeBackgroundColor({
    color: [255, 0, 0, 255]
  })
}

function isIframe() {
  return window.self !== window.top
}
const ex = chrome || browser;
var Storage = {
  get: get$4,
  set: set$2,
  remove: remove$3
};
const MAX_QUOTA = 8e3;
async function set$2(e, t) {
  if (!(JSON.stringify(t).length > MAX_QUOTA)) return ex.storage.sync.set({
    [e]: t
  })
}
async function get$4(e) {
  var t = await ex.storage.sync.get(e) || {};
  return e ? t[e] : t
}
async function remove$3(e) {
  return ex.storage.sync.remove(e)
}
var commonjsGlobal = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
  textareaCaret = {
    exports: {}
  };
! function (e) {
  var c, l, u;
  c = ["direction", "boxSizing", "width", "height", "overflowX", "overflowY", "borderTopWidth", "borderRightWidth", "borderBottomWidth", "borderLeftWidth", "borderStyle", "paddingTop", "paddingRight", "paddingBottom", "paddingLeft", "fontStyle", "fontVariant", "fontWeight", "fontStretch", "fontSize", "fontSizeAdjust", "lineHeight", "fontFamily", "textAlign", "textTransform", "textIndent", "textDecoration", "letterSpacing", "wordSpacing", "tabSize", "MozTabSize"], l = "undefined" != typeof window, u = l && null != window.mozInnerScreenX, e.exports = function (e, t, n) {
    if (!l) throw new Error("textarea-caret-position#getCaretCoordinates should only be called in a browser");
    var o = n && n.debug || !1;
    !o || (a = document.querySelector("#input-textarea-caret-position-mirror-div")) && a.parentNode.removeChild(a), (n = document.createElement("div")).id = "input-textarea-caret-position-mirror-div", document.body.appendChild(n);
    var r = n.style,
      s = window.getComputedStyle ? window.getComputedStyle(e) : e.currentStyle,
      i = "INPUT" === e.nodeName;
    r.whiteSpace = "pre-wrap", i || (r.wordWrap = "break-word"), r.position = "absolute", o || (r.visibility = "hidden"), c.forEach(function (e) {
      i && "lineHeight" === e ? r.lineHeight = s.height : r[e] = s[e]
    }), u ? e.scrollHeight > parseInt(s.height) && (r.overflowY = "scroll") : r.overflow = "hidden", n.textContent = e.value.substring(0, t), i && (n.textContent = n.textContent.replace(/\s/g, " "));
    var a = document.createElement("span");
    return a.textContent = e.value.substring(t) || ".", n.appendChild(a), t = {
      top: a.offsetTop + parseInt(s.borderTopWidth),
      left: a.offsetLeft + parseInt(s.borderLeftWidth),
      height: parseInt(s.lineHeight)
    }, o ? a.style.backgroundColor = "#aaa" : document.body.removeChild(n), t
  }
}(textareaCaret);
var textarea = textareaCaret.exports;

function SelectedText(e) {
  var t, n, o = window.getSelection(),
    r = o + "",
    e = e.target;
  if ("INPUT" === e.tagName && !e.readOnly) return !1;
  if (!r.length) {
    if (!e || !e.selectionEnd) return !1;
    r = e.value.substring(e.selectionStart, e.selectionEnd)
  }
  if ((o + "").length && (t = (s = o.getRangeAt(0).getBoundingClientRect()).top, n = s.bottom, a = s.left, c = s.width), !n && !a) {
    if (!e.selectionEnd) return !1;
    var s, o = textarea(e, e.selectionStart),
      i = textarea(e, e.selectionEnd),
      a = (s = e.getBoundingClientRect()).left + o.left,
      c = i.left - o.left;
    o.top != i.top && (a = s.left, c = s.width), t = s.top + o.top, n = s.top + i.top
  }
  return {
    text: r,
    top: t,
    bottom: n,
    left: a,
    width: c,
    textarea: !!i
  }
}
var domify$1 = parse$1,
  div$1 = document.createElement("div");
div$1.innerHTML = '  <link/><table></table><a href="/a">a</a><input type="checkbox"/>';
var innerHTMLBug = !div$1.getElementsByTagName("link").length,
  div$1 = void 0,
  map$1 = {
    legend: [1, "<fieldset>", "</fieldset>"],
    tr: [2, "<table><tbody>", "</tbody></table>"],
    col: [2, "<table><tbody></tbody><colgroup>", "</colgroup></table>"],
    _default: innerHTMLBug ? [1, "X<div>", "</div>"] : [0, "", ""]
  };

function parse$1(e, t) {
  if ("string" != typeof e) throw new TypeError("String expected");
  t = t || document;
  var n = /<([\w:]+)/.exec(e);
  if (!n) return t.createTextNode(e);
  e = e.replace(/^\s+|\s+$/g, "");
  var o = n[1];
  if ("body" == o) return (r = t.createElement("html")).innerHTML = e, r.removeChild(r.lastChild);
  var r, n = map$1[o] || map$1._default,
    s = n[0],
    o = n[1],
    n = n[2];
  for ((r = t.createElement("div")).innerHTML = o + e + n; s--;) r = r.lastChild;
  if (r.firstChild == r.lastChild) return r.removeChild(r.firstChild);
  for (var i = t.createDocumentFragment(); r.firstChild;) i.appendChild(r.removeChild(r.firstChild));
  return i
}
map$1.td = map$1.th = [3, "<table><tbody><tr>", "</tr></tbody></table>"], map$1.option = map$1.optgroup = [1, '<select multiple="multiple">', "</select>"], map$1.thead = map$1.tbody = map$1.colgroup = map$1.caption = map$1.tfoot = [1, "<table>", "</table>"], map$1.polyline = map$1.ellipse = map$1.polygon = map$1.circle = map$1.text = map$1.line = map$1.path = map$1.rect = map$1.g = [1, '<svg xmlns="http://www.w3.org/2000/svg" version="1.1">', "</svg>"];
var toString$2 = Object.prototype.toString,
  componentType$1 = function (e) {
    switch (toString$2.call(e)) {
      case "[object Function]":
        return "function";
      case "[object Date]":
        return "date";
      case "[object RegExp]":
        return "regexp";
      case "[object Arguments]":
        return "arguments";
      case "[object Array]":
        return "array";
      case "[object String]":
        return "string"
    }
    return null === e ? "null" : void 0 === e ? "undefined" : e && 1 === e.nodeType ? "element" : e === Object(e) ? "object" : typeof e
  },
  globals = /\b(Array|Date|Object|Math|JSON)\b/g,
  componentProps = function (e, t) {
    var n = unique(props(e));
    return (t = t && "string" == typeof t ? prefixed(t) : t) ? map(e, n, t) : n
  },
  expr;

function props(e) {
  return e.replace(/\.\w+|\w+ *\(|"[^"]*"|'[^']*'|\/([^/]+)\//g, "").replace(globals, "").match(/[a-zA-Z_]\w*/g) || []
}

function map(e, t, n) {
  return e.replace(/\.\w+|\w+ *\(|"[^"]*"|'[^']*'|\/([^/]+)\/|[a-zA-Z_]\w*/g, function (e) {
    return "(" == e[e.length - 1] || ~t.indexOf(e) ? n(e) : e
  })
}

function unique(e) {
  for (var t = [], n = 0; n < e.length; n++) ~t.indexOf(e[n]) || t.push(e[n]);
  return t
}

function prefixed(t) {
  return function (e) {
    return t + e
  }
}
try {
  expr = require("props")
} catch (e) {
  expr = componentProps
}
var toFunction_1 = toFunction$1;

function toFunction$1(e) {
  switch ({}.toString.call(e)) {
    case "[object Object]":
      return objectToFunction(e);
    case "[object Function]":
      return e;
    case "[object String]":
      return stringToFunction(e);
    case "[object RegExp]":
      return regexpToFunction(e);
    default:
      return defaultToFunction(e)
  }
}

function defaultToFunction(t) {
  return function (e) {
    return t === e
  }
}

function regexpToFunction(t) {
  return function (e) {
    return t.test(e)
  }
}

function stringToFunction(e) {
  return /^ *\W+/.test(e) ? new Function("_", "return _ " + e) : new Function("_", "return " + get$3(e))
}

function objectToFunction(e) {
  var t, n = {};
  for (t in e) n[t] = ("string" == typeof e[t] ? defaultToFunction : toFunction$1)(e[t]);
  return function (e) {
    if ("object" != typeof e) return !1;
    for (var t in n) {
      if (!(t in e)) return !1;
      if (!n[t](e[t])) return !1
    }
    return !0
  }
}

function get$3(e) {
  var t, n, o = expr(e);
  if (!o.length) return "_." + e;
  for (t = 0; t < o.length; t++) e = stripNested(n = o[t], e, "('function' == typeof " + (n = "_." + n) + " ? " + n + "() : " + n + ")");
  return e
}

function stripNested(e, t, n) {
  return t.replace(new RegExp("(\\.)?" + e, "g"), function (e, t) {
    return t ? e : n
  })
}
try {
  var type$1 = require("type")
} catch (err) {
  var type$1 = componentType$1
}
var toFunction = toFunction_1,
  has$1 = Object.prototype.hasOwnProperty,
  componentEach = function (e, t, n) {
    switch (t = toFunction(t), n = n || this, type$1(e)) {
      case "array":
        return array(e, t, n);
      case "object":
        return "number" == typeof e.length ? array(e, t, n) : object(e, t, n);
      case "string":
        return string(e, t, n)
    }
  };

function string(e, t, n) {
  for (var o = 0; o < e.length; ++o) t.call(n, e.charAt(o), o)
}

function object(e, t, n) {
  for (var o in e) has$1.call(e, o) && t.call(n, o, e[o])
}

function array(e, t, n) {
  for (var o = 0; o < e.length; ++o) t.call(n, e[o], o)
}
var componentEvent$1 = {},
  bind$1 = window.addEventListener ? "addEventListener" : "attachEvent",
  unbind$1 = window.removeEventListener ? "removeEventListener" : "detachEvent",
  prefix$1 = "addEventListener" !== bind$1 ? "on" : "";
componentEvent$1.bind = function (e, t, n, o) {
  return e[bind$1](prefix$1 + t, n, o || !1), n
}, componentEvent$1.unbind = function (e, t, n, o) {
  return e[unbind$1](prefix$1 + t, n, o || !1), n
};
var toStr$1 = Object.prototype.toString,
  isArguments = function (e) {
    var t = toStr$1.call(e);
    return "[object Arguments]" === t || "[object Array]" !== t && null !== e && "object" == typeof e && "number" == typeof e.length && 0 <= e.length && "[object Function]" === toStr$1.call(e.callee)
  },
  has = Object.prototype.hasOwnProperty,
  toStr = Object.prototype.toString,
  isArgs = isArguments,
  hasDontEnumBug = !{
    toString: null
  }.propertyIsEnumerable("toString"),
  hasProtoEnumBug = function () {}.propertyIsEnumerable("prototype"),
  dontEnums = ["toString", "toLocaleString", "valueOf", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "constructor"],
  keysShim = function (e) {
    var t = null !== e && "object" == typeof e,
      n = "[object Function]" === toStr.call(e),
      o = isArgs(e),
      r = t && "[object String]" === toStr.call(e),
      s = [];
    if (!t && !n && !o) throw new TypeError("Object.keys called on a non-object");
    var i = hasProtoEnumBug && n;
    if (r && 0 < e.length && !has.call(e, 0))
      for (var a = 0; a < e.length; ++a) s.push(String(a));
    if (o && 0 < e.length)
      for (var c = 0; c < e.length; ++c) s.push(String(c));
    else
      for (var l in e) i && "prototype" === l || !has.call(e, l) || s.push(String(l));
    if (hasDontEnumBug)
      for (var o = e.constructor, u = o && o.prototype === e, p = 0; p < dontEnums.length; ++p) u && "constructor" === dontEnums[p] || !has.call(e, dontEnums[p]) || s.push(dontEnums[p]);
    return s
  };
keysShim.shim = function () {
  return Object.keys || (Object.keys = keysShim), Object.keys || keysShim
};
var objectKeys = keysShim,
  componentQuery = {
    exports: {}
  };
! function (e, t) {
  function n(e, t) {
    return t.querySelector(e)
  }(t = e.exports = function (e, t) {
    return n(e, t = t || document)
  }).all = function (e, t) {
    return (t = t || document).querySelectorAll(e)
  }, t.engine = function (e) {
    if (!e.one) throw new Error(".one callback required");
    if (!e.all) throw new Error(".all callback required");
    return n = e.one, t.all = e.all, t
  }
}(componentQuery, componentQuery.exports);
var trim$1 = {
  exports: {}
};
! function (e, t) {
  (t = e.exports = function (e) {
    return e.replace(/^\s*|\s*$/g, "")
  }).left = function (e) {
    return e.replace(/^\s*/, "")
  }, t.right = function (e) {
    return e.replace(/\s*$/, "")
  }
}(trim$1, trim$1.exports);
var attributes = {},
  toString$1 = Object.prototype.toString,
  componentType = function (e) {
    switch (toString$1.call(e)) {
      case "[object Date]":
        return "date";
      case "[object RegExp]":
        return "regexp";
      case "[object Arguments]":
        return "arguments";
      case "[object Array]":
        return "array";
      case "[object Error]":
        return "error"
    }
    return null === e ? "null" : void 0 === e ? "undefined" : e != e ? "nan" : e && 1 === e.nodeType ? "element" : isBuffer(e) ? "buffer" : typeof (e = e.valueOf ? e.valueOf() : Object.prototype.valueOf.apply(e))
  };

function isBuffer(e) {
  return !(null == e || !(e._isBuffer || e.constructor && "function" == typeof e.constructor.isBuffer && e.constructor.isBuffer(e)))
}
var typeOf = componentType,
  componentValue = function (e, t) {
    return 2 == arguments.length ? set$1(e, t) : get$2(e)
  };

function get$2(e) {
  switch (type(e)) {
    case "checkbox":
    case "radio":
      if (e.checked) {
        var t = e.getAttribute("value");
        return null == t || t
      }
      return !1;
    case "radiogroup":
      for (var n, o = 0; n = e[o]; o++)
        if (n.checked) return n.value;
      break;
    case "select":
      for (var r, o = 0; r = e.options[o]; o++)
        if (r.selected) return r.value;
      break;
    default:
      return e.value
  }
}

function set$1(e, t) {
  switch (type(e)) {
    case "checkbox":
    case "radio":
      e.checked = !!t;
      break;
    case "radiogroup":
      for (var n, o = 0; n = e[o]; o++) n.checked = n.value === t;
      break;
    case "select":
      for (var r, o = 0; r = e.options[o]; o++) r.selected = r.value === t;
      break;
    default:
      e.value = t
  }
}

function type(e) {
  var t = "array" == typeOf(e) || "object" == typeOf(e),
    n = (e = t ? e[0] : e).nodeName.toLowerCase(),
    e = e.getAttribute("type");
  return t && e && "radio" == e.toLowerCase() ? "radiogroup" : "input" == n && e && "checkbox" == e.toLowerCase() ? "checkbox" : "input" == n && e && "radio" == e.toLowerCase() ? "radio" : "select" == n ? "select" : n
}
var value = componentValue;
attributes.attr = function (t, n) {
  return 1 == arguments.length ? this[0] && this[0].getAttribute(t) : null == n ? this.removeAttr(t) : this.forEach(function (e) {
    e.setAttribute(t, n)
  })
}, attributes.removeAttr = function (t) {
  return this.forEach(function (e) {
    e.removeAttribute(t)
  })
}, attributes.prop = function (t, n) {
  return 1 == arguments.length ? this[0] && this[0][t] : this.forEach(function (e) {
    e[t] = n
  })
}, attributes.val = attributes.value = function (t) {
  return 0 == arguments.length ? this[0] ? value(this[0]) : void 0 : this.forEach(function (e) {
    value(e, t)
  })
};
var classes$1 = {},
  componentIndexof = function (e, t) {
    if (e.indexOf) return e.indexOf(t);
    for (var n = 0; n < e.length; ++n)
      if (e[n] === t) return n;
    return -1
  },
  index = componentIndexof,
  re = /\s+/,
  toString = Object.prototype.toString,
  componentClasses = function (e) {
    return new ClassList(e)
  };

function ClassList(e) {
  if (!e || !e.nodeType) throw new Error("A DOM element reference is required");
  this.el = e, this.list = e.classList
}
ClassList.prototype.add = function (e) {
  if (this.list) return this.list.add(e), this;
  var t = this.array();
  return ~index(t, e) || t.push(e), this.el.className = t.join(" "), this
}, ClassList.prototype.remove = function (e) {
  if ("[object RegExp]" == toString.call(e)) return this.removeMatching(e);
  if (this.list) return this.list.remove(e), this;
  var t = this.array(),
    e = index(t, e);
  return ~e && t.splice(e, 1), this.el.className = t.join(" "), this
}, ClassList.prototype.removeMatching = function (e) {
  for (var t = this.array(), n = 0; n < t.length; n++) e.test(t[n]) && this.remove(t[n]);
  return this
}, ClassList.prototype.toggle = function (e, t) {
  return this.list ? void 0 !== t && t === this.list.toggle(e, t) || this.list.toggle(e) : void 0 !== t ? t ? this.add(e) : this.remove(e) : this.has(e) ? this.remove(e) : this.add(e), this
}, ClassList.prototype.array = function () {
  var e = this.el.className.replace(/^\s+|\s+$/g, "").split(re);
  return "" === e[0] && e.shift(), e
}, ClassList.prototype.has = ClassList.prototype.contains = function (e) {
  return this.list ? this.list.contains(e) : !!~index(this.array(), e)
};
var classes = componentClasses;
classes$1.addClass = function (t) {
  return this.forEach(function (e) {
    e._classes = e._classes || classes(e), e._classes.add(t)
  })
}, classes$1.removeClass = function (t) {
  return this.forEach(function (e) {
    e._classes = e._classes || classes(e), e._classes.remove(t)
  })
}, classes$1.toggleClass = function (t, e) {
  var n = 2 == arguments.length ? e ? "add" : "remove" : "toggle";
  return this.forEach(function (e) {
    e._classes = e._classes || classes(e), e._classes[n](t)
  })
}, classes$1.hasClass = function (e) {
  for (var t, n = 0, o = this.length; n < o; n++)
    if ((t = this[n])._classes = t._classes || classes(t), t._classes.has(e)) return !0;
  return !1
};
var events$1 = {},
  componentDelegate = {},
  globalObject = {
    exports: {}
  };
! function (t) {
  try {
    t("export default global")
  } catch (e) {
    try {
      t("export default self")
    } catch (e) {
      try {
        globalObject.exports = commonjsGlobal
      } catch (e) {
        try {
          self.global = self
        } catch (e) {
          window.global = window
        }
      }
    }
  }
}(eval);
try {
  var query$1 = require("query")
} catch (err) {
  var query$1 = componentQuery.exports
}
var Element$1 = globalObject.exports.Element,
  proto$2 = Element$1 && Element$1.prototype || {},
  vendor$4 = proto$2.matches || proto$2.webkitMatchesSelector || proto$2.mozMatchesSelector || proto$2.msMatchesSelector || proto$2.oMatchesSelector,
  componentMatchesSelector = match$2;

function match$2(e, t) {
  if (!e || 1 !== e.nodeType) return !1;
  if (vendor$4) return vendor$4.call(e, t);
  for (var n = query$1.all(t, e.parentNode), o = 0; o < n.length; ++o)
    if (n[o] == e) return !0;
  return !1
}
try {
  var matches$1 = require("matches-selector")
} catch (err) {
  var matches$1 = componentMatchesSelector
}
var componentClosest = closest$1;

function closest$1(e, t, n) {
  for (n = n || document.documentElement; e && e !== n;) {
    if (matches$1(e, t)) return e;
    e = e.parentNode
  }
  return matches$1(e, t) ? e : null
}
var componentEvent = {},
  bind, unbind, prefix;

function detect() {
  bind = window.addEventListener ? "addEventListener" : "attachEvent", unbind = window.removeEventListener ? "removeEventListener" : "detachEvent", prefix = "addEventListener" !== bind ? "on" : ""
}
componentEvent.bind = function (e, t, n, o) {
  return bind || detect(), e[bind](prefix + t, n, o || !1), n
}, componentEvent.unbind = function (e, t, n, o) {
  return unbind || detect(), e[unbind](prefix + t, n, o || !1), n
};
var closest = componentClosest,
  event = componentEvent;
componentDelegate.bind = function (n, o, e, r, t) {
  return event.bind(n, e, function (e) {
    var t = e.target || e.srcElement;
    e.delegateTarget = closest(t, o, !0), e.delegateTarget && r.call(n, e)
  }, t)
}, componentDelegate.unbind = function (e, t, n, o) {
  event.unbind(e, t, n, o)
};
var events = componentEvent$1,
  delegate = componentDelegate;
events$1.on = function (t, n, o, r) {
  return "string" == typeof n ? this.forEach(function (e) {
    o._delegate = delegate.bind(e, n, t, o, r)
  }) : (r = o, o = n, this.forEach(function (e) {
    events.bind(e, t, o, r)
  }))
}, events$1.off = function (t, e, n, o) {
  return "string" == typeof e ? this.forEach(function (e) {
    delegate.unbind(e, t, n._delegate, o)
  }) : (o = n, n = e, this.forEach(function (e) {
    events.unbind(e, t, n, o)
  }))
};
var manipulate = {},
  browser$1 = {
    exports: {}
  },
  s = 1e3,
  m = 60 * s,
  h = 60 * m,
  d = 24 * h,
  w = 7 * d,
  y = 365.25 * d,
  ms = function (e, t) {
    t = t || {};
    var n = typeof e;
    if ("string" == n && 0 < e.length) return parse(e);
    if ("number" == n && isFinite(e)) return (t.long ? fmtLong : fmtShort)(e);
    throw new Error("val is not a non-empty string or a valid number. val=" + JSON.stringify(e))
  };

function parse(e) {
  if (!(100 < (e = String(e)).length)) {
    e = /^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(e);
    if (e) {
      var t = parseFloat(e[1]);
      switch ((e[2] || "ms").toLowerCase()) {
        case "years":
        case "year":
        case "yrs":
        case "yr":
        case "y":
          return t * y;
        case "weeks":
        case "week":
        case "w":
          return t * w;
        case "days":
        case "day":
        case "d":
          return t * d;
        case "hours":
        case "hour":
        case "hrs":
        case "hr":
        case "h":
          return t * h;
        case "minutes":
        case "minute":
        case "mins":
        case "min":
        case "m":
          return t * m;
        case "seconds":
        case "second":
        case "secs":
        case "sec":
        case "s":
          return t * s;
        case "milliseconds":
        case "millisecond":
        case "msecs":
        case "msec":
        case "ms":
          return t;
        default:
          return
      }
    }
  }
}

function fmtShort(e) {
  var t = Math.abs(e);
  return d <= t ? Math.round(e / d) + "d" : h <= t ? Math.round(e / h) + "h" : m <= t ? Math.round(e / m) + "m" : s <= t ? Math.round(e / s) + "s" : e + "ms"
}

function fmtLong(e) {
  var t = Math.abs(e);
  return d <= t ? plural(e, t, d, "day") : h <= t ? plural(e, t, h, "hour") : m <= t ? plural(e, t, m, "minute") : s <= t ? plural(e, t, s, "second") : e + " ms"
}

function plural(e, t, n, o) {
  t = 1.5 * n <= t;
  return Math.round(e / n) + " " + o + (t ? "s" : "")
}

function setup(t) {
  function c(e) {
    let i, t = null,
      n, o;

    function a(...r) {
      if (a.enabled) {
        const s = a;
        var e = Number(new Date),
          t = e - (i || e);
        s.diff = t, s.prev = i, s.curr = e, i = e, r[0] = c.coerce(r[0]), "string" != typeof r[0] && r.unshift("%O");
        let o = 0;
        r[0] = r[0].replace(/%([a-zA-Z%])/g, (e, t) => {
          if ("%%" === e) return "%";
          o++;
          const n = c.formatters[t];
          return "function" == typeof n && (t = r[o], e = n.call(s, t), r.splice(o, 1), o--), e
        }), c.formatArgs.call(s, r);
        const n = s.log || c.log;
        n.apply(s, r)
      }
    }
    return a.namespace = e, a.useColors = c.useColors(), a.color = c.selectColor(e), a.extend = r, a.destroy = c.destroy, Object.defineProperty(a, "enabled", {
      enumerable: !0,
      configurable: !1,
      get: () => null !== t ? t : (n !== c.namespaces && (n = c.namespaces, o = c.enabled(e)), o),
      set: e => {
        t = e
      }
    }), "function" == typeof c.init && c.init(a), a
  }

  function r(e, t) {
    const n = c(this.namespace + (void 0 === t ? ":" : t) + e);
    return n.log = this.log, n
  }

  function n(e) {
    return e.toString().substring(2, e.toString().length - 2).replace(/\.\*\?$/, "*")
  }
  return ((c.debug = c).default = c).coerce = function (e) {
    if (e instanceof Error) return e.stack || e.message;
    return e
  }, c.disable = function () {
    var e = [...c.names.map(n), ...c.skips.map(n).map(e => "-" + e)].join(",");
    return c.enable(""), e
  }, c.enable = function (e) {
    c.save(e), c.namespaces = e, c.names = [], c.skips = [];
    let t;
    const n = ("string" == typeof e ? e : "").split(/[\s,]+/),
      o = n.length;
    for (t = 0; t < o; t++) n[t] && ("-" === (e = n[t].replace(/\*/g, ".*?"))[0] ? c.skips.push(new RegExp("^" + e.substr(1) + "$")) : c.names.push(new RegExp("^" + e + "$")))
  }, c.enabled = function (e) {
    if ("*" === e[e.length - 1]) return !0;
    let t, n;
    for (t = 0, n = c.skips.length; t < n; t++)
      if (c.skips[t].test(e)) return !1;
    for (t = 0, n = c.names.length; t < n; t++)
      if (c.names[t].test(e)) return !0;
    return !1
  }, c.humanize = ms, c.destroy = function () {
    console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.")
  }, Object.keys(t).forEach(e => {
    c[e] = t[e]
  }), c.names = [], c.skips = [], c.formatters = {}, c.selectColor = function (t) {
    let n = 0;
    for (let e = 0; e < t.length; e++) n = (n << 5) - n + t.charCodeAt(e), n |= 0;
    return c.colors[Math.abs(n) % c.colors.length]
  }, c.enable(c.load()), c
}
var common = setup;
! function (t, n) {
  n.formatArgs = function (e) {
    if (e[0] = (this.useColors ? "%c" : "") + this.namespace + (this.useColors ? " %c" : " ") + e[0] + (this.useColors ? "%c " : " ") + "+" + t.exports.humanize(this.diff), this.useColors) {
      var o = "color: " + this.color;
      e.splice(1, 0, o, "color: inherit");
      let t = 0,
        n = 0;
      e[0].replace(/%[a-zA-Z%]/g, e => {
        "%%" !== e && (t++, "%c" === e && (n = t))
      }), e.splice(n, 0, o)
    }
  }, n.save = function (e) {
    try {
      e ? n.storage.setItem("debug", e) : n.storage.removeItem("debug")
    } catch (e) {}
  }, n.load = function () {
    let e;
    try {
      e = n.storage.getItem("debug")
    } catch (e) {}!e && "undefined" != typeof process && "env" in process && (e = process.env.DEBUG);
    return e
  }, n.useColors = function () {
    if ("undefined" != typeof window && window.process && ("renderer" === window.process.type || window.process.__nwjs)) return !0;
    if ("undefined" != typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().match(/(edge|trident)\/(\d+)/)) return !1;
    return "undefined" != typeof document && document.documentElement && document.documentElement.style && document.documentElement.style.WebkitAppearance || "undefined" != typeof window && window.console && (window.console.firebug || window.console.exception && window.console.table) || "undefined" != typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/) && 31 <= parseInt(RegExp.$1, 10) || "undefined" != typeof navigator && navigator.userAgent && navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/)
  }, n.storage = function () {
    try {
      return localStorage
    } catch (e) {}
  }(), n.destroy = (() => {
    let e = !1;
    return () => {
      e || (e = !0, console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`."))
    }
  })(), n.colors = ["#0000CC", "#0000FF", "#0033CC", "#0033FF", "#0066CC", "#0066FF", "#0099CC", "#0099FF", "#00CC00", "#00CC33", "#00CC66", "#00CC99", "#00CCCC", "#00CCFF", "#3300CC", "#3300FF", "#3333CC", "#3333FF", "#3366CC", "#3366FF", "#3399CC", "#3399FF", "#33CC00", "#33CC33", "#33CC66", "#33CC99", "#33CCCC", "#33CCFF", "#6600CC", "#6600FF", "#6633CC", "#6633FF", "#66CC00", "#66CC33", "#9900CC", "#9900FF", "#9933CC", "#9933FF", "#99CC00", "#99CC33", "#CC0000", "#CC0033", "#CC0066", "#CC0099", "#CC00CC", "#CC00FF", "#CC3300", "#CC3333", "#CC3366", "#CC3399", "#CC33CC", "#CC33FF", "#CC6600", "#CC6633", "#CC9900", "#CC9933", "#CCCC00", "#CCCC33", "#FF0000", "#FF0033", "#FF0066", "#FF0099", "#FF00CC", "#FF00FF", "#FF3300", "#FF3333", "#FF3366", "#FF3399", "#FF33CC", "#FF33FF", "#FF6600", "#FF6633", "#FF9900", "#FF9933", "#FFCC00", "#FFCC33"], n.log = console.debug || console.log || (() => {}), t.exports = common(n);
  const e = t.exports["formatters"];
  e.j = function (e) {
    try {
      return JSON.stringify(e)
    } catch (e) {
      return "[UnexpectedJSONParseError]: " + e.message
    }
  }
}(browser$1, browser$1.exports);
var toNoCase_1 = toNoCase,
  hasSpace = /\s/,
  hasCamel = /[a-z][A-Z]/,
  hasSeparator = /[\W_]/;

function toNoCase(e) {
  return hasSpace.test(e) ? e.toLowerCase() : (hasSeparator.test(e) && (e = unseparate(e)), (e = hasCamel.test(e) ? uncamelize(e) : e).toLowerCase())
}
var separatorSplitter = /[\W_]+(.|$)/g;

function unseparate(e) {
  return e.replace(separatorSplitter, function (e, t) {
    return t ? " " + t : ""
  })
}
var camelSplitter = /(.)([A-Z]+)/g;

function uncamelize(e) {
  return e.replace(camelSplitter, function (e, t, n) {
    return t + " " + n.toLowerCase().split("").join(" ")
  })
}
var clean$1 = toNoCase_1,
  toSpaceCase_1 = toSpaceCase;

function toSpaceCase(e) {
  return clean$1(e).replace(/[\W_]+(.|$)/g, function (e, t) {
    return t ? " " + t : ""
  })
}
var toSpace = toSpaceCase_1,
  toCamelCase_1 = toCamelCase;

function toCamelCase(e) {
  return toSpace(e).replace(/\s(\w)/g, function (e, t) {
    return t.toUpperCase()
  })
}
var support$1 = {},
  boxSizingReliableVal, pixelPositionVal, docElem = document.documentElement,
  container = document.createElement("div"),
  div = document.createElement("div");

function computePixelPositionAndBoxSizingReliable() {
  div.style.cssText = "-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;padding:1px;border:1px;display:block;width:4px;margin-top:1%;position:absolute;top:1%", docElem.appendChild(container);
  var e = window.getComputedStyle(div, null);
  pixelPositionVal = "1%" !== e.top, boxSizingReliableVal = "4px" === e.width, docElem.removeChild(container)
}
div.style.backgroundClip = "content-box", div.cloneNode(!0).style.backgroundClip = "", support$1.clearCloneStyle = "content-box" === div.style.backgroundClip, container.style.cssText = "border:0;width:0;height:0;position:absolute;top:0;left:-9999px;margin-top:1px", container.appendChild(div), support$1.pixelPosition = function () {
  return null == pixelPositionVal && computePixelPositionAndBoxSizingReliable(), pixelPositionVal
}, support$1.boxSizingReliable = function () {
  return null == boxSizingReliableVal && computePixelPositionAndBoxSizingReliable(), boxSizingReliableVal
}, support$1.reliableMarginRight = function () {
  var e = div.appendChild(document.createElement("div"));
  return e.style.cssText = div.style.cssText = divReset, e.style.marginRight = e.style.width = "0", div.style.width = "1px", docElem.appendChild(container), e = !parseFloat(window.getComputedStyle(e, null).marginRight), docElem.removeChild(container), div.innerHTML = "", e
};
var prefixes = ["Webkit", "O", "Moz", "ms"],
  vendor_1 = vendor$3;

function vendor$3(e, t) {
  if (t[e]) return e;
  for (var n = e[0].toUpperCase() + e.slice(1), o = e, r = prefixes.length; r--;)
    if ((e = prefixes[r] + n) in t) return e;
  return o
}
var debug$4 = browser$1.exports("css:prop"),
  vendor$2 = vendor_1,
  prop_1 = prop,
  cssProps = {
    float: "cssFloat" in document.documentElement.style ? "cssFloat" : "styleFloat"
  };

function prop(e, t) {
  return e = cssProps[e] || (cssProps[e] = vendor$2(e, t)), debug$4("transform property: %s => %s", e, t), e
}
var hooks$1 = {},
  withinDocument$1 = function (e) {
    for (var t = e; t = t.parentNode;)
      if (t == document) return !0;
    return !1
  },
  styles_1 = styles$1;

function styles$1(e) {
  return window.getComputedStyle ? e.ownerDocument.defaultView.getComputedStyle(e, null) : e.currentStyle
}
var debug$3 = browser$1.exports("css:computed"),
  withinDocument = withinDocument$1,
  styles = styles_1,
  computed_1 = computed$1;

function computed$1(e, t, n) {
  var n = n || styles(e);
  if (n) return "" !== (n = n.getPropertyValue && n.getPropertyValue(t) || n[t]) || withinDocument(e) || (debug$3("element not within document, try finding from style attribute"), n = style_1(e, t)), debug$3("computed value of %s: %s", t, n), void 0 === n ? n : n + ""
}
var debug$2 = browser$1.exports("css:css"),
  camelcase$1 = toCamelCase_1,
  computed = computed_1,
  property$1 = prop_1,
  css_1 = css$2,
  cssNormalTransform = {
    letterSpacing: 0,
    fontWeight: 400
  };

function css$2(e, t, n, o) {
  var r, s = hooks$1,
    i = camelcase$1(t),
    a = e.style,
    i = s[t = property$1(t, a)] || s[i];
  if (i && i.get && (debug$2("get hook provided. use that"), r = i.get(e, !0, n)), null == r && (debug$2("fetch the computed value of %s", t), r = computed(e, t)), "normal" == r && cssNormalTransform[t] && (r = cssNormalTransform[t], debug$2("normal => %s", r)), "" == n || n) {
    debug$2("converting value: %s into a number", r);
    t = parseFloat(r);
    return !0 === n || isNumeric(t) ? t || 0 : r
  }
  return r
}

function isNumeric(e) {
  return !isNan(parseFloat(e)) && isFinite(e)
}
var swap_1 = swap;

function swap(e, t, n, o) {
  for (var r in t) old[r] = e.style[r], e.style[r] = t[r];
  for (r in ret = n.apply(e, o || []), t) e.style[r] = old[r];
  return ret
}! function (e) {
  var t = componentEach,
    i = css_1,
    o = {
      position: "absolute",
      visibility: "hidden",
      display: "block"
    },
    n = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
    a = new RegExp("^(" + n + ")(?!px)[a-z%]+$", "i"),
    s = new RegExp("^(" + n + ")(.*)$", "i"),
    c = /^(none|table(?!-c[ea]).+)/,
    l = support$1,
    u = swap_1,
    p = computed_1,
    d = ["Top", "Right", "Bottom", "Left"];

  function f(e, t, n) {
    var o = !0,
      r = "width" === t ? e.offsetWidth : e.offsetHeight,
      s = p(e),
      i = l.boxSizing;
    if (r <= 0 || null == r) {
      if (((r = p(e, t, s)) < 0 || null == r) && (r = e.style[t]), a.test(r)) return r;
      o = i, r = parseFloat(r) || 0
    }
    return (r += m(e, t, n = n || "content", o)) + "px"
  }

  function m(e, t, n, o) {
    for (var r = n === (o ? "border" : "content") ? 4 : "width" == t ? 1 : 0, s = 0; r < 4; r += 2) "margin" === n && (s += i(e, n + d[r], !0)), o ? ("content" === n && (s -= i(e, "padding" + d[r], !0)), "margin" !== n && (s -= i(e, "border" + d[r] + "Width", !0))) : (s += i(e, "padding" + d[r], !0), "padding" !== n && (s += i(e, "border" + d[r] + "Width", !0)));
    return s
  }
  t(["width", "height"], function (r) {
    e[r] = {}, e[r].get = function (e, t, n) {
      if (t) return 0 == e.offsetWidth && c.test(i(e, "display")) ? u(e, o, function () {
        return f(e, r, n)
      }) : f(e, r, n)
    }, e[r].set = function (e, t, n) {
      var o = n && o(e);
      return t = t, n && m(e, r, n, "border-box" == i(e, "boxSizing", !1)), (e = s.exec(t)) ? Math.max(0, e[1]) + (e[2] || "px") : t
    }
  }), e.opacity = {}, e.opacity.get = function (e, t) {
    if (t) {
      e = p(e, "opacity");
      return "" == e ? "1" : e
    }
  }
}(hooks$1);
var debug$1 = browser$1.exports("css:style"),
  camelcase = toCamelCase_1,
  support = support$1,
  property = prop_1,
  hooks = hooks$1,
  style_1 = style,
  cssNumber = {
    columnCount: !0,
    fillOpacity: !0,
    fontWeight: !0,
    lineHeight: !0,
    opacity: !0,
    order: !0,
    orphans: !0,
    widows: !0,
    zIndex: !0,
    zoom: !0
  };

function style(e, t, n, o) {
  if (e && 3 !== e.nodeType && 8 !== e.nodeType && e.style) {
    var r = camelcase(t),
      s = e.style,
      i = typeof n;
    if (!n) return get$1(e, t, r, o);
    t = property(t, s);
    var a = hooks[t] || hooks[r];
    "number" != i || cssNumber[r] || (debug$1('adding "px" to end of number'), n += "px"), support.clearCloneStyle || "" !== n || 0 !== t.indexOf("background") || (debug$1('set property (%s) value to "inherit"', t), s[t] = "inherit"), a && a.set && void 0 === (n = a.set(e, n, o)) || (debug$1("set hook defined. setting property (%s) to %s", t, n), s[t] = "", s[t] = n)
  }
}

function get$1(e, t, n, o) {
  var r, s = e.style,
    n = hooks[t] || hooks[n];
  return n && n.get && void 0 !== (r = n.get(e, !1, o)) ? debug$1("get hook defined, returning: %s", r) : (r = s[t], debug$1("getting %s", r)), r
}
var debug = browser$1.exports("css"),
  set = style_1,
  get = css_1,
  componentCss = css$1;

function css$1(e, t, n) {
  if (e) {
    if (void 0 === n) return "object" == typeof t ? (debug("setting styles %j", t), setStyles(e, t)) : (debug("getting %s", t), get(e, t));
    var o = {};
    return o[t] = n, debug("setting styles %j", o), setStyles(e, o)
  }
}

function setStyles(e, t) {
  for (var n in t) set(e, n, t[n]);
  return e
}
var textContent = function (e, t) {
    var n = void 0 !== e.textContent ? "textContent" : "innerText";
    return void 0 !== t && (e[n] = t), e[n]
  },
  css = componentCss,
  text = textContent;

function getText(e) {
  var t, n = "";
  switch (e.nodeType) {
    case 1:
    case 9:
      n = text(e);
      break;
    case 11:
      n = e.textContent || e.innerText;
      break;
    case 3:
    case 4:
      return e.nodeValue;
    default:
      for (; t = e[i++];) n += getText(t)
  }
  return n
}
manipulate.text = function (n) {
  if (1 == arguments.length) return this.forEach(function (e) {
    if (11 == e.nodeType) {
      for (var t; t = e.firstChild;) e.removeChild(t);
      e.appendChild(document.createTextNode(n))
    } else text(e, n)
  });
  var t = "";
  return this.forEach(function (e) {
    11 == e.nodeType ? t += getText(e.firstChild) : t += text(e)
  }), t
}, manipulate.html = function (t) {
  return 1 == arguments.length ? this.forEach(function (e) {
    e.innerHTML = t
  }) : this[0] && this[0].innerHTML
}, manipulate.css = function (t, n) {
  return n || "object" == typeof t ? (this.forEach(function (e) {
    css(e, t, n)
  }), this) : css(this[0], t)
}, manipulate.prepend = function (e) {
  var o = this.dom;
  return this.forEach(function (t, n) {
    o(e).forEach(function (e) {
      e = n ? e.cloneNode(!0) : e, t.children.length ? t.insertBefore(e, t.firstChild) : t.appendChild(e)
    })
  }), this
}, manipulate.append = function (e) {
  var o = this.dom;
  return this.forEach(function (t, n) {
    o(e).forEach(function (e) {
      e = n ? e.cloneNode(!0) : e, t.appendChild(e)
    })
  }), this
}, manipulate.insertAfter = function (e) {
  var t = this.dom;
  return this.forEach(function (n) {
    t(e).forEach(function (e, t) {
      e.parentNode && (n = t ? n.cloneNode(!0) : n, e.parentNode.insertBefore(n, e.nextSibling))
    })
  }), this
}, manipulate.appendTo = function (e) {
  return this.dom(e).append(this), this
}, manipulate.replace = function (e) {
  var r = this;
  return this.dom(e).forEach(function (e, t) {
    var n = r[t],
      o = n.parentNode;
    o && (e = t ? e.cloneNode(!0) : e, o.replaceChild(e, n))
  }), this
}, manipulate.empty = function () {
  return this.forEach(function (e) {
    text(e, "")
  })
}, manipulate.remove = function () {
  return this.forEach(function (e) {
    var t = e.parentNode;
    t && t.removeChild(e)
  })
}, manipulate.clone = function () {
  var e = this.map(function (e) {
    return e.cloneNode(!0)
  });
  return this.dom(e)
}, manipulate.focus = function () {
  return this[0].focus(), this
};
var traverse = {},
  proto$1 = "undefined" != typeof Element ? Element.prototype : {},
  vendor$1 = proto$1.matches || proto$1.matchesSelector || proto$1.webkitMatchesSelector || proto$1.mozMatchesSelector || proto$1.msMatchesSelector || proto$1.oMatchesSelector,
  matchesSelector$1 = match$1;

function match$1(e, t) {
  if (!e || 1 !== e.nodeType) return !1;
  if (vendor$1) return vendor$1.call(e, t);
  for (var n = e.parentNode.querySelectorAll(t), o = 0; o < n.length; o++)
    if (n[o] == e) return !0;
  return !1
}
var matches = matchesSelector$1,
  yieldsTraverse = function (e, t, n, o) {
    var r = o || 1,
      s = [];
    if (!(t = t[e])) return s;
    for (; r != s.length && (1 == t.nodeType && (matches(t, n) && s.push(t), n || s.push(t)), t = t[e]););
    return s
  },
  proto = Element.prototype,
  vendor = proto.matches || proto.matchesSelector || proto.webkitMatchesSelector || proto.mozMatchesSelector || proto.msMatchesSelector || proto.oMatchesSelector,
  matchesSelector = match;

function match(e, t) {
  if (vendor) return vendor.call(e, t);
  for (var n = e.parentNode.querySelectorAll(t), o = 0; o < n.length; o++)
    if (n[o] == e) return !0;
  return !1
}! function (t) {
  var n = Array.prototype,
    e = componentEach,
    o = yieldsTraverse,
    s = toFunction_1,
    r = matchesSelector;
  t.find = function (e) {
    return this.dom(e, this)
  }, t.is = function (e) {
    for (var t, n = 0; t = this[n]; n++)
      if (r(t, e)) return !0;
    return !1
  }, t.parent = function (e, t) {
    return this.dom(o("parentNode", this[0], e, t || 1))
  }, t.next = function (e, t) {
    return this.dom(o("nextSibling", this[0], e, t || 1))
  }, t.prev = t.previous = function (e, t) {
    return this.dom(o("previousSibling", this[0], e, t || 1))
  }, t.each = function (e) {
    for (var t, n = this.dom, o = 0, r = this.length; o < r; o++) t = n(this[o]), e.call(t, t, o);
    return this
  }, t.forEach = function (e) {
    for (var t = 0, n = this.length; t < n; t++) e.call(this[t], this[t], t);
    return this
  }, t.map = function (e) {
    e = s(e);
    for (var t = this.dom, n = [], o = 0, r = this.length; o < r; o++) n.push(e.call(t(this[o]), this[o], o));
    return this.dom(n)
  }, t.filter = t.select = function (e) {
    e = s(e);
    for (var t = this.dom, n = [], o = 0, r = this.length; o < r; o++) e.call(t(this[o]), this[o], o) && n.push(this[o]);
    return this.dom(n)
  }, t.reject = function (e) {
    var t, n = this.dom,
      o = [],
      r = this.length;
    if (e = "string" == typeof e ? s(e) : e)
      for (t = 0; t < r; t++) e.call(n(this[t]), this[t], t) || o.push(this[t]);
    else
      for (t = 0; t < r; t++) this[t] != e && o.push(this[t]);
    return this.dom(o)
  }, t.at = function (e) {
    return this.dom(this[e])
  }, t.first = function () {
    return this.dom(this[0])
  }, t.last = function () {
    return this.dom(this[this.length - 1])
  }, e(["push", "pop", "shift", "splice", "unshift", "reverse", "sort", "toString", "concat", "join", "slice"], function (e) {
    t[e] = function () {
      return n[e].apply(this.toArray(), arguments)
    }
  })
}(traverse);
var domify = domify$1,
  each = componentEach,
  getKeys = objectKeys,
  query = componentQuery.exports,
  trim = trim$1.exports,
  slice = [].slice,
  isArray = Array.isArray || function (e) {
    return !!e && "[object Array]" === Object.prototype.toString.call(e)
  },
  attrs = ["id", "src", "rel", "cols", "rows", "type", "name", "href", "title", "style", "width", "height", "action", "method", "tabindex", "placeholder"],
  quickExpr = /^(?:[^#<]*(<[\w\W]+>)[^>]*$|#([\w\-]*)$)/,
  componentDom = dom;

function dom(e, t) {
  if (isArray(e)) return new List(e);
  if (e instanceof List) return e;
  if (e.nodeName) return new List([e]);
  if ("string" != typeof e) throw new TypeError("invalid selector");
  var n = trim.left(e);
  if (isHTML(n)) return new List([domify(n)], n);
  t = t ? t instanceof List ? t[0] : t : document;
  return new List(query.all(e, t), e)
}

function List(e, t) {
  for (var n = this.length = (e = e || []).length, o = 0; o < n; o++) this[o] = e[o];
  this.selector = t
}

function isHTML(e) {
  if ("<" === e.charAt(0) && ">" === e.charAt(e.length - 1) && 3 <= e.length) return !0;
  e = quickExpr.exec(e);
  return !(!e || !e[1])
}
dom.List = List, dom.attrs = attrs, dom.use = function (e, t) {
  var n, o = [];
  t = 2 == arguments.length ? (o.push(e), (n = {})[e] = t, n) : e.name ? (e = (t = e).name, o.push(e), (n = {})[e] = t, n) : (o = getKeys(e), e);
  for (var r = 0, s = o.length; r < s; r++) List.prototype[o[r]] = t[o[r]];
  return this
}, List.prototype.dom = dom, List.prototype.length = 0, List.prototype.splice = Array.prototype.splice, List.prototype.toArray = function () {
  return slice.call(this)
}, each(attrs, function (t) {
  List.prototype[t] = function (e) {
    return 0 == arguments.length ? this.attr(t) : this.attr(t, e)
  }
}), dom.use(attributes), dom.use(classes$1), dom.use(events$1), dom.use(manipulate), dom.use(traverse);
var scrolltop = function () {
    return window.pageYOffset || (document.documentElement.clientHeight ? document.documentElement : document.body).scrollTop
  },
  scrollleft = function () {
    return window.pageXOffset || (document.documentElement.clientWidth ? document.documentElement : document.body).scrollLeft
  },
  icon = {
    create: create$2,
    remove: remove$2,
    setLocation: setLocation$2
  };
const CLASS_TRANSLATE_BTN = "translate_btn";

function create$2(e, t) {
  const n = new Image;
  n.src = e;
  const o = componentDom(document.createElement("div")).addClass(CLASS_TRANSLATE_BTN).appendTo("body").on("mousedown", e => {
    t(o, e), e.cancelBubble = !0, e.stopPropagation && e.stopPropagation()
  });
  return o.append(n), o
}

function remove$2(e) {
  return e.remove(), null
}

function setLocation$2(e, t, n) {
  t = t.y || t.clientY, n = n.left + n.width;
  e.css({
    top: t + scrolltop() + "px",
    left: n + scrollleft() + "px"
  })
}
var spinner = {
  create: create$1,
  remove: remove$1,
  setLocation: setLocation$1
};
const CLASS_TRANSLATE_WRAPPER$1 = "translate_div";

function create$1(e) {
  const t = new Image;
  t.src = e;
  const n = componentDom(document.createElement("div")).addClass(CLASS_TRANSLATE_WRAPPER$1).appendTo("body").on("mousedown", function (e) {
    e.cancelBubble = !0, e.stopPropagation && e.stopPropagation()
  });
  e = componentDom(document.createElement("p")).css("textAlign", "center").append(t);
  return n.append(e), n
}

function remove$1(e) {
  return e.remove(), null
}

function setLocation$1(e, t, n) {
  let o = n.bottom + 5;
  n.textarea && (o = n.top === n.bottom ? n.top : n.bottom, o += parseInt(e.css("line-height"), 10)), e.css({
    top: o + scrolltop() + "px"
  }), setCenter$1(e, n)
}

function setCenter$1(e, t) {
  let n = t.left;
  var o = parseInt(e.css("width"), 10) + 10;
  o < t.width ? n += (t.width - o) / 2 : n -= (o - t.width) / 2, n < 0 && (n = 5), e.css({
    left: n + scrollleft() + "px"
  })
}
var bubble = {
  create: create,
  remove: remove,
  setLocation: setLocation
};
const CLASS_TRANSLATE_WRAPPER = "translate_div",
  CLASS_TRANSLATE_SPEAKER = "translate_audio",
  MIN_WIDTH = 150;

function create(e, t, n, o) {
  const r = componentDom(document.createElement("div")).addClass(CLASS_TRANSLATE_WRAPPER).on("mousedown", e => {
      e.cancelBubble = !0, e.stopPropagation && e.stopPropagation()
    }).appendTo("body"),
    s = new Image;
  s.src = e;
  e = componentDom(s).addClass(CLASS_TRANSLATE_SPEAKER).on("mousedown", () => {
    n()
  });
  r.append(e);
  e = t.sentences.filter(e => e.src_translit);
  if (0 < e.length) {
    var i = componentDom(document.createElement("span")).addClass("translate_translit").text(e[0].src_translit);
    const u = componentDom(document.createElement("p"));
    u.append(i), r.append(u)
  }
  const a = t.sentences.map(e => e.trans || "").join("");
  for (const p of a.split("\n")) r.append(componentDom(document.createElement("p")).addClass("translate_sentence").text(p));
  if (t.dict && 0 < t.dict.length)
    for (const d of t.dict) {
      r.append(document.createElement("hr"));
      var c = componentDom(document.createElement("p")).addClass("translate_pos").text(d.pos),
        l = componentDom(document.createElement("p")).addClass("translate_terms").text(d.terms.join(", "));
      r.append(c), r.append(l)
    }
  if (t.spell && t.spell.spell_res) {
    r.append(document.createElement("hr"));
    const f = componentDom(document.createElement("p")).addClass("translate_didumean").text("Did you mean ");
    i = componentDom(document.createElement("span")).addClass("translate_spell").text(t.spell.spell_res).on("mousedown", () => {
      o(t.spell.spell_res)
    });
    f.append(i), r.append(f)
  }
  return Helper.isRTL(t.target) && r.css({
    "text-align": "right",
    direction: "rtl"
  }), r
}

function remove(e) {
  return e.remove(), null
}

function setLocation(e, t, n) {
  let o = n.bottom + 5;
  n.textarea && (o = n.top === n.bottom ? n.top : n.bottom, o += parseInt(e.css("line-height"), 10));
  const r = {
    top: o + scrolltop() + "px"
  };
  let s = n.width;
  s = s < MIN_WIDTH ? MIN_WIDTH : s, r.maxWidth = s + "px", e.css(r), setCenter(e, n)
}

function setCenter(e, t) {
  let n = t.left;
  var o = parseInt(e.css("width"), 10) + 10;
  o < t.width ? n += (t.width - o) / 2 : n -= (o - t.width) / 2, n < 0 && (n = 5), e.css({
    left: n + scrollleft() + "px"
  })
}
var Reader = {
  getFileType: getFileType,
  joinPDFlines: joinPDFlines
};

function getFileType() {
  var e = document.getElementById("reader-type");
  return e ? e.value : null
}

function joinPDFlines(e) {
  let t = "",
    n = "";
  for (const r of e.split(/\r?\n/))
    if (0 !== r.length) {
      var o = n[n.length - 1];
      const s = r[0];
      [".", "!", '"', "?", "}", "]", ":", ";", "'"].includes(o) && s.toUpperCase() === s && (t += "\n"), t += r, n = r
    } return t
}
const DELAY_POPUP = 20,
  ERROR_LABEL = "There is an issue with the Google Translate server. Please try again in a moment...",
  src_spin = Helper.getURL("/img/loading.png"),
  src_logo = Helper.getURL("/logo/48.png"),
  src_speaker = Helper.getURL("/img/audio.png");
let ICON, SPINNER, BUBBLE, SETTINGS = null;
(async () => {
  var e = await Storage.get("settings");
  e && init(e), SETTINGS = e
})();
let currentMouseEvent = null;

function init(e) {
  e.dbclick && componentDom("html").on("dblclick", e => {
    check(e)
  }), e.shift && componentDom("html").on("keyup", e => {
    e && 16 === e.keyCode && check(e)
  }), e.icon && componentDom("html").on("mouseup", async e => {
    await Helper.wait(2 * DELAY_POPUP), SPINNER || BUBBLE || check(e, !0)
  }), componentDom("html").on("mousedown", () => {
    clean()
  }), componentDom("html").on("keyup", e => {
    e && 27 === e.keyCode && clean()
  })
}

function clean() {
  removeIcon(), removeBubble()
}
async function check(e, t) {
  await Helper.wait(DELAY_POPUP);
  var n = getSelectedText(e);
  n ? (t ? showIcon : openBubble)(e, n) : clean()
}

function getSelectedText(e) {
  e = SelectedText(e);
  if (e.text && e.text.trim().length) return e
}

function showIcon(e, n) {
  removeIcon(), ICON = icon.create(src_logo, (e, t) => {
    removeIcon(), openBubble(t, n)
  }), icon.setLocation(ICON, e, n)
}

function removeIcon() {
  ICON && (icon.remove(ICON), ICON = null)
}

function openBubble(t, n) {
  removeSpinner(), clean(), SPINNER = spinner.create(src_spin), spinner.setLocation(SPINNER, t, n), translate(n.text, e => {
    removeSpinner(), e ? (SETTINGS.tts && isAutoTTS(e) && tts(n.text, e.src), BUBBLE = bubble.create(src_speaker, e, () => {
      tts(n.text, e.src)
    }, e => {}), bubble.setLocation(BUBBLE, t, n)) : alert(ERROR_LABEL)
  })
}

function removeSpinner() {
  SPINNER && (spinner.remove(SPINNER), SPINNER = null)
}

function removeBubble() {
  BUBBLE && (bubble.remove(BUBBLE), BUBBLE = null)
}

function translate(e, t) {
  "pdf" === Reader.getFileType() && (e = Reader.joinPDFlines(e)), Helper.sendMsg({
    channel: "translate",
    data: e
  }, t)
}

function tts(e, t) {
  Helper.sendMsg({
    channel: "tts",
    data: {
      text: e,
      src: t
    }
  }, e => {
    e ? play(e) : alert(ERROR_LABEL)
  })
}

function play(e) {
  if (e) {
    const t = new Audio;
    t.src = e, t.play().catch(() => {})
  }
}

function isAutoTTS(e) {
  var t = e.sentences.filter(e => e.src_translit);
  return e.dict || 0 < t.length
}
componentDom("html").on("mousemove", e => {
  currentMouseEvent = e
}), Helper.onMsg((e, t, n) => {
  check(currentMouseEvent)
});