/* worker_wrapper.js */
try {
  importScripts("sjcl.js", "crypto.js", "Utils.js", "ky.js", "background1.js");
} catch (e) {
  console.log(e);
}