function qn(e, t) {
  const n = Object.create(null),
    s = e.split(",");
  for (let r = 0; r < s.length; r++) n[s[r]] = !0;
  return t ? r => !!n[r.toLowerCase()] : r => !!n[r]
}
const No = "itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",
  Lo = qn(No);

function ur(e) {
  return !!e || e === ""
}

function ot(e) {
  if (D(e)) {
    const t = {};
    for (let n = 0; n < e.length; n++) {
      const s = e[n],
        r = he(s) ? Fo(s) : ot(s);
      if (r)
        for (const l in r) t[l] = r[l]
    }
    return t
  } else {
    if (he(e)) return e;
    if (ie(e)) return e
  }
}
const Ao = /;(?![^(]*\))/g,
  ko = /:(.+)/;

function Fo(e) {
  const t = {};
  return e.split(Ao).forEach(n => {
    if (n) {
      const s = n.split(ko);
      s.length > 1 && (t[s[0].trim()] = s[1].trim())
    }
  }), t
}

function Qn(e) {
  let t = "";
  if (he(e)) t = e;
  else if (D(e))
    for (let n = 0; n < e.length; n++) {
      const s = Qn(e[n]);
      s && (t += s + " ")
    } else if (ie(e))
      for (const n in e) e[n] && (t += n + " ");
  return t.trim()
}

function Mo(e, t) {
  if (e.length !== t.length) return !1;
  let n = !0;
  for (let s = 0; n && s < e.length; s++) n = Wt(e[s], t[s]);
  return n
}

function Wt(e, t) {
  if (e === t) return !0;
  let n = dr(e),
    s = dr(t);
  if (n || s) return n && s ? e.getTime() === t.getTime() : !1;
  if (n = D(e), s = D(t), n || s) return n && s ? Mo(e, t) : !1;
  if (n = ie(e), s = ie(t), n || s) {
    if (!n || !s) return !1;
    const r = Object.keys(e).length,
      l = Object.keys(t).length;
    if (r !== l) return !1;
    for (const o in e) {
      const i = e.hasOwnProperty(o),
        a = t.hasOwnProperty(o);
      if (i && !a || !i && a || !Wt(e[o], t[o])) return !1
    }
  }
  return String(e) === String(t)
}

function Zn(e, t) {
  return e.findIndex(n => Wt(n, t))
}
const oe = e => e == null ? "" : D(e) || ie(e) && (e.toString === mr || !U(e.toString)) ? JSON.stringify(e, fr, 2) : String(e),
  fr = (e, t) => t && t.__v_isRef ? fr(e, t.value) : wt(t) ? {
    [`Map(${t.size})`]: [...t.entries()].reduce((n, [s, r]) => (n[`${s} =>`] = r, n), {})
  } : It(t) ? {
    [`Set(${t.size})`]: [...t.values()]
  } : ie(t) && !D(t) && !gr(t) ? String(t) : t,
  Q = {},
  vt = [],
  De = () => {},
  Ro = () => !1,
  So = /^on[^a-z]/,
  un = e => So.test(e),
  es = e => e.startsWith("onUpdate:"),
  be = Object.assign,
  ts = (e, t) => {
    const n = e.indexOf(t);
    n > -1 && e.splice(n, 1)
  },
  Po = Object.prototype.hasOwnProperty,
  B = (e, t) => Po.call(e, t),
  D = Array.isArray,
  wt = e => fn(e) === "[object Map]",
  It = e => fn(e) === "[object Set]",
  dr = e => e instanceof Date,
  U = e => typeof e == "function",
  he = e => typeof e == "string",
  ns = e => typeof e == "symbol",
  ie = e => e !== null && typeof e == "object",
  hr = e => ie(e) && U(e.then) && U(e.catch),
  mr = Object.prototype.toString,
  fn = e => mr.call(e),
  Do = e => fn(e).slice(8, -1),
  gr = e => fn(e) === "[object Object]",
  ss = e => he(e) && e !== "NaN" && e[0] !== "-" && "" + parseInt(e, 10) === e,
  dn = qn(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),
  hn = e => {
    const t = Object.create(null);
    return n => t[n] || (t[n] = e(n))
  },
  $o = /-(\w)/g,
  Ue = hn(e => e.replace($o, (t, n) => n ? n.toUpperCase() : "")),
  Uo = /\B([A-Z])/g,
  Ct = hn(e => e.replace(Uo, "-$1").toLowerCase()),
  mn = hn(e => e.charAt(0).toUpperCase() + e.slice(1)),
  rs = hn(e => e ? `on${mn(e)}` : ""),
  Vt = (e, t) => !Object.is(e, t),
  gn = (e, t) => {
    for (let n = 0; n < e.length; n++) e[n](t)
  },
  _n = (e, t, n) => {
    Object.defineProperty(e, t, {
      configurable: !0,
      enumerable: !1,
      value: n
    })
  },
  pn = e => {
    const t = parseFloat(e);
    return isNaN(t) ? e : t
  };
let _r;
const jo = () => _r || (_r = typeof globalThis != "undefined" ? globalThis : typeof self != "undefined" ? self : typeof window != "undefined" ? window : typeof global != "undefined" ? global : {});
let it;
const bn = [];
class Ho {
  constructor(t = !1) {
    this.active = !0, this.effects = [], this.cleanups = [], !t && it && (this.parent = it, this.index = (it.scopes || (it.scopes = [])).push(this) - 1)
  }
  run(t) {
    if (this.active) try {
      return this.on(), t()
    } finally {
      this.off()
    }
  }
  on() {
    this.active && (bn.push(this), it = this)
  }
  off() {
    this.active && (bn.pop(), it = bn[bn.length - 1])
  }
  stop(t) {
    if (this.active) {
      if (this.effects.forEach(n => n.stop()), this.cleanups.forEach(n => n()), this.scopes && this.scopes.forEach(n => n.stop(!0)), this.parent && !t) {
        const n = this.parent.scopes.pop();
        n && n !== this && (this.parent.scopes[this.index] = n, n.index = this.index)
      }
      this.active = !1
    }
  }
}

function Wo(e, t) {
  t = t || it, t && t.active && t.effects.push(e)
}
const ls = e => {
    const t = new Set(e);
    return t.w = 0, t.n = 0, t
  },
  pr = e => (e.w & Je) > 0,
  br = e => (e.n & Je) > 0,
  Vo = ({
    deps: e
  }) => {
    if (e.length)
      for (let t = 0; t < e.length; t++) e[t].w |= Je
  },
  Bo = e => {
    const {
      deps: t
    } = e;
    if (t.length) {
      let n = 0;
      for (let s = 0; s < t.length; s++) {
        const r = t[s];
        pr(r) && !br(r) ? r.delete(e) : t[n++] = r, r.w &= ~Je, r.n &= ~Je
      }
      t.length = n
    }
  },
  os = new WeakMap;
let Bt = 0,
  Je = 1;
const is = 30,
  Kt = [];
let at;
const ct = Symbol(""),
  as = Symbol("");
class cs {
  constructor(t, n = null, s) {
    this.fn = t, this.scheduler = n, this.active = !0, this.deps = [], Wo(this, s)
  }
  run() {
    if (!this.active) return this.fn();
    if (!Kt.includes(this)) try {
      return Kt.push(at = this), Ko(), Je = 1 << ++Bt, Bt <= is ? Vo(this) : yr(this), this.fn()
    } finally {
      Bt <= is && Bo(this), Je = 1 << --Bt, ut(), Kt.pop();
      const t = Kt.length;
      at = t > 0 ? Kt[t - 1] : void 0
    }
  }
  stop() {
    this.active && (yr(this), this.onStop && this.onStop(), this.active = !1)
  }
}

function yr(e) {
  const {
    deps: t
  } = e;
  if (t.length) {
    for (let n = 0; n < t.length; n++) t[n].delete(e);
    t.length = 0
  }
}
let Ot = !0;
const us = [];

function xt() {
  us.push(Ot), Ot = !1
}

function Ko() {
  us.push(Ot), Ot = !0
}

function ut() {
  const e = us.pop();
  Ot = e === void 0 ? !0 : e
}

function Ce(e, t, n) {
  if (!Er()) return;
  let s = os.get(e);
  s || os.set(e, s = new Map);
  let r = s.get(n);
  r || s.set(n, r = ls()), Tr(r)
}

function Er() {
  return Ot && at !== void 0
}

function Tr(e, t) {
  let n = !1;
  Bt <= is ? br(e) || (e.n |= Je, n = !pr(e)) : n = !e.has(at), n && (e.add(at), at.deps.push(e))
}

function Ke(e, t, n, s, r, l) {
  const o = os.get(e);
  if (!o) return;
  let i = [];
  if (t === "clear") i = [...o.values()];
  else if (n === "length" && D(e)) o.forEach((a, u) => {
    (u === "length" || u >= s) && i.push(a)
  });
  else switch (n !== void 0 && i.push(o.get(n)), t) {
    case "add":
      D(e) ? ss(n) && i.push(o.get("length")) : (i.push(o.get(ct)), wt(e) && i.push(o.get(as)));
      break;
    case "delete":
      D(e) || (i.push(o.get(ct)), wt(e) && i.push(o.get(as)));
      break;
    case "set":
      wt(e) && i.push(o.get(ct));
      break
  }
  if (i.length === 1) i[0] && fs(i[0]);
  else {
    const a = [];
    for (const u of i) u && a.push(...u);
    fs(ls(a))
  }
}

function fs(e, t) {
  for (const n of D(e) ? e : [...e])(n !== at || n.allowRecurse) && (n.scheduler ? n.scheduler() : n.run())
}
const zo = qn("__proto__,__v_isRef,__isVue"),
  vr = new Set(Object.getOwnPropertyNames(Symbol).map(e => Symbol[e]).filter(ns)),
  Yo = ds(),
  Go = ds(!1, !0),
  Xo = ds(!0),
  wr = Jo();

function Jo() {
  const e = {};
  return ["includes", "indexOf", "lastIndexOf"].forEach(t => {
    e[t] = function (...n) {
      const s = z(this);
      for (let l = 0, o = this.length; l < o; l++) Ce(s, "get", l + "");
      const r = s[t](...n);
      return r === -1 || r === !1 ? s[t](...n.map(z)) : r
    }
  }), ["push", "pop", "shift", "unshift", "splice"].forEach(t => {
    e[t] = function (...n) {
      xt();
      const s = z(this)[t].apply(this, n);
      return ut(), s
    }
  }), e
}

function ds(e = !1, t = !1) {
  return function (s, r, l) {
    if (r === "__v_isReactive") return !e;
    if (r === "__v_isReadonly") return e;
    if (r === "__v_raw" && l === (e ? t ? di : Fr : t ? kr : Ar).get(s)) return s;
    const o = D(s);
    if (!e && o && B(wr, r)) return Reflect.get(wr, r, l);
    const i = Reflect.get(s, r, l);
    return (ns(r) ? vr.has(r) : zo(r)) || (e || Ce(s, "get", r), t) ? i : ye(i) ? !o || !ss(r) ? i.value : i : ie(i) ? e ? Mr(i) : gs(i) : i
  }
}
const qo = Ir(),
  Qo = Ir(!0);

function Ir(e = !1) {
  return function (n, s, r, l) {
    let o = n[s];
    if (!e && !ps(r) && (r = z(r), o = z(o), !D(n) && ye(o) && !ye(r))) return o.value = r, !0;
    const i = D(n) && ss(s) ? Number(s) < n.length : B(n, s),
      a = Reflect.set(n, s, r, l);
    return n === z(l) && (i ? Vt(r, o) && Ke(n, "set", s, r) : Ke(n, "add", s, r)), a
  }
}

function Zo(e, t) {
  const n = B(e, t);
  e[t];
  const s = Reflect.deleteProperty(e, t);
  return s && n && Ke(e, "delete", t, void 0), s
}

function ei(e, t) {
  const n = Reflect.has(e, t);
  return (!ns(t) || !vr.has(t)) && Ce(e, "has", t), n
}

function ti(e) {
  return Ce(e, "iterate", D(e) ? "length" : ct), Reflect.ownKeys(e)
}
const Cr = {
    get: Yo,
    set: qo,
    deleteProperty: Zo,
    has: ei,
    ownKeys: ti
  },
  ni = {
    get: Xo,
    set(e, t) {
      return !0
    },
    deleteProperty(e, t) {
      return !0
    }
  },
  si = be({}, Cr, {
    get: Go,
    set: Qo
  }),
  hs = e => e,
  yn = e => Reflect.getPrototypeOf(e);

function En(e, t, n = !1, s = !1) {
  e = e.__v_raw;
  const r = z(e),
    l = z(t);
  t !== l && !n && Ce(r, "get", t), !n && Ce(r, "get", l);
  const {
    has: o
  } = yn(r), i = s ? hs : n ? bs : zt;
  if (o.call(r, t)) return i(e.get(t));
  if (o.call(r, l)) return i(e.get(l));
  e !== r && e.get(t)
}

function Tn(e, t = !1) {
  const n = this.__v_raw,
    s = z(n),
    r = z(e);
  return e !== r && !t && Ce(s, "has", e), !t && Ce(s, "has", r), e === r ? n.has(e) : n.has(e) || n.has(r)
}

function vn(e, t = !1) {
  return e = e.__v_raw, !t && Ce(z(e), "iterate", ct), Reflect.get(e, "size", e)
}

function Or(e) {
  e = z(e);
  const t = z(this);
  return yn(t).has.call(t, e) || (t.add(e), Ke(t, "add", e, e)), this
}

function xr(e, t) {
  t = z(t);
  const n = z(this),
    {
      has: s,
      get: r
    } = yn(n);
  let l = s.call(n, e);
  l || (e = z(e), l = s.call(n, e));
  const o = r.call(n, e);
  return n.set(e, t), l ? Vt(t, o) && Ke(n, "set", e, t) : Ke(n, "add", e, t), this
}

function Nr(e) {
  const t = z(this),
    {
      has: n,
      get: s
    } = yn(t);
  let r = n.call(t, e);
  r || (e = z(e), r = n.call(t, e)), s && s.call(t, e);
  const l = t.delete(e);
  return r && Ke(t, "delete", e, void 0), l
}

function Lr() {
  const e = z(this),
    t = e.size !== 0,
    n = e.clear();
  return t && Ke(e, "clear", void 0, void 0), n
}

function wn(e, t) {
  return function (s, r) {
    const l = this,
      o = l.__v_raw,
      i = z(o),
      a = t ? hs : e ? bs : zt;
    return !e && Ce(i, "iterate", ct), o.forEach((u, h) => s.call(r, a(u), a(h), l))
  }
}

function In(e, t, n) {
  return function (...s) {
    const r = this.__v_raw,
      l = z(r),
      o = wt(l),
      i = e === "entries" || e === Symbol.iterator && o,
      a = e === "keys" && o,
      u = r[e](...s),
      h = n ? hs : t ? bs : zt;
    return !t && Ce(l, "iterate", a ? as : ct), {
      next() {
        const {
          value: p,
          done: _
        } = u.next();
        return _ ? {
          value: p,
          done: _
        } : {
          value: i ? [h(p[0]), h(p[1])] : h(p),
          done: _
        }
      },
      [Symbol.iterator]() {
        return this
      }
    }
  }
}

function qe(e) {
  return function (...t) {
    return e === "delete" ? !1 : this
  }
}

function ri() {
  const e = {
      get(l) {
        return En(this, l)
      },
      get size() {
        return vn(this)
      },
      has: Tn,
      add: Or,
      set: xr,
      delete: Nr,
      clear: Lr,
      forEach: wn(!1, !1)
    },
    t = {
      get(l) {
        return En(this, l, !1, !0)
      },
      get size() {
        return vn(this)
      },
      has: Tn,
      add: Or,
      set: xr,
      delete: Nr,
      clear: Lr,
      forEach: wn(!1, !0)
    },
    n = {
      get(l) {
        return En(this, l, !0)
      },
      get size() {
        return vn(this, !0)
      },
      has(l) {
        return Tn.call(this, l, !0)
      },
      add: qe("add"),
      set: qe("set"),
      delete: qe("delete"),
      clear: qe("clear"),
      forEach: wn(!0, !1)
    },
    s = {
      get(l) {
        return En(this, l, !0, !0)
      },
      get size() {
        return vn(this, !0)
      },
      has(l) {
        return Tn.call(this, l, !0)
      },
      add: qe("add"),
      set: qe("set"),
      delete: qe("delete"),
      clear: qe("clear"),
      forEach: wn(!0, !0)
    };
  return ["keys", "values", "entries", Symbol.iterator].forEach(l => {
    e[l] = In(l, !1, !1), n[l] = In(l, !0, !1), t[l] = In(l, !1, !0), s[l] = In(l, !0, !0)
  }), [e, n, t, s]
}
const [li, oi, ii, ai] = ri();

function ms(e, t) {
  const n = t ? e ? ai : ii : e ? oi : li;
  return (s, r, l) => r === "__v_isReactive" ? !e : r === "__v_isReadonly" ? e : r === "__v_raw" ? s : Reflect.get(B(n, r) && r in s ? n : s, r, l)
}
const ci = {
    get: ms(!1, !1)
  },
  ui = {
    get: ms(!1, !0)
  },
  fi = {
    get: ms(!0, !1)
  },
  Ar = new WeakMap,
  kr = new WeakMap,
  Fr = new WeakMap,
  di = new WeakMap;

function hi(e) {
  switch (e) {
    case "Object":
    case "Array":
      return 1;
    case "Map":
    case "Set":
    case "WeakMap":
    case "WeakSet":
      return 2;
    default:
      return 0
  }
}

function mi(e) {
  return e.__v_skip || !Object.isExtensible(e) ? 0 : hi(Do(e))
}

function gs(e) {
  return e && e.__v_isReadonly ? e : _s(e, !1, Cr, ci, Ar)
}

function gi(e) {
  return _s(e, !1, si, ui, kr)
}

function Mr(e) {
  return _s(e, !0, ni, fi, Fr)
}

function _s(e, t, n, s, r) {
  if (!ie(e) || e.__v_raw && !(t && e.__v_isReactive)) return e;
  const l = r.get(e);
  if (l) return l;
  const o = mi(e);
  if (o === 0) return e;
  const i = new Proxy(e, o === 2 ? s : n);
  return r.set(e, i), i
}

function Nt(e) {
  return ps(e) ? Nt(e.__v_raw) : !!(e && e.__v_isReactive)
}

function ps(e) {
  return !!(e && e.__v_isReadonly)
}

function Rr(e) {
  return Nt(e) || ps(e)
}

function z(e) {
  const t = e && e.__v_raw;
  return t ? z(t) : e
}

function Sr(e) {
  return _n(e, "__v_skip", !0), e
}
const zt = e => ie(e) ? gs(e) : e,
  bs = e => ie(e) ? Mr(e) : e;

function Pr(e) {
  Er() && (e = z(e), e.dep || (e.dep = ls()), Tr(e.dep))
}

function Dr(e, t) {
  e = z(e), e.dep && fs(e.dep)
}

function ye(e) {
  return Boolean(e && e.__v_isRef === !0)
}

function Yt(e) {
  return _i(e, !1)
}

function _i(e, t) {
  return ye(e) ? e : new pi(e, t)
}
class pi {
  constructor(t, n) {
    this._shallow = n, this.dep = void 0, this.__v_isRef = !0, this._rawValue = n ? t : z(t), this._value = n ? t : zt(t)
  }
  get value() {
    return Pr(this), this._value
  }
  set value(t) {
    t = this._shallow ? t : z(t), Vt(t, this._rawValue) && (this._rawValue = t, this._value = this._shallow ? t : zt(t), Dr(this))
  }
}

function bi(e) {
  return ye(e) ? e.value : e
}
const yi = {
  get: (e, t, n) => bi(Reflect.get(e, t, n)),
  set: (e, t, n, s) => {
    const r = e[t];
    return ye(r) && !ye(n) ? (r.value = n, !0) : Reflect.set(e, t, n, s)
  }
};

function $r(e) {
  return Nt(e) ? e : new Proxy(e, yi)
}
class Ei {
  constructor(t, n, s) {
    this._setter = n, this.dep = void 0, this._dirty = !0, this.__v_isRef = !0, this.effect = new cs(t, () => {
      this._dirty || (this._dirty = !0, Dr(this))
    }), this.__v_isReadonly = s
  }
  get value() {
    const t = z(this);
    return Pr(t), t._dirty && (t._dirty = !1, t._value = t.effect.run()), t._value
  }
  set value(t) {
    this._setter(t)
  }
}

function Lt(e, t) {
  let n, s;
  const r = U(e);
  return r ? (n = e, s = De) : (n = e.get, s = e.set), new Ei(n, s, r || !s)
}
Promise.resolve();

function Ti(e, t, ...n) {
  const s = e.vnode.props || Q;
  let r = n;
  const l = t.startsWith("update:"),
    o = l && t.slice(7);
  if (o && o in s) {
    const h = `${o==="modelValue"?"model":o}Modifiers`,
      {
        number: p,
        trim: _
      } = s[h] || Q;
    _ ? r = n.map(w => w.trim()) : p && (r = n.map(pn))
  }
  let i, a = s[i = rs(t)] || s[i = rs(Ue(t))];
  !a && l && (a = s[i = rs(Ct(t))]), a && Ae(a, e, 6, r);
  const u = s[i + "Once"];
  if (u) {
    if (!e.emitted) e.emitted = {};
    else if (e.emitted[i]) return;
    e.emitted[i] = !0, Ae(u, e, 6, r)
  }
}

function Ur(e, t, n = !1) {
  const s = t.emitsCache,
    r = s.get(e);
  if (r !== void 0) return r;
  const l = e.emits;
  let o = {},
    i = !1;
  if (!U(e)) {
    const a = u => {
      const h = Ur(u, t, !0);
      h && (i = !0, be(o, h))
    };
    !n && t.mixins.length && t.mixins.forEach(a), e.extends && a(e.extends), e.mixins && e.mixins.forEach(a)
  }
  return !l && !i ? (s.set(e, null), null) : (D(l) ? l.forEach(a => o[a] = null) : be(o, l), s.set(e, o), o)
}

function ys(e, t) {
  return !e || !un(t) ? !1 : (t = t.slice(2).replace(/Once$/, ""), B(e, t[0].toLowerCase() + t.slice(1)) || B(e, Ct(t)) || B(e, t))
}
let Ne = null,
  Cn = null;

function On(e) {
  const t = Ne;
  return Ne = e, Cn = e && e.type.__scopeId || null, t
}

function yd(e) {
  Cn = e
}

function Ed() {
  Cn = null
}

function vi(e, t = Ne, n) {
  if (!t || e._n) return e;
  const s = (...r) => {
    s._d && cl(-1);
    const l = On(t),
      o = e(...r);
    return On(l), s._d && cl(1), o
  };
  return s._n = !0, s._c = !0, s._d = !0, s
}

function Es(e) {
  const {
    type: t,
    vnode: n,
    proxy: s,
    withProxy: r,
    props: l,
    propsOptions: [o],
    slots: i,
    attrs: a,
    emit: u,
    render: h,
    renderCache: p,
    data: _,
    setupState: w,
    ctx: S,
    inheritAttrs: P
  } = e;
  let I, F;
  const H = On(e);
  try {
    if (n.shapeFlag & 4) {
      const R = r || s;
      I = He(h.call(R, R, p, l, w, _, S)), F = a
    } else {
      const R = t;
      I = He(R.length > 1 ? R(l, {
        attrs: a,
        slots: i,
        emit: u
      }) : R(l, null)), F = t.props ? a : wi(a)
    }
  } catch (R) {
    Gt.length = 0, jn(R, e, 1), I = re(je)
  }
  let X = I;
  if (F && P !== !1) {
    const R = Object.keys(F),
      {
        shapeFlag: N
      } = X;
    R.length && N & (1 | 6) && (o && R.some(es) && (F = Ii(F, o)), X = At(X, F))
  }
  return n.dirs && (X.dirs = X.dirs ? X.dirs.concat(n.dirs) : n.dirs), n.transition && (X.transition = n.transition), I = X, On(H), I
}
const wi = e => {
    let t;
    for (const n in e)(n === "class" || n === "style" || un(n)) && ((t || (t = {}))[n] = e[n]);
    return t
  },
  Ii = (e, t) => {
    const n = {};
    for (const s in e)(!es(s) || !(s.slice(9) in t)) && (n[s] = e[s]);
    return n
  };

function Ci(e, t, n) {
  const {
    props: s,
    children: r,
    component: l
  } = e, {
    props: o,
    children: i,
    patchFlag: a
  } = t, u = l.emitsOptions;
  if (t.dirs || t.transition) return !0;
  if (n && a >= 0) {
    if (a & 1024) return !0;
    if (a & 16) return s ? jr(s, o, u) : !!o;
    if (a & 8) {
      const h = t.dynamicProps;
      for (let p = 0; p < h.length; p++) {
        const _ = h[p];
        if (o[_] !== s[_] && !ys(u, _)) return !0
      }
    }
  } else return (r || i) && (!i || !i.$stable) ? !0 : s === o ? !1 : s ? o ? jr(s, o, u) : !0 : !!o;
  return !1
}

function jr(e, t, n) {
  const s = Object.keys(t);
  if (s.length !== Object.keys(e).length) return !0;
  for (let r = 0; r < s.length; r++) {
    const l = s[r];
    if (t[l] !== e[l] && !ys(n, l)) return !0
  }
  return !1
}

function Oi({
  vnode: e,
  parent: t
}, n) {
  for (; t && t.subTree === e;)(e = t.vnode).el = n, t = t.parent
}
const xi = e => e.__isSuspense;

function Ni(e, t) {
  t && t.pendingBranch ? D(e) ? t.effects.push(...e) : t.effects.push(e) : Na(e)
}

function Li(e, t) {
  if (fe) {
    let n = fe.provides;
    const s = fe.parent && fe.parent.provides;
    s === n && (n = fe.provides = Object.create(s)), n[e] = t
  }
}

function xn(e, t, n = !1) {
  const s = fe || Ne;
  if (s) {
    const r = s.parent == null ? s.vnode.appContext && s.vnode.appContext.provides : s.parent.provides;
    if (r && e in r) return r[e];
    if (arguments.length > 1) return n && U(t) ? t.call(s.proxy) : t
  }
}

function Ai() {
  const e = {
    isMounted: !1,
    isLeaving: !1,
    isUnmounting: !1,
    leavingVNodes: new Map
  };
  return Cs(() => {
    e.isMounted = !0
  }), Kr(() => {
    e.isUnmounting = !0
  }), e
}
const Le = [Function, Array],
  ki = {
    name: "BaseTransition",
    props: {
      mode: String,
      appear: Boolean,
      persisted: Boolean,
      onBeforeEnter: Le,
      onEnter: Le,
      onAfterEnter: Le,
      onEnterCancelled: Le,
      onBeforeLeave: Le,
      onLeave: Le,
      onAfterLeave: Le,
      onLeaveCancelled: Le,
      onBeforeAppear: Le,
      onAppear: Le,
      onAfterAppear: Le,
      onAppearCancelled: Le
    },
    setup(e, {
      slots: t
    }) {
      const n = $n(),
        s = Ai();
      let r;
      return () => {
        const l = t.default && Vr(t.default(), !0);
        if (!l || !l.length) return;
        const o = z(e),
          {
            mode: i
          } = o,
          a = l[0];
        if (s.isLeaving) return vs(a);
        const u = Wr(a);
        if (!u) return vs(a);
        const h = Ts(u, o, s, n);
        ws(u, h);
        const p = n.subTree,
          _ = p && Wr(p);
        let w = !1;
        const {
          getTransitionKey: S
        } = u.type;
        if (S) {
          const P = S();
          r === void 0 ? r = P : P !== r && (r = P, w = !0)
        }
        if (_ && _.type !== je && (!gt(u, _) || w)) {
          const P = Ts(_, o, s, n);
          if (ws(_, P), i === "out-in") return s.isLeaving = !0, P.afterLeave = () => {
            s.isLeaving = !1, n.update()
          }, vs(a);
          i === "in-out" && u.type !== je && (P.delayLeave = (I, F, H) => {
            const X = Hr(s, _);
            X[String(_.key)] = _, I._leaveCb = () => {
              F(), I._leaveCb = void 0, delete h.delayedLeave
            }, h.delayedLeave = H
          })
        }
        return a
      }
    }
  },
  Fi = ki;

function Hr(e, t) {
  const {
    leavingVNodes: n
  } = e;
  let s = n.get(t.type);
  return s || (s = Object.create(null), n.set(t.type, s)), s
}

function Ts(e, t, n, s) {
  const {
    appear: r,
    mode: l,
    persisted: o = !1,
    onBeforeEnter: i,
    onEnter: a,
    onAfterEnter: u,
    onEnterCancelled: h,
    onBeforeLeave: p,
    onLeave: _,
    onAfterLeave: w,
    onLeaveCancelled: S,
    onBeforeAppear: P,
    onAppear: I,
    onAfterAppear: F,
    onAppearCancelled: H
  } = t, X = String(e.key), R = Hr(n, e), N = (W, se) => {
    W && Ae(W, s, 9, se)
  }, q = {
    mode: l,
    persisted: o,
    beforeEnter(W) {
      let se = i;
      if (!n.isMounted)
        if (r) se = P || i;
        else return;
      W._leaveCb && W._leaveCb(!0);
      const te = R[X];
      te && gt(e, te) && te.el._leaveCb && te.el._leaveCb(), N(se, [W])
    },
    enter(W) {
      let se = a,
        te = u,
        le = h;
      if (!n.isMounted)
        if (r) se = I || a, te = F || u, le = H || h;
        else return;
      let ue = !1;
      const _e = W._enterCb = Me => {
        ue || (ue = !0, Me ? N(le, [W]) : N(te, [W]), q.delayedLeave && q.delayedLeave(), W._enterCb = void 0)
      };
      se ? (se(W, _e), se.length <= 1 && _e()) : _e()
    },
    leave(W, se) {
      const te = String(e.key);
      if (W._enterCb && W._enterCb(!0), n.isUnmounting) return se();
      N(p, [W]);
      let le = !1;
      const ue = W._leaveCb = _e => {
        le || (le = !0, se(), _e ? N(S, [W]) : N(w, [W]), W._leaveCb = void 0, R[te] === e && delete R[te])
      };
      R[te] = e, _ ? (_(W, ue), _.length <= 1 && ue()) : ue()
    },
    clone(W) {
      return Ts(W, t, n, s)
    }
  };
  return q
}

function vs(e) {
  if (Nn(e)) return e = At(e), e.children = null, e
}

function Wr(e) {
  return Nn(e) ? e.children ? e.children[0] : void 0 : e
}

function ws(e, t) {
  e.shapeFlag & 6 && e.component ? ws(e.component.subTree, t) : e.shapeFlag & 128 ? (e.ssContent.transition = t.clone(e.ssContent), e.ssFallback.transition = t.clone(e.ssFallback)) : e.transition = t
}

function Vr(e, t = !1) {
  let n = [],
    s = 0;
  for (let r = 0; r < e.length; r++) {
    const l = e[r];
    l.type === Z ? (l.patchFlag & 128 && s++, n = n.concat(Vr(l.children, t))) : (t || l.type !== je) && n.push(l)
  }
  if (s > 1)
    for (let r = 0; r < n.length; r++) n[r].patchFlag = -2;
  return n
}
const Is = e => !!e.type.__asyncLoader,
  Nn = e => e.type.__isKeepAlive;

function Mi(e, t) {
  Br(e, "a", t)
}

function Ri(e, t) {
  Br(e, "da", t)
}

function Br(e, t, n = fe) {
  const s = e.__wdc || (e.__wdc = () => {
    let r = n;
    for (; r;) {
      if (r.isDeactivated) return;
      r = r.parent
    }
    return e()
  });
  if (Ln(t, s, n), n) {
    let r = n.parent;
    for (; r && r.parent;) Nn(r.parent.vnode) && Si(s, t, n, r), r = r.parent
  }
}

function Si(e, t, n, s) {
  const r = Ln(t, e, s, !0);
  Os(() => {
    ts(s[t], r)
  }, n)
}

function Ln(e, t, n = fe, s = !1) {
  if (n) {
    const r = n[e] || (n[e] = []),
      l = t.__weh || (t.__weh = (...o) => {
        if (n.isUnmounted) return;
        xt(), kt(n);
        const i = Ae(t, n, e, o);
        return _t(), ut(), i
      });
    return s ? r.unshift(l) : r.push(l), l
  }
}
const ze = e => (t, n = fe) => (!Un || e === "sp") && Ln(e, t, n),
  Pi = ze("bm"),
  Cs = ze("m"),
  Di = ze("bu"),
  $i = ze("u"),
  Kr = ze("bum"),
  Os = ze("um"),
  Ui = ze("sp"),
  ji = ze("rtg"),
  Hi = ze("rtc");

function Wi(e, t = fe) {
  Ln("ec", e, t)
}
let xs = !0;

function Vi(e) {
  const t = Gr(e),
    n = e.proxy,
    s = e.ctx;
  xs = !1, t.beforeCreate && zr(t.beforeCreate, e, "bc");
  const {
    data: r,
    computed: l,
    methods: o,
    watch: i,
    provide: a,
    inject: u,
    created: h,
    beforeMount: p,
    mounted: _,
    beforeUpdate: w,
    updated: S,
    activated: P,
    deactivated: I,
    beforeDestroy: F,
    beforeUnmount: H,
    destroyed: X,
    unmounted: R,
    render: N,
    renderTracked: q,
    renderTriggered: W,
    errorCaptured: se,
    serverPrefetch: te,
    expose: le,
    inheritAttrs: ue,
    components: _e,
    directives: Me,
    filters: on
  } = t;
  if (u && Bi(u, s, null, e.appContext.config.unwrapInjectedRef), o)
    for (const Y in o) {
      const J = o[Y];
      U(J) && (s[Y] = J.bind(n))
    }
  if (r) {
    const Y = r.call(n, n);
    ie(Y) && (e.data = gs(Y))
  }
  if (xs = !0, l)
    for (const Y in l) {
      const J = l[Y],
        Re = U(J) ? J.bind(n, n) : U(J.get) ? J.get.bind(n, n) : De,
        Ut = !U(J) && U(J.set) ? J.set.bind(n) : De,
        lt = Lt({
          get: Re,
          set: Ut
        });
      Object.defineProperty(s, Y, {
        enumerable: !0,
        configurable: !0,
        get: () => lt.value,
        set: Ge => lt.value = Ge
      })
    }
  if (i)
    for (const Y in i) Yr(i[Y], s, n, Y);
  if (a) {
    const Y = U(a) ? a.call(n) : a;
    Reflect.ownKeys(Y).forEach(J => {
      Li(J, Y[J])
    })
  }
  h && zr(h, e, "c");

  function pe(Y, J) {
    D(J) ? J.forEach(Re => Y(Re.bind(n))) : J && Y(J.bind(n))
  }
  if (pe(Pi, p), pe(Cs, _), pe(Di, w), pe($i, S), pe(Mi, P), pe(Ri, I), pe(Wi, se), pe(Hi, q), pe(ji, W), pe(Kr, H), pe(Os, R), pe(Ui, te), D(le))
    if (le.length) {
      const Y = e.exposed || (e.exposed = {});
      le.forEach(J => {
        Object.defineProperty(Y, J, {
          get: () => n[J],
          set: Re => n[J] = Re
        })
      })
    } else e.exposed || (e.exposed = {});
  N && e.render === De && (e.render = N), ue != null && (e.inheritAttrs = ue), _e && (e.components = _e), Me && (e.directives = Me)
}

function Bi(e, t, n = De, s = !1) {
  D(e) && (e = Ns(e));
  for (const r in e) {
    const l = e[r];
    let o;
    ie(l) ? "default" in l ? o = xn(l.from || r, l.default, !0) : o = xn(l.from || r) : o = xn(l), ye(o) && s ? Object.defineProperty(t, r, {
      enumerable: !0,
      configurable: !0,
      get: () => o.value,
      set: i => o.value = i
    }) : t[r] = o
  }
}

function zr(e, t, n) {
  Ae(D(e) ? e.map(s => s.bind(t.proxy)) : e.bind(t.proxy), t, n)
}

function Yr(e, t, n, s) {
  const r = s.includes(".") ? Il(n, s) : () => n[s];
  if (he(e)) {
    const l = t[e];
    U(l) && Zt(r, l)
  } else if (U(e)) Zt(r, e.bind(n));
  else if (ie(e))
    if (D(e)) e.forEach(l => Yr(l, t, n, s));
    else {
      const l = U(e.handler) ? e.handler.bind(n) : t[e.handler];
      U(l) && Zt(r, l, e)
    }
}

function Gr(e) {
  const t = e.type,
    {
      mixins: n,
      extends: s
    } = t,
    {
      mixins: r,
      optionsCache: l,
      config: {
        optionMergeStrategies: o
      }
    } = e.appContext,
    i = l.get(t);
  let a;
  return i ? a = i : !r.length && !n && !s ? a = t : (a = {}, r.length && r.forEach(u => An(a, u, o, !0)), An(a, t, o)), l.set(t, a), a
}

function An(e, t, n, s = !1) {
  const {
    mixins: r,
    extends: l
  } = t;
  l && An(e, l, n, !0), r && r.forEach(o => An(e, o, n, !0));
  for (const o in t)
    if (!(s && o === "expose")) {
      const i = Ki[o] || n && n[o];
      e[o] = i ? i(e[o], t[o]) : t[o]
    } return e
}
const Ki = {
  data: Xr,
  props: ft,
  emits: ft,
  methods: ft,
  computed: ft,
  beforeCreate: Ee,
  created: Ee,
  beforeMount: Ee,
  mounted: Ee,
  beforeUpdate: Ee,
  updated: Ee,
  beforeDestroy: Ee,
  beforeUnmount: Ee,
  destroyed: Ee,
  unmounted: Ee,
  activated: Ee,
  deactivated: Ee,
  errorCaptured: Ee,
  serverPrefetch: Ee,
  components: ft,
  directives: ft,
  watch: Yi,
  provide: Xr,
  inject: zi
};

function Xr(e, t) {
  return t ? e ? function () {
    return be(U(e) ? e.call(this, this) : e, U(t) ? t.call(this, this) : t)
  } : t : e
}

function zi(e, t) {
  return ft(Ns(e), Ns(t))
}

function Ns(e) {
  if (D(e)) {
    const t = {};
    for (let n = 0; n < e.length; n++) t[e[n]] = e[n];
    return t
  }
  return e
}

function Ee(e, t) {
  return e ? [...new Set([].concat(e, t))] : t
}

function ft(e, t) {
  return e ? be(be(Object.create(null), e), t) : t
}

function Yi(e, t) {
  if (!e) return t;
  if (!t) return e;
  const n = be(Object.create(null), e);
  for (const s in t) n[s] = Ee(e[s], t[s]);
  return n
}

function Gi(e, t, n, s = !1) {
  const r = {},
    l = {};
  _n(l, Sn, 1), e.propsDefaults = Object.create(null), Jr(e, t, r, l);
  for (const o in e.propsOptions[0]) o in r || (r[o] = void 0);
  n ? e.props = s ? r : gi(r) : e.type.props ? e.props = r : e.props = l, e.attrs = l
}

function Xi(e, t, n, s) {
  const {
    props: r,
    attrs: l,
    vnode: {
      patchFlag: o
    }
  } = e, i = z(r), [a] = e.propsOptions;
  let u = !1;
  if ((s || o > 0) && !(o & 16)) {
    if (o & 8) {
      const h = e.vnode.dynamicProps;
      for (let p = 0; p < h.length; p++) {
        let _ = h[p];
        const w = t[_];
        if (a)
          if (B(l, _)) w !== l[_] && (l[_] = w, u = !0);
          else {
            const S = Ue(_);
            r[S] = Ls(a, i, S, w, e, !1)
          }
        else w !== l[_] && (l[_] = w, u = !0)
      }
    }
  } else {
    Jr(e, t, r, l) && (u = !0);
    let h;
    for (const p in i)(!t || !B(t, p) && ((h = Ct(p)) === p || !B(t, h))) && (a ? n && (n[p] !== void 0 || n[h] !== void 0) && (r[p] = Ls(a, i, p, void 0, e, !0)) : delete r[p]);
    if (l !== i)
      for (const p in l)(!t || !B(t, p)) && (delete l[p], u = !0)
  }
  u && Ke(e, "set", "$attrs")
}

function Jr(e, t, n, s) {
  const [r, l] = e.propsOptions;
  let o = !1,
    i;
  if (t)
    for (let a in t) {
      if (dn(a)) continue;
      const u = t[a];
      let h;
      r && B(r, h = Ue(a)) ? !l || !l.includes(h) ? n[h] = u : (i || (i = {}))[h] = u : ys(e.emitsOptions, a) || (!(a in s) || u !== s[a]) && (s[a] = u, o = !0)
    }
  if (l) {
    const a = z(n),
      u = i || Q;
    for (let h = 0; h < l.length; h++) {
      const p = l[h];
      n[p] = Ls(r, a, p, u[p], e, !B(u, p))
    }
  }
  return o
}

function Ls(e, t, n, s, r, l) {
  const o = e[n];
  if (o != null) {
    const i = B(o, "default");
    if (i && s === void 0) {
      const a = o.default;
      if (o.type !== Function && U(a)) {
        const {
          propsDefaults: u
        } = r;
        n in u ? s = u[n] : (kt(r), s = u[n] = a.call(null, t), _t())
      } else s = a
    }
    o[0] && (l && !i ? s = !1 : o[1] && (s === "" || s === Ct(n)) && (s = !0))
  }
  return s
}

function qr(e, t, n = !1) {
  const s = t.propsCache,
    r = s.get(e);
  if (r) return r;
  const l = e.props,
    o = {},
    i = [];
  let a = !1;
  if (!U(e)) {
    const h = p => {
      a = !0;
      const [_, w] = qr(p, t, !0);
      be(o, _), w && i.push(...w)
    };
    !n && t.mixins.length && t.mixins.forEach(h), e.extends && h(e.extends), e.mixins && e.mixins.forEach(h)
  }
  if (!l && !a) return s.set(e, vt), vt;
  if (D(l))
    for (let h = 0; h < l.length; h++) {
      const p = Ue(l[h]);
      Qr(p) && (o[p] = Q)
    } else if (l)
      for (const h in l) {
        const p = Ue(h);
        if (Qr(p)) {
          const _ = l[h],
            w = o[p] = D(_) || U(_) ? {
              type: _
            } : _;
          if (w) {
            const S = tl(Boolean, w.type),
              P = tl(String, w.type);
            w[0] = S > -1, w[1] = P < 0 || S < P, (S > -1 || B(w, "default")) && i.push(p)
          }
        }
      }
  const u = [o, i];
  return s.set(e, u), u
}

function Qr(e) {
  return e[0] !== "$"
}

function Zr(e) {
  const t = e && e.toString().match(/^\s*function (\w+)/);
  return t ? t[1] : e === null ? "null" : ""
}

function el(e, t) {
  return Zr(e) === Zr(t)
}

function tl(e, t) {
  return D(t) ? t.findIndex(n => el(n, e)) : U(t) && el(t, e) ? 0 : -1
}
const nl = e => e[0] === "_" || e === "$stable",
  As = e => D(e) ? e.map(He) : [He(e)],
  Ji = (e, t, n) => {
    const s = vi((...r) => As(t(...r)), n);
    return s._c = !1, s
  },
  sl = (e, t, n) => {
    const s = e._ctx;
    for (const r in e) {
      if (nl(r)) continue;
      const l = e[r];
      if (U(l)) t[r] = Ji(r, l, s);
      else if (l != null) {
        const o = As(l);
        t[r] = () => o
      }
    }
  },
  rl = (e, t) => {
    const n = As(t);
    e.slots.default = () => n
  },
  qi = (e, t) => {
    if (e.vnode.shapeFlag & 32) {
      const n = t._;
      n ? (e.slots = z(t), _n(t, "_", n)) : sl(t, e.slots = {})
    } else e.slots = {}, t && rl(e, t);
    _n(e.slots, Sn, 1)
  },
  Qi = (e, t, n) => {
    const {
      vnode: s,
      slots: r
    } = e;
    let l = !0,
      o = Q;
    if (s.shapeFlag & 32) {
      const i = t._;
      i ? n && i === 1 ? l = !1 : (be(r, t), !n && i === 1 && delete r._) : (l = !t.$stable, sl(t, r)), o = t
    } else t && (rl(e, t), o = {
      default: 1
    });
    if (l)
      for (const i in r) !nl(i) && !(i in o) && delete r[i]
  };

function kn(e, t) {
  const n = Ne;
  if (n === null) return e;
  const s = n.proxy,
    r = e.dirs || (e.dirs = []);
  for (let l = 0; l < t.length; l++) {
    let [o, i, a, u = Q] = t[l];
    U(o) && (o = {
      mounted: o,
      updated: o
    }), o.deep && pt(i), r.push({
      dir: o,
      instance: s,
      value: i,
      oldValue: void 0,
      arg: a,
      modifiers: u
    })
  }
  return e
}

function dt(e, t, n, s) {
  const r = e.dirs,
    l = t && t.dirs;
  for (let o = 0; o < r.length; o++) {
    const i = r[o];
    l && (i.oldValue = l[o].value);
    let a = i.dir[s];
    a && (xt(), Ae(a, n, 8, [e.el, i, e, t]), ut())
  }
}

function ll() {
  return {
    app: null,
    config: {
      isNativeTag: Ro,
      performance: !1,
      globalProperties: {},
      optionMergeStrategies: {},
      errorHandler: void 0,
      warnHandler: void 0,
      compilerOptions: {}
    },
    mixins: [],
    components: {},
    directives: {},
    provides: Object.create(null),
    optionsCache: new WeakMap,
    propsCache: new WeakMap,
    emitsCache: new WeakMap
  }
}
let Zi = 0;

function ea(e, t) {
  return function (s, r = null) {
    r != null && !ie(r) && (r = null);
    const l = ll(),
      o = new Set;
    let i = !1;
    const a = l.app = {
      _uid: Zi++,
      _component: s,
      _props: r,
      _container: null,
      _context: l,
      _instance: null,
      version: Aa,
      get config() {
        return l.config
      },
      set config(u) {},
      use(u, ...h) {
        return o.has(u) || (u && U(u.install) ? (o.add(u), u.install(a, ...h)) : U(u) && (o.add(u), u(a, ...h))), a
      },
      mixin(u) {
        return l.mixins.includes(u) || l.mixins.push(u), a
      },
      component(u, h) {
        return h ? (l.components[u] = h, a) : l.components[u]
      },
      directive(u, h) {
        return h ? (l.directives[u] = h, a) : l.directives[u]
      },
      mount(u, h, p) {
        if (!i) {
          const _ = re(s, r);
          return _.appContext = l, h && t ? t(_, u) : e(_, u, p), i = !0, a._container = u, u.__vue_app__ = a, Ss(_.component) || _.component.proxy
        }
      },
      unmount() {
        i && (e(null, a._container), delete a._container.__vue_app__)
      },
      provide(u, h) {
        return l.provides[u] = h, a
      }
    };
    return a
  }
}

function ks(e, t, n, s, r = !1) {
  if (D(e)) {
    e.forEach((_, w) => ks(_, t && (D(t) ? t[w] : t), n, s, r));
    return
  }
  if (Is(s) && !r) return;
  const l = s.shapeFlag & 4 ? Ss(s.component) || s.component.proxy : s.el,
    o = r ? null : l,
    {
      i,
      r: a
    } = e,
    u = t && t.r,
    h = i.refs === Q ? i.refs = {} : i.refs,
    p = i.setupState;
  if (u != null && u !== a && (he(u) ? (h[u] = null, B(p, u) && (p[u] = null)) : ye(u) && (u.value = null)), U(a)) Ze(a, i, 12, [o, h]);
  else {
    const _ = he(a),
      w = ye(a);
    if (_ || w) {
      const S = () => {
        if (e.f) {
          const P = _ ? h[a] : a.value;
          r ? D(P) && ts(P, l) : D(P) ? P.includes(l) || P.push(l) : _ ? h[a] = [l] : (a.value = [l], e.k && (h[e.k] = a.value))
        } else _ ? (h[a] = o, B(p, a) && (p[a] = o)) : ye(a) && (a.value = o, e.k && (h[e.k] = o))
      };
      o ? (S.id = -1, ve(S, n)) : S()
    }
  }
}
const ve = Ni;

function ta(e) {
  return na(e)
}

function na(e, t) {
  const n = jo();
  n.__VUE__ = !0;
  const {
    insert: s,
    remove: r,
    patchProp: l,
    createElement: o,
    createText: i,
    createComment: a,
    setText: u,
    setElementText: h,
    parentNode: p,
    nextSibling: _,
    setScopeId: w = De,
    cloneNode: S,
    insertStaticContent: P
  } = e, I = (c, d, g, y = null, b = null, v = null, C = !1, T = null, E = !!d.dynamicChildren) => {
    if (c === d) return;
    c && !gt(c, d) && (y = yt(c), Be(c, b, v, !0), c = null), d.patchFlag === -2 && (E = !1, d.dynamicChildren = null);
    const {
      type: f,
      ref: m,
      shapeFlag: O
    } = d;
    switch (f) {
      case Fn:
        F(c, d, g, y);
        break;
      case je:
        H(c, d, g, y);
        break;
      case Mn:
        c == null && X(d, g, y, C);
        break;
      case Z:
        Me(c, d, g, y, b, v, C, T, E);
        break;
      default:
        O & 1 ? q(c, d, g, y, b, v, C, T, E) : O & 6 ? on(c, d, g, y, b, v, C, T, E) : (O & 64 || O & 128) && f.process(c, d, g, y, b, v, C, T, E, Xe)
    }
    m != null && b && ks(m, c && c.ref, v, d || c, !d)
  }, F = (c, d, g, y) => {
    if (c == null) s(d.el = i(d.children), g, y);
    else {
      const b = d.el = c.el;
      d.children !== c.children && u(b, d.children)
    }
  }, H = (c, d, g, y) => {
    c == null ? s(d.el = a(d.children || ""), g, y) : d.el = c.el
  }, X = (c, d, g, y) => {
    [c.el, c.anchor] = P(c.children, d, g, y)
  }, R = ({
    el: c,
    anchor: d
  }, g, y) => {
    let b;
    for (; c && c !== d;) b = _(c), s(c, g, y), c = b;
    s(d, g, y)
  }, N = ({
    el: c,
    anchor: d
  }) => {
    let g;
    for (; c && c !== d;) g = _(c), r(c), c = g;
    r(d)
  }, q = (c, d, g, y, b, v, C, T, E) => {
    C = C || d.type === "svg", c == null ? W(d, g, y, b, v, C, T, E) : le(c, d, b, v, C, T, E)
  }, W = (c, d, g, y, b, v, C, T) => {
    let E, f;
    const {
      type: m,
      props: O,
      shapeFlag: x,
      transition: $,
      patchFlag: j,
      dirs: K
    } = c;
    if (c.el && S !== void 0 && j === -1) E = c.el = S(c.el);
    else {
      if (E = c.el = o(c.type, v, O && O.is, O), x & 8 ? h(E, c.children) : x & 16 && te(c.children, E, null, y, b, v && m !== "foreignObject", C, T), K && dt(c, null, y, "created"), O) {
        for (const ne in O) ne !== "value" && !dn(ne) && l(E, ne, null, O[ne], v, c.children, y, b, Se);
        "value" in O && l(E, "value", null, O.value), (f = O.onVnodeBeforeMount) && We(f, y, c)
      }
      se(E, c, c.scopeId, C, y)
    }
    K && dt(c, null, y, "beforeMount");
    const G = (!b || b && !b.pendingBranch) && $ && !$.persisted;
    G && $.beforeEnter(E), s(E, d, g), ((f = O && O.onVnodeMounted) || G || K) && ve(() => {
      f && We(f, y, c), G && $.enter(E), K && dt(c, null, y, "mounted")
    }, b)
  }, se = (c, d, g, y, b) => {
    if (g && w(c, g), y)
      for (let v = 0; v < y.length; v++) w(c, y[v]);
    if (b) {
      let v = b.subTree;
      if (d === v) {
        const C = b.vnode;
        se(c, C, C.scopeId, C.slotScopeIds, b.parent)
      }
    }
  }, te = (c, d, g, y, b, v, C, T, E = 0) => {
    for (let f = E; f < c.length; f++) {
      const m = c[f] = T ? Qe(c[f]) : He(c[f]);
      I(null, m, d, g, y, b, v, C, T)
    }
  }, le = (c, d, g, y, b, v, C) => {
    const T = d.el = c.el;
    let {
      patchFlag: E,
      dynamicChildren: f,
      dirs: m
    } = d;
    E |= c.patchFlag & 16;
    const O = c.props || Q,
      x = d.props || Q;
    let $;
    g && ht(g, !1), ($ = x.onVnodeBeforeUpdate) && We($, g, d, c), m && dt(d, c, g, "beforeUpdate"), g && ht(g, !0);
    const j = b && d.type !== "foreignObject";
    if (f ? ue(c.dynamicChildren, f, T, g, y, j, v) : C || Re(c, d, T, null, g, y, j, v, !1), E > 0) {
      if (E & 16) _e(T, d, O, x, g, y, b);
      else if (E & 2 && O.class !== x.class && l(T, "class", null, x.class, b), E & 4 && l(T, "style", O.style, x.style, b), E & 8) {
        const K = d.dynamicProps;
        for (let G = 0; G < K.length; G++) {
          const ne = K[G],
            Pe = O[ne],
            Tt = x[ne];
          (Tt !== Pe || ne === "value") && l(T, ne, Pe, Tt, b, c.children, g, y, Se)
        }
      }
      E & 1 && c.children !== d.children && h(T, d.children)
    } else !C && f == null && _e(T, d, O, x, g, y, b);
    (($ = x.onVnodeUpdated) || m) && ve(() => {
      $ && We($, g, d, c), m && dt(d, c, g, "updated")
    }, y)
  }, ue = (c, d, g, y, b, v, C) => {
    for (let T = 0; T < d.length; T++) {
      const E = c[T],
        f = d[T],
        m = E.el && (E.type === Z || !gt(E, f) || E.shapeFlag & (6 | 64)) ? p(E.el) : g;
      I(E, f, m, null, y, b, v, C, !0)
    }
  }, _e = (c, d, g, y, b, v, C) => {
    if (g !== y) {
      for (const T in y) {
        if (dn(T)) continue;
        const E = y[T],
          f = g[T];
        E !== f && T !== "value" && l(c, T, f, E, C, d.children, b, v, Se)
      }
      if (g !== Q)
        for (const T in g) !dn(T) && !(T in y) && l(c, T, g[T], null, C, d.children, b, v, Se);
      "value" in y && l(c, "value", g.value, y.value)
    }
  }, Me = (c, d, g, y, b, v, C, T, E) => {
    const f = d.el = c ? c.el : i(""),
      m = d.anchor = c ? c.anchor : i("");
    let {
      patchFlag: O,
      dynamicChildren: x,
      slotScopeIds: $
    } = d;
    $ && (T = T ? T.concat($) : $), c == null ? (s(f, g, y), s(m, g, y), te(d.children, g, m, b, v, C, T, E)) : O > 0 && O & 64 && x && c.dynamicChildren ? (ue(c.dynamicChildren, x, g, b, v, C, T), (d.key != null || b && d === b.subTree) && ol(c, d, !0)) : Re(c, d, g, m, b, v, C, T, E)
  }, on = (c, d, g, y, b, v, C, T, E) => {
    d.slotScopeIds = T, c == null ? d.shapeFlag & 512 ? b.ctx.activate(d, g, y, C, E) : $t(d, g, y, b, v, C, E) : pe(c, d, E)
  }, $t = (c, d, g, y, b, v, C) => {
    const T = c.component = _a(c, y, b);
    if (Nn(c) && (T.ctx.renderer = Xe), pa(T), T.asyncDep) {
      if (b && b.registerDep(T, Y), !c.el) {
        const E = T.subTree = re(je);
        H(null, E, d, g)
      }
      return
    }
    Y(T, c, d, g, b, v, C)
  }, pe = (c, d, g) => {
    const y = d.component = c.component;
    if (Ci(c, d, g))
      if (y.asyncDep && !y.asyncResolved) {
        J(y, d, g);
        return
      } else y.next = d, Oa(y.update), y.update();
    else d.component = c.component, d.el = c.el, y.vnode = d
  }, Y = (c, d, g, y, b, v, C) => {
    const T = () => {
        if (c.isMounted) {
          let {
            next: m,
            bu: O,
            u: x,
            parent: $,
            vnode: j
          } = c, K = m, G;
          ht(c, !1), m ? (m.el = j.el, J(c, m, C)) : m = j, O && gn(O), (G = m.props && m.props.onVnodeBeforeUpdate) && We(G, $, m, j), ht(c, !0);
          const ne = Es(c),
            Pe = c.subTree;
          c.subTree = ne, I(Pe, ne, p(Pe.el), yt(Pe), c, b, v), m.el = ne.el, K === null && Oi(c, ne.el), x && ve(x, b), (G = m.props && m.props.onVnodeUpdated) && ve(() => We(G, $, m, j), b)
        } else {
          let m;
          const {
            el: O,
            props: x
          } = d, {
            bm: $,
            m: j,
            parent: K
          } = c, G = Is(d);
          if (ht(c, !1), $ && gn($), !G && (m = x && x.onVnodeBeforeMount) && We(m, K, d), ht(c, !0), O && Et) {
            const ne = () => {
              c.subTree = Es(c), Et(O, c.subTree, c, b, null)
            };
            G ? d.type.__asyncLoader().then(() => !c.isUnmounted && ne()) : ne()
          } else {
            const ne = c.subTree = Es(c);
            I(null, ne, g, y, c, b, v), d.el = ne.el
          }
          if (j && ve(j, b), !G && (m = x && x.onVnodeMounted)) {
            const ne = d;
            ve(() => We(m, K, ne), b)
          }
          d.shapeFlag & 256 && c.a && ve(c.a, b), c.isMounted = !0, d = g = y = null
        }
      },
      E = c.effect = new cs(T, () => pl(c.update), c.scope),
      f = c.update = E.run.bind(E);
    f.id = c.uid, ht(c, !0), f()
  }, J = (c, d, g) => {
    d.component = c;
    const y = c.vnode.props;
    c.vnode = d, c.next = null, Xi(c, d.props, y, g), Qi(c, d.children, g), xt(), Us(void 0, c.update), ut()
  }, Re = (c, d, g, y, b, v, C, T, E = !1) => {
    const f = c && c.children,
      m = c ? c.shapeFlag : 0,
      O = d.children,
      {
        patchFlag: x,
        shapeFlag: $
      } = d;
    if (x > 0) {
      if (x & 128) {
        lt(f, O, g, y, b, v, C, T, E);
        return
      } else if (x & 256) {
        Ut(f, O, g, y, b, v, C, T, E);
        return
      }
    }
    $ & 8 ? (m & 16 && Se(f, b, v), O !== f && h(g, O)) : m & 16 ? $ & 16 ? lt(f, O, g, y, b, v, C, T, E) : Se(f, b, v, !0) : (m & 8 && h(g, ""), $ & 16 && te(O, g, y, b, v, C, T, E))
  }, Ut = (c, d, g, y, b, v, C, T, E) => {
    c = c || vt, d = d || vt;
    const f = c.length,
      m = d.length,
      O = Math.min(f, m);
    let x;
    for (x = 0; x < O; x++) {
      const $ = d[x] = E ? Qe(d[x]) : He(d[x]);
      I(c[x], $, g, null, b, v, C, T, E)
    }
    f > m ? Se(c, b, v, !0, !1, O) : te(d, g, y, b, v, C, T, E, O)
  }, lt = (c, d, g, y, b, v, C, T, E) => {
    let f = 0;
    const m = d.length;
    let O = c.length - 1,
      x = m - 1;
    for (; f <= O && f <= x;) {
      const $ = c[f],
        j = d[f] = E ? Qe(d[f]) : He(d[f]);
      if (gt($, j)) I($, j, g, null, b, v, C, T, E);
      else break;
      f++
    }
    for (; f <= O && f <= x;) {
      const $ = c[O],
        j = d[x] = E ? Qe(d[x]) : He(d[x]);
      if (gt($, j)) I($, j, g, null, b, v, C, T, E);
      else break;
      O--, x--
    }
    if (f > O) {
      if (f <= x) {
        const $ = x + 1,
          j = $ < m ? d[$].el : y;
        for (; f <= x;) I(null, d[f] = E ? Qe(d[f]) : He(d[f]), g, j, b, v, C, T, E), f++
      }
    } else if (f > x)
      for (; f <= O;) Be(c[f], b, v, !0), f++;
    else {
      const $ = f,
        j = f,
        K = new Map;
      for (f = j; f <= x; f++) {
        const Ie = d[f] = E ? Qe(d[f]) : He(d[f]);
        Ie.key != null && K.set(Ie.key, f)
      }
      let G, ne = 0;
      const Pe = x - j + 1;
      let Tt = !1,
        ir = 0;
      const Ht = new Array(Pe);
      for (f = 0; f < Pe; f++) Ht[f] = 0;
      for (f = $; f <= O; f++) {
        const Ie = c[f];
        if (ne >= Pe) {
          Be(Ie, b, v, !0);
          continue
        }
        let $e;
        if (Ie.key != null) $e = K.get(Ie.key);
        else
          for (G = j; G <= x; G++)
            if (Ht[G - j] === 0 && gt(Ie, d[G])) {
              $e = G;
              break
            } $e === void 0 ? Be(Ie, b, v, !0) : (Ht[$e - j] = f + 1, $e >= ir ? ir = $e : Tt = !0, I(Ie, d[$e], g, null, b, v, C, T, E), ne++)
      }
      const ar = Tt ? sa(Ht) : vt;
      for (G = ar.length - 1, f = Pe - 1; f >= 0; f--) {
        const Ie = j + f,
          $e = d[Ie],
          cr = Ie + 1 < m ? d[Ie + 1].el : y;
        Ht[f] === 0 ? I(null, $e, g, cr, b, v, C, T, E) : Tt && (G < 0 || f !== ar[G] ? Ge($e, g, cr, 2) : G--)
      }
    }
  }, Ge = (c, d, g, y, b = null) => {
    const {
      el: v,
      type: C,
      transition: T,
      children: E,
      shapeFlag: f
    } = c;
    if (f & 6) {
      Ge(c.component.subTree, d, g, y);
      return
    }
    if (f & 128) {
      c.suspense.move(d, g, y);
      return
    }
    if (f & 64) {
      C.move(c, d, g, Xe);
      return
    }
    if (C === Z) {
      s(v, d, g);
      for (let O = 0; O < E.length; O++) Ge(E[O], d, g, y);
      s(c.anchor, d, g);
      return
    }
    if (C === Mn) {
      R(c, d, g);
      return
    }
    if (y !== 2 && f & 1 && T)
      if (y === 0) T.beforeEnter(v), s(v, d, g), ve(() => T.enter(v), b);
      else {
        const {
          leave: O,
          delayLeave: x,
          afterLeave: $
        } = T, j = () => s(v, d, g), K = () => {
          O(v, () => {
            j(), $ && $()
          })
        };
        x ? x(v, j, K) : K()
      }
    else s(v, d, g)
  }, Be = (c, d, g, y = !1, b = !1) => {
    const {
      type: v,
      props: C,
      ref: T,
      children: E,
      dynamicChildren: f,
      shapeFlag: m,
      patchFlag: O,
      dirs: x
    } = c;
    if (T != null && ks(T, null, g, c, !0), m & 256) {
      d.ctx.deactivate(c);
      return
    }
    const $ = m & 1 && x,
      j = !Is(c);
    let K;
    if (j && (K = C && C.onVnodeBeforeUnmount) && We(K, d, c), m & 6) Jn(c.component, g, y);
    else {
      if (m & 128) {
        c.suspense.unmount(g, y);
        return
      }
      $ && dt(c, null, d, "beforeUnmount"), m & 64 ? c.type.remove(c, d, g, b, Xe, y) : f && (v !== Z || O > 0 && O & 64) ? Se(f, d, g, !1, !0) : (v === Z && O & (128 | 256) || !b && m & 16) && Se(E, d, g), y && an(c)
    }(j && (K = C && C.onVnodeUnmounted) || $) && ve(() => {
      K && We(K, d, c), $ && dt(c, null, d, "unmounted")
    }, g)
  }, an = c => {
    const {
      type: d,
      el: g,
      anchor: y,
      transition: b
    } = c;
    if (d === Z) {
      Xn(g, y);
      return
    }
    if (d === Mn) {
      N(c);
      return
    }
    const v = () => {
      r(g), b && !b.persisted && b.afterLeave && b.afterLeave()
    };
    if (c.shapeFlag & 1 && b && !b.persisted) {
      const {
        leave: C,
        delayLeave: T
      } = b, E = () => C(g, v);
      T ? T(c.el, v, E) : E()
    } else v()
  }, Xn = (c, d) => {
    let g;
    for (; c !== d;) g = _(c), r(c), c = g;
    r(d)
  }, Jn = (c, d, g) => {
    const {
      bum: y,
      scope: b,
      update: v,
      subTree: C,
      um: T
    } = c;
    y && gn(y), b.stop(), v && (v.active = !1, Be(C, c, d, g)), T && ve(T, d), ve(() => {
      c.isUnmounted = !0
    }, d), d && d.pendingBranch && !d.isUnmounted && c.asyncDep && !c.asyncResolved && c.suspenseId === d.pendingId && (d.deps--, d.deps === 0 && d.resolve())
  }, Se = (c, d, g, y = !1, b = !1, v = 0) => {
    for (let C = v; C < c.length; C++) Be(c[C], d, g, y, b)
  }, yt = c => c.shapeFlag & 6 ? yt(c.component.subTree) : c.shapeFlag & 128 ? c.suspense.next() : _(c.anchor || c.el), cn = (c, d, g) => {
    c == null ? d._vnode && Be(d._vnode, null, null, !0) : I(d._vnode || null, c, d, null, null, null, g), El(), d._vnode = c
  }, Xe = {
    p: I,
    um: Be,
    m: Ge,
    r: an,
    mt: $t,
    mc: te,
    pc: Re,
    pbc: ue,
    n: yt,
    o: e
  };
  let jt, Et;
  return t && ([jt, Et] = t(Xe)), {
    render: cn,
    hydrate: jt,
    createApp: ea(cn, jt)
  }
}

function ht({
  effect: e,
  update: t
}, n) {
  e.allowRecurse = t.allowRecurse = n
}

function ol(e, t, n = !1) {
  const s = e.children,
    r = t.children;
  if (D(s) && D(r))
    for (let l = 0; l < s.length; l++) {
      const o = s[l];
      let i = r[l];
      i.shapeFlag & 1 && !i.dynamicChildren && ((i.patchFlag <= 0 || i.patchFlag === 32) && (i = r[l] = Qe(r[l]), i.el = o.el), n || ol(o, i))
    }
}

function sa(e) {
  const t = e.slice(),
    n = [0];
  let s, r, l, o, i;
  const a = e.length;
  for (s = 0; s < a; s++) {
    const u = e[s];
    if (u !== 0) {
      if (r = n[n.length - 1], e[r] < u) {
        t[s] = r, n.push(s);
        continue
      }
      for (l = 0, o = n.length - 1; l < o;) i = l + o >> 1, e[n[i]] < u ? l = i + 1 : o = i;
      u < e[n[l]] && (l > 0 && (t[s] = n[l - 1]), n[l] = s)
    }
  }
  for (l = n.length, o = n[l - 1]; l-- > 0;) n[l] = o, o = t[o];
  return n
}
const ra = e => e.__isTeleport,
  il = "components";

function Td(e, t) {
  return oa(il, e, !0, t) || e
}
const la = Symbol();

function oa(e, t, n = !0, s = !1) {
  const r = Ne || fe;
  if (r) {
    const l = r.type;
    if (e === il) {
      const i = Ta(l);
      if (i && (i === t || i === Ue(t) || i === mn(Ue(t)))) return l
    }
    const o = al(r[e] || l[e], t) || al(r.appContext[e], t);
    return !o && s ? l : o
  }
}

function al(e, t) {
  return e && (e[t] || e[Ue(t)] || e[mn(Ue(t))])
}
const Z = Symbol(void 0),
  Fn = Symbol(void 0),
  je = Symbol(void 0),
  Mn = Symbol(void 0),
  Gt = [];
let mt = null;

function L(e = !1) {
  Gt.push(mt = e ? null : [])
}

function ia() {
  Gt.pop(), mt = Gt[Gt.length - 1] || null
}
let Rn = 1;

function cl(e) {
  Rn += e
}

function ul(e) {
  return e.dynamicChildren = Rn > 0 ? mt || vt : null, ia(), Rn > 0 && mt && mt.push(e), e
}

function k(e, t, n, s, r, l) {
  return ul(A(e, t, n, s, r, l, !0))
}

function aa(e, t, n, s, r) {
  return ul(re(e, t, n, s, r, !0))
}

function Fs(e) {
  return e ? e.__v_isVNode === !0 : !1
}

function gt(e, t) {
  return e.type === t.type && e.key === t.key
}
const Sn = "__vInternal",
  fl = ({
    key: e
  }) => e != null ? e : null,
  Pn = ({
    ref: e,
    ref_key: t,
    ref_for: n
  }) => e != null ? he(e) || ye(e) || U(e) ? {
    i: Ne,
    r: e,
    k: t,
    f: !!n
  } : e : null;

function A(e, t = null, n = null, s = 0, r = null, l = e === Z ? 0 : 1, o = !1, i = !1) {
  const a = {
    __v_isVNode: !0,
    __v_skip: !0,
    type: e,
    props: t,
    key: t && fl(t),
    ref: t && Pn(t),
    scopeId: Cn,
    slotScopeIds: null,
    children: n,
    component: null,
    suspense: null,
    ssContent: null,
    ssFallback: null,
    dirs: null,
    transition: null,
    el: null,
    anchor: null,
    target: null,
    targetAnchor: null,
    staticCount: 0,
    shapeFlag: l,
    patchFlag: s,
    dynamicProps: r,
    dynamicChildren: null,
    appContext: null
  };
  return i ? (Ms(a, n), l & 128 && e.normalize(a)) : n && (a.shapeFlag |= he(n) ? 8 : 16), Rn > 0 && !o && mt && (a.patchFlag > 0 || l & 6) && a.patchFlag !== 32 && mt.push(a), a
}
const re = ca;

function ca(e, t = null, n = null, s = 0, r = null, l = !1) {
  if ((!e || e === la) && (e = je), Fs(e)) {
    const i = At(e, t, !0);
    return n && Ms(i, n), i
  }
  if (va(e) && (e = e.__vccOpts), t) {
    t = ua(t);
    let {
      class: i,
      style: a
    } = t;
    i && !he(i) && (t.class = Qn(i)), ie(a) && (Rr(a) && !D(a) && (a = be({}, a)), t.style = ot(a))
  }
  const o = he(e) ? 1 : xi(e) ? 128 : ra(e) ? 64 : ie(e) ? 4 : U(e) ? 2 : 0;
  return A(e, t, n, s, r, o, l, !0)
}

function ua(e) {
  return e ? Rr(e) || Sn in e ? be({}, e) : e : null
}

function At(e, t, n = !1) {
  const {
    props: s,
    ref: r,
    patchFlag: l,
    children: o
  } = e, i = t ? da(s || {}, t) : s;
  return {
    __v_isVNode: !0,
    __v_skip: !0,
    type: e.type,
    props: i,
    key: i && fl(i),
    ref: t && t.ref ? n && r ? D(r) ? r.concat(Pn(t)) : [r, Pn(t)] : Pn(t) : r,
    scopeId: e.scopeId,
    slotScopeIds: e.slotScopeIds,
    children: o,
    target: e.target,
    targetAnchor: e.targetAnchor,
    staticCount: e.staticCount,
    shapeFlag: e.shapeFlag,
    patchFlag: t && e.type !== Z ? l === -1 ? 16 : l | 16 : l,
    dynamicProps: e.dynamicProps,
    dynamicChildren: e.dynamicChildren,
    appContext: e.appContext,
    dirs: e.dirs,
    transition: e.transition,
    component: e.component,
    suspense: e.suspense,
    ssContent: e.ssContent && At(e.ssContent),
    ssFallback: e.ssFallback && At(e.ssFallback),
    el: e.el,
    anchor: e.anchor
  }
}

function fa(e = " ", t = 0) {
  return re(Fn, null, e, t)
}

function vd(e, t) {
  const n = re(Mn, null, e);
  return n.staticCount = t, n
}

function ee(e = "", t = !1) {
  return t ? (L(), aa(je, null, e)) : re(je, null, e)
}

function He(e) {
  return e == null || typeof e == "boolean" ? re(je) : D(e) ? re(Z, null, e.slice()) : typeof e == "object" ? Qe(e) : re(Fn, null, String(e))
}

function Qe(e) {
  return e.el === null || e.memo ? e : At(e)
}

function Ms(e, t) {
  let n = 0;
  const {
    shapeFlag: s
  } = e;
  if (t == null) t = null;
  else if (D(t)) n = 16;
  else if (typeof t == "object")
    if (s & (1 | 64)) {
      const r = t.default;
      r && (r._c && (r._d = !1), Ms(e, r()), r._c && (r._d = !0));
      return
    } else {
      n = 32;
      const r = t._;
      !r && !(Sn in t) ? t._ctx = Ne : r === 3 && Ne && (Ne.slots._ === 1 ? t._ = 1 : (t._ = 2, e.patchFlag |= 1024))
    }
  else U(t) ? (t = {
    default: t,
    _ctx: Ne
  }, n = 32) : (t = String(t), s & 64 ? (n = 16, t = [fa(t)]) : n = 8);
  e.children = t, e.shapeFlag |= n
}

function da(...e) {
  const t = {};
  for (let n = 0; n < e.length; n++) {
    const s = e[n];
    for (const r in s)
      if (r === "class") t.class !== s.class && (t.class = Qn([t.class, s.class]));
      else if (r === "style") t.style = ot([t.style, s.style]);
    else if (un(r)) {
      const l = t[r],
        o = s[r];
      l !== o && !(D(l) && l.includes(o)) && (t[r] = l ? [].concat(l, o) : o)
    } else r !== "" && (t[r] = s[r])
  }
  return t
}

function We(e, t, n, s = null) {
  Ae(e, t, 7, [n, s])
}

function we(e, t, n, s) {
  let r;
  const l = n && n[s];
  if (D(e) || he(e)) {
    r = new Array(e.length);
    for (let o = 0, i = e.length; o < i; o++) r[o] = t(e[o], o, void 0, l && l[o])
  } else if (typeof e == "number") {
    r = new Array(e);
    for (let o = 0; o < e; o++) r[o] = t(o + 1, o, void 0, l && l[o])
  } else if (ie(e))
    if (e[Symbol.iterator]) r = Array.from(e, (o, i) => t(o, i, void 0, l && l[i]));
    else {
      const o = Object.keys(e);
      r = new Array(o.length);
      for (let i = 0, a = o.length; i < a; i++) {
        const u = o[i];
        r[i] = t(e[u], u, i, l && l[i])
      }
    }
  else r = [];
  return n && (n[s] = r), r
}
const Rs = e => e ? dl(e) ? Ss(e) || e.proxy : Rs(e.parent) : null,
  Dn = be(Object.create(null), {
    $: e => e,
    $el: e => e.vnode.el,
    $data: e => e.data,
    $props: e => e.props,
    $attrs: e => e.attrs,
    $slots: e => e.slots,
    $refs: e => e.refs,
    $parent: e => Rs(e.parent),
    $root: e => Rs(e.root),
    $emit: e => e.emit,
    $options: e => Gr(e),
    $forceUpdate: e => () => pl(e.update),
    $nextTick: e => Ia.bind(e.proxy),
    $watch: e => La.bind(e)
  }),
  ha = {
    get({
      _: e
    }, t) {
      const {
        ctx: n,
        setupState: s,
        data: r,
        props: l,
        accessCache: o,
        type: i,
        appContext: a
      } = e;
      let u;
      if (t[0] !== "$") {
        const w = o[t];
        if (w !== void 0) switch (w) {
          case 1:
            return s[t];
          case 2:
            return r[t];
          case 4:
            return n[t];
          case 3:
            return l[t]
        } else {
          if (s !== Q && B(s, t)) return o[t] = 1, s[t];
          if (r !== Q && B(r, t)) return o[t] = 2, r[t];
          if ((u = e.propsOptions[0]) && B(u, t)) return o[t] = 3, l[t];
          if (n !== Q && B(n, t)) return o[t] = 4, n[t];
          xs && (o[t] = 0)
        }
      }
      const h = Dn[t];
      let p, _;
      if (h) return t === "$attrs" && Ce(e, "get", t), h(e);
      if ((p = i.__cssModules) && (p = p[t])) return p;
      if (n !== Q && B(n, t)) return o[t] = 4, n[t];
      if (_ = a.config.globalProperties, B(_, t)) return _[t]
    },
    set({
      _: e
    }, t, n) {
      const {
        data: s,
        setupState: r,
        ctx: l
      } = e;
      if (r !== Q && B(r, t)) r[t] = n;
      else if (s !== Q && B(s, t)) s[t] = n;
      else if (B(e.props, t)) return !1;
      return t[0] === "$" && t.slice(1) in e ? !1 : (l[t] = n, !0)
    },
    has({
      _: {
        data: e,
        setupState: t,
        accessCache: n,
        ctx: s,
        appContext: r,
        propsOptions: l
      }
    }, o) {
      let i;
      return !!n[o] || e !== Q && B(e, o) || t !== Q && B(t, o) || (i = l[0]) && B(i, o) || B(s, o) || B(Dn, o) || B(r.config.globalProperties, o)
    }
  },
  ma = ll();
let ga = 0;

function _a(e, t, n) {
  const s = e.type,
    r = (t ? t.appContext : e.appContext) || ma,
    l = {
      uid: ga++,
      vnode: e,
      type: s,
      parent: t,
      appContext: r,
      root: null,
      next: null,
      subTree: null,
      effect: null,
      update: null,
      scope: new Ho(!0),
      render: null,
      proxy: null,
      exposed: null,
      exposeProxy: null,
      withProxy: null,
      provides: t ? t.provides : Object.create(r.provides),
      accessCache: null,
      renderCache: [],
      components: null,
      directives: null,
      propsOptions: qr(s, r),
      emitsOptions: Ur(s, r),
      emit: null,
      emitted: null,
      propsDefaults: Q,
      inheritAttrs: s.inheritAttrs,
      ctx: Q,
      data: Q,
      props: Q,
      attrs: Q,
      slots: Q,
      refs: Q,
      setupState: Q,
      setupContext: null,
      suspense: n,
      suspenseId: n ? n.pendingId : 0,
      asyncDep: null,
      asyncResolved: !1,
      isMounted: !1,
      isUnmounted: !1,
      isDeactivated: !1,
      bc: null,
      c: null,
      bm: null,
      m: null,
      bu: null,
      u: null,
      um: null,
      bum: null,
      da: null,
      a: null,
      rtg: null,
      rtc: null,
      ec: null,
      sp: null
    };
  return l.ctx = {
    _: l
  }, l.root = t ? t.root : l, l.emit = Ti.bind(null, l), e.ce && e.ce(l), l
}
let fe = null;
const $n = () => fe || Ne,
  kt = e => {
    fe = e, e.scope.on()
  },
  _t = () => {
    fe && fe.scope.off(), fe = null
  };

function dl(e) {
  return e.vnode.shapeFlag & 4
}
let Un = !1;

function pa(e, t = !1) {
  Un = t;
  const {
    props: n,
    children: s
  } = e.vnode, r = dl(e);
  Gi(e, n, r, t), qi(e, s);
  const l = r ? ba(e, t) : void 0;
  return Un = !1, l
}

function ba(e, t) {
  const n = e.type;
  e.accessCache = Object.create(null), e.proxy = Sr(new Proxy(e.ctx, ha));
  const {
    setup: s
  } = n;
  if (s) {
    const r = e.setupContext = s.length > 1 ? Ea(e) : null;
    kt(e), xt();
    const l = Ze(s, e, 0, [e.props, r]);
    if (ut(), _t(), hr(l)) {
      if (l.then(_t, _t), t) return l.then(o => {
        hl(e, o, t)
      }).catch(o => {
        jn(o, e, 0)
      });
      e.asyncDep = l
    } else hl(e, l, t)
  } else gl(e, t)
}

function hl(e, t, n) {
  U(t) ? e.type.__ssrInlineRender ? e.ssrRender = t : e.render = t : ie(t) && (e.setupState = $r(t)), gl(e, n)
}
let ml;

function gl(e, t, n) {
  const s = e.type;
  if (!e.render) {
    if (!t && ml && !s.render) {
      const r = s.template;
      if (r) {
        const {
          isCustomElement: l,
          compilerOptions: o
        } = e.appContext.config, {
          delimiters: i,
          compilerOptions: a
        } = s, u = be(be({
          isCustomElement: l,
          delimiters: i
        }, o), a);
        s.render = ml(r, u)
      }
    }
    e.render = s.render || De
  }
  kt(e), xt(), Vi(e), ut(), _t()
}

function ya(e) {
  return new Proxy(e.attrs, {
    get(t, n) {
      return Ce(e, "get", "$attrs"), t[n]
    }
  })
}

function Ea(e) {
  const t = s => {
    e.exposed = s || {}
  };
  let n;
  return {
    get attrs() {
      return n || (n = ya(e))
    },
    slots: e.slots,
    emit: e.emit,
    expose: t
  }
}

function Ss(e) {
  if (e.exposed) return e.exposeProxy || (e.exposeProxy = new Proxy($r(Sr(e.exposed)), {
    get(t, n) {
      if (n in t) return t[n];
      if (n in Dn) return Dn[n](e)
    }
  }))
}

function Ta(e) {
  return U(e) && e.displayName || e.name
}

function va(e) {
  return U(e) && "__vccOpts" in e
}

function Ze(e, t, n, s) {
  let r;
  try {
    r = s ? e(...s) : e()
  } catch (l) {
    jn(l, t, n)
  }
  return r
}

function Ae(e, t, n, s) {
  if (U(e)) {
    const l = Ze(e, t, n, s);
    return l && hr(l) && l.catch(o => {
      jn(o, t, n)
    }), l
  }
  const r = [];
  for (let l = 0; l < e.length; l++) r.push(Ae(e[l], t, n, s));
  return r
}

function jn(e, t, n, s = !0) {
  const r = t ? t.vnode : null;
  if (t) {
    let l = t.parent;
    const o = t.proxy,
      i = n;
    for (; l;) {
      const u = l.ec;
      if (u) {
        for (let h = 0; h < u.length; h++)
          if (u[h](e, o, i) === !1) return
      }
      l = l.parent
    }
    const a = t.appContext.config.errorHandler;
    if (a) {
      Ze(a, null, 10, [e, o, i]);
      return
    }
  }
  wa(e, n, r, s)
}

function wa(e, t, n, s = !0) {
  console.error(e)
}
let Hn = !1,
  Ps = !1;
const Oe = [];
let Ye = 0;
const Xt = [];
let Jt = null,
  Ft = 0;
const qt = [];
let et = null,
  Mt = 0;
const _l = Promise.resolve();
let Ds = null,
  $s = null;

function Ia(e) {
  const t = Ds || _l;
  return e ? t.then(this ? e.bind(this) : e) : t
}

function Ca(e) {
  let t = Ye + 1,
    n = Oe.length;
  for (; t < n;) {
    const s = t + n >>> 1;
    Qt(Oe[s]) < e ? t = s + 1 : n = s
  }
  return t
}

function pl(e) {
  (!Oe.length || !Oe.includes(e, Hn && e.allowRecurse ? Ye + 1 : Ye)) && e !== $s && (e.id == null ? Oe.push(e) : Oe.splice(Ca(e.id), 0, e), bl())
}

function bl() {
  !Hn && !Ps && (Ps = !0, Ds = _l.then(Tl))
}

function Oa(e) {
  const t = Oe.indexOf(e);
  t > Ye && Oe.splice(t, 1)
}

function yl(e, t, n, s) {
  D(e) ? n.push(...e) : (!t || !t.includes(e, e.allowRecurse ? s + 1 : s)) && n.push(e), bl()
}

function xa(e) {
  yl(e, Jt, Xt, Ft)
}

function Na(e) {
  yl(e, et, qt, Mt)
}

function Us(e, t = null) {
  if (Xt.length) {
    for ($s = t, Jt = [...new Set(Xt)], Xt.length = 0, Ft = 0; Ft < Jt.length; Ft++) Jt[Ft]();
    Jt = null, Ft = 0, $s = null, Us(e, t)
  }
}

function El(e) {
  if (qt.length) {
    const t = [...new Set(qt)];
    if (qt.length = 0, et) {
      et.push(...t);
      return
    }
    for (et = t, et.sort((n, s) => Qt(n) - Qt(s)), Mt = 0; Mt < et.length; Mt++) et[Mt]();
    et = null, Mt = 0
  }
}
const Qt = e => e.id == null ? 1 / 0 : e.id;

function Tl(e) {
  Ps = !1, Hn = !0, Us(e), Oe.sort((n, s) => Qt(n) - Qt(s));
  const t = De;
  try {
    for (Ye = 0; Ye < Oe.length; Ye++) {
      const n = Oe[Ye];
      n && n.active !== !1 && Ze(n, null, 14)
    }
  } finally {
    Ye = 0, Oe.length = 0, El(), Hn = !1, Ds = null, (Oe.length || Xt.length || qt.length) && Tl(e)
  }
}
const vl = {};

function Zt(e, t, n) {
  return wl(e, t, n)
}

function wl(e, t, {
  immediate: n,
  deep: s,
  flush: r,
  onTrack: l,
  onTrigger: o
} = Q) {
  const i = fe;
  let a, u = !1,
    h = !1;
  if (ye(e) ? (a = () => e.value, u = !!e._shallow) : Nt(e) ? (a = () => e, s = !0) : D(e) ? (h = !0, u = e.some(Nt), a = () => e.map(F => {
      if (ye(F)) return F.value;
      if (Nt(F)) return pt(F);
      if (U(F)) return Ze(F, i, 2)
    })) : U(e) ? t ? a = () => Ze(e, i, 2) : a = () => {
      if (!(i && i.isUnmounted)) return p && p(), Ae(e, i, 3, [_])
    } : a = De, t && s) {
    const F = a;
    a = () => pt(F())
  }
  let p, _ = F => {
    p = I.onStop = () => {
      Ze(F, i, 4)
    }
  };
  if (Un) return _ = De, t ? n && Ae(t, i, 3, [a(), h ? [] : void 0, _]) : a(), De;
  let w = h ? [] : vl;
  const S = () => {
    if (!!I.active)
      if (t) {
        const F = I.run();
        (s || u || (h ? F.some((H, X) => Vt(H, w[X])) : Vt(F, w))) && (p && p(), Ae(t, i, 3, [F, w === vl ? void 0 : w, _]), w = F)
      } else I.run()
  };
  S.allowRecurse = !!t;
  let P;
  r === "sync" ? P = S : r === "post" ? P = () => ve(S, i && i.suspense) : P = () => {
    !i || i.isMounted ? xa(S) : S()
  };
  const I = new cs(a, P);
  return t ? n ? S() : w = I.run() : r === "post" ? ve(I.run.bind(I), i && i.suspense) : I.run(), () => {
    I.stop(), i && i.scope && ts(i.scope.effects, I)
  }
}

function La(e, t, n) {
  const s = this.proxy,
    r = he(e) ? e.includes(".") ? Il(s, e) : () => s[e] : e.bind(s, s);
  let l;
  U(t) ? l = t : (l = t.handler, n = t);
  const o = fe;
  kt(this);
  const i = wl(r, l.bind(s), n);
  return o ? kt(o) : _t(), i
}

function Il(e, t) {
  const n = t.split(".");
  return () => {
    let s = e;
    for (let r = 0; r < n.length && s; r++) s = s[n[r]];
    return s
  }
}

function pt(e, t) {
  if (!ie(e) || e.__v_skip || (t = t || new Set, t.has(e))) return e;
  if (t.add(e), ye(e)) pt(e.value, t);
  else if (D(e))
    for (let n = 0; n < e.length; n++) pt(e[n], t);
  else if (It(e) || wt(e)) e.forEach(n => {
    pt(n, t)
  });
  else if (gr(e))
    for (const n in e) pt(e[n], t);
  return e
}

function Cl(e, t, n) {
  const s = arguments.length;
  return s === 2 ? ie(t) && !D(t) ? Fs(t) ? re(e, null, [t]) : re(e, t) : re(e, null, t) : (s > 3 ? n = Array.prototype.slice.call(arguments, 2) : s === 3 && Fs(n) && (n = [n]), re(e, t, n))
}
const Aa = "3.2.26",
  ka = "http://www.w3.org/2000/svg",
  Rt = typeof document != "undefined" ? document : null,
  Ol = new Map,
  Fa = {
    insert: (e, t, n) => {
      t.insertBefore(e, n || null)
    },
    remove: e => {
      const t = e.parentNode;
      t && t.removeChild(e)
    },
    createElement: (e, t, n, s) => {
      const r = t ? Rt.createElementNS(ka, e) : Rt.createElement(e, n ? {
        is: n
      } : void 0);
      return e === "select" && s && s.multiple != null && r.setAttribute("multiple", s.multiple), r
    },
    createText: e => Rt.createTextNode(e),
    createComment: e => Rt.createComment(e),
    setText: (e, t) => {
      e.nodeValue = t
    },
    setElementText: (e, t) => {
      e.textContent = t
    },
    parentNode: e => e.parentNode,
    nextSibling: e => e.nextSibling,
    querySelector: e => Rt.querySelector(e),
    setScopeId(e, t) {
      e.setAttribute(t, "")
    },
    cloneNode(e) {
      const t = e.cloneNode(!0);
      return "_value" in e && (t._value = e._value), t
    },
    insertStaticContent(e, t, n, s) {
      const r = n ? n.previousSibling : t.lastChild;
      let l = Ol.get(e);
      if (!l) {
        const o = Rt.createElement("template");
        if (o.innerHTML = s ? `<svg>${e}</svg>` : e, l = o.content, s) {
          const i = l.firstChild;
          for (; i.firstChild;) l.appendChild(i.firstChild);
          l.removeChild(i)
        }
        Ol.set(e, l)
      }
      return t.insertBefore(l.cloneNode(!0), n), [r ? r.nextSibling : t.firstChild, n ? n.previousSibling : t.lastChild]
    }
  };

function Ma(e, t, n) {
  const s = e._vtc;
  s && (t = (t ? [t, ...s] : [...s]).join(" ")), t == null ? e.removeAttribute("class") : n ? e.setAttribute("class", t) : e.className = t
}

function Ra(e, t, n) {
  const s = e.style,
    r = he(n);
  if (n && !r) {
    for (const l in n) js(s, l, n[l]);
    if (t && !he(t))
      for (const l in t) n[l] == null && js(s, l, "")
  } else {
    const l = s.display;
    r ? t !== n && (s.cssText = n) : t && e.removeAttribute("style"), "_vod" in e && (s.display = l)
  }
}
const xl = /\s*!important$/;

function js(e, t, n) {
  if (D(n)) n.forEach(s => js(e, t, s));
  else if (t.startsWith("--")) e.setProperty(t, n);
  else {
    const s = Sa(e, t);
    xl.test(n) ? e.setProperty(Ct(s), n.replace(xl, ""), "important") : e[s] = n
  }
}
const Nl = ["Webkit", "Moz", "ms"],
  Hs = {};

function Sa(e, t) {
  const n = Hs[t];
  if (n) return n;
  let s = Ue(t);
  if (s !== "filter" && s in e) return Hs[t] = s;
  s = mn(s);
  for (let r = 0; r < Nl.length; r++) {
    const l = Nl[r] + s;
    if (l in e) return Hs[t] = l
  }
  return t
}
const Ll = "http://www.w3.org/1999/xlink";

function Pa(e, t, n, s, r) {
  if (s && t.startsWith("xlink:")) n == null ? e.removeAttributeNS(Ll, t.slice(6, t.length)) : e.setAttributeNS(Ll, t, n);
  else {
    const l = Lo(t);
    n == null || l && !ur(n) ? e.removeAttribute(t) : e.setAttribute(t, l ? "" : n)
  }
}

function Da(e, t, n, s, r, l, o) {
  if (t === "innerHTML" || t === "textContent") {
    s && o(s, r, l), e[t] = n == null ? "" : n;
    return
  }
  if (t === "value" && e.tagName !== "PROGRESS" && !e.tagName.includes("-")) {
    e._value = n;
    const i = n == null ? "" : n;
    (e.value !== i || e.tagName === "OPTION") && (e.value = i), n == null && e.removeAttribute(t);
    return
  }
  if (n === "" || n == null) {
    const i = typeof e[t];
    if (i === "boolean") {
      e[t] = ur(n);
      return
    } else if (n == null && i === "string") {
      e[t] = "", e.removeAttribute(t);
      return
    } else if (i === "number") {
      try {
        e[t] = 0
      } catch {}
      e.removeAttribute(t);
      return
    }
  }
  try {
    e[t] = n
  } catch {}
}
let Wn = Date.now,
  Al = !1;
if (typeof window != "undefined") {
  Wn() > document.createEvent("Event").timeStamp && (Wn = () => performance.now());
  const e = navigator.userAgent.match(/firefox\/(\d+)/i);
  Al = !!(e && Number(e[1]) <= 53)
}
let Ws = 0;
const $a = Promise.resolve(),
  Ua = () => {
    Ws = 0
  },
  ja = () => Ws || ($a.then(Ua), Ws = Wn());

function tt(e, t, n, s) {
  e.addEventListener(t, n, s)
}

function Ha(e, t, n, s) {
  e.removeEventListener(t, n, s)
}

function Wa(e, t, n, s, r = null) {
  const l = e._vei || (e._vei = {}),
    o = l[t];
  if (s && o) o.value = s;
  else {
    const [i, a] = Va(t);
    if (s) {
      const u = l[t] = Ba(s, r);
      tt(e, i, u, a)
    } else o && (Ha(e, i, o, a), l[t] = void 0)
  }
}
const kl = /(?:Once|Passive|Capture)$/;

function Va(e) {
  let t;
  if (kl.test(e)) {
    t = {};
    let n;
    for (; n = e.match(kl);) e = e.slice(0, e.length - n[0].length), t[n[0].toLowerCase()] = !0
  }
  return [Ct(e.slice(2)), t]
}

function Ba(e, t) {
  const n = s => {
    const r = s.timeStamp || Wn();
    (Al || r >= n.attached - 1) && Ae(Ka(s, n.value), t, 5, [s])
  };
  return n.value = e, n.attached = ja(), n
}

function Ka(e, t) {
  if (D(t)) {
    const n = e.stopImmediatePropagation;
    return e.stopImmediatePropagation = () => {
      n.call(e), e._stopped = !0
    }, t.map(s => r => !r._stopped && s(r))
  } else return t
}
const Fl = /^on[a-z]/,
  za = (e, t, n, s, r = !1, l, o, i, a) => {
    t === "class" ? Ma(e, s, r) : t === "style" ? Ra(e, n, s) : un(t) ? es(t) || Wa(e, t, n, s, o) : (t[0] === "." ? (t = t.slice(1), !0) : t[0] === "^" ? (t = t.slice(1), !1) : Ya(e, t, s, r)) ? Da(e, t, s, l, o, i, a) : (t === "true-value" ? e._trueValue = s : t === "false-value" && (e._falseValue = s), Pa(e, t, s, r))
  };

function Ya(e, t, n, s) {
  return s ? !!(t === "innerHTML" || t === "textContent" || t in e && Fl.test(t) && U(n)) : t === "spellcheck" || t === "draggable" || t === "form" || t === "list" && e.tagName === "INPUT" || t === "type" && e.tagName === "TEXTAREA" || Fl.test(t) && he(n) ? !1 : t in e
}
const Ga = {
  name: String,
  type: String,
  css: {
    type: Boolean,
    default: !0
  },
  duration: [String, Number, Object],
  enterFromClass: String,
  enterActiveClass: String,
  enterToClass: String,
  appearFromClass: String,
  appearActiveClass: String,
  appearToClass: String,
  leaveFromClass: String,
  leaveActiveClass: String,
  leaveToClass: String
};
Fi.props;
const St = e => {
  const t = e.props["onUpdate:modelValue"];
  return D(t) ? n => gn(t, n) : t
};

function Xa(e) {
  e.target.composing = !0
}

function Ml(e) {
  const t = e.target;
  t.composing && (t.composing = !1, Ja(t, "input"))
}

function Ja(e, t) {
  const n = document.createEvent("HTMLEvents");
  n.initEvent(t, !0, !0), e.dispatchEvent(n)
}
const qa = {
    created(e, {
      modifiers: {
        lazy: t,
        trim: n,
        number: s
      }
    }, r) {
      e._assign = St(r);
      const l = s || r.props && r.props.type === "number";
      tt(e, t ? "change" : "input", o => {
        if (o.target.composing) return;
        let i = e.value;
        n ? i = i.trim() : l && (i = pn(i)), e._assign(i)
      }), n && tt(e, "change", () => {
        e.value = e.value.trim()
      }), t || (tt(e, "compositionstart", Xa), tt(e, "compositionend", Ml), tt(e, "change", Ml))
    },
    mounted(e, {
      value: t
    }) {
      e.value = t == null ? "" : t
    },
    beforeUpdate(e, {
      value: t,
      modifiers: {
        lazy: n,
        trim: s,
        number: r
      }
    }, l) {
      if (e._assign = St(l), e.composing || document.activeElement === e && (n || s && e.value.trim() === t || (r || e.type === "number") && pn(e.value) === t)) return;
      const o = t == null ? "" : t;
      e.value !== o && (e.value = o)
    }
  },
  Qa = {
    deep: !0,
    created(e, t, n) {
      e._assign = St(n), tt(e, "change", () => {
        const s = e._modelValue,
          r = en(e),
          l = e.checked,
          o = e._assign;
        if (D(s)) {
          const i = Zn(s, r),
            a = i !== -1;
          if (l && !a) o(s.concat(r));
          else if (!l && a) {
            const u = [...s];
            u.splice(i, 1), o(u)
          }
        } else if (It(s)) {
          const i = new Set(s);
          l ? i.add(r) : i.delete(r), o(i)
        } else o(Dl(e, l))
      })
    },
    mounted: Rl,
    beforeUpdate(e, t, n) {
      e._assign = St(n), Rl(e, t, n)
    }
  };

function Rl(e, {
  value: t,
  oldValue: n
}, s) {
  e._modelValue = t, D(t) ? e.checked = Zn(t, s.props.value) > -1 : It(t) ? e.checked = t.has(s.props.value) : t !== n && (e.checked = Wt(t, Dl(e, !0)))
}
const Sl = {
  deep: !0,
  created(e, {
    value: t,
    modifiers: {
      number: n
    }
  }, s) {
    const r = It(t);
    tt(e, "change", () => {
      const l = Array.prototype.filter.call(e.options, o => o.selected).map(o => n ? pn(en(o)) : en(o));
      e._assign(e.multiple ? r ? new Set(l) : l : l[0])
    }), e._assign = St(s)
  },
  mounted(e, {
    value: t
  }) {
    Pl(e, t)
  },
  beforeUpdate(e, t, n) {
    e._assign = St(n)
  },
  updated(e, {
    value: t
  }) {
    Pl(e, t)
  }
};

function Pl(e, t) {
  const n = e.multiple;
  if (!(n && !D(t) && !It(t))) {
    for (let s = 0, r = e.options.length; s < r; s++) {
      const l = e.options[s],
        o = en(l);
      if (n) D(t) ? l.selected = Zn(t, o) > -1 : l.selected = t.has(o);
      else if (Wt(en(l), t)) {
        e.selectedIndex !== s && (e.selectedIndex = s);
        return
      }
    }!n && e.selectedIndex !== -1 && (e.selectedIndex = -1)
  }
}

function en(e) {
  return "_value" in e ? e._value : e.value
}

function Dl(e, t) {
  const n = t ? "_trueValue" : "_falseValue";
  return n in e ? e[n] : t
}
const Za = be({
  patchProp: za
}, Fa);
let $l;

function ec() {
  return $l || ($l = ta(Za))
}
const wd = (...e) => {
  const t = ec().createApp(...e),
    {
      mount: n
    } = t;
  return t.mount = s => {
    const r = tc(s);
    if (!r) return;
    const l = t._component;
    !U(l) && !l.render && !l.template && (l.template = r.innerHTML), r.innerHTML = "";
    const o = n(r, !1, r instanceof SVGElement);
    return r instanceof Element && (r.removeAttribute("v-cloak"), r.setAttribute("data-v-app", "")), o
  }, t
};

function tc(e) {
  return he(e) ? document.querySelector(e) : e
}
var Vs = {
  isRTL: nc
};

function nc(e) {
  return ["ar", "fa", "iw", "yi", "ur", "pa"].indexOf(e) > -1
}
var nt = (e, t) => {
  const n = e.__vccOpts || e;
  for (const [s, r] of t) n[s] = r;
  return n
};
const sc = {
    props: {
      select: {
        type: Object,
        default: null
      }
    },
    emits: ["select"],
    data() {
      return {
        src: "",
        target: "",
        recents: {
          src: [],
          target: []
        }
      }
    },
    watch: {
      select(e) {
        !e || (this.src = e.src, this.target = e.target, this.loadRecents())
      }
    },
    methods: {
      onRecentSrc(e) {
        this.src = e, this.onSelect()
      },
      onRecentTarget(e) {
        this.target = e, this.onSelect()
      },
      swap() {
        if (this.src === "auto" || !this.select.srcs[this.target] || !this.select.targets[this.src]) return;
        const e = this.target;
        this.target = this.src, this.src = e, this.onSelect()
      },
      onSelect() {
        const e = JSON.parse(JSON.stringify(this.select));
        e.src = this.src, e.target = this.target, this.$emit("select", e), this.saveRecents(this.src, this.target)
      },
      loadRecents() {
        const e = JSON.parse(localStorage.getItem("recents"));
        !e || (this.recents = e)
      },
      saveRecents(e, t) {
        this.recents.src.includes(e) || this.recents.src.push(e), this.recents.target.includes(t) || this.recents.target.push(t), this.recents.src.length > 3 && this.recents.src.shift(), this.recents.target.length > 3 && this.recents.target.shift(), localStorage.setItem("recents", JSON.stringify(this.recents))
      }
    }
  },
  rc = {
    key: 0,
    class: "flex flex-row"
  },
  lc = ["value"],
  oc = {
    key: 0,
    xmlns: "http://www.w3.org/2000/svg",
    class: "h-6 w-6",
    fill: "none",
    viewBox: "0 0 24 24",
    stroke: "currentColor"
  },
  ic = A("path", {
    "stroke-linecap": "round",
    "stroke-linejoin": "round",
    "stroke-width": "2",
    d: "M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4"
  }, null, -1),
  ac = [ic],
  cc = {
    key: 1,
    xmlns: "http://www.w3.org/2000/svg",
    class: "h-6 w-6",
    fill: "none",
    viewBox: "0 0 24 24",
    stroke: "currentColor"
  },
  uc = A("path", {
    "stroke-linecap": "round",
    "stroke-linejoin": "round",
    "stroke-width": "2",
    d: "M13 7l5 5m0 0l-5 5m5-5H6"
  }, null, -1),
  fc = [uc],
  dc = ["value"],
  hc = {
    key: 1,
    class: "flex flex-row"
  },
  mc = {
    class: "grow"
  },
  gc = ["onClick"],
  _c = {
    class: "grow"
  },
  pc = ["onClick"];

function bc(e, t, n, s, r, l) {
  return L(), k(Z, null, [n.select ? (L(), k("div", rc, [kn(A("select", {
    "onUpdate:modelValue": t[0] || (t[0] = o => r.src = o),
    class: "select select-bordered grow",
    onChange: t[1] || (t[1] = (...o) => l.onSelect && l.onSelect(...o))
  }, [(L(!0), k(Z, null, we(n.select.srcs, (o, i) => (L(), k("option", {
    value: i,
    key: i
  }, oe(o), 9, lc))), 128))], 544), [
    [Sl, r.src]
  ]), A("button", {
    class: "grow-0 ml-2 mr-2",
    onClick: t[2] || (t[2] = (...o) => l.swap && l.swap(...o))
  }, [r.src != "auto" ? (L(), k("svg", oc, ac)) : ee("", !0), r.src == "auto" ? (L(), k("svg", cc, fc)) : ee("", !0)]), kn(A("select", {
    "onUpdate:modelValue": t[3] || (t[3] = o => r.target = o),
    class: "select select-bordered grow",
    onChange: t[4] || (t[4] = (...o) => l.onSelect && l.onSelect(...o))
  }, [(L(!0), k(Z, null, we(n.select.targets, (o, i) => (L(), k("option", {
    value: i,
    key: i
  }, oe(o), 9, dc))), 128))], 544), [
    [Sl, r.target]
  ])])) : ee("", !0), n.select && r.src && r.target && r.recents ? (L(), k("div", hc, [A("div", mc, [(L(!0), k(Z, null, we(r.recents.src, o => (L(), k("span", {
    key: o,
    onClick: i => l.onRecentSrc(o),
    class: "badge badge-sm ml-1 badge-outline"
  }, oe(n.select.srcs[o]), 9, gc))), 128))]), A("div", _c, [(L(!0), k(Z, null, we(r.recents.target, o => (L(), k("span", {
    key: o,
    onClick: i => l.onRecentTarget(o),
    class: "badge badge-sm ml-1 float-right mt-1"
  }, oe(n.select.targets[o]), 9, pc))), 128))])])) : ee("", !0)], 64)
}
var yc = nt(sc, [
    ["render", bc]
  ]),
  Vn = {
    INPUT_MAX_LENGTH: 5e3,
    INPUT_DELAY: 1e3
  },
  bt = {
    init: Tc,
    autoResize: vc
  };
const Bn = 100,
  Ul = 600,
  Ec = 10;

function Tc(e, t) {
  t && (e.maxlength = t), e.spellcheck = !1, tn(e, Bn)
}

function vc(e) {
  if (e.value == "") {
    tn(e, Bn);
    return
  }
  if (e.scrollHeight < Bn) {
    tn(e, Bn);
    return
  }
  if (e.scrollHeight > Ul) {
    tn(e, Ul);
    return
  }
  e.style.height.replace("px", "") > e.scrollHeight || tn(e, e.scrollHeight + Ec)
}

function tn(e, t) {
  e.style.height = `${t}px`
}
const jl = "auto_translate",
  wc = {
    props: {
      data: {
        type: Object,
        default: null
      },
      tts: {
        type: Object,
        default: null
      },
      replace: {
        type: String,
        default: ""
      }
    },
    data() {
      return {
        input: "",
        INPUT_MAX_LENGTH: Vn.INPUT_MAX_LENGTH,
        input_timeout: null,
        player: new Audio,
        playing: !1,
        ttsIndex: 0,
        auto_translate: !0,
        firstTime: !0
      }
    },
    computed: {
      rtl() {
        return this.data ? Vs.isRTL(this.data.src) : !1
      }
    },
    watch: {
      replace(e) {
        this.input = e, (this.firstTime || !this.auto_translate) && setTimeout(() => {
          this.$refs.input.select()
        }, 100), this.firstTime = !1
      },
      tts() {
        this.ttsIndex = 0
      },
      auto_translate(e) {
        e && this.translate(), localStorage.setItem(jl, e)
      }
    },
    mounted() {
      bt.init(this.$refs.input, Vn.INPUT_MAX_LENGTH), this.player.addEventListener("ended", () => {
        if (this.ttsIndex++, this.ttsIndex >= this.tts.src.length) {
          this.stop();
          return
        }
        this.play()
      }), this.$refs.input.addEventListener("input", () => {
        bt.autoResize(this.$refs.input), !!this.auto_translate && (clearTimeout(this.input_timeout), this.input_timeout = setTimeout(this.translate, Vn.INPUT_DELAY))
      }), this.$refs.input.addEventListener("keyup", e => {
        this.auto_translate || e && e.keyCode === 13 && this.translate()
      })
    },
    created() {
      localStorage.getItem(jl) === "false" && (this.auto_translate = !1)
    },
    methods: {
      play() {
        !this.tts.src || (this.player.src = this.tts.src[this.ttsIndex], this.playing = !0, this.player.play().catch(() => {
          this.playing = !1
        }))
      },
      stop() {
        this.playing = !1, this.ttsIndex = 0, this.player.pause()
      },
      clear() {
        this.$emit("clear"), this.input = "", bt.init(this.$refs.input, Vn.INPUT_MAX_LENGTH), this.$refs.input.focus()
      },
      translate() {
        if (!this.input) {
          this.clear();
          return
        }
        this.$emit("translate", this.input)
      }
    }
  },
  Ic = {
    class: "relative indicator w-full"
  },
  Cc = {
    key: 0,
    class: "absolute top-0 left-0 w-4/5 ml-2 text-sm truncate"
  },
  Oc = A("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    class: "h-4 w-4 inline",
    fill: "none",
    viewBox: "0 0 24 24",
    stroke: "currentColor"
  }, [A("path", {
    "stroke-linecap": "round",
    "stroke-linejoin": "round",
    "stroke-width": "2",
    d: "M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z"
  })], -1),
  xc = [Oc],
  Nc = A("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    class: "h-4 w-4 inline",
    fill: "none",
    viewBox: "0 0 24 24",
    stroke: "currentColor"
  }, [A("path", {
    "stroke-linecap": "round",
    "stroke-linejoin": "round",
    "stroke-width": "2",
    d: "M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
  }), A("path", {
    "stroke-linecap": "round",
    "stroke-linejoin": "round",
    "stroke-width": "2",
    d: "M9 10a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 01-1-1v-4z"
  })], -1),
  Lc = [Nc],
  Ac = {
    key: 2,
    class: "ml-1"
  },
  kc = {
    key: 0
  },
  Fc = A("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    class: "h-5 w-5",
    fill: "none",
    viewBox: "0 0 24 24",
    stroke: "currentColor"
  }, [A("path", {
    "stroke-linecap": "round",
    "stroke-linejoin": "round",
    "stroke-width": "2",
    d: "M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"
  })], -1),
  Mc = [Fc],
  Rc = {
    class: "cursor-pointer label justify-start"
  },
  Sc = A("span", {
    class: "ml-1 label-text text-xs"
  }, "Auto translate", -1);

function Pc(e, t, n, s, r, l) {
  return L(), k("div", null, [A("div", Ic, [n.data ? (L(), k("div", Cc, [r.playing ? ee("", !0) : (L(), k("span", {
    key: 0,
    class: "pointer",
    onClick: t[0] || (t[0] = (...o) => l.play && l.play(...o))
  }, xc)), r.playing ? (L(), k("span", {
    key: 1,
    class: "pointer",
    onClick: t[1] || (t[1] = (...o) => l.stop && l.stop(...o))
  }, Lc)) : ee("", !0), n.data._Src ? (L(), k("span", Ac, oe(n.data._Src), 1)) : ee("", !0), (L(!0), k(Z, null, we(n.data.sentences, (o, i) => (L(), k("span", {
    key: `${o.src_translit}-${i}`,
    class: "italic"
  }, [o.src_translit ? (L(), k("span", kc, " \u2015 " + oe(o.src_translit), 1)) : ee("", !0)]))), 128))])) : ee("", !0), r.input != "" ? (L(), k("div", {
    key: 1,
    onClick: t[2] || (t[2] = (...o) => l.clear && l.clear(...o)),
    class: "indicator-item m-3"
  }, Mc)) : ee("", !0), kn(A("textarea", {
    id: "input",
    ref: "input",
    "onUpdate:modelValue": t[3] || (t[3] = o => r.input = o),
    class: "text-lg textarea textarea-bordered w-full pt-5",
    style: ot({
      "text-align": l.rtl ? "right" : "left"
    }),
    autofocus: ""
  }, null, 4), [
    [qa, r.input, void 0, {
      trim: !0
    }]
  ])]), A("label", Rc, [kn(A("input", {
    "onUpdate:modelValue": t[4] || (t[4] = o => r.auto_translate = o),
    type: "checkbox",
    class: "toggle toggle-xs"
  }, null, 512), [
    [Qa, r.auto_translate]
  ]), Sc])])
}
var Dc = nt(wc, [
  ["render", Pc]
]);
const $c = {
    props: {
      data: {
        type: Object,
        default: null
      },
      tts: {
        type: Object,
        default: null
      }
    },
    data() {
      return {
        player: new Audio,
        playing: !1,
        copied: !1,
        ttsIndex: 0
      }
    },
    computed: {
      rtl() {
        return this.data ? Vs.isRTL(this.data.target) : !1
      }
    },
    watch: {
      data(e) {
        if (!e) {
          this.$refs.input.value = "", bt.init(this.$refs.input);
          return
        }
        this.$refs.input.value = e.sentences.map(t => t.trans).join(""), bt.autoResize(this.$refs.input)
      },
      tts() {
        this.ttsIndex = 0
      }
    },
    mounted() {
      bt.init(this.$refs.input), bt.autoResize(this.$refs.input), this.player.addEventListener("ended", () => {
        if (this.ttsIndex++, this.ttsIndex >= this.tts.target.length) {
          this.stop();
          return
        }
        this.play()
      })
    },
    methods: {
      play() {
        !this.tts.target || (this.player.src = this.tts.target[this.ttsIndex], this.playing = !0, this.player.play().catch(() => {
          this.playing = !1
        }))
      },
      stop() {
        this.playing = !1, this.ttsIndex = 0, this.player.pause()
      },
      copy() {
        const e = this.$refs.input.value;
        !e || (navigator.clipboard.writeText(e), this.copied = !0, setTimeout(() => {
          this.copied = !1
        }, 500))
      }
    }
  },
  Uc = {
    class: "relative indicator w-full"
  },
  jc = {
    key: 0,
    class: "absolute top-0 left-0 w-2/3 ml-2 text-sm truncate"
  },
  Hc = A("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    class: "h-4 w-4 inline",
    fill: "none",
    viewBox: "0 0 24 24",
    stroke: "currentColor"
  }, [A("path", {
    "stroke-linecap": "round",
    "stroke-linejoin": "round",
    "stroke-width": "2",
    d: "M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z"
  })], -1),
  Wc = [Hc],
  Vc = A("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    class: "h-4 w-4 inline",
    fill: "none",
    viewBox: "0 0 24 24",
    stroke: "currentColor"
  }, [A("path", {
    "stroke-linecap": "round",
    "stroke-linejoin": "round",
    "stroke-width": "2",
    d: "M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
  }), A("path", {
    "stroke-linecap": "round",
    "stroke-linejoin": "round",
    "stroke-width": "2",
    d: "M9 10a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1h-4a1 1 0 01-1-1v-4z"
  })], -1),
  Bc = [Vc],
  Kc = {
    key: 2,
    class: "ml-1"
  },
  zc = {
    key: 0,
    xmlns: "http://www.w3.org/2000/svg",
    class: "h-5 w-5",
    fill: "none",
    viewBox: "0 0 24 24",
    stroke: "currentColor"
  },
  Yc = A("path", {
    "stroke-linecap": "round",
    "stroke-linejoin": "round",
    "stroke-width": "2",
    d: "M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3"
  }, null, -1),
  Gc = [Yc],
  Xc = {
    key: 1,
    xmlns: "http://www.w3.org/2000/svg",
    class: "h-5 w-5",
    viewBox: "0 0 20 20",
    fill: "currentColor"
  },
  Jc = A("path", {
    d: "M8 2a1 1 0 000 2h2a1 1 0 100-2H8z"
  }, null, -1),
  qc = A("path", {
    d: "M3 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v6h-4.586l1.293-1.293a1 1 0 00-1.414-1.414l-3 3a1 1 0 000 1.414l3 3a1 1 0 001.414-1.414L10.414 13H15v3a2 2 0 01-2 2H5a2 2 0 01-2-2V5zM15 11h2a1 1 0 110 2h-2v-2z"
  }, null, -1),
  Qc = [Jc, qc],
  Zc = {
    key: 0,
    class: "label justify-end"
  },
  eu = A("span", {
    class: "text-xs"
  }, "Powered by Google Translate.", -1),
  tu = [eu];

function nu(e, t, n, s, r, l) {
  return L(), k(Z, null, [A("div", Uc, [n.data ? (L(), k("div", jc, [r.playing ? ee("", !0) : (L(), k("span", {
    key: 0,
    class: "pointer",
    onClick: t[0] || (t[0] = (...o) => l.play && l.play(...o))
  }, Wc)), r.playing ? (L(), k("span", {
    key: 1,
    class: "pointer",
    onClick: t[1] || (t[1] = (...o) => l.stop && l.stop(...o))
  }, Bc)) : ee("", !0), n.data._Target ? (L(), k("span", Kc, oe(n.data._Target), 1)) : ee("", !0)])) : ee("", !0), n.data ? (L(), k("div", {
    key: 1,
    onClick: t[2] || (t[2] = (...o) => l.copy && l.copy(...o)),
    class: "indicator-item m-3"
  }, [r.copied ? ee("", !0) : (L(), k("svg", zc, Gc)), r.copied ? (L(), k("svg", Xc, Qc)) : ee("", !0)])) : ee("", !0), A("textarea", {
    ref: "input",
    class: "text-lg textarea textarea-bordered w-full pt-5",
    style: ot({
      "text-align": l.rtl ? "right" : "left"
    }),
    readonly: "",
    spellcheck: "false"
  }, null, 4)]), n.data ? (L(), k("p", Zc, tu)) : ee("", !0)], 64)
}
var su = nt($c, [
  ["render", nu]
]);
const ru = {
    props: {
      data: {
        type: Object,
        default: null
      }
    },
    data() {
      return {
        name: "Definitions"
      }
    }
  },
  lu = {
    key: 0
  },
  ou = {
    class: "card-body p-4"
  },
  iu = {
    class: "card-title font-bold"
  },
  au = {
    class: "list-decimal"
  },
  cu = {
    class: "capitalize font-bold"
  },
  uu = A("br", null, null, -1),
  fu = {
    key: 0,
    class: "italic"
  };

function du(e, t, n, s, r, l) {
  return n.data.definitions ? (L(), k("div", lu, [A("div", ou, [A("h2", iu, oe(r.name), 1), A("ul", null, [(L(!0), k(Z, null, we(n.data.definitions, (o, i) => (L(), k("li", {
    key: `${o.pos}-${i}`,
    class: "mb-2"
  }, [A("ul", au, [A("h5", cu, oe(o.pos), 1), (L(!0), k(Z, null, we(o.entry, (a, u) => (L(), k("li", {
    key: `${a.definition_id}-${u}`,
    class: "ml-5 mb-2"
  }, [A("span", null, oe(a.gloss), 1), uu, a.example ? (L(), k("small", fu, '"' + oe(a.example) + '"', 1)) : ee("", !0)]))), 128))])]))), 128))])])])) : ee("", !0)
}
var hu = nt(ru, [
  ["render", du]
]);
const mu = {
    props: {
      data: {
        type: Object,
        default: null
      }
    },
    data() {
      return {
        name: "Translations"
      }
    },
    methods: {
      translate(e) {
        this.$emit("translate", e)
      }
    }
  },
  gu = {
    key: 0
  },
  _u = {
    class: "card-body p-4"
  },
  pu = {
    class: "card-title"
  },
  bu = {
    class: "capitalize font-bold"
  },
  yu = ["onClick"],
  Eu = {
    key: 0,
    class: "italic"
  };

function Tu(e, t, n, s, r, l) {
  return n.data.dict ? (L(), k("div", gu, [A("div", _u, [A("h2", pu, oe(r.name), 1), A("ul", null, [(L(!0), k(Z, null, we(n.data.dict, (o, i) => (L(), k("li", {
    key: `${o.pos}-${i}`,
    class: "mb-2"
  }, [A("h5", bu, oe(o.pos), 1), (L(!0), k(Z, null, we(o.entry, (a, u) => (L(), k("div", {
    key: `${a.word}-${u}`
  }, [A("span", {
    class: "badge bg-neutral",
    onClick: h => l.translate(a.word)
  }, oe(a.word), 9, yu), a.reverse_translation ? (L(), k("small", Eu, " \u2015 " + oe(a.reverse_translation.join(", ")), 1)) : ee("", !0)]))), 128))]))), 128))])])])) : ee("", !0)
}
var vu = nt(mu, [
  ["render", Tu]
]);
const wu = {
    props: {
      data: {
        type: Object,
        default: null
      }
    },
    data() {
      return {
        name: "Examples"
      }
    }
  },
  Iu = {
    key: 0
  },
  Cu = {
    class: "card-body p-4"
  },
  Ou = {
    class: "card-title font-bold"
  },
  xu = {
    class: "list-disc"
  },
  Nu = ["innerHTML"];

function Lu(e, t, n, s, r, l) {
  return n.data.examples && n.data.examples.example ? (L(), k("div", Iu, [A("div", Cu, [A("h2", Ou, oe(r.name), 1), A("ul", xu, [(L(!0), k(Z, null, we(n.data.examples.example, (o, i) => (L(), k("li", {
    key: `${o.definition_id}-${i}`,
    class: "ml-4 mb-2",
    innerHTML: o.text
  }, null, 8, Nu))), 128))])])])) : ee("", !0)
}
var Au = nt(wu, [
  ["render", Lu]
]);
const ku = {
    props: {
      data: {
        type: Object,
        default: null
      }
    },
    data() {
      return {
        name: "Synonyms"
      }
    }
  },
  Fu = {
    key: 0
  },
  Mu = {
    class: "card-body p-4"
  },
  Ru = {
    class: "card-title font-bold"
  },
  Su = {
    class: "capitalize font-bold"
  },
  Pu = ["onClick"],
  Du = A("span", null, null, -1);

function $u(e, t, n, s, r, l) {
  return n.data.synsets ? (L(), k("div", Fu, [A("div", Mu, [A("h2", Ru, oe(r.name), 1), A("ul", null, [(L(!0), k(Z, null, we(n.data.synsets, (o, i) => (L(), k("li", {
    key: `${o.pos}-${i}`,
    class: "mb-2"
  }, [A("h5", Su, oe(o.pos), 1), (L(!0), k(Z, null, we(o.entry, (a, u) => (L(), k("div", {
    key: `${a.definition_id}-${u}`
  }, [(L(!0), k(Z, null, we(a.synonym, (h, p) => (L(), k("span", {
    key: `${h}-${p}`
  }, [A("span", {
    class: "badge bg-neutral mr-1",
    onClick: _ => e.$emit("translate", h)
  }, oe(h), 9, Pu), Du]))), 128))]))), 128))]))), 128))])])])) : ee("", !0)
}
var Uu = nt(ku, [
  ["render", $u]
]);
const ju = {
    props: {
      data: {
        type: Object,
        default: null
      }
    },
    data() {
      return {
        name: "See also"
      }
    }
  },
  Hu = {
    key: 0
  },
  Wu = {
    class: "card-body p-4"
  },
  Vu = {
    class: "card-title font-bold"
  },
  Bu = ["onClick"],
  Ku = A("span", null, null, -1);

function zu(e, t, n, s, r, l) {
  return n.data.related_words && n.data.related_words.word ? (L(), k("div", Hu, [A("div", Wu, [A("h2", Vu, oe(r.name), 1), (L(!0), k(Z, null, we(n.data.related_words.word, (o, i) => (L(), k("span", {
    key: `${o}-${i}`
  }, [A("span", {
    class: "badge bg-neutral",
    onClick: a => e.$emit("translate", o)
  }, oe(o), 9, Bu), Ku]))), 128))])])) : ee("", !0)
}
var Yu = nt(ju, [
  ["render", zu]
]);
const Gu = {
    class: "p-2"
  },
  Xu = {
    class: "mt-2 grid grid-cols-1 md:grid-cols-2 gap-3"
  },
  Ju = {
    class: "w-full"
  },
  qu = {
    class: "w-full"
  },
  Qu = {
    name: "Popup",
    props: {
      export_data: {
        type: Object,
        default: null
      },
      export_select: {
        type: Object,
        default: null
      },
      export_tts: {
        type: Object,
        default: null
      }
    },
    data() {
      return {
        data: null,
        select: null,
        tts: null,
        replace: ""
      }
    },
    computed: {
      rtl() {
        return this.data ? Vs.isRTL(this.data.target) : !1
      }
    },
    watch: {
      export_data(e) {
        this.data = e, e.text && this.replace != e.text && (this.replace = e.text)
      },
      export_select(e) {
        this.select = e
      },
      export_tts(e) {
        this.tts = e
      }
    },
    methods: {
      clear() {
        this.data = null, this.$emit("clear")
      },
      translateReplace(e) {
        return this.translate(e, !0)
      },
      translateSwap(e) {
        return this.translate(e, !0, !0)
      },
      translate(e, t, n) {
        if (n) {
          if (!this.data.src || this.data.src === "auto" || !this.data.target) return;
          const s = JSON.parse(JSON.stringify(this.select));
          s.src = this.data.target, s.target = this.data.src, this.$emit("srctarget", s)
        }
        window.scrollTo(0, 0), this.clear(), t && (this.replace = e), this.$emit("translate", e)
      },
      onSelect(e) {
        if (this.$emit("srctarget", e), this.data) {
          const t = this.data.sentences.map(n => n.orig).join("");
          this.$emit("translate", t)
        }
      }
    }
  },
  Id = Object.assign(Qu, {
    setup(e) {
      return (t, n) => (L(), k("div", Gu, [re(yc, {
        select: t.select,
        onSelect: t.onSelect
      }, null, 8, ["select", "onSelect"]), A("div", Xu, [A("div", Ju, [re(Dc, {
        data: t.data,
        tts: t.tts,
        replace: t.replace,
        onTranslate: t.translate,
        onClear: t.clear
      }, null, 8, ["data", "tts", "replace", "onTranslate", "onClear"])]), A("div", qu, [re(su, {
        data: t.data,
        tts: t.tts
      }, null, 8, ["data", "tts"])])]), t.data ? (L(), k("div", {
        key: 0,
        class: "mt-3 grid grid-cols-1 md:grid-cols-3 gap-3",
        style: ot({
          "text-align": t.rtl ? "right" : "left"
        })
      }, [re(hu, {
        class: "card border",
        data: t.data
      }, null, 8, ["data"]), re(vu, {
        class: "card border",
        data: t.data,
        onTranslate: t.translateSwap
      }, null, 8, ["data", "onTranslate"]), re(Uu, {
        class: "card border",
        data: t.data,
        onTranslate: t.translateReplace
      }, null, 8, ["data", "onTranslate"]), re(Yu, {
        class: "card border",
        data: t.data,
        onTranslate: t.translateReplace
      }, null, 8, ["data", "onTranslate"])], 4)) : ee("", !0), t.data ? (L(), k("div", {
        key: 1,
        class: "mt-5 grid grid-cols-1 gap-6",
        style: ot({
          "text-align": t.rtl ? "right" : "left"
        })
      }, [re(Au, {
        class: "card border",
        data: t.data
      }, null, 8, ["data"])], 4)) : ee("", !0)]))
    }
  });
var Bs = {
  makeURL: Zu,
  qs: Hl
};

function Zu(e = "", t = {}) {
  return `${e}?${Hl(t)}`
}

function Hl(e = {}) {
  const t = {},
    n = {};
  let s = "";
  for (const r in e) {
    const l = e[r];
    if (!Array.isArray(l)) {
      t[r] = l;
      continue
    }
    n[r] = l
  }
  s = new URLSearchParams(t).toString();
  for (const r in n) {
    s += "&";
    const l = e[r],
      o = [];
    for (const i of l) o.push(new URLSearchParams({
      [r]: i
    }).toString());
    s += o.join("&")
  }
  return s
}
var ef = {
  getLanguages: nf,
  translate: sf,
  tts: rf
};
const Wl = "en",
  nn = "UTF-8",
  Ks = "GoogleTranslate",
  Vl = 5e3,
  tf = 200;

function nf(e = "en") {
  const t = "https://translate.google.com/translate_a/l",
    n = {
      hl: e,
      client: "it",
      oe: nn,
      ie: nn
    };
  return {
    url: Bs.makeURL(t, n),
    method: "GET",
    headers: {
      "User-Agent": Ks
    }
  }
}

function sf(e = Wl, t, n, s, r = !1) {
  if (t.length > Vl) throw new Error(`Maximum text length exceeded: ${Vl}`);
  const l = "https://translate.google.com/translate_a/single",
    o = {
      q: t,
      sl: n,
      tl: s,
      hl: e,
      client: "it",
      dt: ["t", "rmt", "bd", "rms", "qca", "ss", "md", "ld", "ex", "rw"],
      otf: "2",
      dj: "1",
      ie: nn,
      oe: nn
    };
  return r && (o.dt = "t"), {
    url: Bs.makeURL(l, o),
    method: "GET",
    headers: {
      "User-Agent": Ks
    }
  }
}

function rf(e = Wl, t, n = "input", s) {
  t = t.substring(0, tf), n !== "input" && n !== "target" && (n = "input");
  const r = "https://translate.google.com/translate_tts",
    l = {
      q: t,
      tl: s,
      hl: e,
      client: "it",
      total: "1",
      idx: "0",
      textlen: t.length,
      prev: n,
      ie: nn
    };
  return {
    url: Bs.makeURL(r, l),
    method: "GET",
    headers: {
      "User-Agent": Ks,
      Connection: "keep-alive"
    }
  }
}
var Cd = {
  google: ef
};
/*!
 * shared v9.2.0-beta.26
 * (c) 2021 kazuya kawaguchi
 * Released under the MIT License.
 */
const lf = typeof Symbol == "function" && typeof Symbol.toStringTag == "symbol",
  st = e => lf ? Symbol(e) : e,
  of = (e, t, n) => af({
    l: e,
    k: t,
    s: n
  }),
  af = e => JSON.stringify(e).replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029").replace(/\u0027/g, "\\u0027"),
  me = e => typeof e == "number" && isFinite(e),
  cf = e => Gs(e) === "[object Date]",
  Kn = e => Gs(e) === "[object RegExp]",
  zn = e => V(e) && Object.keys(e).length === 0;

function uf(e, t) {
  typeof console != "undefined" && (console.warn("[intlify] " + e), t && console.warn(t.stack))
}
const Te = Object.assign;
let Bl;
const zs = () => Bl || (Bl = typeof globalThis != "undefined" ? globalThis : typeof self != "undefined" ? self : typeof window != "undefined" ? window : typeof global != "undefined" ? global : {});

function Kl(e) {
  return e.replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;")
}
const ff = Object.prototype.hasOwnProperty;

function Ys(e, t) {
  return ff.call(e, t)
}
const de = Array.isArray,
  ge = e => typeof e == "function",
  M = e => typeof e == "string",
  ce = e => typeof e == "boolean",
  ae = e => e !== null && typeof e == "object",
  zl = Object.prototype.toString,
  Gs = e => zl.call(e),
  V = e => Gs(e) === "[object Object]",
  df = e => e == null ? "" : de(e) || V(e) && e.toString === zl ? JSON.stringify(e, null, 2) : String(e);
/*!
 * message-compiler v9.2.0-beta.26
 * (c) 2021 kazuya kawaguchi
 * Released under the MIT License.
 */
const Yl = {
  EXPECTED_TOKEN: 1,
  INVALID_TOKEN_IN_PLACEHOLDER: 2,
  UNTERMINATED_SINGLE_QUOTE_IN_PLACEHOLDER: 3,
  UNKNOWN_ESCAPE_SEQUENCE: 4,
  INVALID_UNICODE_ESCAPE_SEQUENCE: 5,
  UNBALANCED_CLOSING_BRACE: 6,
  UNTERMINATED_CLOSING_BRACE: 7,
  EMPTY_PLACEHOLDER: 8,
  NOT_ALLOW_NEST_PLACEHOLDER: 9,
  INVALID_LINKED_FORMAT: 10,
  MUST_HAVE_MESSAGES_IN_PLURAL: 11,
  UNEXPECTED_EMPTY_LINKED_MODIFIER: 12,
  UNEXPECTED_EMPTY_LINKED_KEY: 13,
  UNEXPECTED_LEXICAL_ANALYSIS: 14,
  __EXTEND_POINT__: 15
};

function Gl(e, t, n = {}) {
  const {
    domain: s,
    messages: r,
    args: l
  } = n, o = e, i = new SyntaxError(String(o));
  return i.code = e, t && (i.location = t), i.domain = s, i
}
/*!
 * devtools-if v9.2.0-beta.26
 * (c) 2021 kazuya kawaguchi
 * Released under the MIT License.
 */
const Xl = {
  I18nInit: "i18n:init",
  FunctionTranslate: "function:translate"
};
/*!
 * core-base v9.2.0-beta.26
 * (c) 2021 kazuya kawaguchi
 * Released under the MIT License.
 */
const rt = [];
rt[0] = {
  w: [0],
  i: [3, 0],
  ["["]: [4],
  o: [7]
};
rt[1] = {
  w: [1],
  ["."]: [2],
  ["["]: [4],
  o: [7]
};
rt[2] = {
  w: [2],
  i: [3, 0],
  ["0"]: [3, 0]
};
rt[3] = {
  i: [3, 0],
  ["0"]: [3, 0],
  w: [1, 1],
  ["."]: [2, 1],
  ["["]: [4, 1],
  o: [7, 1]
};
rt[4] = {
  ["'"]: [5, 0],
  ['"']: [6, 0],
  ["["]: [4, 2],
  ["]"]: [1, 3],
  o: 8,
  l: [4, 0]
};
rt[5] = {
  ["'"]: [4, 0],
  o: 8,
  l: [5, 0]
};
rt[6] = {
  ['"']: [4, 0],
  o: 8,
  l: [6, 0]
};
const hf = /^\s?(?:true|false|-?[\d.]+|'[^']*'|"[^"]*")\s?$/;

function mf(e) {
  return hf.test(e)
}

function gf(e) {
  const t = e.charCodeAt(0),
    n = e.charCodeAt(e.length - 1);
  return t === n && (t === 34 || t === 39) ? e.slice(1, -1) : e
}

function _f(e) {
  if (e == null) return "o";
  switch (e.charCodeAt(0)) {
    case 91:
    case 93:
    case 46:
    case 34:
    case 39:
      return e;
    case 95:
    case 36:
    case 45:
      return "i";
    case 9:
    case 10:
    case 13:
    case 160:
    case 65279:
    case 8232:
    case 8233:
      return "w"
  }
  return "i"
}

function pf(e) {
  const t = e.trim();
  return e.charAt(0) === "0" && isNaN(parseInt(e)) ? !1 : mf(t) ? gf(t) : "*" + t
}

function bf(e) {
  const t = [];
  let n = -1,
    s = 0,
    r = 0,
    l, o, i, a, u, h, p;
  const _ = [];
  _[0] = () => {
    o === void 0 ? o = i : o += i
  }, _[1] = () => {
    o !== void 0 && (t.push(o), o = void 0)
  }, _[2] = () => {
    _[0](), r++
  }, _[3] = () => {
    if (r > 0) r--, s = 4, _[0]();
    else {
      if (r = 0, o === void 0 || (o = pf(o), o === !1)) return !1;
      _[1]()
    }
  };

  function w() {
    const S = e[n + 1];
    if (s === 5 && S === "'" || s === 6 && S === '"') return n++, i = "\\" + S, _[0](), !0
  }
  for (; s !== null;)
    if (n++, l = e[n], !(l === "\\" && w())) {
      if (a = _f(l), p = rt[s], u = p[a] || p.l || 8, u === 8 || (s = u[0], u[1] !== void 0 && (h = _[u[1]], h && (i = l, h() === !1)))) return;
      if (s === 7) return t
    }
}
const Jl = new Map;

function yf(e, t) {
  return ae(e) ? e[t] : null
}

function Ef(e, t) {
  if (!ae(e)) return null;
  let n = Jl.get(t);
  if (n || (n = bf(t), n && Jl.set(t, n)), !n) return null;
  const s = n.length;
  let r = e,
    l = 0;
  for (; l < s;) {
    const o = r[n[l]];
    if (o === void 0) return null;
    r = o, l++
  }
  return r
}
const Tf = e => e,
  vf = e => "",
  wf = "text",
  If = e => e.length === 0 ? "" : e.join(""),
  Cf = df;

function ql(e, t) {
  return e = Math.abs(e), t === 2 ? e ? e > 1 ? 1 : 0 : 1 : e ? Math.min(e, 2) : 0
}

function Of(e) {
  const t = me(e.pluralIndex) ? e.pluralIndex : -1;
  return e.named && (me(e.named.count) || me(e.named.n)) ? me(e.named.count) ? e.named.count : me(e.named.n) ? e.named.n : t : t
}

function xf(e, t) {
  t.count || (t.count = e), t.n || (t.n = e)
}

function Nf(e = {}) {
  const t = e.locale,
    n = Of(e),
    s = ae(e.pluralRules) && M(t) && ge(e.pluralRules[t]) ? e.pluralRules[t] : ql,
    r = ae(e.pluralRules) && M(t) && ge(e.pluralRules[t]) ? ql : void 0,
    l = I => I[s(n, I.length, r)],
    o = e.list || [],
    i = I => o[I],
    a = e.named || {};
  me(e.pluralIndex) && xf(n, a);
  const u = I => a[I];

  function h(I) {
    const F = ge(e.messages) ? e.messages(I) : ae(e.messages) ? e.messages[I] : !1;
    return F || (e.parent ? e.parent.message(I) : vf)
  }
  const p = I => e.modifiers ? e.modifiers[I] : Tf,
    _ = V(e.processor) && ge(e.processor.normalize) ? e.processor.normalize : If,
    w = V(e.processor) && ge(e.processor.interpolate) ? e.processor.interpolate : Cf,
    S = V(e.processor) && M(e.processor.type) ? e.processor.type : wf,
    P = {
      list: i,
      named: u,
      plural: l,
      linked: (I, F) => {
        const H = h(I)(P);
        return M(F) ? p(F)(H) : H
      },
      message: h,
      type: S,
      interpolate: w,
      normalize: _
    };
  return P
}
let sn = null;

function Lf(e) {
  sn = e
}

function Af(e, t, n) {
  sn && sn.emit(Xl.I18nInit, {
    timestamp: Date.now(),
    i18n: e,
    version: t,
    meta: n
  })
}
const kf = Ff(Xl.FunctionTranslate);

function Ff(e) {
  return t => sn && sn.emit(e, t)
}
const Mf = {
  NOT_FOUND_KEY: 1,
  FALLBACK_TO_TRANSLATE: 2,
  CANNOT_FORMAT_NUMBER: 3,
  FALLBACK_TO_NUMBER_FORMAT: 4,
  CANNOT_FORMAT_DATE: 5,
  FALLBACK_TO_DATE_FORMAT: 6,
  __EXTEND_POINT__: 7
};

function Rf(e, t, n) {
  return [...new Set([n, ...de(t) ? t : ae(t) ? Object.keys(t) : M(t) ? [t] : [n]])]
}

function Ql(e, t, n) {
  const s = M(n) ? n : Xs,
    r = e;
  r.__localeChainCache || (r.__localeChainCache = new Map);
  let l = r.__localeChainCache.get(s);
  if (!l) {
    l = [];
    let o = [n];
    for (; de(o);) o = Zl(l, o, t);
    const i = de(t) || !V(t) ? t : t.default ? t.default : null;
    o = M(i) ? [i] : i, de(o) && Zl(l, o, !1), r.__localeChainCache.set(s, l)
  }
  return l
}

function Zl(e, t, n) {
  let s = !0;
  for (let r = 0; r < t.length && ce(s); r++) {
    const l = t[r];
    M(l) && (s = Sf(e, t[r], n))
  }
  return s
}

function Sf(e, t, n) {
  let s;
  const r = t.split("-");
  do {
    const l = r.join("-");
    s = Pf(e, l, n), r.splice(-1, 1)
  } while (r.length && s === !0);
  return s
}

function Pf(e, t, n) {
  let s = !1;
  if (!e.includes(t) && (s = !0, t)) {
    s = t[t.length - 1] !== "!";
    const r = t.replace(/!/g, "");
    e.push(r), (de(n) || V(n)) && n[r] && (s = n[r])
  }
  return s
}
const Df = "9.2.0-beta.26",
  Yn = -1,
  Xs = "en-US",
  eo = "";

function $f() {
  return {
    upper: e => M(e) ? e.toUpperCase() : e,
    lower: e => M(e) ? e.toLowerCase() : e,
    capitalize: e => M(e) ? `${e.charAt(0).toLocaleUpperCase()}${e.substr(1)}` : e
  }
}
let Uf, to;

function jf(e) {
  to = e
}
let no;

function Hf(e) {
  no = e
}
let so = null;
const ro = e => {
    so = e
  },
  Wf = () => so;
let lo = 0;

function Vf(e = {}) {
  const t = M(e.version) ? e.version : Df,
    n = M(e.locale) ? e.locale : Xs,
    s = de(e.fallbackLocale) || V(e.fallbackLocale) || M(e.fallbackLocale) || e.fallbackLocale === !1 ? e.fallbackLocale : n,
    r = V(e.messages) ? e.messages : {
      [n]: {}
    },
    l = V(e.datetimeFormats) ? e.datetimeFormats : {
      [n]: {}
    },
    o = V(e.numberFormats) ? e.numberFormats : {
      [n]: {}
    },
    i = Te({}, e.modifiers || {}, $f()),
    a = e.pluralRules || {},
    u = ge(e.missing) ? e.missing : null,
    h = ce(e.missingWarn) || Kn(e.missingWarn) ? e.missingWarn : !0,
    p = ce(e.fallbackWarn) || Kn(e.fallbackWarn) ? e.fallbackWarn : !0,
    _ = !!e.fallbackFormat,
    w = !!e.unresolving,
    S = ge(e.postTranslation) ? e.postTranslation : null,
    P = V(e.processor) ? e.processor : null,
    I = ce(e.warnHtmlMessage) ? e.warnHtmlMessage : !0,
    F = !!e.escapeParameter,
    H = ge(e.messageCompiler) ? e.messageCompiler : Uf,
    X = ge(e.messageResolver) ? e.messageResolver : to || yf,
    R = ge(e.localeFallbacker) ? e.localeFallbacker : no || Rf,
    N = ge(e.onWarn) ? e.onWarn : uf,
    q = e,
    W = ae(q.__datetimeFormatters) ? q.__datetimeFormatters : new Map,
    se = ae(q.__numberFormatters) ? q.__numberFormatters : new Map,
    te = ae(q.__meta) ? q.__meta : {};
  lo++;
  const le = {
    version: t,
    cid: lo,
    locale: n,
    fallbackLocale: s,
    messages: r,
    modifiers: i,
    pluralRules: a,
    missing: u,
    missingWarn: h,
    fallbackWarn: p,
    fallbackFormat: _,
    unresolving: w,
    postTranslation: S,
    processor: P,
    warnHtmlMessage: I,
    escapeParameter: F,
    messageCompiler: H,
    messageResolver: X,
    localeFallbacker: R,
    onWarn: N,
    __meta: te
  };
  return le.datetimeFormats = l, le.numberFormats = o, le.__datetimeFormatters = W, le.__numberFormatters = se, __INTLIFY_PROD_DEVTOOLS__ && Af(le, t, te), le
}

function Js(e, t, n, s, r) {
  const {
    missing: l,
    onWarn: o
  } = e;
  if (l !== null) {
    const i = l(e, n, t, r);
    return M(i) ? i : t
  } else return t
}

function rn(e, t, n) {
  const s = e;
  s.__localeChainCache = new Map, e.localeFallbacker(e, n, t)
}
let oo = Yl.__EXTEND_POINT__;
const qs = () => ++oo,
  Pt = {
    INVALID_ARGUMENT: oo,
    INVALID_DATE_ARGUMENT: qs(),
    INVALID_ISO_DATE_ARGUMENT: qs(),
    __EXTEND_POINT__: qs()
  };

function Dt(e) {
  return Gl(e, null, void 0)
}
const io = () => "",
  Ve = e => ge(e);

function ao(e, ...t) {
  const {
    fallbackFormat: n,
    postTranslation: s,
    unresolving: r,
    messageCompiler: l,
    fallbackLocale: o,
    messages: i
  } = e, [a, u] = Qs(...t), h = ce(u.missingWarn) ? u.missingWarn : e.missingWarn, p = ce(u.fallbackWarn) ? u.fallbackWarn : e.fallbackWarn, _ = ce(u.escapeParameter) ? u.escapeParameter : e.escapeParameter, w = !!u.resolvedMessage, S = M(u.default) || ce(u.default) ? ce(u.default) ? a : u.default : n ? l ? a : () => a : "", P = n || S !== "", I = M(u.locale) ? u.locale : e.locale;
  _ && Bf(u);
  let [F, H, X] = w ? [a, I, i[I] || {}] : Kf(e, a, I, o, p, h), R = F, N = a;
  if (!w && !(M(R) || Ve(R)) && P && (R = S, N = R), !w && (!(M(R) || Ve(R)) || !M(H))) return r ? Yn : a;
  let q = !1;
  const W = () => {
      q = !0
    },
    se = Ve(R) ? R : co(e, a, H, R, N, W);
  if (q) return R;
  const te = Gf(e, H, X, u),
    le = Nf(te),
    ue = zf(e, se, le),
    _e = s ? s(ue) : ue;
  if (__INTLIFY_PROD_DEVTOOLS__) {
    const Me = {
      timestamp: Date.now(),
      key: M(a) ? a : Ve(R) ? R.key : "",
      locale: H || (Ve(R) ? R.locale : ""),
      format: M(R) ? R : Ve(R) ? R.source : "",
      message: _e
    };
    Me.meta = Te({}, e.__meta, Wf() || {}), kf(Me)
  }
  return _e
}

function Bf(e) {
  de(e.list) ? e.list = e.list.map(t => M(t) ? Kl(t) : t) : ae(e.named) && Object.keys(e.named).forEach(t => {
    M(e.named[t]) && (e.named[t] = Kl(e.named[t]))
  })
}

function Kf(e, t, n, s, r, l) {
  const {
    messages: o,
    onWarn: i,
    messageResolver: a,
    localeFallbacker: u
  } = e, h = u(e, s, n);
  let p = {},
    _, w = null;
  const S = "translate";
  for (let P = 0; P < h.length && (_ = h[P], p = o[_] || {}, (w = a(p, t)) === null && (w = p[t]), !(M(w) || ge(w))); P++) {
    const I = Js(e, t, _, l, S);
    I !== t && (w = I)
  }
  return [w, _, p]
}

function co(e, t, n, s, r, l) {
  const {
    messageCompiler: o,
    warnHtmlMessage: i
  } = e;
  if (Ve(s)) {
    const u = s;
    return u.locale = u.locale || n, u.key = u.key || t, u
  }
  const a = o(s, Yf(e, n, r, s, i, l));
  return a.locale = n, a.key = t, a.source = s, a
}

function zf(e, t, n) {
  return t(n)
}

function Qs(...e) {
  const [t, n, s] = e, r = {};
  if (!M(t) && !me(t) && !Ve(t)) throw Dt(Pt.INVALID_ARGUMENT);
  const l = me(t) ? String(t) : (Ve(t), t);
  return me(n) ? r.plural = n : M(n) ? r.default = n : V(n) && !zn(n) ? r.named = n : de(n) && (r.list = n), me(s) ? r.plural = s : M(s) ? r.default = s : V(s) && Te(r, s), [l, r]
}

function Yf(e, t, n, s, r, l) {
  return {
    warnHtmlMessage: r,
    onError: o => {
      throw l && l(o), o
    },
    onCacheKey: o => of (t, n, o)
  }
}

function Gf(e, t, n, s) {
  const {
    modifiers: r,
    pluralRules: l,
    messageResolver: o
  } = e, a = {
    locale: t,
    modifiers: r,
    pluralRules: l,
    messages: u => {
      const h = o(n, u);
      if (M(h)) {
        let p = !1;
        const w = co(e, u, t, h, u, () => {
          p = !0
        });
        return p ? io : w
      } else return Ve(h) ? h : io
    }
  };
  return e.processor && (a.processor = e.processor), s.list && (a.list = s.list), s.named && (a.named = s.named), me(s.plural) && (a.pluralIndex = s.plural), a
}

function uo(e, ...t) {
  const {
    datetimeFormats: n,
    unresolving: s,
    fallbackLocale: r,
    onWarn: l,
    localeFallbacker: o
  } = e, {
    __datetimeFormatters: i
  } = e, [a, u, h, p] = Zs(...t), _ = ce(h.missingWarn) ? h.missingWarn : e.missingWarn;
  ce(h.fallbackWarn) ? h.fallbackWarn : e.fallbackWarn;
  const w = !!h.part,
    S = M(h.locale) ? h.locale : e.locale,
    P = o(e, r, S);
  if (!M(a) || a === "") return new Intl.DateTimeFormat(S).format(u);
  let I = {},
    F, H = null;
  const X = "datetime format";
  for (let q = 0; q < P.length && (F = P[q], I = n[F] || {}, H = I[a], !V(H)); q++) Js(e, a, F, _, X);
  if (!V(H) || !M(F)) return s ? Yn : a;
  let R = `${F}__${a}`;
  zn(p) || (R = `${R}__${JSON.stringify(p)}`);
  let N = i.get(R);
  return N || (N = new Intl.DateTimeFormat(F, Te({}, H, p)), i.set(R, N)), w ? N.formatToParts(u) : N.format(u)
}

function Zs(...e) {
  const [t, n, s, r] = e;
  let l = {},
    o = {},
    i;
  if (M(t)) {
    const a = t.match(/(\d{4}-\d{2}-\d{2})(T|\s)?(.*)/);
    if (!a) throw Dt(Pt.INVALID_ISO_DATE_ARGUMENT);
    const u = a[3] ? a[3].trim().startsWith("T") ? `${a[1].trim()}${a[3].trim()}` : `${a[1].trim()}T${a[3].trim()}` : a[1].trim();
    i = new Date(u);
    try {
      i.toISOString()
    } catch {
      throw Dt(Pt.INVALID_ISO_DATE_ARGUMENT)
    }
  } else if (cf(t)) {
    if (isNaN(t.getTime())) throw Dt(Pt.INVALID_DATE_ARGUMENT);
    i = t
  } else if (me(t)) i = t;
  else throw Dt(Pt.INVALID_ARGUMENT);
  return M(n) ? l.key = n : V(n) && (l = n), M(s) ? l.locale = s : V(s) && (o = s), V(r) && (o = r), [l.key || "", i, l, o]
}

function fo(e, t, n) {
  const s = e;
  for (const r in n) {
    const l = `${t}__${r}`;
    !s.__datetimeFormatters.has(l) || s.__datetimeFormatters.delete(l)
  }
}

function ho(e, ...t) {
  const {
    numberFormats: n,
    unresolving: s,
    fallbackLocale: r,
    onWarn: l,
    localeFallbacker: o
  } = e, {
    __numberFormatters: i
  } = e, [a, u, h, p] = er(...t), _ = ce(h.missingWarn) ? h.missingWarn : e.missingWarn;
  ce(h.fallbackWarn) ? h.fallbackWarn : e.fallbackWarn;
  const w = !!h.part,
    S = M(h.locale) ? h.locale : e.locale,
    P = o(e, r, S);
  if (!M(a) || a === "") return new Intl.NumberFormat(S).format(u);
  let I = {},
    F, H = null;
  const X = "number format";
  for (let q = 0; q < P.length && (F = P[q], I = n[F] || {}, H = I[a], !V(H)); q++) Js(e, a, F, _, X);
  if (!V(H) || !M(F)) return s ? Yn : a;
  let R = `${F}__${a}`;
  zn(p) || (R = `${R}__${JSON.stringify(p)}`);
  let N = i.get(R);
  return N || (N = new Intl.NumberFormat(F, Te({}, H, p)), i.set(R, N)), w ? N.formatToParts(u) : N.format(u)
}

function er(...e) {
  const [t, n, s, r] = e;
  let l = {},
    o = {};
  if (!me(t)) throw Dt(Pt.INVALID_ARGUMENT);
  const i = t;
  return M(n) ? l.key = n : V(n) && (l = n), M(s) ? l.locale = s : V(s) && (o = s), V(r) && (o = r), [l.key || "", i, l, o]
}

function mo(e, t, n) {
  const s = e;
  for (const r in n) {
    const l = `${t}__${r}`;
    !s.__numberFormatters.has(l) || s.__numberFormatters.delete(l)
  }
}
typeof __INTLIFY_PROD_DEVTOOLS__ != "boolean" && (zs().__INTLIFY_PROD_DEVTOOLS__ = !1);
/*!
 * vue-i18n v9.2.0-beta.26
 * (c) 2021 kazuya kawaguchi
 * Released under the MIT License.
 */
const Xf = "9.2.0-beta.26";

function Jf() {
  typeof __INTLIFY_PROD_DEVTOOLS__ != "boolean" && (zs().__INTLIFY_PROD_DEVTOOLS__ = !1)
}
Mf.__EXTEND_POINT__;
let go = Yl.__EXTEND_POINT__;
const ke = () => ++go,
  xe = {
    UNEXPECTED_RETURN_TYPE: go,
    INVALID_ARGUMENT: ke(),
    MUST_BE_CALL_SETUP_TOP: ke(),
    NOT_INSLALLED: ke(),
    NOT_AVAILABLE_IN_LEGACY_MODE: ke(),
    REQUIRED_VALUE: ke(),
    INVALID_VALUE: ke(),
    CANNOT_SETUP_VUE_DEVTOOLS_PLUGIN: ke(),
    NOT_INSLALLED_WITH_PROVIDE: ke(),
    UNEXPECTED_ERROR: ke(),
    NOT_COMPATIBLE_LEGACY_VUE_I18N: ke(),
    BRIDGE_SUPPORT_VUE_2_ONLY: ke(),
    __EXTEND_POINT__: ke()
  };

function Fe(e, ...t) {
  return Gl(e, null, void 0)
}
const tr = st("__transrateVNode"),
  nr = st("__datetimeParts"),
  sr = st("__numberParts"),
  qf = st("__setPluralRules");
st("__intlifyMeta");
const Qf = st("__injectWithOption");

function rr(e) {
  if (!ae(e)) return e;
  for (const t in e)
    if (!!Ys(e, t))
      if (!t.includes(".")) ae(e[t]) && rr(e[t]);
      else {
        const n = t.split("."),
          s = n.length - 1;
        let r = e;
        for (let l = 0; l < s; l++) n[l] in r || (r[n[l]] = {}), r = r[n[l]];
        r[n[s]] = e[t], delete e[t], ae(r[n[s]]) && rr(r[n[s]])
      } return e
}

function _o(e, t) {
  const {
    messages: n,
    __i18n: s,
    messageResolver: r,
    flatJson: l
  } = t, o = V(n) ? n : de(s) ? {} : {
    [e]: {}
  };
  if (de(s) && s.forEach(i => {
      if ("locale" in i && "resource" in i) {
        const {
          locale: a,
          resource: u
        } = i;
        a ? (o[a] = o[a] || {}, ln(u, o[a])) : ln(u, o)
      } else M(i) && ln(JSON.parse(i), o)
    }), r == null && l)
    for (const i in o) Ys(o, i) && rr(o[i]);
  return o
}
const Gn = e => !ae(e) || de(e);

function ln(e, t) {
  if (Gn(e) || Gn(t)) throw Fe(xe.INVALID_VALUE);
  for (const n in e) Ys(e, n) && (Gn(e[n]) || Gn(t[n]) ? t[n] = e[n] : ln(e[n], t[n]))
}

function po(e) {
  return e.type
}

function Zf(e, t, n) {
  let s = ae(t.messages) ? t.messages : {};
  "__i18nGlobal" in n && (s = _o(e.locale.value, {
    messages: s,
    __i18n: n.__i18nGlobal
  }));
  const r = Object.keys(s);
  r.length && r.forEach(l => {
    e.mergeLocaleMessage(l, s[l])
  }); {
    if (ae(t.datetimeFormats)) {
      const l = Object.keys(t.datetimeFormats);
      l.length && l.forEach(o => {
        e.mergeDateTimeFormat(o, t.datetimeFormats[o])
      })
    }
    if (ae(t.numberFormats)) {
      const l = Object.keys(t.numberFormats);
      l.length && l.forEach(o => {
        e.mergeNumberFormat(o, t.numberFormats[o])
      })
    }
  }
}

function bo(e) {
  return re(Fn, null, e, 0)
}
const yo = "__INTLIFY_META__";
let Eo = 0;

function To(e) {
  return (t, n, s, r) => e(n, s, $n() || void 0, r)
}
const ed = () => {
  const e = $n();
  let t = null;
  return e && (t = po(e)[yo]) ? {
    [yo]: t
  } : null
};

function vo(e = {}, t) {
  const {
    __root: n
  } = e, s = n === void 0;
  let r = ce(e.inheritLocale) ? e.inheritLocale : !0;
  const l = Yt(n && r ? n.locale.value : M(e.locale) ? e.locale : Xs),
    o = Yt(n && r ? n.fallbackLocale.value : M(e.fallbackLocale) || de(e.fallbackLocale) || V(e.fallbackLocale) || e.fallbackLocale === !1 ? e.fallbackLocale : l.value),
    i = Yt(_o(l.value, e)),
    a = Yt(V(e.datetimeFormats) ? e.datetimeFormats : {
      [l.value]: {}
    }),
    u = Yt(V(e.numberFormats) ? e.numberFormats : {
      [l.value]: {}
    });
  let h = n ? n.missingWarn : ce(e.missingWarn) || Kn(e.missingWarn) ? e.missingWarn : !0,
    p = n ? n.fallbackWarn : ce(e.fallbackWarn) || Kn(e.fallbackWarn) ? e.fallbackWarn : !0,
    _ = n ? n.fallbackRoot : ce(e.fallbackRoot) ? e.fallbackRoot : !0,
    w = !!e.fallbackFormat,
    S = ge(e.missing) ? e.missing : null,
    P = ge(e.missing) ? To(e.missing) : null,
    I = ge(e.postTranslation) ? e.postTranslation : null,
    F = n ? n.warnHtmlMessage : ce(e.warnHtmlMessage) ? e.warnHtmlMessage : !0,
    H = !!e.escapeParameter;
  const X = n ? n.modifiers : V(e.modifiers) ? e.modifiers : {};
  let R = e.pluralRules || n && n.pluralRules,
    N;

  function q() {
    const f = {
      version: Xf,
      locale: l.value,
      fallbackLocale: o.value,
      messages: i.value,
      modifiers: X,
      pluralRules: R,
      missing: P === null ? void 0 : P,
      missingWarn: h,
      fallbackWarn: p,
      fallbackFormat: w,
      unresolving: !0,
      postTranslation: I === null ? void 0 : I,
      warnHtmlMessage: F,
      escapeParameter: H,
      messageResolver: e.messageResolver,
      __meta: {
        framework: "vue"
      }
    };
    return f.datetimeFormats = a.value, f.numberFormats = u.value, f.__datetimeFormatters = V(N) ? N.__datetimeFormatters : void 0, f.__numberFormatters = V(N) ? N.__numberFormatters : void 0, Vf(f)
  }
  N = q(), rn(N, l.value, o.value);

  function W() {
    return [l.value, o.value, i.value, a.value, u.value]
  }
  const se = Lt({
      get: () => l.value,
      set: f => {
        l.value = f, N.locale = l.value
      }
    }),
    te = Lt({
      get: () => o.value,
      set: f => {
        o.value = f, N.fallbackLocale = o.value, rn(N, l.value, f)
      }
    }),
    le = Lt(() => i.value),
    ue = Lt(() => a.value),
    _e = Lt(() => u.value);

  function Me() {
    return ge(I) ? I : null
  }

  function on(f) {
    I = f, N.postTranslation = f
  }

  function $t() {
    return S
  }

  function pe(f) {
    f !== null && (P = To(f)), S = f, N.missing = P
  }

  function Y(f, m, O, x, $, j) {
    W();
    let K;
    if (__INTLIFY_PROD_DEVTOOLS__) try {
      ro(ed()), K = f(N)
    } finally {
      ro(null)
    } else K = f(N);
    if (me(K) && K === Yn) {
      const [G, ne] = m();
      return n && _ ? x(n) : $(G)
    } else {
      if (j(K)) return K;
      throw Fe(xe.UNEXPECTED_RETURN_TYPE)
    }
  }

  function J(...f) {
    return Y(m => Reflect.apply(ao, null, [m, ...f]), () => Qs(...f), "translate", m => Reflect.apply(m.t, m, [...f]), m => m, m => M(m))
  }

  function Re(...f) {
    const [m, O, x] = f;
    if (x && !ae(x)) throw Fe(xe.INVALID_ARGUMENT);
    return J(m, O, Te({
      resolvedMessage: !0
    }, x || {}))
  }

  function Ut(...f) {
    return Y(m => Reflect.apply(uo, null, [m, ...f]), () => Zs(...f), "datetime format", m => Reflect.apply(m.d, m, [...f]), () => eo, m => M(m))
  }

  function lt(...f) {
    return Y(m => Reflect.apply(ho, null, [m, ...f]), () => er(...f), "number format", m => Reflect.apply(m.n, m, [...f]), () => eo, m => M(m))
  }

  function Ge(f) {
    return f.map(m => M(m) ? bo(m) : m)
  }
  const an = {
    normalize: Ge,
    interpolate: f => f,
    type: "vnode"
  };

  function Xn(...f) {
    return Y(m => {
      let O;
      const x = m;
      try {
        x.processor = an, O = Reflect.apply(ao, null, [x, ...f])
      } finally {
        x.processor = null
      }
      return O
    }, () => Qs(...f), "translate", m => m[tr](...f), m => [bo(m)], m => de(m))
  }

  function Jn(...f) {
    return Y(m => Reflect.apply(ho, null, [m, ...f]), () => er(...f), "number format", m => m[sr](...f), () => [], m => M(m) || de(m))
  }

  function Se(...f) {
    return Y(m => Reflect.apply(uo, null, [m, ...f]), () => Zs(...f), "datetime format", m => m[nr](...f), () => [], m => M(m) || de(m))
  }

  function yt(f) {
    R = f, N.pluralRules = R
  }

  function cn(f, m) {
    const O = M(m) ? m : l.value,
      x = Et(O);
    return N.messageResolver(x, f) !== null
  }

  function Xe(f) {
    let m = null;
    const O = Ql(N, o.value, l.value);
    for (let x = 0; x < O.length; x++) {
      const $ = i.value[O[x]] || {},
        j = N.messageResolver($, f);
      if (j != null) {
        m = j;
        break
      }
    }
    return m
  }

  function jt(f) {
    const m = Xe(f);
    return m != null ? m : n ? n.tm(f) || {} : {}
  }

  function Et(f) {
    return i.value[f] || {}
  }

  function c(f, m) {
    i.value[f] = m, N.messages = i.value
  }

  function d(f, m) {
    i.value[f] = i.value[f] || {}, ln(m, i.value[f]), N.messages = i.value
  }

  function g(f) {
    return a.value[f] || {}
  }

  function y(f, m) {
    a.value[f] = m, N.datetimeFormats = a.value, fo(N, f, m)
  }

  function b(f, m) {
    a.value[f] = Te(a.value[f] || {}, m), N.datetimeFormats = a.value, fo(N, f, m)
  }

  function v(f) {
    return u.value[f] || {}
  }

  function C(f, m) {
    u.value[f] = m, N.numberFormats = u.value, mo(N, f, m)
  }

  function T(f, m) {
    u.value[f] = Te(u.value[f] || {}, m), N.numberFormats = u.value, mo(N, f, m)
  }
  Eo++, n && (Zt(n.locale, f => {
    r && (l.value = f, N.locale = f, rn(N, l.value, o.value))
  }), Zt(n.fallbackLocale, f => {
    r && (o.value = f, N.fallbackLocale = f, rn(N, l.value, o.value))
  }));
  const E = {
    id: Eo,
    locale: se,
    fallbackLocale: te,
    get inheritLocale() {
      return r
    },
    set inheritLocale(f) {
      r = f, f && n && (l.value = n.locale.value, o.value = n.fallbackLocale.value, rn(N, l.value, o.value))
    },
    get availableLocales() {
      return Object.keys(i.value).sort()
    },
    messages: le,
    get modifiers() {
      return X
    },
    get pluralRules() {
      return R || {}
    },
    get isGlobal() {
      return s
    },
    get missingWarn() {
      return h
    },
    set missingWarn(f) {
      h = f, N.missingWarn = h
    },
    get fallbackWarn() {
      return p
    },
    set fallbackWarn(f) {
      p = f, N.fallbackWarn = p
    },
    get fallbackRoot() {
      return _
    },
    set fallbackRoot(f) {
      _ = f
    },
    get fallbackFormat() {
      return w
    },
    set fallbackFormat(f) {
      w = f, N.fallbackFormat = w
    },
    get warnHtmlMessage() {
      return F
    },
    set warnHtmlMessage(f) {
      F = f, N.warnHtmlMessage = f
    },
    get escapeParameter() {
      return H
    },
    set escapeParameter(f) {
      H = f, N.escapeParameter = f
    },
    t: J,
    getLocaleMessage: Et,
    setLocaleMessage: c,
    mergeLocaleMessage: d,
    getPostTranslationHandler: Me,
    setPostTranslationHandler: on,
    getMissingHandler: $t,
    setMissingHandler: pe,
    [qf]: yt
  };
  return E.datetimeFormats = ue, E.numberFormats = _e, E.rt = Re, E.te = cn, E.tm = jt, E.d = Ut, E.n = lt, E.getDateTimeFormat = g, E.setDateTimeFormat = y, E.mergeDateTimeFormat = b, E.getNumberFormat = v, E.setNumberFormat = C, E.mergeNumberFormat = T, E[Qf] = e.__injectWithOption, E[tr] = Xn, E[nr] = Se, E[sr] = Jn, E
}
const lr = {
  tag: {
    type: [String, Object]
  },
  locale: {
    type: String
  },
  scope: {
    type: String,
    validator: e => e === "parent" || e === "global",
    default: "parent"
  },
  i18n: {
    type: Object
  }
};

function td({
  slots: e
}, t) {
  return t.length === 1 && t[0] === "default" ? (e.default ? e.default() : []).reduce((s, r) => s = [...s, ...de(r.children) ? r.children : [r]], []) : t.reduce((n, s) => {
    const r = e[s];
    return r && (n[s] = r()), n
  }, {})
}

function wo(e) {
  return Z
}
const Io = {
  name: "i18n-t",
  props: Te({
    keypath: {
      type: String,
      required: !0
    },
    plural: {
      type: [Number, String],
      validator: e => me(e) || !isNaN(e)
    }
  }, lr),
  setup(e, t) {
    const {
      slots: n,
      attrs: s
    } = t, r = e.i18n || or({
      useScope: e.scope,
      __useComponent: !0
    }), l = Object.keys(n).filter(o => o !== "_");
    return () => {
      const o = {};
      e.locale && (o.locale = e.locale), e.plural !== void 0 && (o.plural = M(e.plural) ? +e.plural : e.plural);
      const i = td(t, l),
        a = r[tr](e.keypath, i, o),
        u = Te({}, s),
        h = M(e.tag) || ae(e.tag) ? e.tag : wo();
      return Cl(h, u, a)
    }
  }
};

function Co(e, t, n, s) {
  const {
    slots: r,
    attrs: l
  } = t;
  return () => {
    const o = {
      part: !0
    };
    let i = {};
    e.locale && (o.locale = e.locale), M(e.format) ? o.key = e.format : ae(e.format) && (M(e.format.key) && (o.key = e.format.key), i = Object.keys(e.format).reduce((_, w) => n.includes(w) ? Te({}, _, {
      [w]: e.format[w]
    }) : _, {}));
    const a = s(e.value, o, i);
    let u = [o.key];
    de(a) ? u = a.map((_, w) => {
      const S = r[_.type];
      return S ? S({
        [_.type]: _.value,
        index: w,
        parts: a
      }) : [_.value]
    }) : M(a) && (u = [a]);
    const h = Te({}, l),
      p = M(e.tag) || ae(e.tag) ? e.tag : wo();
    return Cl(p, h, u)
  }
}
const nd = ["localeMatcher", "style", "unit", "unitDisplay", "currency", "currencyDisplay", "useGrouping", "numberingSystem", "minimumIntegerDigits", "minimumFractionDigits", "maximumFractionDigits", "minimumSignificantDigits", "maximumSignificantDigits", "notation", "formatMatcher"],
  Oo = {
    name: "i18n-n",
    props: Te({
      value: {
        type: Number,
        required: !0
      },
      format: {
        type: [String, Object]
      }
    }, lr),
    setup(e, t) {
      const n = e.i18n || or({
        useScope: "parent",
        __useComponent: !0
      });
      return Co(e, t, nd, (...s) => n[sr](...s))
    }
  },
  sd = ["dateStyle", "timeStyle", "fractionalSecondDigits", "calendar", "dayPeriod", "numberingSystem", "localeMatcher", "timeZone", "hour12", "hourCycle", "formatMatcher", "weekday", "era", "year", "month", "day", "hour", "minute", "second", "timeZoneName"],
  xo = {
    name: "i18n-d",
    props: Te({
      value: {
        type: [Number, Date],
        required: !0
      },
      format: {
        type: [String, Object]
      }
    }, lr),
    setup(e, t) {
      const n = e.i18n || or({
        useScope: "parent",
        __useComponent: !0
      });
      return Co(e, t, sd, (...s) => n[nr](...s))
    }
  };

function rd(e, t) {
  const n = e;
  if (e.mode === "composition") return n.__getInstance(t) || e.global; {
    const s = n.__getInstance(t);
    return s != null ? s.__composer : e.global.__composer
  }
}

function ld(e) {
  const t = (n, {
    instance: s,
    value: r,
    modifiers: l
  }) => {
    if (!s || !s.$) throw Fe(xe.UNEXPECTED_ERROR);
    const o = rd(e, s.$),
      i = od(r);
    n.textContent = Reflect.apply(o.t, o, [...id(i)])
  };
  return {
    beforeMount: t,
    beforeUpdate: t
  }
}

function od(e) {
  if (M(e)) return {
    path: e
  };
  if (V(e)) {
    if (!("path" in e)) throw Fe(xe.REQUIRED_VALUE, "path");
    return e
  } else throw Fe(xe.INVALID_VALUE)
}

function id(e) {
  const {
    path: t,
    locale: n,
    args: s,
    choice: r,
    plural: l
  } = e, o = {}, i = s || {};
  return M(n) && (o.locale = n), me(r) && (o.plural = r), me(l) && (o.plural = l), [t, i, o]
}

function ad(e, t, ...n) {
  const s = V(n[0]) ? n[0] : {},
    r = !!s.useI18nComponentName;
  (ce(s.globalInstall) ? s.globalInstall : !0) && (e.component(r ? "i18n" : Io.name, Io), e.component(Oo.name, Oo), e.component(xo.name, xo)), e.directive("t", ld(t))
}
const cd = st("global-vue-i18n");

function Od(e = {}, t) {
  const n = !!e.globalInjection,
    s = new Map,
    r = ud(e),
    l = st("");

  function o(u) {
    return s.get(u) || null
  }

  function i(u, h) {
    s.set(u, h)
  }

  function a(u) {
    s.delete(u)
  } {
    const u = {
      get mode() {
        return "composition"
      },
      async install(h, ...p) {
        h.__VUE_I18N_SYMBOL__ = l, h.provide(h.__VUE_I18N_SYMBOL__, u), n && bd(h, u.global), ad(h, u, ...p)
      },
      get global() {
        return r
      },
      __instances: s,
      __getInstance: o,
      __setInstance: i,
      __deleteInstance: a
    };
    return u
  }
}

function or(e = {}) {
  const t = $n();
  if (t == null) throw Fe(xe.MUST_BE_CALL_SETUP_TOP);
  if (!t.isCE && t.appContext.app != null && !t.appContext.app.__VUE_I18N_SYMBOL__) throw Fe(xe.NOT_INSLALLED);
  const n = fd(t),
    s = hd(n),
    r = po(t),
    l = dd(e, r);
  if (l === "global") return Zf(s, e, r), s;
  if (l === "parent") {
    let a = md(n, t, e.__useComponent);
    return a == null && (a = s), a
  }
  if (n.mode === "legacy") throw Fe(xe.NOT_AVAILABLE_IN_LEGACY_MODE);
  const o = n;
  let i = o.__getInstance(t);
  if (i == null) {
    const a = Te({}, e);
    "__i18n" in r && (a.__i18n = r.__i18n), s && (a.__root = s), i = vo(a), gd(o, t), o.__setInstance(t, i)
  }
  return i
}

function ud(e, t, n) {
  return vo(e)
}

function fd(e) {
  {
    const t = xn(e.isCE ? cd : e.appContext.app.__VUE_I18N_SYMBOL__);
    if (!t) throw Fe(e.isCE ? xe.NOT_INSLALLED_WITH_PROVIDE : xe.UNEXPECTED_ERROR);
    return t
  }
}

function dd(e, t) {
  return zn(e) ? "__i18n" in t ? "local" : "global" : e.useScope ? e.useScope : "local"
}

function hd(e) {
  return e.mode === "composition" ? e.global : e.global.__composer
}

function md(e, t, n = !1) {
  let s = null;
  const r = t.root;
  let l = t.parent;
  for (; l != null;) {
    const o = e;
    if (e.mode === "composition" && (s = o.__getInstance(l)), s != null || r === l) break;
    l = l.parent
  }
  return s
}

function gd(e, t, n) {
  Cs(() => {}, t), Os(() => {
    e.__deleteInstance(t)
  }, t)
}
const _d = ["locale", "fallbackLocale", "availableLocales"],
  pd = ["t", "rt", "d", "n", "tm"];

function bd(e, t) {
  const n = Object.create(null);
  _d.forEach(s => {
    const r = Object.getOwnPropertyDescriptor(t, s);
    if (!r) throw Fe(xe.UNEXPECTED_ERROR);
    const l = ye(r.value) ? {
      get() {
        return r.value.value
      },
      set(o) {
        r.value.value = o
      }
    } : {
      get() {
        return r.get && r.get()
      }
    };
    Object.defineProperty(n, s, l)
  }), e.config.globalProperties.$i18n = n, pd.forEach(s => {
    const r = Object.getOwnPropertyDescriptor(t, s);
    if (!r || !r.value) throw Fe(xe.UNEXPECTED_ERROR);
    Object.defineProperty(e.config.globalProperties, `$${s}`, r)
  })
}
jf(Ef);
Hf(Ql);
Jf();
if (__INTLIFY_PROD_DEVTOOLS__) {
  const e = zs();
  e.__INTLIFY__ = !0, Lf(e.__INTLIFY_DEVTOOLS_GLOBAL_HOOK__)
}
export {
  Z as F, Cd as T, Id as _, vd as a, A as b, k as c, Ed as d, re as e, wd as f, Od as g, we as h, fa as i, Qa as j, ee as k, L as o, yd as p, Td as r, oe as t, bi as u, Sl as v, kn as w
};