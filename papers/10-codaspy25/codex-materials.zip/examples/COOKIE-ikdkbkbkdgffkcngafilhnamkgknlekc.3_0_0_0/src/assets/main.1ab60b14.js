import {
  o as u,
  c as _,
  b as e,
  a as v,
  p as b,
  d as f,
  e as g,
  u as k,
  F as m,
  _ as x,
  f as T
} from "./vendor.db840a70.js";
import {
  _ as L,
  H as r,
  F as S,
  D as c,
  S as o,
  G as l
} from "./index.733e49c2.js";
const C = {
    data() {
      return {
        optionURL: r.getURL("/options.html"),
        tabURL: r.getURL("/tab.html")
      }
    },
    methods: {
      openTab(t) {
        r.openTab(t)
      },
      openPopup(t) {
        location.hash !== "#popup" ? r.openPopup(t + "#popup") : r.openTab(t), window.close()
      }
    }
  },
  d = t => (b("data-v-0b6c15f8"), t = t(), f(), t),
  y = {
    class: "navbar mb-2 shadow-lg bg-neutral text-neutral-content"
  },
  R = v('<div class="flex-none" data-v-0b6c15f8><span class="mx-2" data-v-0b6c15f8><svg xmlns="http://www.w3.org/2000/svg" class="inline-block w-6 h-6 stroke-current" fill="none" viewBox="0 0 24 24" stroke="currentColor" data-v-0b6c15f8><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129" data-v-0b6c15f8></path></svg></span><span class="text-lg font-bold" data-v-0b6c15f8> Translate </span></div><div class="flex-1 px-2 mx-2" data-v-0b6c15f8><div class="items-stretch hidden lg:flex" data-v-0b6c15f8></div></div>', 2),
  M = {
    class: "flex-none"
  },
  U = d(() => e("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    class: "inline-block w-6 h-6 stroke-current",
    fill: "none",
    viewBox: "0 0 24 24",
    stroke: "currentColor"
  }, [e("path", {
    "stroke-linecap": "round",
    "stroke-linejoin": "round",
    "stroke-width": "2",
    d: "M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"
  })], -1)),
  j = [U],
  B = {
    class: "flex-none"
  },
  A = d(() => e("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    class: "inline-block w-6 h-6 stroke-current",
    fill: "none",
    viewBox: "0 0 24 24",
    stroke: "currentColor"
  }, [e("path", {
    "stroke-linecap": "round",
    "stroke-linejoin": "round",
    "stroke-width": "2",
    d: "M12 8v13m0-13V6a2 2 0 112 2h-2zm0 0V5.5A2.5 2.5 0 109.5 8H12zm-7 4h14M5 12a2 2 0 110-4h14a2 2 0 110 4M5 12v7a2 2 0 002 2h10a2 2 0 002-2v-7"
  })], -1)),
  D = [A],
  H = {
    class: "flex-none"
  },
  V = d(() => e("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    class: "inline-block w-6 h-6 stroke-current",
    fill: "none",
    viewBox: "0 0 24 24",
    stroke: "currentColor"
  }, [e("path", {
    "stroke-linecap": "round",
    "stroke-linejoin": "round",
    "stroke-width": "2",
    d: "M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
  })], -1)),
  q = [V],
  z = {
    class: "flex-none"
  },
  F = d(() => e("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    class: "inline-block w-6 h-6 stroke-current",
    fill: "none",
    viewBox: "0 0 24 24",
    stroke: "currentColor"
  }, [e("path", {
    "stroke-linecap": "round",
    "stroke-linejoin": "round",
    "stroke-width": "2",
    d: "M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"
  }), e("path", {
    "stroke-linecap": "round",
    "stroke-linejoin": "round",
    "stroke-width": "2",
    d: "M15 12a3 3 0 11-6 0 3 3 0 016 0z"
  })], -1)),
  I = [F];

function P(t, s, a, p, n, i) {
  return u(), _("nav", y, [R, e("div", M, []), e("div", B, []), e("div", H, [e("button", {
    onClick: s[2] || (s[2] = h => i.openPopup(n.tabURL)),
    class: "btn btn-square btn-ghost"
  }, q)]), e("div", z, [e("button", {
    onClick: s[3] || (s[3] = h => i.openTab(n.optionURL)),
    class: "btn btn-square btn-ghost"
  }, I)])])
}
var E = L(C, [
  ["render", P],
  ["__scopeId", "data-v-0b6c15f8"]
]);
const w = "There is an issue with the Google Translate server. Please try again in a moment...",
  G = {
    data() {
      return {
        data: null,
        select: null,
        tts: {},
        lang: null,
        src: null,
        target: null,
        autoTTS: null
      }
    },
    async created() {
      this.select = {
        src: c.settings.src,
        target: c.settings.target,
        srcs: c.languages.sl,
        targets: c.languages.tl
      };
      const t = await o.get(null);
      await this.load(t)
    },
    methods: {
      async load(t) {
        const s = await this.getLanguages(t),
          a = t.settings || c.settings;
        this.lang = t.lang, this.src = a.src, this.target = a.target, this.autoTTS = a.tts, this.select = {
          src: a.src,
          target: a.target,
          srcs: s.sl,
          targets: s.tl
        }, t.last_word && this.loadData(t.last_word)
      },
      async getLanguages(t) {
        if (t.languages) return t.languages;
        const s = await l.getLanguages(t.lang);
        return await o.set("languages", s), s
      },
      async clear() {
        await o.remove("last_word")
      },
      async translate(t) {
        if (!!t) try {
          const s = await l.translate(this.lang, t, this.src, this.target);
          await this.loadData(s), this.autoTTS && N(s) && O(this.tts.src[0]), await o.set("last_word", s)
        } catch (s) {
          console.error(s), alert(w)
        }
      },
      async loadData(t) {
        this.data = t, this.data.src || (this.data.src = this.select.src), this.data.target || (this.data.target = this.select.target), this.data._Src = this.select.srcs[t.src], this.data._Target = this.select.targets[t.target], await this.getTTS(this.data)
      },
      async getTTS(t) {
        try {
          const s = await l.tts(this.lang, t.text, t.src),
            a = t.sentences.map(n => n.trans ? n.trans : "").join(""),
            p = await l.tts(this.lang, a, t.target);
          this.tts = {
            src: [s],
            target: [p]
          }
        } catch (s) {
          console.error(s), alert(w)
        }
      },
      async srctarget(t) {
        this.select = t, this.src = t.src, this.target = t.target;
        const s = await o.get("settings") || {};
        s.src = t.src, s.target = t.target, await o.set("settings", s)
      }
    }
  };

function N(t) {
  const s = t.sentences.filter(a => a.src_translit);
  return t.dict || s.length > 0
}

function O(t) {
  if (!t) return;
  const s = new Audio;
  s.src = t, s.play().catch(() => {})
}
const $ = Object.assign(G, {
    setup(t) {
      return (s, a) => (u(), _(m, null, [g(E), g(k(x), {
        export_data: s.data,
        export_select: s.select,
        export_tts: s.tts,
        onSrctarget: s.srctarget,
        onTranslate: s.translate,
        onClear: s.clear
      }, null, 8, ["export_data", "export_select", "export_tts", "onSrctarget", "onTranslate", "onClear"]), g(S)], 64))
    }
  }),
  J = T($);
J.mount("#app");