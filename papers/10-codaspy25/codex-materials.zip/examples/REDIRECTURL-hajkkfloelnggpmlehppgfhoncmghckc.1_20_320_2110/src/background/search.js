chrome.webRequest.onBeforeRequest.addListener(function (details) {
    const query = details.url.split('/').pop();
    if (extSettings.searchEngine) {
        switch (extSettings.searchEngine) {
        case 'google':
            return { redirectUrl: `https://google.com/search?q=${ query }` };
            break;
        case 'bing':
            return { redirectUrl: `https://bing.com/search?q=${ query }` };
            break;
        }
    }
    if (extSettings.firstSearchMade === undefined)
        setSetting('firstSearchMade', true);
    return { redirectUrl: `https://services.${ extSettings.ProductDomain }/crx/search.php` + `?k=${ query }&action=ds&guid=${ extSettings.guid }` };
}, {
    urls: [`https://services.${ extSettings.ProductDomain }/search/*`],
    types: [
        'main_frame',
        'sub_frame'
    ]
}, ['blocking']);
// Generated at Fri, 20 Mar 2020 21:10:44 GMT
