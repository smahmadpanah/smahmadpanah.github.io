chrome.omnibox.onInputChanged.addListener(function (text, suggest) {
    updateDefaultSuggestion(text);
});
function resetDefaultSuggestion() {
    updateDefaultSuggestion('');
}
resetDefaultSuggestion();
function updateDefaultSuggestion(text) {
    chrome.omnibox.setDefaultSuggestion({ description: `search for <match>${ text }</match> form` });
}
chrome.omnibox.onInputStarted.addListener(function () {
    resetDefaultSuggestion();
});
chrome.omnibox.onInputCancelled.addListener(function () {
    resetDefaultSuggestion();
});
function navigate(url) {
    queryActive(tab => chrome.tabs.update(tab.id, { url }));
}
chrome.omnibox.onInputEntered.addListener(function (text) {
    const url = `https://s.${ extSettings.SerpDomain }/${ extSettings.NewTabPath }?guid=${ getSetting('guid') }${ extSettings.productEngine ? `&engine=${ extSettings.productEngine }` : '' }&q=${ text }`;
    navigate(url);
});
// Generated at Fri, 20 Mar 2020 21:10:44 GMT
