const optionsList = [
    {
        id: 3,
        uniqueID: 'three',
        title: 'I like this extension'
    },
    {
        id: 2,
        uniqueID: 'two',
        title: 'About'
    }
];
chrome.contextMenus.removeAll(() => {
    optionsList.map(({title, id, uniqueID}) => {
        chrome.contextMenus.create({
            title,
            contexts: ['browser_action'],
            onclick: openOption(id),
            id: uniqueID
        });
    });
});
const openOption = optionID => () => {
    switch (optionID) {
    default:
        setSetting('tabOption', optionID);
        OpenUrl('/options/options.html');
    }
};
// Generated at Fri, 20 Mar 2020 21:10:44 GMT
