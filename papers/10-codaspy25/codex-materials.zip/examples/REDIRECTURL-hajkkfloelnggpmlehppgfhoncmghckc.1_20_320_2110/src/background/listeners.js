chrome.runtime.onMessage.addListener(function (req, sender, sendResponse) {
    const res = {};
    switch (req.task) {
    case 'openNewTab':
        queryActive(function (activeTab) {
            if (activeTab.id) {
                chrome.tabs.update(activeTab.id, { url: getNTUrl() });
            } else {
                OpenUrl(getNTUrl());
            }
        });
        break;
    case 'getSetting':
        sendResponse(getSetting(req.name));
        break;
    case 'setSetting':
        setSetting(req.name, req.value);
        sendResponse(res);
        break;
    case 'getRedirectUrl':
        sendResponse({ url: getNTUrl() });
        break;
    case 'getPopUpUrl':
        sendResponse({ url: getPopUpUrl() });
        break;
    case 'openUrl':
        OpenUrl(req.obj.url);
        break;
    case 'getOptionsRedirectUrl':
        sendResponse({ url: getOptionsUrl() });
        break;
    case 'getExtName':
        sendResponse(chrome.runtime.getManifest().name);
        break;
    case 'getExtVersion':
        sendResponse(chrome.runtime.getManifest().version);
        break;
    }
    return true;
});
// Generated at Fri, 20 Mar 2020 21:10:44 GMT
