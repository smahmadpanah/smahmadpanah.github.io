window.addEventListener("message", function(event) {
    if (event && event.data && event.data.task) {
        switch (event.data.task) {
            case "getSetting":
                chrome.runtime.sendMessage(
                    {
                        task: "getSetting",
                        name: event.data.name,
                    },
                    function(res) {
                        returnMessage(res);
                    }
                );
                break;
            case "setSetting":
                chrome.runtime.sendMessage(
                    {
                        task: "setSetting",
                        name: event.data.name,
                        value: event.data.value,
                    },
                    function(res) {
                        returnMessage(res);
                    }
                );
                break;
            case "sendMessage":
                chrome.runtime.sendMessage(
                    {
                        task: event.data.msg,
                        obj: event.data.obj,
                    },
                    function(res) {
                        returnMessage(res);
                    }
                );
                break;
            case "openUrl":
                chrome.runtime.sendMessage(
                    {
                        task: "openUrl",
                        obj: event.data,
                    },
                    function(res) {
                        returnMessage(res);
                    }
                );
                break;
        }
    }
});

function returnMessage(obj) {
    document
        .getElementById("frame")
        .contentWindow.postMessage({ msg: "msgResponse", res: obj }, "*");
}

// Generated at Fri, 20 Mar 2020 21:10:44 GMT
