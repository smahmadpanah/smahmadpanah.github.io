chrome.runtime.sendMessage({ task: "getOptionsRedirectUrl" }, function(res) {
    document.querySelector("#frame").src = res.url;
});

// Generated at Fri, 20 Mar 2020 21:10:44 GMT
