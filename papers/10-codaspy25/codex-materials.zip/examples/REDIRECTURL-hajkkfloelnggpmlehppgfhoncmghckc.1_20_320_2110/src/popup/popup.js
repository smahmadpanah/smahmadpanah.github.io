if (!navigator.onLine) {
    document.querySelector(".offline").style.display = "block";
    document.querySelector("#frame").style.display = "none";
} else {
    chrome.runtime.sendMessage({ task: "getPopUpUrl" }, function(res) {
        document.querySelector("#frame").src = res.url;
    });
}

// Generated at Fri, 20 Mar 2020 21:10:44 GMT
