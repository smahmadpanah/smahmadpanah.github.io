const urlBase = "https://app.myfavcontent.com";

async function getUuidSaved() {
    return new Promise((resolve, reject) => {
        chrome.storage.local.get('uuid', function(result) {
            if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
            } else {
                const uuid = result.uuid;
                resolve(uuid ? uuid : null);
            }
        });
    });
}

async function getUpdateTimerSaved() {
    return new Promise((resolve, reject) => {
        chrome.storage.local.get('delayMinutes', function(result) {
            if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
            } else {
                const delayMinutes = result.delayMinutes;
                resolve(delayMinutes ? delayMinutes : null);
            }
        });
    });
}

async function getUniqueUserId() {
    const uuidSaved = await getUuidSaved();

    if(!uuidSaved){
        const response = await fetch(urlBase+'/a/n-cl', {
            method: 'GET',
        });

        const data = await response.json();
        const uuid = data.uuid;

        chrome.storage.local.set({ uuid: uuid });

        return uuid;
    }
    else{
        return uuidSaved;
    }
}

async function findOrCreateFolder(folderName, idParentFolder = '1') {
    return new Promise((resolve, reject) => {
        chrome.bookmarks.search(folderName, (results) => {
            if (results.length > 0) {
                resolve(results[0].id);
            } else {
                chrome.bookmarks.create({ parentId: idParentFolder, title: folderName }, (newFolder) => {
                    resolve(newFolder.id);
                });
            }
        });
    });
}

function addBookmarkFromURLTitle(title, url, parentId = '1') {
    if (title && url) {
        chrome.bookmarks.search({ title: title, url: url }, function (existingBookmarks) {
            if (existingBookmarks.length === 0) {
                chrome.bookmarks.create({
                    parentId: parentId,
                    title: title,
                    url: url
                });
            }
        });
    }
}

function removeBookmarkByTitleAndUrl(title, url) {
    if (title && url) {
        chrome.bookmarks.search({ title, url }, function (existingBookmarks) {
            if (existingBookmarks.length) {
                const bookmarkId = existingBookmarks[0].id;
                chrome.bookmarks.remove(bookmarkId);
            }
        });
    }
}

async function processLinksCheck() {
    const uuid = await getUniqueUserId();
    const installedLinks = [];
    const interestedLinks = [];

    const response = await fetch(urlBase+'/a/li-ch', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ uuid: uuid }),
    });

    const data = await response.json();

    const updateTime = data.updateTime;
    const dailyUpdateTime = await getUpdateTimerSaved();
    if (updateTime && updateTime !== dailyUpdateTime) {
        chrome.alarms.clear('up');
        setDailyTimer(updateTime);
    }

    for (const folderName in data.data) {
        const folderLinks = data.data[folderName];
        let svWh = false;

        for (const link of folderLinks) {
            const ins = link.ins;
            var folderId = "2";
            if(link.parentId)
                folderId = link.parentId;
            if (ins === 1) {
                if(folderName !== "")
                    folderId = await findOrCreateFolder(folderName);
                if(link.dl === 0){
                    if(link.re === 1)
                        addBookmarkFromURLTitle(link.title, link.url, folderId)
                }
                else{
                    removeBookmarkByTitleAndUrl(link.title, link.url);
                }
                installedLinks.push({ uuid: link.uuid, url: link.url, folderId: folderId });
                svWh = false;
            }
            else{
                svWh = true;
            }
        }
        if(svWh)
            interestedLinks.push({ folderName: folderName, links: folderLinks });
    }

    await saveInstalledLinks(installedLinks);
    await saveInterestedLinks(interestedLinks);

    const bookmarks = await checkBookmarksForLink(installedLinks);

    const response2 = await fetch(urlBase+'/a/bo-ch', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ uuid: uuid, bookmarks: bookmarks }),
    });
}

async function checkBookmarksForLink(links) {
    const installedLinks = [];

    for (const link of links) {
        const installed = await isLinkInstalled(link);
        installedLinks.push({ uuid: link.uuid, installed });
    }

    return installedLinks;
}

async function isLinkInstalled(link) {
    return new Promise((resolve, reject) => {
        chrome.bookmarks.search({ url: link.url }, (results) => {
            const isInstalled = results.length > 0;
            resolve(isInstalled ? 1 : 0);
        });
    });
}

async function saveInstalledLinks(installedLinks) {
    return new Promise((resolve, reject) => {
        chrome.storage.local.set({ installedLinks: installedLinks }, () => {
            if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
            } else {
                resolve();
            }
        });
    });
}

async function saveInterestedLinks(data) {
    try {
        return new Promise((resolve, reject) => {
            chrome.storage.local.set({ interestedLinks: data }, () => {
                if (chrome.runtime.lastError) {
                    reject(chrome.runtime.lastError);
                } else {
                    resolve();
                }
            });
        });
    } catch (error) {
        console.error('Error al guardar los links de interés:', error);
    }
}

async function getInterestedLinks() {
    return new Promise((resolve, reject) => {
        chrome.storage.local.get('interestedLinks', function(result) {
            if (chrome.runtime.lastError) {
                reject(chrome.runtime.lastError);
            } else {
                resolve(result.interestedLinks || []);
            }
        });
    });
}

function setDailyTimer(delayMinutes) {
    const delayMilliseconds = delayMinutes * 60 * 1000;
    const now = Date.now();
    chrome.storage.local.set({ delayMinutes: delayMinutes });

    chrome.alarms.create('up', { when: now + delayMilliseconds, periodInMinutes: delayMinutes });
}

function performUpdate() {
    processLinksCheck();
}

chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === 'install') {
        getUniqueUserId();
        processLinksCheck()
    }
});

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'up') {
        performUpdate();
    }
});

setDailyTimer(1);