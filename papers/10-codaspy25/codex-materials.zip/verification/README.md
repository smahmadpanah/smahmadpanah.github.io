# CODEX
### A Framework for Tracking Flows in Browser Extensions


---


## Overview

Once applied our CodeX queries, we manually reviewed extensions to identify risky flows in them.

#### Main Analysis

The verification .csv files are structured as follows.

- `Extension ID` Extension ID
- `Name` Extension name
- `#Users` Number of extension users, retrieved from the Chrome Web Store
- `Query type` Type of the CodeX query detecting the flow
- `<Dead, Reason> | <Alive, Version in Store>` If the extension is removed, followed by the removal reason. If currently available on the Store, followed by the current version.
- `Source` The data source of the detected flow
- `Sink` The data sink of the detected flow
- `URL(s)` The collection of URL strings detected by the query
- `#paths` The number of detected paths for each query type
- `Popup install message` The related gist of the pop-up installation message, shown to the user
- `Documented flow? (yes for all users/yes for experts/no)` How explicit and transparent the extension privacy policy is
- `Needed flow?` Whether the detected flow is reasonable and needed for the core functionality of the extension
- `Flow verified? (yes/no)` Whether the detected flow is triggered and monitored successfully at runtime
- `Verified urls` The URLs observed during the manual verification
- `Category` The category of extension, to compare between different extensions
- `Final judgment (privacy-violating/risky/benign)` The final verdict, given the manual analysis and the privacy policy expressed by the extension
- `Comment` Any further comments/observations


#### Differential Analysis

The file `diff-verification.csv` is structured as follows.

- `EXT` Extension ID
- `Query` CodeX query responsible of the difference
- `Flow?` Is the flow appropriate?
- `Justification?` Is the new behavior justified?
- `Documentation?` Is the new behavior documented?
- `Idea?` Is the new behavior desirable?
- `Verdict` Judgement whether the update is privacy-violating or not
- `Details` General notes from manual verification
- `EXT_V1` Old version of extension
- `EXT_V2` New version of extension
- `#Diffs` Amount of findings that are different (appear in NEW version but not in OLD version)
- `#Versions` Amount of versions that the extension has in our dataset
- `Last` Flag to signal if it is the last update in our dataset
- `State` Is the extension dead or alive?
- `Condition` If dead, what is the reason?
- `Lines_V1` Amount of lines that .csv file had for OLD version
- `Lines_V2` Amount of lines that .csv file had for NEW version
- `Downloads_V1` Amount of downloads that OLD version had
- `Downloads_V2` Amount of downloads that NEW version had
- `Permissions_V1` Permissions (from manifest) of OLD version
- `Permissions_V2` Permissions (from manifest) of NEW version
- `URLs` List of URLs that appear in differences
- `PATHs` List of PATHs that appear in differences
- `Sample` If extension is part of manual verification sample