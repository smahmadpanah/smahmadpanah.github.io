
<<doc
Given a compressed @CWS_Extension, decompress and store its contents in @CB_Path.
doc
UTILS_Create_CB()
{
    CWS_Extension=$1
    CB_Path=$2
    LOG_Path=$3

    mkdir -p $CB_Path

    unzip "$CWS_Extension" -d $CB_Path &>> $LOG_Path
}


<<doc
Count the return codes, @Return_CODE, on the parallel log-file, @Parallel_LOG.
doc
HELPER_Count_CTR()
{
    Parallel_LOG=$1
    Return_CODE=$2

    # The EXIT-VALUE is located on the 7th column.
    EXIT_VAL=7

    awk "{print \$$EXIT_VAL}" $Parallel_LOG | grep -xc "$Return_CODE"
}


<<doc
Count the number of occurrences of all return codes, on the parallel log-file, @Parallel_LOG.
doc
UTILS_Count_CTR()
{
    Parallel_LOG=$@

    CTR_TOTAL=$(wc -l < $Parallel_LOG);
    # Don't count the LOG header
    CTR_TOTAL=$((CTR_TOTAL - 1));
    # Special codes
    CTR_TIMEOUT=$(HELPER_Count_CTR $Parallel_LOG \\$TIMEOUT_CODE);
    CTR_SUCCESS=$(HELPER_Count_CTR $Parallel_LOG $SUCCESS_CODE);
    CTR_OMITTED=$(HELPER_Count_CTR $Parallel_LOG $OMITTED_CODE);
    # Failure codes
    CTR_UNZIP=$(HELPER_Count_CTR $Parallel_LOG $FAILURE_CODE_UNZIP);
    CTR_BUILD=$(HELPER_Count_CTR $Parallel_LOG $FAILURE_CODE_BUILD);
    CTR_CLEAN=$(HELPER_Count_CTR $Parallel_LOG $FAILURE_CODE_CLEAN);
    CTR_QUERY=$(HELPER_Count_CTR $Parallel_LOG $FAILURE_CODE_QUERY);
}


export -f UTILS_Create_CB UTILS_Count_CTR
