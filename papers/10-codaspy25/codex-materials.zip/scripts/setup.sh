echo "Setting up project..."


mkdir -pv $CODEX_DS
mkdir -pv $CODEX_DS_CWS

mkdir -pv $CODEX_CB
mkdir -pv $CODEX_CB_CWS

mkdir -pv $CODEX_DB
mkdir -pv $CODEX_DB_CWS

mkdir -pv $CODEX_CQL
mkdir -pv $CODEX_CQL_CWS

mkdir -pv $CODEX_LOG
mkdir -pv $CODEX_LOG_Unzip
mkdir -pv $CODEX_LOG_Build
mkdir -pv $CODEX_LOG_Clean
mkdir -pv $CODEX_LOG_Query
mkdir -pv $CODEX_LOG_Parallel
