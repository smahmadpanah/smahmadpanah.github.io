# Automatically export the following variables...
set -a

LOCATION_FS="/home/codex"
SNAPSHOT_FS="$LOCATION_FS/experiment"

# ---------- #

# Storage: Snapshot of CWS ecosystem
CODEX_DS="$SNAPSHOT_FS/1_Extension"
CODEX_DS_CWS="$CODEX_DS/CWS"

# Storage: Source Code for each CWS's extension
CODEX_CB="$SNAPSHOT_FS/2_CodeBase"
CODEX_CB_CWS="$CODEX_CB/CWS"

# Storage: CodeQL's generated DataBase
CODEX_DB="$SNAPSHOT_FS/3_DataBase"
CODEX_DB_CWS="$CODEX_DB/CWS"

# ---------- #

# Method: CodeQL's query results
CODEX_CQL="$SNAPSHOT_FS/4_Query"
CODEX_CQL_CWS="$CODEX_CQL/CWS"

# ---------- #

# Log for future debugging
CODEX_LOG="$SNAPSHOT_FS/log"
CODEX_LOG_Unzip="$CODEX_LOG/1_unzip"
CODEX_LOG_Build="$CODEX_LOG/2_build"
CODEX_LOG_Clean="$CODEX_LOG/3_clean"
CODEX_LOG_Query="$CODEX_LOG/4_query"

CODEX_LOG_Parallel="$CODEX_LOG/parallel"

# ---------- #

# Possible return codes for future debugging
TIMEOUT_CODE=-1
SUCCESS_CODE=0
OMITTED_CODE=1
FAILURE_CODE_UNZIP=2
FAILURE_CODE_BUILD=3
FAILURE_CODE_CLEAN=4
FAILURE_CODE_QUERY=5

# Extension of debug/temporary files
CRX_EXTENSION=".crx"
LOG_EXTENSION=".log"
OUT_EXTENSION=".csv"
CQL_EXTENSION=".ql"

set +a
