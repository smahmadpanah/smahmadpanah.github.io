#!/bin/bash

all_reasons_dir=$1

base_out_path=$2

dead_reasons_dir="$base_out_path/dead-reasons"

rm -rf $dead_reasons_dir
mkdir $dead_reasons_dir

while IFS= read -r ext_version
do
    [[ $ext_version =~ (.*)\. ]] && ext="${BASH_REMATCH[1]}"
    cp "$all_reasons_dir/$ext.txt" $dead_reasons_dir
done < "$base_out_path/dead-proper-exts.txt"
