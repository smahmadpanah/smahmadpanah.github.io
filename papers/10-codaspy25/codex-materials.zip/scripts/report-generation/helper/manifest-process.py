import json
import sys
import os
import shutil
from os.path import exists
import codecs



directory = ""
p = "./"

newtab = []
search_provider = []
history = []
topSites = []
cookies = []
bookmarks = []
webRequest = []

permission_types = [ "permissions", "optional_permissions", "host_permissions", "optional_host_permissions" ]

if len(sys.argv) > 1:
    directory = sys.argv[1]
    p = directory + "-manifest-analysis"
    if exists(p):
        try:
            shutil.rmtree(p)
        except:
            print('Folder not deleted')
    os.makedirs(p)
else:
    sys.exit("the analysis path is missing")


f_error = open(p + "/json_load_error.txt", "w")


for ext in os.listdir(directory):

    manifest_path = os.path.join(directory, ext, "manifest.json")
    if os.path.isfile(manifest_path):
        with open(manifest_path, encoding='utf-8-sig') as mf:
            manfiest = set()
            try:
                manfiest = json.load(mf, strict=False)
            except:
                f_error.write(ext + "manifest.json cannot be loaded...\n")
            if "chrome_url_overrides" in manfiest:
                if "newtab" in manfiest["chrome_url_overrides"]:
                  newtab.append(ext)
            if "chrome_settings_overrides" in manfiest:
                if "search_provider" in manfiest["chrome_settings_overrides"]:
                    search_provider.append(ext)
            for perm in permission_types:
                if perm in manfiest:
                    if "history" in manfiest[perm]:
                        history.append(ext)
                    if "topSites" in manfiest[perm]:
                        topSites.append(ext)
                    if "cookies" in manfiest[perm]:
                        cookies.append(ext)
                    if "bookmarks" in manfiest[perm]:
                        bookmarks.append(ext)
                    if "webRequest" in manfiest[perm]:
                        webRequest.append(ext)

        
f_error.close()

with open(p + "/newtab-exts.txt", "w") as txt_file:
    for line in newtab:
        txt_file.write(line + "\n")

with open(p + "/search_provider-exts.txt", "w") as txt_file:
    for line in search_provider:
        txt_file.write(line + "\n")

with open(p + "/history-exts.txt", "w") as txt_file:
    for line in history:
        txt_file.write(line + "\n")

with open(p + "/topSites-exts.txt", "w") as txt_file:
    for line in topSites:
        txt_file.write(line + "\n")

with open(p + "/cookies-exts.txt", "w") as txt_file:
    for line in cookies:
        txt_file.write(line + "\n")

with open(p + "/bookmarks-exts.txt", "w") as txt_file:
    for line in bookmarks:
        txt_file.write(line + "\n")

with open(p + "/webRequest-exts.txt", "w") as txt_file:
    for line in webRequest:
        txt_file.write(line + "\n")
