import sys

dead_reasons_analysis_dir = sys.argv[1]
dead_reasons_file = sys.argv[2]

reasons = {}
with open(dead_reasons_file) as f:
  for line in f:
    ext = line[0:line.find(" : [")]
    rsn = line[line.find(" : [ ")+6:line.find(" ]")]
    reasons[ext] = rsn

for ext, rsn in reasons.items():
  flag = False
  if '_malware="true"' in rsn:
    flag = True
    with open(dead_reasons_analysis_dir + "/dead-malware.txt","a") as file:
        file.write(ext + "\n")
  if '_policy_violation="true"' in rsn:
    flag = True
    with open(dead_reasons_analysis_dir + "/dead-policy_violation.txt","a") as file:
        file.write(ext + "\n")
  if '_potentially_uws="true"' in rsn:
    flag = True
    with open(dead_reasons_analysis_dir + "/dead-potentially_uws.txt","a") as file:
        file.write(ext + "\n")
  if flag is False:
    if '_esbAllowlist="false"' in rsn:
      with open(dead_reasons_analysis_dir + "/dead-suspicious.txt","a") as file:
        file.write(ext + "\n")
    else:
      with open(dead_reasons_analysis_dir + "/dead-benign.txt","a") as file:
        file.write(ext + "\n")