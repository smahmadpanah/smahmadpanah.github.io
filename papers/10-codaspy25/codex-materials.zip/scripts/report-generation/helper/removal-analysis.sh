#!/bin/bash

base_out_path=$1
dead_reasons_dir="$base_out_path/dead-reasons"
dead_reasons_analysis_dir="$base_out_path/dead-reasons-analysis"

rm -rf $dead_reasons_analysis_dir
mkdir $dead_reasons_analysis_dir

for txt in $dead_reasons_dir/*; do
  ext=`basename -- "$txt" .txt`
  if [ "$ext" == "log" ]
    then continue
  fi
  flag=false
  if grep -qe '_malware="true"' "$txt"
    then
      echo $ext >> "$dead_reasons_analysis_dir/dead-malware.txt"
      flag=true
  fi
  if grep -qe '_policy_violation="true"' "$txt"
    then
      echo $ext >> "$dead_reasons_analysis_dir/dead-policy_violation.txt"
      flag=true
  fi
  if grep -qe '_potentially_uws="true"' "$txt"
    then
      echo $ext >> "$dead_reasons_analysis_dir/dead-potentially_uws.txt"
      flag=true
  fi
  if [ "$flag" = false ];
  then 
      if grep -qe '_esbAllowlist="false"' "$txt"
      then
        echo $ext >> "$dead_reasons_analysis_dir/dead-suspicious.txt"
      else
        echo $ext >> "$dead_reasons_analysis_dir/dead-benign.txt"
      fi
    fi
  done