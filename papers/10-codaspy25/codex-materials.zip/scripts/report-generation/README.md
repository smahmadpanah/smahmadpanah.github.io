## Instructions

0) apply the CodeX queries: generates a csv file per extension
1) `./process-result.sh run PATH_TO_QUERY_FILES`: generates
	- `PATH_TO_QUERY_FILES-processed`: creates a dir for each extension, copies the query result csv into the dir, generates txt files for each analysis
	- `PATH_TO_QUERY_FILES-analysis`: generates the overall report saying which extension is marked with what query results
2) `./generate-report.sh` 
`./generate-report.sh PATH_TO_QUERY_FILES-analysis DB_LIST_FILE.txt /PATH/TO/all-proper-extensions.txt /PATH/TO/alive-all.txt /PATH/TO/all-dead-removal-reasons-analysis /PATH/TO/all-exts-manifest-analysis /PATH/TO/last_downloads-4apr2024.csv`
	- generates two directories:
		- `PATH_TO_QUERY_FILES-analysis-input`: copies the input args into this directory to keep track of the inputs. The proper extensions, alive and dead ones are enumerated under the `out` subdirectory generated during the script execution. 
		- `PATH_TO_QUERY_FILES-analysis-report`: final reports are here! the csv file, the log file, and an overview of identified severe, moderate, and uncertain extensions of the dataset. 

## Expected outputs
- `PATH_TO_QUERY_FILES-analysis-processed`: processed analysis per ext
- `PATH_TO_QUERY_FILES-analysis-processed`: a copy of inputs needed for the report generator
- `PATH_TO_QUERY_FILES-analysis`: reporting an overall analysis of the query results, mostly the outputs of `process-result.sh`:
	- `ext-empty-csvs.txt`: **the exts with no query results** (removed in the processed dir)
	- `ext-UI-SURL.txt`: the exts that _JStoSink_ found a path in with _user input detected_ and _a suspicious url_  found (i.e., any url starting with http which is not allowlisted (google,bing,yahoo,duckduckgo) as well [marked _Severe_]
	- `ext-UI-BURL.txt`: the exts that _JStoSink_ found a path in with _user input detected_ and _a maybe benign url_  found as well
	- `ext-UI-noURL.txt`: the exts that _JStoSink_ found a path in with _user input detected_ and _no url_  found [marked _Moderate_]
	- `ext-noUI-SURL.txt`: the exts that _JStoSink_ found a path in with _user input is not detected_ and _a suspicious url_  found [marked _Moderate_]
	- `ext-noUI-BURL.txt`: the exts that _JStoSink_ found a path in with _user input is not detected_ and _a maybe benign url_ found
	- `ext-noUI-noURL.txt`: the exts that _JStoSink_ found a path (_no user input detected, no url found_) **all paths that JStoSink found** [marked _Uncertain_]
	- `ext-form-SURL.txt`: the exts that _InputToFormActionHTML_ found a _suspicious action url_ (i.e., any url starting with http which is not allowlisted (google,bing,yahoo,duckduckgo) [marked _Severe_]
	- `ext-form-BURL.txt`: the exts that _InputToFormActionHTML_ found a _maybe benign action url_
	- `ext-redirect-SURL.txt`: the exts that _RedirectURL_ found a _suspicious target url_ (i.e., any url starting with http which is not allowlisted (google,bing,yahoo,duckduckgo)) [marked _Severe_]
	- `ext-redirect-BURL.txt`: the exts that _RedirectURL_ found a _maybe benign target url_ 
	- `ext-redirect-noURL.txt`: the exts that _RedirectURL_ is found but _not url_ **all paths that RedirectURL found** [marked _Moderate_]
	- `ext-cookie-SURL.txt`: the exts that _CookieStealing_ found a _suspicious target url_ (i.e., any url starting with http) [marked _Severe_]
	- `ext-cookie-noURL-Ssink.txt`: the exts that _CookieStealing_ did _not find a http url_ and the sink is any client request _except for postmessage_  [marked _Moderate_]
	- `ext-cookie-all.txt`: the exts that _CookieStealing_ is found but _not url_ **all paths that CookieStealing found** [marked _Uncertain_]
	- `ext-bookmark-SURL.txt`: the exts that _BookmarkStealing_ found a _suspicious target url_ (i.e., any url starting with http) [marked _Severe_]
	- `ext-bookmark-noURL-Ssink.txt`: the exts that _BookmarkStealing_ did _not find a http url_ and the sink is any client request _except for postmessage_  [marked _Moderate_]
	- `ext-bookmark-all.txt`: the exts that _BookmarkStealing_ is found but _not url_ **all paths that BookmarkStealing found** [marked _Uncertain_]
	- `ext-history-SURL.txt`: the exts that _HistoryStealing_ found a _suspicious target url_ (i.e., any url starting with http) [marked _Severe_]
	- `ext-history-noURL-Ssink.txt`: the exts that _HistoryStealing_ did _not find a http url_ and the sink is any client request _except for postmessage_  [marked _Moderate_]
	- `ext-history-all.txt`: the exts that _HistoryStealing_ is found but _not url_ **all paths that HistoryStealing found** [marked _Uncertain_]
	- `manifest-webRequest-path-detected-exts.txt`: the exts that they require _webRequest permission_ in their manfiest and _RedirectURL has detected_ a path
	- `manifest-webRequest-path-NOTdetected-exts.txt`: the exts that they require _webRequest permission_ in their manfiest but _RedirectURL has NOT detected_ any path
	- `manifest-bookmark-path-detected-exts.txt`: the exts that they require _bookmark or topSites permission_ in their manfiest and _BookmarkStealing has detected_ a path
	- `manifest-bookmark-path-NOT-detected-exts.txt`: the exts that they require _bookmark or topSites permission_ in their manfiest but _BookmarkStealing has NOT detected_ any path
	- `manifest-cookie-path-detected-exts.txt`: the exts that they require _cookie permission_ in their manfiest and _CookieStealing has detected_ a path
	- `manifest-cookie-path-NOT-detected-exts.txt`: the exts that they require _cookie permission_ in their manfiest but _CookieStealing has NOT detected_ any path
	- `manifest-history-path-detected-exts.txt`: the exts that they require _history permission_ in their manfiest and _HistoryStealing has detected_ a path
	- `manifest-history-path-NOT-detected-exts.txt`: the exts that they require _history permission_ in their manfiest but _HistoryStealing has NOT detected_ any path
	- `manifest-newtab-path-detected-exts.txt`: the exts that they require _newtab or search_provider permission_ in their manfiest and _JStoSink or InputToFormActionHTML has detected_ a path
	- `manifest-newtab-NOT-path-detected-exts.txt`: the exts that they require _newtab or search_provider permission_ in their manfiest but _JStoSink or InputToFormActionHTML has NOT detected_ any path

- `PATH_TO_QUERY_FILES-analysis-report`: final reports are here! the csv file, the log file, and an overview of identified severe, moderate, and uncertain extensions of the dataset. 
	- the log file: capturing all the steps of the script execution
	- the csv file: the final csv file, reporting all the details of each extension and the query results as well as manifest and download info
	- `severe-exts.txt`: the list of extensions with severe paths
	- `moderate-exts.txt`: the list of extensions with moderate paths (might inlcude some severe extensions)
	- `uncertain-exts.txt`: the list of extensions with uncertain paths (might inlcude some severe and moderate extensions)
	- `top-n` directory: n is an argument passed by the user. the list of top n most downloaded extensions that are severe/moderate/uncertain for each kind of stealing paths. 
	
## An overview of suspiciousness definitions:
### severe paths
- UI-SURL
- form-SURL
- redirect-SURL
- cookie-SURL
- bookmark-SURL
- history-SURL

### moderate paths
- UI-noURL
- noUI-SURL
- redirect-noURL
- cookie-noURL-Ssink
- bookmark-noURL-Ssink
- history-noURL-Ssink

### uncertain paths
- noUI-noURL
- cookie-all (mostly for the paths going to postmessage without a detected url)
- bookmark-all
- history-all

### benign paths (not interesting)
- UI-BURL
- noUI-BURL
- form-BURL
- redirect-BURL
