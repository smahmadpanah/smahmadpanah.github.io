import os
import sys
import re
import csv

csv_input = sys.argv[1]

newtabOrSearchprovider_list = []
newtabOrSearchprovider_malicious_list = []
newtabOrSearchprovider_suspicious_list = []
newtabOrSearchprovider_uncertain_list = []

cookies_list = []
cookies_malicious_list = []
cookies_suspicious_list = []

history_list = []
history_malicious_list = []
history_suspicious_list = []

bookmarksOrTopsites_list = []
bookmarksOrTopsites_malicious_list = []
bookmarksOrTopsites_suspicious_list = []

webRequest_list = []
webRequest_malicious_list = []
webRequest_suspicious_list = []

with open(csv_input, newline='') as csvfile:
        data = list(csv.reader(csvfile, delimiter=','))


for row in data:
    ext = row[0]
    #permission check
    if re.search(r"newtab|search_provider", row[1]):
        newtabOrSearchprovider_list.append(ext)
        if re.search(r"(^(?!no)UI_SURL)|form_SURL", row[7]):
            newtabOrSearchprovider_malicious_list.append(ext)
        elif re.search(r"(^(?!no)UI_noURL)|noUI_SURL", row[7]):
            newtabOrSearchprovider_suspicious_list.append(ext)
        elif re.search(r"noUI_noURL", row[7]):
            newtabOrSearchprovider_uncertain_list.append(ext)

    if re.search(r"bookmarks|topSites", row[1]):
        bookmarksOrTopsites_list.append(ext)
        if re.search(r"malicious", row[9]):
            bookmarksOrTopsites_malicious_list.append(ext)
        elif re.search(r"postmsg", row[9]):
            bookmarksOrTopsites_suspicious_list.append(ext)
    
    if re.search(r"cookies", row[1]):
        cookies_list.append(ext)
        if re.search(r"malicious", row[11]):
            cookies_malicious_list.append(ext)
        elif re.search(r"postmsg", row[11]):
            cookies_suspicious_list.append(ext)

    if re.search(r"history", row[1]):
        history_list.append(ext)
        if re.search(r"malicious", row[13]):
            history_malicious_list.append(ext)
        elif re.search(r"postmsg", row[13]):
            history_suspicious_list.append(ext)
        
    if re.search(r"webRequest", row[1]):
        try:
            webRequest_list.append(ext)
            if re.search(r"redirect_SURL", row[15]):
                webRequest_malicious_list.append(ext)
            elif re.search(r"redirect_noURL", row[15]):
                webRequest_suspicious_list.append(ext)
        except:
            print(ext)
    






with open('stat/newtabOrSearchprovider_stat.txt', 'w') as f:
    for line in newtabOrSearchprovider_list:
        f.write(f"{line}\n")

with open('stat/newtabOrSearchprovider_malicious_stat.txt', 'w') as f:
    for line in newtabOrSearchprovider_malicious_list:
        f.write(f"{line}\n")

with open('stat/newtabOrSearchprovider_suspicious_stat.txt', 'w') as f:
    for line in newtabOrSearchprovider_suspicious_list:
        f.write(f"{line}\n")

with open('stat/newtabOrSearchprovider_uncertain_stat.txt', 'w') as f:
    for line in newtabOrSearchprovider_uncertain_list:
        f.write(f"{line}\n")


with open('stat/cookies_stat.txt', 'w') as f:
    for line in cookies_list:
        f.write(f"{line}\n")

with open('stat/cookies_malicious_stat.txt', 'w') as f:
    for line in cookies_malicious_list:
        f.write(f"{line}\n")

with open('stat/cookies_suspicious_stat.txt', 'w') as f:
    for line in cookies_suspicious_list:
        f.write(f"{line}\n")

with open('stat/history_stat.txt', 'w') as f:
    for line in history_list:
        f.write(f"{line}\n")

with open('stat/history_malicious_stat.txt', 'w') as f:
    for line in history_malicious_list:
        f.write(f"{line}\n")

with open('stat/history_suspicious_stat.txt', 'w') as f:
    for line in history_suspicious_list:
        f.write(f"{line}\n")

with open('stat/bookmarksOrTopsites_stat.txt', 'w') as f:
    for line in bookmarksOrTopsites_list:
        f.write(f"{line}\n")

with open('stat/bookmarksOrTopsites_malicious_stat.txt', 'w') as f:
    for line in bookmarksOrTopsites_malicious_list:
        f.write(f"{line}\n")

with open('stat/bookmarksOrTopsites_suspicious_stat.txt', 'w') as f:
    for line in bookmarksOrTopsites_suspicious_list:
        f.write(f"{line}\n")

with open('stat/webRequest_stat.txt', 'w') as f:
    for line in webRequest_list:
        f.write(f"{line}\n")

with open('stat/webRequest_malicious_stat.txt', 'w') as f:
    for line in webRequest_malicious_list:
        f.write(f"{line}\n")

with open('stat/webRequest_suspicious_stat.txt', 'w') as f:
    for line in webRequest_suspicious_list:
        f.write(f"{line}\n")        