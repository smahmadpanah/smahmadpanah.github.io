### flow detection accuracy
### [certainty levels: high, medium, low]

## search query flows 
## for exts with 'newtab' or 'search_provider' permissions
# high: UI-BURL + UI-SURL + form-SURL + form-BURL (= UI-URL | form-URL)
# medium: UI-noURL + noUI-SURL + noUI-BURL + form-noURL
# low: noUI-noURL

## redirect url flows
## for exts with 'webRequest' permission
# high: redirect-SURL + redirect-BURL (redirect-URL)
# medium: redirect-noURL

## cookie flows
## for exts with 'cookies' permission
# high: cookie-SURL + cookie-noURL-Ssink (cookie-URL)
# medium: cookie-all

## bookmark flows
## for exts with 'bookmarks' or 'topSites' permission
# high: bookmark-SURL + bookmark-noURL-Ssink (bookmark-URL)
# medium: bookmark-all

## history flows
## for exts with 'history' permission
# high: history-SURL + history-noURL-Ssink (history-URL)
# medium: history-all

###########################################

### suspiciousness severity
### [levels: severe > moderate > uncertain]

### severe paths
#1 UI-SURL
#2 form-SURL
#3 redirect-SURL
#4 cookie-SURL
#5 bookmark-SURL
#6 history-SURL

### moderate paths
#7 form-noURL
#8 UI-noURL
#9 noUI-SURL
#10 redirect-noURL
#11 cookie-noURL-Ssink
#12 bookmark-noURL-Ssink
#13 history-noURL-Ssink

### uncertain paths
#14 noUI-noURL
#15 cookie-all (mostly for the paths going to postmessage without a detected url)
#16 bookmark-all
#17 history-all

### benign paths (not interesting for suspiciousness) - should be reported anyway for flows
#18 UI-BURL
#19 noUI-BURL
#20 form-BURL
#21 redirect-BURL

###########################################

import sys
import os
from os.path import exists
import shutil
import csv
import re

print("\n\n\n\nsuspiciousness analysis started...\n")

# csv row of each ext for printing 
final_csv_rows_ext_dict = {}

# ext -> {severe, moderate, uncertain} -- overall analysis
suspiciousness_ext_dict = {}

severe_ext_dict = {}
moderate_ext_dict = {}
uncertain_ext_dict = {}
maybe_benign_ext_dict = {}

# args
analysis_path = sys.argv[1]
report_path = analysis_path + "-report"
analysis_out_path = sys.argv[2]
all_manifest_analysis_path = sys.argv[3]
dead_reasons_analysis = sys.argv[4]
analysis_dirname = sys.argv[5]
last_download_file = sys.argv[6]
#number_limit = int(sys.argv[7])

##### helper functions
def add_to_suspiciousness_ext_dict(ext, smu_type):
    try:
        suspiciousness_ext_dict[ext].add(smu_type)
    except KeyError:
        suspiciousness_ext_dict[ext] = set()
        suspiciousness_ext_dict[ext].add(smu_type)

def add_to_severe_ext_dict(ext, severe_type):
    try:
        severe_ext_dict[ext].add(severe_type)
    except KeyError:
        severe_ext_dict[ext] = set()
        severe_ext_dict[ext].add(severe_type)

def add_to_moderate_ext_dict(ext, moderate_type):
    try:
        moderate_ext_dict[ext].add(moderate_type)
    except KeyError:
        moderate_ext_dict[ext] = set()
        moderate_ext_dict[ext].add(moderate_type)

def add_to_uncertain_ext_dict(ext, uncertain_type):
    try:
        uncertain_ext_dict[ext].add(uncertain_type)
    except KeyError:
        uncertain_ext_dict[ext] = set()
        uncertain_ext_dict[ext].add(uncertain_type)

def add_to_maybe_benign_ext_dict(ext, benign_type):
    try:
        maybe_benign_ext_dict[ext].add(benign_type)
    except KeyError:
        maybe_benign_ext_dict[ext] = set()
        maybe_benign_ext_dict[ext].add(benign_type)

def file_read_to_set(filename):
    try:
        return set() | set(l.strip() for l in open(filename))
    except:
        print("File Read Error: ", filename, " File exists: ", exists(filename))
        return set()

def write_csv_rows_of_extset_to_file_sorted(ext_set, filename):
    try:
        temp_result = []
        try:
            for ext in ext_set:
                if ext in final_csv_rows_ext_dict:
                    temp_result.append(final_csv_rows_ext_dict[ext])
        except Exception as e: 
                print("Error in finding the csv row of ext ", ext, " while writing into the file ", filename, " -> ", e)
        sorted_temp_result = sorted(temp_result, key=lambda x: int(x[2]), reverse=True)
        with open(filename, 'w') as f:
            for row in sorted_temp_result:
                f.write(f"{','.join(str(v) for v in row)}\n")                
    except Exception as e: 
        print("Error in writing into ", filename, " -> ", e)


def unique_set_of_extset(ext_set):
    return set(re.split(r'\.', extver)[0] for extver in ext_set)

def write_extset_to_file(ext_set, filename):
    try: 
        with open(filename,'w') as f:
            f.write("\n".join(ext_set))
    except Exception as e: 
        print("Error in writing into ", filename)

##### file read

#1 UI-SURL
UI_SURL = file_read_to_set(analysis_path + '/ext-UI-SURL.txt')

#2 form-SURL
form_SURL = file_read_to_set(analysis_path + '/ext-form-SURL.txt')

#3 redirect-SURL
redirect_SURL = file_read_to_set(analysis_path + '/ext-redirect-SURL.txt')

#4 cookie-SURL
cookie_SURL = file_read_to_set(analysis_path + '/ext-cookie-SURL.txt')

#5 bookmark-SURL
bookmark_SURL = file_read_to_set(analysis_path + '/ext-bookmark-SURL.txt')

#6 history-SURL
history_SURL = file_read_to_set(analysis_path + '/ext-history-SURL.txt')

#7 UI-noURL
UI_noURL = file_read_to_set(analysis_path + '/ext-UI-noURL.txt')

#8 noUI-SURL
noUI_SURL = file_read_to_set(analysis_path + '/ext-noUI-SURL.txt')

#9 redirect-noURL
redirect_noURL = file_read_to_set(analysis_path + '/ext-redirect-noURL.txt')

#10 cookie-noURL-Ssink
cookie_noURL_Ssink = file_read_to_set(analysis_path + '/ext-cookie-noURL-Ssink.txt')

#11 bookmark-noURL-Ssink
bookmark_noURL_Ssink = file_read_to_set(analysis_path + '/ext-bookmark-noURL-Ssink.txt')

#12 history-noURL-Ssink
history_noURL_Ssink = file_read_to_set(analysis_path + '/ext-history-noURL-Ssink.txt')

#13 form-noURL
form_noURL = file_read_to_set(analysis_path + '/ext-form-noURL.txt')

#14 noUI-noURL
noUI_noURL = file_read_to_set(analysis_path + '/ext-noUI-noURL.txt')

#15 cookie-all
cookie_all = file_read_to_set(analysis_path + '/ext-cookie-all.txt')

#16 bookmark-all
bookmark_all = file_read_to_set(analysis_path + '/ext-bookmark-all.txt')

#17 history-all
history_all = file_read_to_set(analysis_path + '/ext-history-all.txt')

#18 UI-BURL
UI_BURL = file_read_to_set(analysis_path + '/ext-UI-BURL.txt')

#19 noUI-BURL
noUI_BURL = file_read_to_set(analysis_path + '/ext-noUI-BURL.txt')

#20 form-BURL
form_BURL = file_read_to_set(analysis_path + '/ext-form-BURL.txt')

#21 redirect-BURL
redirect_BURL = file_read_to_set(analysis_path + '/ext-redirect-BURL.txt')


# proper extensions (no themes, no apps)
proper_exts = file_read_to_set(analysis_out_path + '/proper-exts.txt')

# alive proper extensions 
alive_proper_exts = file_read_to_set(analysis_out_path + '/alive-proper-exts.txt')

# dead proper extensions
dead_proper_exts = file_read_to_set(analysis_out_path + '/dead-proper-exts.txt')



# dead reasons
# dead: malware
dead_malware = file_read_to_set(dead_reasons_analysis + '/dead-malware.txt')

# dead: policy violation
dead_policy_violation = file_read_to_set(dead_reasons_analysis + '/dead-policy_violation.txt')

# dead: unwanted software
dead_potentially_uws = file_read_to_set(dead_reasons_analysis + '/dead-potentially_uws.txt')

# dead: suspicious
dead_suspicious = file_read_to_set(dead_reasons_analysis + '/dead-suspicious.txt')

# dead: benign -> it means the ext is still alive and got updated! so it's not dead in fact
#file = dead_reasons_analysis + '/dead-benign.txt'
#dead_benign = set()


# manifest sets
manifest_bookmarks = file_read_to_set(all_manifest_analysis_path + '/bookmarks-exts.txt')

manifest_cookies = file_read_to_set(all_manifest_analysis_path + '/cookies-exts.txt')

manifest_history = file_read_to_set(all_manifest_analysis_path + '/history-exts.txt')

manifest_newtab = file_read_to_set(all_manifest_analysis_path + '/newtab-exts.txt')

manifest_search_provider = file_read_to_set(all_manifest_analysis_path + '/search_provider-exts.txt')

manifest_topSites = file_read_to_set(all_manifest_analysis_path + '/topSites-exts.txt')

manifest_webRequest = file_read_to_set(all_manifest_analysis_path + '/webRequest-exts.txt')

######## file read done



os.mkdir(report_path + '/overall')

### severe paths of an extenstion
#1 UI-SURL
for ext in UI_SURL:
    add_to_severe_ext_dict(ext, "UI-SURL")
    add_to_suspiciousness_ext_dict(ext, "severe")

#2 form-SURL
for ext in form_SURL:
    add_to_severe_ext_dict(ext, "form-SURL")
    add_to_suspiciousness_ext_dict(ext, "severe")

#3 redirect-SURL
for ext in redirect_SURL:
    add_to_severe_ext_dict(ext, "redirect-SURL")
    add_to_suspiciousness_ext_dict(ext, "severe")

#4 cookie-SURL
for ext in cookie_SURL:
    add_to_severe_ext_dict(ext, "cookie-SURL")
    add_to_suspiciousness_ext_dict(ext, "severe")

#5 bookmark-SURL
for ext in bookmark_SURL:
    add_to_severe_ext_dict(ext, "bookmark-SURL")
    add_to_suspiciousness_ext_dict(ext, "severe")

#6 history-SURL
for ext in history_SURL:
    add_to_severe_ext_dict(ext, "history-SURL")
    add_to_suspiciousness_ext_dict(ext, "severe")

with open(report_path + '/overall/severe-exts.txt', 'w') as f:
    for ext in severe_ext_dict:
        f.write(f"{ext}, {severe_ext_dict[ext]}\n")

write_extset_to_file(unique_set_of_extset(severe_ext_dict.keys()), report_path + '/overall/unique-severe-exts.txt')



### moderate paths of an extenstion
#7 form-noURL
for ext in form_noURL:
    add_to_moderate_ext_dict(ext, "form-noURL")
    add_to_suspiciousness_ext_dict(ext, "moderate")

#8 UI-noURL
for ext in UI_noURL:
    add_to_moderate_ext_dict(ext, "UI-noURL")
    add_to_suspiciousness_ext_dict(ext, "moderate")

#9 noUI-SURL
for ext in noUI_SURL:
    add_to_moderate_ext_dict(ext, "noUI-SURL")
    add_to_suspiciousness_ext_dict(ext, "moderate")

#10 redirect-noURL
for ext in redirect_noURL:
    add_to_moderate_ext_dict(ext, "redirect-noURL")
    add_to_suspiciousness_ext_dict(ext, "moderate")

#11 cookie-noURL-Ssink
for ext in cookie_noURL_Ssink:
    add_to_moderate_ext_dict(ext, "cookie-noURL-Ssink")
    add_to_suspiciousness_ext_dict(ext, "moderate")

#12 bookmark-noURL-Ssink
for ext in bookmark_noURL_Ssink:
    add_to_moderate_ext_dict(ext, "bookmark-noURL-Ssink")
    add_to_suspiciousness_ext_dict(ext, "moderate")

#13 history-noURL-Ssink
for ext in history_noURL_Ssink:
    add_to_moderate_ext_dict(ext, "history-noURL-Ssink")
    add_to_suspiciousness_ext_dict(ext, "moderate")

with open(report_path + '/overall/moderate-exts.txt', 'w') as f:
    for ext in moderate_ext_dict:
        f.write(f"{ext}, {moderate_ext_dict[ext]}\n")

write_extset_to_file(unique_set_of_extset(moderate_ext_dict.keys()), report_path + '/overall/unique-moderate-exts.txt')


### uncertain paths of an extenstion
#14 noUI-noURL
for ext in noUI_noURL:
    add_to_uncertain_ext_dict(ext, "noUI-noURL")
    add_to_suspiciousness_ext_dict(ext, "uncertain")

#15 cookie-all
for ext in cookie_all:
    add_to_uncertain_ext_dict(ext, "cookie-all")
    add_to_suspiciousness_ext_dict(ext, "uncertain")

#16 bookmark-all
for ext in bookmark_all:
    add_to_uncertain_ext_dict(ext, "bookmark-all")
    add_to_suspiciousness_ext_dict(ext, "uncertain")

#17 history-all
for ext in history_all:
    add_to_uncertain_ext_dict(ext, "history-all")
    add_to_suspiciousness_ext_dict(ext, "uncertain")

with open(report_path + '/overall/uncertain-exts.txt', 'w') as f:
    for ext in uncertain_ext_dict:
        f.write(f"{ext}, {uncertain_ext_dict[ext]}\n")

write_extset_to_file(unique_set_of_extset(uncertain_ext_dict.keys()), report_path + '/overall/unique-uncertain-exts.txt')


### benign paths of an extenstion
# just for the sake of completeness 
#18 UI-BURL
for ext in UI_BURL:
    add_to_maybe_benign_ext_dict(ext, "UI-BURL")
    add_to_suspiciousness_ext_dict(ext, "maybe benign")

#19 noUI-BURL
for ext in noUI_BURL:
    add_to_maybe_benign_ext_dict(ext, "noUI-BURL")
    add_to_suspiciousness_ext_dict(ext, "maybe benign")

#20 form-BURL
for ext in form_BURL:
    add_to_maybe_benign_ext_dict(ext, "form-BURL")
    add_to_suspiciousness_ext_dict(ext, "maybe benign")

#21 redirect-BURL
for ext in redirect_BURL:
    add_to_maybe_benign_ext_dict(ext, "redirect-BURL")
    add_to_suspiciousness_ext_dict(ext, "maybe benign")

with open(report_path + '/overall/exts-with-benign-flows.txt', 'w') as f:
    for ext in maybe_benign_ext_dict:
        f.write(f"{ext}, {maybe_benign_ext_dict[ext]}\n")

write_extset_to_file(unique_set_of_extset(maybe_benign_ext_dict.keys()), report_path + '/overall/unique-maybe_benign-exts.txt')


### done with suspiciousness overall analysis




# last downloads of extensions 
last_download_exts = {}
try:
    with open(last_download_file, newline='') as last_download:
        reader = csv.reader(last_download, delimiter=',')
        for line in reader:
            last_download_exts[line[0]] = int(line[-1]) 
            #last column is the num of downloads
except Exception as e: 
    print("Download File Read Error: ", e)

# descending sort of downloads
sorted_last_downloads_exts = sorted(last_download_exts.items(), key=lambda item: item[1], reverse=True)





# generating the csv output...
csv_file = open(report_path + "/" + analysis_dirname + "-analysis-report-sorted-by-severity.csv", "w")

manifest_of_exts = {}

for ext, smu in suspiciousness_ext_dict.items():

    if ext not in proper_exts:
        continue

    row = {}
    row['ext_id'] = ext
    row['title'] = ' '

    try:
        # we name number of downloads as #users, same as chrome web store
        row['#users'] = last_download_exts[ext]
    except:
        row['#users'] = '-1' #for the exts with unknown number of downloads

    # permission list
    permission_type = ""
    if ext in manifest_bookmarks:
        permission_type += "bookmarks | "
    if ext in manifest_cookies:
        permission_type += "cookies | "
    if ext in manifest_history:
        permission_type += "history | "
    if ext in manifest_newtab:
        permission_type += "newtab | "
    if ext in manifest_search_provider:
        permission_type += "search_provider | "
    if ext in manifest_topSites:
        permission_type += "topSites | "
    if ext in manifest_webRequest:
        permission_type += "webRequest | "
    if permission_type == "":
        permission_type = "-"

    permission_type = permission_type.rstrip(" | ")
    manifest_of_exts[ext] = permission_type
    row['permissions'] = permission_type


    if "severe" in smu:
        row['severe'] = 'severe'
    else:
        row['severe'] = '-'
    if "moderate" in smu:
        row['moderate'] = 'moderate'
    else:
        row['moderate'] = '-'
    if "uncertain" in smu:
        row['uncertain'] = 'uncertain'
    else:
        row['uncertain'] = '-'
    

    # alive/removed?
    if ext in alive_proper_exts:
        row['alive/removed'] = 'alive'
        row['removal_reason'] = '-'
    elif ext in dead_proper_exts:
        row['alive/removed'] = 'removed'


    # reason of removal
    ext_name_only = re.split(r'\.', ext)[0] #removing the version from the ext id
    if ext_name_only in dead_malware:
        row['removal_reason'] = "malware"
    elif ext_name_only in dead_policy_violation:
        row['removal_reason'] = "policy_violation"
    elif ext_name_only in dead_potentially_uws:
        row['removal_reason'] = "potentially_uws"
    elif ext_name_only in dead_suspicious:
        row['removal_reason'] = "suspicious"


    # search query types
    search_query_type = ""
    if ext in UI_SURL:
        search_query_type += "UI_SURL [S] | "
    if ext in form_SURL:
        search_query_type += "form_SURL [S] | "
    if ext in form_noURL:
        search_query_type += "form_noURL [M] | "
    if ext in UI_noURL:
        search_query_type += "UI_noURL [M] | "
    if ext in noUI_SURL:
        search_query_type += "noUI_SURL [M] | "
    if ext in noUI_noURL:
        search_query_type += "noUI_noURL [U] | "
    if ext in UI_BURL:
        search_query_type += "UI_BURL [B] | "
    if ext in noUI_BURL:
        search_query_type += "noUI_BURL [B] | "
    if ext in form_BURL:
        search_query_type += "form_BURL [B] | "
    if search_query_type == "":
        search_query_type = "-"

    search_query_type = search_query_type.rstrip(" | ")
    row['search_query_type'] = search_query_type
    # evaled?
    if (row['search_query_type'] == "-") :
        row['search_query_type_evaled'] = "-"
    else:
        row['search_query_type_evaled'] = " "

    row['search_feature_evaled'] = " "
    row['search_url_evaled'] = " "


    # bookmark
    if ext in bookmark_SURL:
        row['bookmark'] = 'bookmark_SURL [S]'
    elif ext in bookmark_noURL_Ssink:
        row['bookmark'] = 'bookmark_noURL_Ssink [M]'
    elif ext in bookmark_all:
        row['bookmark'] = 'bookmark_all [U]'
    else:
        row['bookmark'] = '-'
    # evaled?
    if (row['bookmark'] == "-") :
        row['bookmark_evaled'] = "-"
    else:
        row['bookmark_evaled'] = " "


    # cookie
    if ext in cookie_SURL:
        row['cookie'] = "cookie_SURL [S]"
    elif ext in cookie_noURL_Ssink:
        row['cookie'] = "cookie_noURL_Ssink [M]"
    elif ext in cookie_all:
        row['cookie'] = "cookie_all [U]"
    else:
        row['cookie'] = "-"
    # evaled?
    if (row['cookie'] == "-"):
        row['cookie_evaled'] = "-"
    else:
        row['cookie_evaled'] = " "

    # history
    if ext in history_SURL:
        row['history'] = "history_SURL [S]"
    elif ext in history_noURL_Ssink:
        row['history'] = "history_noURL_Ssink [M]"
    elif ext in history_all:
        row['history'] = "history_all [U]"
    else:
        row['history'] = "-"
    # evaled?
    if (row['history'] == "-"):
        row['history_evaled'] = "-"
    else:
        row['history_evaled'] = " "


    # redirect url
    redirect_url_type = ""
    if ext in redirect_SURL:
        redirect_url_type += "redirect_SURL [S] | "
    if ext in redirect_BURL:
        redirect_url_type += "redirect_BURL [B] | "
    if ext in redirect_noURL:
        redirect_url_type += "redirect_noURL [M] | "
    if redirect_url_type == "":
        redirect_url_type = "-"

    redirect_url_type = redirect_url_type.rstrip(" | ")
    row['redirect_url_type'] = redirect_url_type
    # evaled?
    if (row['redirect_url_type'] == "-"):
        row['redirect_url_type_evaled'] = "-"
    else:
        row['redirect_url_type_evaled'] = " "




    csv_row = [] 
    try:
        csv_row.extend([row['ext_id'], row['title'], row['#users'], row['permissions'], row['severe'], row['moderate'], row['uncertain'], row['alive/removed'], row['removal_reason'], row['search_query_type'], row['search_query_type_evaled'], row['search_feature_evaled'], row['search_url_evaled'], row['bookmark'], row['bookmark_evaled'], row['cookie'], row['cookie_evaled'], row['history'], row['history_evaled'], row['redirect_url_type'], row['redirect_url_type_evaled']])
        final_csv_rows_ext_dict[ext] = csv_row
    except Exception as e: 
        print("Error in generating the csv row for ", ext, " because of ",  e)

    csv.writer(csv_file, dialect='excel').writerow(csv_row)

csv_file.close()

# sorted final csv by number of users/downloads
sorted_final_csv_rows_ext_list = sorted(final_csv_rows_ext_dict.items(), key=lambda x: int(x[1][2]), reverse=True)
with open(report_path + "/" + analysis_dirname + "-analysis-report-sorted-by-users.csv", "w") as f:
    csv_writer = csv.writer(f, dialect='excel')
    for item in sorted_final_csv_rows_ext_list:
        csv_writer.writerow(item[1])




########## Search Query ##########

searchquery_flowsandsuspicious_dirpath = report_path + '/search_query_report'
searchquery_flows_dirpath = searchquery_flowsandsuspicious_dirpath + '/flows'
searchquery_suspicious_dirpath = searchquery_flowsandsuspicious_dirpath + '/suspicious'
os.mkdir(searchquery_flowsandsuspicious_dirpath)
os.mkdir(searchquery_flows_dirpath)
os.mkdir(searchquery_suspicious_dirpath)

manifest_newtab_or_searchprovider = manifest_newtab | manifest_search_provider


# search query detected flows in the exts with either newtab or search_provider permission in their manifest

high_certain_searchquery_flows = UI_BURL | UI_SURL | form_SURL | form_BURL
medium_certain_searchquery_flows = UI_noURL | noUI_SURL | noUI_BURL | form_noURL
low_certain_searchquery_flows = noUI_noURL

# only search_provider permission, various certainty for the detected search query flows
write_csv_rows_of_extset_to_file_sorted(manifest_search_provider.intersection(high_certain_searchquery_flows), searchquery_flows_dirpath + '/high_certain_searchquery_flows-search_provider-exts.txt')
write_csv_rows_of_extset_to_file_sorted(manifest_search_provider.intersection(medium_certain_searchquery_flows), searchquery_flows_dirpath + '/medium_certain_searchquery_flows-search_provider-exts.txt')
write_csv_rows_of_extset_to_file_sorted(manifest_search_provider.intersection(low_certain_searchquery_flows), searchquery_flows_dirpath + '/low_certain_searchquery_flows-search_provider-exts.txt')

# only newtab permission, various certainty for the detected search query flows
write_csv_rows_of_extset_to_file_sorted(manifest_newtab.intersection(high_certain_searchquery_flows), searchquery_flows_dirpath + '/high_certain_searchquery_flows-newtab-exts.txt')
write_csv_rows_of_extset_to_file_sorted(manifest_newtab.intersection(medium_certain_searchquery_flows), searchquery_flows_dirpath + '/medium_certain_searchquery_flows-newtab-exts.txt')
write_csv_rows_of_extset_to_file_sorted(manifest_newtab.intersection(low_certain_searchquery_flows), searchquery_flows_dirpath + '/low_certain_searchquery_flows-newtab-exts.txt')

# newtab or search_provider permissions, various certainty for the detected search query flows
write_csv_rows_of_extset_to_file_sorted(manifest_newtab_or_searchprovider.intersection(high_certain_searchquery_flows), searchquery_flows_dirpath + '/high_certain_searchquery_flows-newtab_or_search_provider-exts.txt')
write_csv_rows_of_extset_to_file_sorted(manifest_newtab_or_searchprovider.intersection(medium_certain_searchquery_flows), searchquery_flows_dirpath + '/medium_certain_searchquery_flows-newtab_or_search_provider-exts.txt')
write_csv_rows_of_extset_to_file_sorted(manifest_newtab_or_searchprovider.intersection(low_certain_searchquery_flows), searchquery_flows_dirpath + '/low_certain_searchquery_flows-newtab_or_search_provider-exts.txt')


all_searchquery_detected_flows = low_certain_searchquery_flows | medium_certain_searchquery_flows | high_certain_searchquery_flows

write_csv_rows_of_extset_to_file_sorted(manifest_search_provider.intersection(all_searchquery_detected_flows), searchquery_flows_dirpath + '/a-flow-detected-and-search_provider-exts.txt')
write_extset_to_file(manifest_search_provider.difference(all_searchquery_detected_flows), searchquery_flows_dirpath + '/no-flow-detected-and-search_provider-exts.txt')

write_csv_rows_of_extset_to_file_sorted(manifest_newtab.intersection(all_searchquery_detected_flows), searchquery_flows_dirpath + '/a-flow-detected-and-newtab-exts.txt')
write_extset_to_file(manifest_newtab.difference(all_searchquery_detected_flows), searchquery_flows_dirpath + '/no-flow-detected-and-newtab-exts.txt')

write_csv_rows_of_extset_to_file_sorted(manifest_newtab_or_searchprovider.intersection(all_searchquery_detected_flows), searchquery_flows_dirpath + '/a-flow-detected-and-newtab-or-search_provider-exts.txt')
write_extset_to_file(manifest_newtab_or_searchprovider.difference(all_searchquery_detected_flows), searchquery_flows_dirpath + '/no-flow-detected-and-newtab-or-search_provider-exts.txt')


# search query suspicious analysis report in the exts with either newtab or search_provider permission in their manifest

severe_searchquery_suspicious_exts = UI_SURL | form_SURL
moderate_searchquery_suspicious_exts = UI_noURL | noUI_SURL | form_noURL
uncertain_searchquery_suspicious_exts = noUI_noURL
maybe_benign_searchquery_suspicious_exts = UI_BURL | noUI_BURL | form_BURL

# only search_provider permission in their manifest
write_csv_rows_of_extset_to_file_sorted(manifest_search_provider.intersection(severe_searchquery_suspicious_exts), searchquery_suspicious_dirpath + '/severe_searchquery_suspicious-search_provider-exts.txt')
write_extset_to_file(unique_set_of_extset(manifest_search_provider.intersection(severe_searchquery_suspicious_exts)), searchquery_suspicious_dirpath + '/unique-severe_searchquery_suspicious-search_provider-exts.txt')
write_csv_rows_of_extset_to_file_sorted(manifest_search_provider.intersection(moderate_searchquery_suspicious_exts), searchquery_suspicious_dirpath + '/moderate_searchquery_suspicious-search_provider-exts.txt')
write_extset_to_file(unique_set_of_extset(manifest_search_provider.intersection(moderate_searchquery_suspicious_exts)), searchquery_suspicious_dirpath + '/unique-moderate_searchquery_suspicious-search_provider-exts.txt')
write_csv_rows_of_extset_to_file_sorted(manifest_search_provider.intersection(uncertain_searchquery_suspicious_exts), searchquery_suspicious_dirpath + '/uncertain_searchquery_suspicious-search_provider-exts.txt')
write_extset_to_file(unique_set_of_extset(manifest_search_provider.intersection(uncertain_searchquery_suspicious_exts)), searchquery_suspicious_dirpath + '/unique-uncertain_searchquery_suspicious-search_provider-exts.txt')

# only newtab permission in their manifest
write_csv_rows_of_extset_to_file_sorted(manifest_newtab.intersection(severe_searchquery_suspicious_exts), searchquery_suspicious_dirpath + '/severe_searchquery_suspicious-newtab-exts.txt')
write_extset_to_file(unique_set_of_extset(manifest_newtab.intersection(severe_searchquery_suspicious_exts)),searchquery_suspicious_dirpath + '/unique-severe_searchquery_suspicious-newtab-exts.txt')
write_csv_rows_of_extset_to_file_sorted(manifest_newtab.intersection(moderate_searchquery_suspicious_exts), searchquery_suspicious_dirpath + '/moderate_searchquery_suspicious-newtab-exts.txt')
write_extset_to_file(unique_set_of_extset(manifest_newtab.intersection(moderate_searchquery_suspicious_exts)), searchquery_suspicious_dirpath + '/unique-moderate_searchquery_suspicious-newtab-exts.txt')
write_csv_rows_of_extset_to_file_sorted(manifest_newtab.intersection(uncertain_searchquery_suspicious_exts), searchquery_suspicious_dirpath + '/uncertain_searchquery_suspicious-newtab-exts.txt')
write_extset_to_file(unique_set_of_extset(manifest_newtab.intersection(uncertain_searchquery_suspicious_exts)), searchquery_suspicious_dirpath + '/unique-uncertain_searchquery_suspicious-newtab-exts.txt')

# either search_provider or newtab permission in their manifest
write_csv_rows_of_extset_to_file_sorted(manifest_newtab_or_searchprovider.intersection(severe_searchquery_suspicious_exts), searchquery_suspicious_dirpath + '/severe_searchquery_suspicious-newtab-or-search_provider-exts.txt')
write_extset_to_file(unique_set_of_extset(manifest_newtab_or_searchprovider.intersection(severe_searchquery_suspicious_exts)), searchquery_suspicious_dirpath + '/unique-severe_searchquery_suspicious-newtab-or-search_provider-exts.txt')
write_csv_rows_of_extset_to_file_sorted(manifest_newtab_or_searchprovider.intersection(moderate_searchquery_suspicious_exts), searchquery_suspicious_dirpath + '/moderate_searchquery_suspicious-newtab-or-search_provider-exts.txt')
write_extset_to_file(unique_set_of_extset(manifest_newtab_or_searchprovider.intersection(moderate_searchquery_suspicious_exts)), searchquery_suspicious_dirpath + '/unique-moderate_searchquery_suspicious-newtab-or-search_provider-exts.txt')
write_csv_rows_of_extset_to_file_sorted(manifest_newtab_or_searchprovider.intersection(uncertain_searchquery_suspicious_exts), searchquery_suspicious_dirpath + '/uncertain_searchquery_suspicious-newtab-or-search_provider-exts.txt')
write_extset_to_file(unique_set_of_extset(manifest_newtab_or_searchprovider.intersection(uncertain_searchquery_suspicious_exts)), searchquery_suspicious_dirpath + '/unique-uncertain_searchquery_suspicious-newtab-or-search_provider-exts.txt')

all_searchquery_suspicious_exts = severe_searchquery_suspicious_exts | moderate_searchquery_suspicious_exts | uncertain_searchquery_suspicious_exts

write_csv_rows_of_extset_to_file_sorted(manifest_search_provider.intersection(all_searchquery_suspicious_exts), searchquery_suspicious_dirpath + '/a-suspicious_flow-detected-and-search_provider-exts.txt')
write_extset_to_file(manifest_search_provider.difference(all_searchquery_suspicious_exts), searchquery_suspicious_dirpath + '/no-suspicious_flow-detected-and-search_provider-exts.txt')

write_csv_rows_of_extset_to_file_sorted(manifest_newtab.intersection(all_searchquery_suspicious_exts), searchquery_suspicious_dirpath + '/a-suspicious_flow-detected-and-newtab-exts.txt')
write_extset_to_file(manifest_newtab.difference(all_searchquery_suspicious_exts), searchquery_suspicious_dirpath + '/no-suspicious_flow-detected-and-newtab-exts.txt')

write_csv_rows_of_extset_to_file_sorted(manifest_newtab_or_searchprovider.intersection(all_searchquery_suspicious_exts), searchquery_suspicious_dirpath + '/a-suspicious_flow-detected-and-newtab-or-search_provider-exts.txt')
write_extset_to_file(manifest_newtab_or_searchprovider.difference(all_searchquery_suspicious_exts), searchquery_suspicious_dirpath + '/no-suspicious_flow-detected-and-newtab-or-search_provider-exts.txt')

########## end of Search Query ##########






########## RedirectURL ##########
redirecturl_flowsandsuspicious_dirpath = report_path + '/redirectURL_report'
redirecturl_flows_dirpath = redirecturl_flowsandsuspicious_dirpath + '/flows'
redirecturl_suspicious_dirpath = redirecturl_flowsandsuspicious_dirpath + '/suspicious'
os.mkdir(redirecturl_flowsandsuspicious_dirpath)
os.mkdir(redirecturl_flows_dirpath)
os.mkdir(redirecturl_suspicious_dirpath)

# RedirectURL detected flows in the exts with webRequest permission in their manifest
high_certain_redirecturl_flows = redirect_SURL | redirect_BURL
medium_certain_redirecturl_flows = redirect_noURL

write_csv_rows_of_extset_to_file_sorted(manifest_webRequest.intersection(high_certain_redirecturl_flows), redirecturl_flows_dirpath + '/high_certain_redirecturl_flows-webRequest-exts.txt')
write_csv_rows_of_extset_to_file_sorted(manifest_webRequest.intersection(medium_certain_redirecturl_flows), redirecturl_flows_dirpath + '/medium_certain_redirecturl_flows-webRequest-exts.txt')

all_redirecturl_detected_flows = high_certain_redirecturl_flows | medium_certain_redirecturl_flows

write_csv_rows_of_extset_to_file_sorted(manifest_webRequest.intersection(all_redirecturl_detected_flows), redirecturl_flows_dirpath + '/a-flow-detected-and-webRequest-exts.txt')
write_extset_to_file(manifest_webRequest.difference(all_redirecturl_detected_flows), redirecturl_flows_dirpath + '/no-flow-detected-and-webRequest-exts.txt')

# RedirectURL suspicious analysis report in the exts with webRequest permission in their manifest

severe_redirecturl_suspicious_exts = redirect_SURL
moderate_redirecturl_suspicious_exts = redirect_noURL
maybe_benign_redirecturl_suspicious_exts = redirect_BURL

write_csv_rows_of_extset_to_file_sorted(manifest_webRequest.intersection(severe_redirecturl_suspicious_exts), redirecturl_suspicious_dirpath + '/severe_redirecturl_suspicious-webRequest-exts.txt')
write_extset_to_file(unique_set_of_extset(manifest_webRequest.intersection(severe_redirecturl_suspicious_exts)), redirecturl_suspicious_dirpath + '/unique-severe_redirecturl_suspicious-webRequest-exts.txt')
write_csv_rows_of_extset_to_file_sorted(manifest_webRequest.intersection(moderate_redirecturl_suspicious_exts), redirecturl_suspicious_dirpath + '/moderate_redirecturl_suspicious-webRequest-exts.txt')
write_extset_to_file(unique_set_of_extset(manifest_webRequest.intersection(moderate_redirecturl_suspicious_exts)), redirecturl_suspicious_dirpath + '/unique-moderate_redirecturl_suspicious-webRequest-exts.txt')

all_redirecturl_suspicious_exts = severe_redirecturl_suspicious_exts | moderate_redirecturl_suspicious_exts 

write_csv_rows_of_extset_to_file_sorted(manifest_webRequest.intersection(all_redirecturl_suspicious_exts), redirecturl_suspicious_dirpath + '/a-suspicious_flow-detected-and-webRequest-exts.txt')
write_extset_to_file(manifest_webRequest.difference(all_redirecturl_suspicious_exts), redirecturl_suspicious_dirpath + '/no-suspicious_flow-detected-and-webRequest-exts.txt')

########## end of RedirectURL ##########



########## Cookie ##########
cookie_flowsandsuspicious_dirpath = report_path + '/cookie_report'
cookie_flows_dirpath = cookie_flowsandsuspicious_dirpath + '/flows'
cookie_suspicious_dirpath = cookie_flowsandsuspicious_dirpath + '/suspicious'
os.mkdir(cookie_flowsandsuspicious_dirpath)
os.mkdir(cookie_flows_dirpath)
os.mkdir(cookie_suspicious_dirpath)

# Cookie detected flows in the exts with cookies permission in their manifest
high_certain_cookie_flows = cookie_SURL | cookie_noURL_Ssink
medium_certain_cookie_flows = cookie_all

write_csv_rows_of_extset_to_file_sorted(manifest_cookies.intersection(high_certain_cookie_flows), cookie_flows_dirpath + '/high_certain_cookie_flows-cookies-exts.txt')
write_csv_rows_of_extset_to_file_sorted(manifest_cookies.intersection(medium_certain_cookie_flows), cookie_flows_dirpath + '/medium_certain_cookie_flows-cookies-exts.txt')

all_cookie_detected_flows = high_certain_cookie_flows | medium_certain_cookie_flows

write_csv_rows_of_extset_to_file_sorted(manifest_cookies.intersection(all_cookie_detected_flows), cookie_flows_dirpath + '/a-flow-detected-and-cookies-exts.txt')
write_extset_to_file(manifest_cookies.difference(all_cookie_detected_flows), cookie_flows_dirpath + '/no-flow-detected-and-cookies-exts.txt')

# Cookie suspicious analysis report in the exts with cookies permission in their manifest

severe_cookie_suspicious_exts = cookie_SURL
moderate_cookie_suspicious_exts = cookie_noURL_Ssink
uncertain_cookie_suspicious_exts = cookie_all

write_csv_rows_of_extset_to_file_sorted(manifest_cookies.intersection(severe_cookie_suspicious_exts), cookie_suspicious_dirpath + '/severe_cookie_suspicious-cookies-exts.txt')
write_extset_to_file(unique_set_of_extset(manifest_cookies.intersection(severe_cookie_suspicious_exts)), cookie_suspicious_dirpath + '/unique-severe_cookie_suspicious-cookies-exts.txt')
write_csv_rows_of_extset_to_file_sorted(manifest_cookies.intersection(moderate_cookie_suspicious_exts), cookie_suspicious_dirpath + '/moderate_cookie_suspicious-cookies-exts.txt')
write_extset_to_file(unique_set_of_extset(manifest_cookies.intersection(moderate_cookie_suspicious_exts)), cookie_suspicious_dirpath + '/unique-moderate_cookie_suspicious-cookies-exts.txt')
write_csv_rows_of_extset_to_file_sorted(manifest_cookies.intersection(uncertain_cookie_suspicious_exts), cookie_suspicious_dirpath + '/uncertain_cookie_suspicious-cookies-exts.txt')
write_extset_to_file(unique_set_of_extset(manifest_cookies.intersection(uncertain_cookie_suspicious_exts)), cookie_suspicious_dirpath + '/unique-uncertain_cookie_suspicious-cookies-exts.txt')

all_cookie_suspicious_exts = severe_cookie_suspicious_exts | moderate_cookie_suspicious_exts | uncertain_cookie_suspicious_exts

write_csv_rows_of_extset_to_file_sorted(manifest_cookies.intersection(all_cookie_suspicious_exts), cookie_suspicious_dirpath + '/a-suspicious_flow-detected-and-cookies-exts.txt')
write_extset_to_file(manifest_cookies.difference(all_cookie_suspicious_exts), cookie_suspicious_dirpath + '/no-suspicious_flow-detected-and-cookies-exts.txt')

########## end of Cookie ##########


########## History ##########
history_flowsandsuspicious_dirpath = report_path + '/history_report'
history_flows_dirpath = history_flowsandsuspicious_dirpath + '/flows'
history_suspicious_dirpath = history_flowsandsuspicious_dirpath + '/suspicious'
os.mkdir(history_flowsandsuspicious_dirpath)
os.mkdir(history_flows_dirpath)
os.mkdir(history_suspicious_dirpath)

# History detected flows in the exts with history permission in their manifest
high_certain_history_flows = history_SURL | history_noURL_Ssink
medium_certain_history_flows = history_all

write_csv_rows_of_extset_to_file_sorted(manifest_history.intersection(high_certain_history_flows), history_flows_dirpath + '/high_certain_history_flows-history-exts.txt')
write_csv_rows_of_extset_to_file_sorted(manifest_history.intersection(medium_certain_history_flows), history_flows_dirpath + '/medium_certain_history_flows-history-exts.txt')

all_history_detected_flows = high_certain_history_flows | medium_certain_history_flows

write_csv_rows_of_extset_to_file_sorted(manifest_history.intersection(all_history_detected_flows), history_flows_dirpath + '/a-flow-detected-and-history-exts.txt')
write_extset_to_file(manifest_history.difference(all_history_detected_flows), history_flows_dirpath + '/no-flow-detected-and-history-exts.txt')

# History suspicious analysis report in the exts with history permission in their manifest

severe_history_suspicious_exts = history_SURL
moderate_history_suspicious_exts = history_noURL_Ssink
uncertain_history_suspicious_exts = history_all

write_csv_rows_of_extset_to_file_sorted(manifest_history.intersection(severe_history_suspicious_exts), history_suspicious_dirpath + '/severe_history_suspicious-history-exts.txt')
write_extset_to_file(unique_set_of_extset(manifest_history.intersection(severe_history_suspicious_exts)), history_suspicious_dirpath + '/unique-severe_history_suspicious-history-exts.txt')
write_csv_rows_of_extset_to_file_sorted(manifest_history.intersection(moderate_history_suspicious_exts), history_suspicious_dirpath + '/moderate_history_suspicious-history-exts.txt')
write_extset_to_file(unique_set_of_extset(manifest_history.intersection(moderate_history_suspicious_exts)), history_suspicious_dirpath + '/unique-moderate_history_suspicious-history-exts.txt')
write_csv_rows_of_extset_to_file_sorted(manifest_history.intersection(uncertain_history_suspicious_exts), history_suspicious_dirpath + '/uncertain_history_suspicious-history-exts.txt')
write_extset_to_file(unique_set_of_extset(manifest_history.intersection(uncertain_history_suspicious_exts)), history_suspicious_dirpath + '/unique-uncertain_history_suspicious-history-exts.txt')

all_history_suspicious_exts = severe_history_suspicious_exts | moderate_history_suspicious_exts | uncertain_history_suspicious_exts

write_csv_rows_of_extset_to_file_sorted(manifest_history.intersection(all_history_suspicious_exts), history_suspicious_dirpath + '/a-suspicious_flow-detected-and-history-exts.txt')
write_extset_to_file(manifest_history.difference(all_history_suspicious_exts), history_suspicious_dirpath + '/no-suspicious_flow-detected-and-history-exts.txt')

########## end of History ##########


########## Bookmark ##########
bookmark_flowsandsuspicious_dirpath = report_path + '/bookmark_report'
bookmark_flows_dirpath = bookmark_flowsandsuspicious_dirpath + '/flows'
bookmark_suspicious_dirpath = bookmark_flowsandsuspicious_dirpath + '/suspicious'
os.mkdir(bookmark_flowsandsuspicious_dirpath)
os.mkdir(bookmark_flows_dirpath)
os.mkdir(bookmark_suspicious_dirpath)

manifest_bookmarks_or_topSites = manifest_bookmarks | manifest_topSites

# Bookmark detected flows in the exts with bookmark permission in their manifest
high_certain_bookmark_flows = bookmark_SURL | bookmark_noURL_Ssink
medium_certain_bookmark_flows = bookmark_all

write_csv_rows_of_extset_to_file_sorted(manifest_bookmarks_or_topSites.intersection(high_certain_bookmark_flows), bookmark_flows_dirpath + '/high_certain_bookmark_flows-bookmark-exts.txt')
write_csv_rows_of_extset_to_file_sorted(manifest_bookmarks_or_topSites.intersection(medium_certain_bookmark_flows), bookmark_flows_dirpath + '/medium_certain_bookmark_flows-bookmark-exts.txt')

all_bookmark_detected_flows = high_certain_bookmark_flows | medium_certain_bookmark_flows

write_csv_rows_of_extset_to_file_sorted(manifest_bookmarks_or_topSites.intersection(all_bookmark_detected_flows), bookmark_flows_dirpath + '/a-flow-detected-and-bookmark-exts.txt')
write_extset_to_file(manifest_bookmarks_or_topSites.difference(all_bookmark_detected_flows), bookmark_flows_dirpath + '/no-flow-detected-and-bookmark-exts.txt')

# Bookmark suspicious analysis report in the exts with bookmarks or topSites permission in their manifest

severe_bookmark_suspicious_exts = bookmark_SURL
moderate_bookmark_suspicious_exts = bookmark_noURL_Ssink
uncertain_bookmark_suspicious_exts = bookmark_all

write_csv_rows_of_extset_to_file_sorted(manifest_bookmarks_or_topSites.intersection(severe_bookmark_suspicious_exts), bookmark_suspicious_dirpath + '/severe_bookmark_suspicious-bookmark-exts.txt')
write_extset_to_file(unique_set_of_extset(manifest_bookmarks_or_topSites.intersection(severe_bookmark_suspicious_exts)), bookmark_suspicious_dirpath + '/unique-severe_bookmark_suspicious-bookmark-exts.txt')
write_csv_rows_of_extset_to_file_sorted(manifest_bookmarks_or_topSites.intersection(moderate_bookmark_suspicious_exts), bookmark_suspicious_dirpath + '/moderate_bookmark_suspicious-bookmark-exts.txt')
write_extset_to_file(unique_set_of_extset(manifest_bookmarks_or_topSites.intersection(moderate_bookmark_suspicious_exts)), bookmark_suspicious_dirpath + '/unique-moderate_bookmark_suspicious-bookmark-exts.txt')
write_csv_rows_of_extset_to_file_sorted(manifest_bookmarks_or_topSites.intersection(uncertain_bookmark_suspicious_exts), bookmark_suspicious_dirpath + '/uncertain_bookmark_suspicious-bookmark-exts.txt')
write_extset_to_file(unique_set_of_extset(manifest_bookmarks_or_topSites.intersection(uncertain_bookmark_suspicious_exts)), bookmark_suspicious_dirpath + '/unique-uncertain_bookmark_suspicious-bookmark-exts.txt')

all_bookmark_suspicious_exts = severe_bookmark_suspicious_exts | moderate_bookmark_suspicious_exts | uncertain_bookmark_suspicious_exts

write_csv_rows_of_extset_to_file_sorted(manifest_bookmarks_or_topSites.intersection(all_bookmark_suspicious_exts), bookmark_suspicious_dirpath + '/a-suspicious_flow-detected-and-bookmark-exts.txt')
write_extset_to_file(manifest_bookmarks_or_topSites.difference(all_bookmark_suspicious_exts), bookmark_suspicious_dirpath + '/no-suspicious_flow-detected-and-bookmark-exts.txt')

########## end of Bookmark ##########

print("\n\n\n\nsuspiciousness analysis finished!\n")
