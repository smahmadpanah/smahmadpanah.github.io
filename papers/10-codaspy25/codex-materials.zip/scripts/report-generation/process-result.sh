#!/bin/bash


# clean <dirname>
# cleaning up the analysis directory and the report file

# run <dirname>
# **cleans up**, creates a dir for each extension, moves the csv file inside, runs the grep commands there

base="./"

if [ -z "$1" ] 
then 
	printf "arg1 missing: clean <dirname> | run <dirname> \n" 
    exit 1
else
	if ! [ "$1" = "run" ] && ! [ "$1" = "clean" ];
	then
		printf "invalid command: clean <dirname> | run <dirname> \n" 
    	exit 1
	fi
fi


if [ -z "$2" ] 
then
	printf "arg2 <dirname> is missing \n" 
    exit 1
else
	base="$2"
	result="$base/../`basename $base`-processed"
	analysis="$base/../`basename $base`-analysis"
	report="$analysis/report.txt"
fi

# copy csv directory
rm -rf "$result"
cp -r "$base" "$result"

rm -rf $analysis
mkdir $analysis
rm -f $report
printf "clean done, $analysis renewed\n" 

if [ "$1" = "clean" ]; then
	exit 0
fi



grep_print () {
#$1: grep value
#$2: local filename
#$3: path
#$4: ext
	filename="$3/$2.txt"
	error="$3/$2-ERROR.txt"
	temp=`grep -E "$1" "$3/$4.csv"` 
	if [[ ! -z "$temp" ]]; then
		printf '%s\n' "$temp" >> "$filename"
		printf '%s\n' "$4" >> "$analysis/ext-$2.txt" 
	fi
}

grep_exclude_postmessage_print () {
#$1: grep value
#$2: local filename
#$3: path
#$4: ext
	filename="$3/$2.txt"
	error="$3/$2-ERROR.txt"
	temp=`grep -E "$1" "$3/$4.csv" | grep -v "postMessage("` 
	if [[ ! -z "$temp" ]]; then
		printf '%s\n' "$temp" >> "$filename"
		printf '%s\n' "$4" >> "$analysis/ext-$2.txt" 
	fi
}


regex_exclude_http="[\"\']{0,2}(([#\/]?)|(http[s]?((:\/\/)(www)?(\.)?)?))[\"\']{0,2}\}"

grep_exclude_regex_print () {
#$1: grep value
#$2: local filename
#$3: path
#$4: ext
#$5: grep exclude expr
	filename="$3/$2.txt"
	error="$3/$2-ERROR.txt"
	temp=`grep -E "$1" "$3/$4.csv" | grep -Ev "$5"` 
	if [[ ! -z "$temp" ]]; then
		printf '%s\n' "$temp" >> "$filename"
		printf '%s\n' "$4" >> "$analysis/ext-$2.txt" 
	fi
}


printf "Running the process...\n" 

for csv in $result/*; do 
		ext=`basename -- "$csv" .csv`
		path="$result/$ext"
	if ! [ -s $csv ]
	then 
	# empty csv files removed
		printf '%s\n' "$ext" >> "$analysis/ext-empty-csvs.txt"
		rm -f $csv
	else
		mkdir $path
		mv $csv "$path/$ext.csv"
	

		### JStoSink
		# suspicious url found and user input detected
		grep_exclude_regex_print "{A USER INPUT} {JStoSink url FOUND and suspicious" "UI-SURL" $path $ext "{A USER INPUT} {JStoSink url FOUND and suspicious: $regex_exclude_http"
		
		grep_print "{A USER INPUT} {JStoSink url FOUND and suspicious: $regex_exclude_http" "UI-noURL" $path $ext
		
		# benign url found and user input detected
		grep_print "{A USER INPUT} {JStoSink url FOUND and maybe benign" "UI-BURL" $path $ext
	
		# url not found and user input detected
		grep_print "{A USER INPUT} {JStoSink url NOT found" "UI-noURL" $path $ext
	
		# suspicious url found and user input not detected
		grep_exclude_regex_print "{user input not detected} {JStoSink url FOUND and suspicious" "noUI-SURL" $path $ext "{user input not detected} {JStoSink url FOUND and suspicious: $regex_exclude_http"
		
		grep_print "{user input not detected} {JStoSink url FOUND and suspicious: $regex_exclude_http" "noUI-noURL" $path $ext 
		
		# benign url found and user input not detected
		grep_print "{user input not detected} {JStoSink url FOUND and maybe benign" "noUI-BURL" $path $ext

		# no url found and user input not detected
		grep_print "{user input not detected} {JStoSink url NOT found" "noUI-noURL" $path $ext
		###



		### InputToFormHTML
		# suspicious url found in the action form html
		grep_exclude_regex_print "{InputToFormActionHTML.*suspicious" "form-SURL" $path $ext "{InputToFormActionHTML suspicious: $regex_exclude_http"
		
		# no interesting url found in the action form html
		grep_print "{InputToFormActionHTML suspicious: $regex_exclude_http" "form-noURL" $path $ext

		# benign url found in the action form html
		grep_print "{InputToFormActionHTML.*benign" "form-BURL" $path $ext
		###


		### RedirectURL
		# suspicious url found
		grep_exclude_regex_print "{RedirectURL url FOUND and suspicious" "redirect-SURL" $path $ext "{RedirectURL url FOUND and suspicious: $regex_exclude_http"
		
		grep_print "{RedirectURL url FOUND and suspicious: $regex_exclude_http" "redirect-noURL" $path $ext

		# benign url found
		grep_print "{RedirectURL url FOUND and maybe benign" "redirect-BURL" $path $ext

		# no url found
		grep_print "{RedirectURL url NOT found" "redirect-noURL" $path $ext


		### Cookie
		# "http" url found => malicious
		grep_print "{CookieStealing url FOUND" "cookie-SURL" $path $ext
		# url not found AND the sink is not postmessage => suspicious
		grep_exclude_postmessage_print "{CookieStealing url NOT found" "cookie-noURL-Ssink" $path $ext
		# url not found => uncertain
		grep_print "{CookieStealing url NOT found" "cookie-all" $path $ext
		# with postmessage as sink - no need
		# grep_print "Cookie Stealing.*postMessage(" "cookie-postmsg" $path $ext

		### Bookmark
		# "http" url found => malicious
		grep_print "{BookmarkStealing url FOUND" "bookmark-SURL" $path $ext
		# url not found AND the sink is not postmessage => suspicious
		grep_exclude_postmessage_print "{BookmarkStealing url NOT found" "bookmark-noURL-Ssink" $path $ext
		# url not found => uncertain
		grep_print "{BookmarkStealing url NOT found" "bookmark-all" $path $ext
		# with postmessage as sink - no need
		# grep_print "Bookmark Stealing.*postMessage(" "bookmark-postmsg" $path $ext


		### History
		# "http" url found => malicious
		grep_print "{HistoryStealing url FOUND" "history-SURL" $path $ext
		# url not found AND the sink is not postmessage => suspicious
		grep_exclude_postmessage_print "{HistoryStealing url NOT found" "history-noURL-Ssink" $path $ext
		# url not found => uncertain
		grep_print "{HistoryStealing url NOT found" "history-all" $path $ext
		# with postmessage as sink - no need
		# grep_print "History Stealing.*postMessage(" "history-postmsg" $path $ext

	fi
done


for f in $analysis/*; do
	name=`basename -- "$f" .txt`
	if ! [ "$name" = "report" ]; then
		cmd=`cat $f | wc -l`
		printf '%s: %s\n' "$name" "$cmd" >> $report
	fi 
done

echo "Report"
cat $report

printf "The process finished!\n" 

