import re
import sys

base_dir = sys.argv[1]
all_alive_file = sys.argv[2]

all_latest = {}
with open(base_dir + '/out/proper-exts.txt') as f:
   for line in f:
      arr = re.split(r'\.', line)
      try:
         all_latest[arr[0]].append(line.strip())
      except KeyError:
         all_latest[arr[0]] = [line.strip()]

alive = set(l.strip() for l in open(all_alive_file))

alive_file = open(base_dir + '/out/alive-proper-exts.txt', "w")
dead_file = open(base_dir + '/out/dead-proper-exts.txt', "w")

for key, value in all_latest.items():
   if key in alive:
      alive_file.write("\n".join(value) + "\n")
   else:
      dead_file.write("\n".join(value) + "\n")
      
alive_file.close()
dead_file.close()

