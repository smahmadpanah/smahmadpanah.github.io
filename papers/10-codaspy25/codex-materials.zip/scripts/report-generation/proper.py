import sys

base_dir = sys.argv[1]
db_list_file = sys.argv[2]
all_proper_file = sys.argv[3]

all_ext = set(l.strip() for l in open(db_list_file))

all_proper = set(l.strip() for l in open(all_proper_file))

proper_exts = all_ext.intersection(all_proper)

with open(base_dir + '/out/proper-exts.txt', 'w') as f:
    for line in proper_exts:
        f.write(f"{line}\n")

improper_exts = all_ext.difference(all_proper)

with open(base_dir + '/out/not-exts.txt', 'w') as f:
    for line in improper_exts:
        f.write(f"{line}\n")
