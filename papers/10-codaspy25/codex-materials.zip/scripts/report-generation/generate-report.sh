#!/bin/bash


######
# note: manifest and dead removal reasons should not end with '/'! 


ANALYSIS_DIR=$1 # the analysis directory; e.g., /path/to/1711122025-analysis
DB_LIST_ARG=$2 # the path to the db-list txt file; e.g. /path/to/sample_1K_databases.txt
ALL_PROPER_EXT_ARG=$3 # the path to the list of all proper extensions; e.g. /path/to/all-proper-extensions.txt
ALL_ALIVE_ARG=$4 # the path to the list of all alive extensions; e.g., /path/to/alive-all.txt
DEAD_REASONS_ARG=$5 # the path to the directory for reasons for removing the dead exts; e.g., /path/to/./all-dead-removal-reasons-analysis
MANIFEST_ANALYSIS_ARG=$6 # the path to the manifest analysis of all exts ; e.g., /path/to/../all-exts-manifest-analysis
LAST_DOWNLOAD_FILE_ARG=$7 # the path to the last downloads of all exts ; e.g., /path/to/../last_downloads-4apr2024.csv
#TOP_N_MOST_DOWNLOADED_ARG=$8 # number of the top N severe/moderate/uncertain most downloaded exts to be reported; e.g., 10

printf '\n\n'
echo "ANALYSIS_DIR=$1"
echo "DB_LIST_ARG=$2"
echo "ALL_PROPER_EXT_ARG=$3"
echo "ALL_ALIVE_ARG=$4"
echo "DEAD_REASONS_ARG=$5"
echo "MANIFEST_ANALYSIS_ARG=$6"
echo "LAST_DOWNLOAD_FILE_ARG=$7"
#echo "TOP_N_MOST_DOWNLOADED_ARG=$8"

echo "Are you sure about the input config?"
read answer
if [ "$answer" != "${answer#[Yy]}" ] ;then 
    echo "Running..."
else
    exit
fi

INPUT_DIR="$ANALYSIS_DIR-input" # the dir to the input files: DATABASE_LIST
rm -rf $INPUT_DIR
mkdir $INPUT_DIR

REPORT_DIR="$ANALYSIS_DIR-report" # the dir to the report files: log, final csv, and so on...
rm -rf $REPORT_DIR
mkdir $REPORT_DIR
#mkdir "$REPORT_DIR/top-$TOP_N_MOST_DOWNLOADED_ARG"

# printing each command before executing
Timestamp_Analysis_Dirname=`basename $ANALYSIS_DIR`
LOG_FILE="$REPORT_DIR/$Timestamp_Analysis_Dirname-analysis-log.txt"
exec   > >(tee -ia $LOG_FILE)
exec  2> >(tee -ia $LOG_FILE >& 2)
exec 19> $LOG_FILE
export BASH_XTRACEFD="19"
set -o xtrace
#




cp $DB_LIST_ARG $INPUT_DIR
cp $ALL_PROPER_EXT_ARG $INPUT_DIR
cp $ALL_ALIVE_ARG $INPUT_DIR
cp -r $DEAD_REASONS_ARG $INPUT_DIR
cp -r $MANIFEST_ANALYSIS_ARG $INPUT_DIR
cp $LAST_DOWNLOAD_FILE_ARG $INPUT_DIR



# input config
DATABASE_LIST="$INPUT_DIR/`basename $DB_LIST_ARG`" #used in proper.py
ALL_PROPER_EXTS="$INPUT_DIR/`basename $ALL_PROPER_EXT_ARG`" #used in proper.py
ALL_ALIVE="$INPUT_DIR/`basename $ALL_ALIVE_ARG`" #used in alive-and-dead.py
DEAD_REASONS_DIR="$INPUT_DIR/`basename $DEAD_REASONS_ARG`" #used in analysis-suspiciousness.py
MANIFEST_ANALYSIS_DIR="$INPUT_DIR/`basename $MANIFEST_ANALYSIS_ARG`" #used in analysis-suspiciousness.py
LAST_DOWNLOAD_FILE="$INPUT_DIR/`basename $LAST_DOWNLOAD_FILE_ARG`" #used in analysis-suspiciousness.py
INPUT_OUT="$INPUT_DIR/out"


rm -rf $INPUT_OUT
mkdir $INPUT_OUT

# find proper extensions
python3 proper.py $INPUT_DIR $DATABASE_LIST $ALL_PROPER_EXTS

# find alive and dead proper extensions
python3 alive-and-dead.py $INPUT_DIR $ALL_ALIVE

# generating the comprehensive analysis results, as csv to be imported to google doc
python3 analysis-suspiciousness.py $ANALYSIS_DIR $INPUT_OUT $MANIFEST_ANALYSIS_DIR $DEAD_REASONS_DIR $Timestamp_Analysis_Dirname $LAST_DOWNLOAD_FILE #$TOP_N_MOST_DOWNLOADED_ARG

printf "\n\n\n**Reports generated in $REPORT_DIR**\n\n\n"