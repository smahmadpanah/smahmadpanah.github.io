echo "Deleting content from project..."


<<doc
Delete content inside of @DeletePath.
doc
delete_Contents()
{
    DeletePath=$@

    echo "Trying to remove $DeletePath"
    rm -R $DeletePath
}

<<doc
Delete snapshot.
doc
delete_DS()
{
    delete_Contents $CODEX_DS_CWS
    delete_Contents $CODEX_DS
}

<<doc
Delete codebases.
doc
delete_CB()
{
    delete_Contents $CODEX_CB_CWS
    delete_Contents $CODEX_CB
}

<<doc
Delete databases.
doc
delete_DB()
{
    delete_Contents $CODEX_DB_CWS
    delete_Contents $CODEX_DB
}

<<doc
Delete query results.
doc
delete_CQL()
{
    delete_Contents $CODEX_CQL_CWS
    delete_Contents $CODEX_CQL
}

<<doc
Delete LOGs.
doc
delete_LOG()
{
    delete_Contents $CODEX_LOG_Unzip
    delete_Contents $CODEX_LOG_Build
    delete_Contents $CODEX_LOG_Clean
    delete_Contents $CODEX_LOG_Query
    delete_Contents $CODEX_LOG_Parallel
    delete_Contents $CODEX_LOG
}


MODULE_NAME='Delete'
PS3="$PROGRAM_NAME | $MODULE_NAME > "

echo "Select what do you want to delete..."
select delete in 'Help' 'Done' 'DS' 'CB' 'DB' 'CQL' 'LOG'; do
    case $delete in
        Help ) REPLY='';;
        Done ) echo "Going back!"; break;;
        DS   ) delete_DS;;
        CB   ) delete_CB;;
        DB   ) delete_DB;;
        CQL  ) delete_CQL;;
        LOG  ) delete_LOG;;
        *    ) echo "Unknown action > $REPLY";;
    esac
done
