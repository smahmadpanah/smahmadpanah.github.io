import os
import sys
import csv
import subprocess

from datetime import datetime

csv.field_size_limit(sys.maxsize)


# ------------------------------------------------------------------- #
# Process `.csv` files to set up diff analysis                        #
# ------------------------------------------------------------------- #


# ------------------------------------------------------------------- #
def appendContent(filePATH, content):
    outFile = open(filePATH, 'a')
    outFile.write(content)
    outFile.close()

def findString(filePATH, searchString):
    openFile = open(filePATH, 'r')
    lines = openFile.readlines()
    for line in lines:
        if searchString in line:
            return True
    return False
# ------------------------------------------------------------------- #


MAIN_PATH = sys.argv[1]
OUT_PATH = sys.argv[2]

FILE_LIST_APPS = "/home/codex/lists/proper/other/apps_codebases.txt"
FILE_LIST_THEMES = "/home/codex/lists/proper/other/themes_codebases.txt"
FILE_LIST_UPDATES = "/home/codex/repository/statistics/diff/EXT_with_updates.txt"

startTime = datetime.now()

# ------------------------------------------------------------------- #
# 1) Organize results in separate folder by extension ID
subprocess.run(["mkdir", "-p", OUT_PATH])

for csv_file in os.listdir(MAIN_PATH):

    # Obtain extension ID
    ext_Version = os.path.splitext(csv_file)[0]

    if findString(FILE_LIST_APPS, ext_Version) or findString(FILE_LIST_THEMES, ext_Version):
        print(f'Skipping... {ext_Version}')
        continue

    parse = ext_Version.split(sep = '.', maxsplit = 1)
    ext_ID = parse[0]

    print(f'Organizing... {ext_Version}')

    # Make new subfolder
    subprocess.run(["mkdir", "-p", OUT_PATH + "/" + ext_ID])

    # Copy results
    subprocess.run(["cp", MAIN_PATH + "/" + csv_file, OUT_PATH + "/" + ext_ID + "/"])

print("DONE: Step 1")

# ------------------------------------------------------------------- #
# 2) Remove results of extensions without updates
for ext_DIR in os.listdir(OUT_PATH):

    versions = len(os.listdir(OUT_PATH + "/" + ext_DIR))

    if versions > 1:
        appendContent(FILE_LIST_UPDATES, ext_DIR + '\n')
    else:
        print(f'Removing... {ext_DIR}')
        subprocess.run(["rm", "-r", OUT_PATH + "/" + ext_DIR])

print("DONE: Step 2")

# ------------------------------------------------------------------- #
# 3) Parse `.csv` files
with open(FILE_LIST_UPDATES, 'rt') as ext_list:

    # For each extension ID
    for line in ext_list:
        ext_ID = line.rstrip()
        ext_PATH = OUT_PATH + "/" + ext_ID

        # Get all versions
        result = subprocess.run(["ls", "-v", ext_PATH], stdout = subprocess.PIPE, text = True)

        # For each extension version
        for ext_CSV in result.stdout.splitlines():
            result_PATH = ext_PATH + "/" + ext_CSV
            process_PATH = ext_PATH + "/" + ext_CSV + ".tmp"

            print(f'Parsing... {ext_CSV}')

            # Parse findings
            with open(result_PATH, 'rt') as results:
                reader = csv.reader(results, quotechar='"')

                # Process findings
                with open(process_PATH, 'w+') as process:
                    for row in reader:

                        # The description contains multiple findings!
                        description = row[3].splitlines()
                        for finding in description:
                            process.write(row[0] + "," + row[4] + "," + finding + "\n")

            # Remove `.tmp` file
            subprocess.run(["rm", result_PATH])
            subprocess.run(["mv", process_PATH, result_PATH])

print("DONE: Step 3")

# ------------------------------------------------------------------- #
endTime = datetime.now()

print(f'Done in {endTime - startTime} seconds.')
