import os
import re
import sys
import subprocess

from datetime import datetime


# ------------------------------------------------------------------- #
# Produce diff results of `.csv` files to discover suspicious updates #
# ------------------------------------------------------------------- #

# ------------------------------------------------------------------- #
# Documentation
# > EXT | Extension ID
# > Query | CodeQL query responsible of the difference
# > EXT_V1 | Old version of extension
# > EXT_V2 | New version of extension
# > #Diffs | Amount of findings that are different (appear in NEW version but not in OLD version)
# > #Versions | Amount of versions that the extension has
# > Last | Flag to signal if it is the last update in our dataset
# > State | Is the extension dead or alive?
# > Condition | If dead, what is the reason?
# > Lines_V1 | Amount of lines that .csv file had for OLD version
# > Lines_V2 | Amount of lines that .csv file had for NEW version
# > Downloads_V1 | Amount of downloads that OLD version had
# > Downloads_V2 | Amount of downloads that NEW version had
# > Permissions_V1 | Permissions (from manifest) of OLD version
# > Permissions_V2 | Permissions (from manifest) of NEW version
# > URLs | List of URLs that appear in differences
# > PATHs | List of PATHs that appear in differences

# UPDATE
# > We capture the URLs of findings to improve analysis
# > We display suspicious files to improve analysis
# > We do not report the description of findings to improve readability
# ------------------------------------------------------------------- #

# ------------------------------------------------------------------- #
def writeHeader(filePATH):
    # Writes the .csv header for analysis results
    outFile = open(filePATH, 'w')
    outFile.write("EXT,Query,EXT_V1,EXT_V2,#Diffs,#Versions,Last,State,Condition,Lines_V1,Lines_V2,Downloads_V1,Downloads_V2,Permissions_V1,Permissions_V2,URLs,PATHs\n")#,Description\n")
    outFile.close()

def appendContent(filePATH, content):
    # Appends content to a given file
    outFile = open(filePATH, 'a')
    outFile.write(content)
    outFile.close()

def findString(filePATH, searchString):
    # Checks if a given string appears in a file
    openFile = open(filePATH, 'r')
    lines = openFile.readlines()
    for line in lines:
        if searchString in line:
            return True
    return False

def countLines(filePATH):
    # Counts lines of .csv file
    with open(filePATH, 'r') as csvFile:
        return len(csvFile.readlines())

def getDownloads(extVersion):
    # Gets number of downloads / users
    grep = subprocess.run(["grep", extVersion, DOWNLOAD_LIST], stdout = subprocess.PIPE, text = True)
    ext_ENTRY = grep.stdout.rstrip().split(sep = ',')
    downloads = ext_ENTRY[-1]
    return downloads if downloads.isdigit() else "missing"

def checkPermissions(filePATH, extVersion, permission):
    # Checks if extension has a given permission
    return permission if findString(filePATH, extVersion) else "NO." + permission
# ------------------------------------------------------------------- #


# Path for query results
MAIN_PATH = sys.argv[1]
# Path for analysis results
OUT_PATH = sys.argv[2]
# List of extensions with updates
FILE_LIST = sys.argv[3]

Query_B = 'query.bookmark'
Query_C = 'query.cookie'
Query_H = 'query.history'
Query_I = 'query.html'
Query_J = 'query.jquery'
Query_R = 'query.redirect'

# Paths for analysis results of every query
OUT_B_PATH = OUT_PATH + '/' + Query_B + '.txt'
OUT_C_PATH = OUT_PATH + '/' + Query_C + '.txt'
OUT_H_PATH = OUT_PATH + '/' + Query_H + '.txt'
OUT_I_PATH = OUT_PATH + '/' + Query_I + '.txt'
OUT_J_PATH = OUT_PATH + '/' + Query_J + '.txt'
OUT_R_PATH = OUT_PATH + '/' + Query_R + '.txt'

# Lists of alive/dead extensions
ALIVE_LIST = "/home/codex/repository/statistics/proper/alive-dead/alive-all.txt"

DEAD_PATH = "/home/codex/repository/statistics/proper/all-dead-removal-reasons-analysis"
DEAD_M_LIST = DEAD_PATH + "/dead-malware.txt"
DEAD_P_LIST = DEAD_PATH + "/dead-policy_violation.txt"
DEAD_U_LIST = DEAD_PATH + "/dead-potentially_uws.txt"
DEAD_S_LIST = DEAD_PATH + "/dead-suspicious.txt"

MANIFEST_B = "/home/codex/repository/statistics/proper/all-exts-manifest-analysis/bookmarks-exts.txt"
MANIFEST_C = "/home/codex/repository/statistics/proper/all-exts-manifest-analysis/cookies-exts.txt"
MANIFEST_H = "/home/codex/repository/statistics/proper/all-exts-manifest-analysis/history-exts.txt"
MANIFEST_TS = "/home/codex/repository/statistics/proper/all-exts-manifest-analysis/topSites-exts.txt"
MANIFEST_NT = "/home/codex/repository/statistics/proper/all-exts-manifest-analysis/newtab-exts.txt"
MANIFEST_SP = "/home/codex/repository/statistics/proper/all-exts-manifest-analysis/search_provider-exts.txt"
MANIFEST_WR = "/home/codex/repository/statistics/proper/all-exts-manifest-analysis/webRequest-exts.txt"

# Download count of extensions
DOWNLOAD_LIST = "/home/codex/repository/statistics/proper/num-of-users/sorted_last_downloads-4apr2024.csv"

# Detect when a URL is incomplete
URL_REGEXP = r"""["'`]{0,2}(([#/]?)|(http[s]?(://(www.)?)?))["'`]{0,2}}"""
"""
|     Match either option.
?     Match 0 or 1 repetitions.
\     Escapes special characters.
[]    Indicate a set of characters.
{m,n} Match from m to n repetitions.
(...) Matches whatever is inside the parentheses.
"""

startTime = datetime.now()

writeHeader(OUT_B_PATH)
writeHeader(OUT_C_PATH)
writeHeader(OUT_H_PATH)
writeHeader(OUT_I_PATH)
writeHeader(OUT_J_PATH)
writeHeader(OUT_R_PATH)

with open(FILE_LIST, 'rt') as ext_list:

    # For each extension ID
    for line in ext_list:
        ext_ID = line.rstrip()
        ext_PATH = MAIN_PATH + "/" + ext_ID

        # Check state of extension
        condition = ""
        if findString(ALIVE_LIST, ext_ID): state = "alive"
        else:
            state = "dead"
            if findString(DEAD_M_LIST, ext_ID): condition = "malware"
            elif findString(DEAD_P_LIST, ext_ID): condition = "violation"
            elif findString(DEAD_U_LIST, ext_ID): condition = "unwanted"
            elif findString(DEAD_S_LIST, ext_ID): condition = "suspicious"
            else: condition = "unknown"

        # Get all versions (ordered according to semver)
        result = subprocess.run(["ls", "-v", ext_PATH], stdout = subprocess.PIPE, text = True)
        ext_VERSIONS = result.stdout.splitlines()
        versions = len(ext_VERSIONS)

        print(f'-----> Analyzing {ext_ID} <-----')

        # Loop over updates (pair of versions)
        for csv1, csv2 in zip(ext_VERSIONS[:-1], ext_VERSIONS[1:]):
            v1 = os.path.splitext(csv1)[0]
            v2 = os.path.splitext(csv2)[0]

            csv1_PATH = ext_PATH + '/' + csv1
            csv2_PATH = ext_PATH + '/' + csv2

            # Check for last (available) update of extension
            lastUpdate = csv2 == ext_VERSIONS[-1]

            # Suspicious update!
            if os.path.getsize(csv2_PATH) > 0:

                # Get download numbers
                downloadsV1 = getDownloads(v1)
                downloadsV2 = getDownloads(v2)

                # Get lines count
                linesV1 = countLines(csv1_PATH)
                linesV2 = countLines(csv2_PATH)

                count_B = 0
                count_C = 0
                count_H = 0
                count_I = 0
                count_J = 0
                count_R = 0

                finds_B = ""
                finds_C = ""
                finds_H = ""
                finds_I = ""
                finds_J = ""
                finds_R = ""

                files_B = []
                files_C = []
                files_H = []
                files_I = []
                files_J = []
                files_R = []

                urls_B = []
                urls_C = []
                urls_H = []
                urls_I = []
                urls_J = []
                urls_R = []

                with open(csv2_PATH, 'rt') as csv2_results:

                    # For each finding
                    for line in csv2_results:
                        result = line.rstrip()

                        # Check if the finding was there before update
                        if not findString(csv1_PATH, result):

                            parse = result.split(sep = ',', maxsplit = 2)
                            queryID = parse[0]
                            susFILE = parse[1]
                            finding = parse[2]

                            match queryID:
                                case "Bookmark Stealing":
                                    rawString = r"""{BookmarkStealing url FOUND """
                                    searchURL = re.search(rawString + r"""["'`]?(http[s]?://.*?)["'`]?}""", finding)
                                    # if "Extracted URL" and "New URL" and "Valid URL" and "Suspicious Sink":
                                    if searchURL and not findString(csv1_PATH, searchURL.group(1)) and not re.search(rawString + URL_REGEXP, finding) and ".postMessage(" not in finding:
                                        count_B += 1
                                        finds_B += f'|{susFILE}|{finding}|'
                                        files_B.append(susFILE)
                                        urls_B.append(searchURL.group(1))
                                case "Cookie Stealing":
                                    rawString = r"""{CookieStealing url FOUND """
                                    searchURL = re.search(rawString + r"""["'`]?(http[s]?://.*?)["'`]?}""", finding)
                                    # if "Extracted URL" and "New URL" and "Valid URL" and "Suspicious Sink":
                                    if searchURL and not findString(csv1_PATH, searchURL.group(1)) and not re.search(rawString + URL_REGEXP, finding) and ".postMessage(" not in finding:
                                        count_C += 1
                                        finds_C += f'|{susFILE}|{finding}|'
                                        files_C.append(susFILE)
                                        urls_C.append(searchURL.group(1))
                                case "History Stealing":
                                    rawString = r"""{HistoryStealing url FOUND """
                                    searchURL = re.search(rawString + r"""["'`]?(http[s]?://.*?)["'`]?}""", finding)
                                    # if "Extracted URL" and "New URL" and "Valid URL" and "Suspicious Sink":
                                    if searchURL and not findString(csv1_PATH, searchURL.group(1)) and not re.search(rawString + URL_REGEXP, finding) and ".postMessage(" not in finding:
                                        count_H += 1
                                        finds_H += f'|{susFILE}|{finding}|'
                                        files_H.append(susFILE)
                                        urls_H.append(searchURL.group(1))
                                case "InputToFormActionHTML":
                                    rawString = r"""{InputToFormActionHTML suspicious: """
                                    searchURL = re.search(rawString + r"""["'`]?(http[s]?://.*?)["'`]?}""", finding)
                                    # if "Extracted URL" and "New URL" and "Valid URL":
                                    if searchURL and not findString(csv1_PATH, searchURL.group(1)) and not re.search(rawString + URL_REGEXP, finding):
                                        count_I += 1
                                        finds_I += f'|{susFILE}|{finding}|'
                                        files_I.append(susFILE)
                                        urls_I.append(searchURL.group(1))
                                case "JStoSink-userInputCrossCheck":
                                    rawString = r"""{A USER INPUT} {JStoSink url FOUND and suspicious: """
                                    searchURL = re.search(rawString + r"""["'`]?(http[s]?://.*?)["'`]?}""", finding)
                                    # if "Extracted URL" and "New URL" and "Valid URL":
                                    if searchURL and not findString(csv1_PATH, searchURL.group(1)) and not re.search(rawString + URL_REGEXP, finding):
                                        count_J += 1
                                        finds_J += f'|{susFILE}|{finding}|'
                                        files_J.append(susFILE)
                                        urls_J.append(searchURL.group(1))
                                case "RedirectURL":
                                    rawString = r"""{RedirectURL url FOUND and suspicious: """
                                    searchURL = re.search(rawString + r"""["'`]?(http[s]?://.*?)["'`]?}""", finding)
                                    # if "Extracted URL" and "New URL" and "Valid URL":
                                    if searchURL and not findString(csv1_PATH, searchURL.group(1)) and not re.search(rawString + URL_REGEXP, finding):
                                        count_R += 1
                                        finds_R += f'|{susFILE}|{finding}|'
                                        files_R.append(susFILE)
                                        urls_R.append(searchURL.group(1))
                                case _:
                                    print("Unknown")

                if count_B > 0:
                    permissionsV1 = checkPermissions(MANIFEST_B, v1, 'bookmark') + '|' + checkPermissions(MANIFEST_TS, v1, 'topSite')
                    permissionsV2 = checkPermissions(MANIFEST_B, v2, 'bookmark') + '|' + checkPermissions(MANIFEST_TS, v2, 'topSite')
                    appendContent(OUT_B_PATH, f'{ext_ID},{Query_B},{v1},{v2},{count_B},{versions},{lastUpdate},{state},{condition},{linesV1},{linesV2},{downloadsV1},{downloadsV2},{permissionsV1},{permissionsV2},{" | ".join(urls_B).replace(",", ".")},{" | ".join(files_B)}\n')#,{finds_B}\n')
                if count_C > 0:
                    permissionsV1 = checkPermissions(MANIFEST_C, v1, 'cookie')
                    permissionsV2 = checkPermissions(MANIFEST_C, v2, 'cookie')
                    appendContent(OUT_C_PATH, f'{ext_ID},{Query_C},{v1},{v2},{count_C},{versions},{lastUpdate},{state},{condition},{linesV1},{linesV2},{downloadsV1},{downloadsV2},{permissionsV1},{permissionsV2},{" | ".join(urls_C).replace(",", ".")},{" | ".join(files_C)}\n')#,{finds_C}\n')
                if count_H > 0:
                    permissionsV1 = checkPermissions(MANIFEST_H, v1, 'history')
                    permissionsV2 = checkPermissions(MANIFEST_H, v2, 'history')
                    appendContent(OUT_H_PATH, f'{ext_ID},{Query_H},{v1},{v2},{count_H},{versions},{lastUpdate},{state},{condition},{linesV1},{linesV2},{downloadsV1},{downloadsV2},{permissionsV1},{permissionsV2},{" | ".join(urls_H).replace(",", ".")},{" | ".join(files_H)}\n')#,{finds_H}\n')
                if count_I > 0:
                    permissionsV1 = checkPermissions(MANIFEST_NT, v1, 'newTab') + '|' + checkPermissions(MANIFEST_SP, v1, 'searchProv')
                    permissionsV2 = checkPermissions(MANIFEST_NT, v2, 'newTab') + '|' + checkPermissions(MANIFEST_SP, v2, 'searchProv')
                    appendContent(OUT_I_PATH, f'{ext_ID},{Query_I},{v1},{v2},{count_I},{versions},{lastUpdate},{state},{condition},{linesV1},{linesV2},{downloadsV1},{downloadsV2},{permissionsV1},{permissionsV2},{" | ".join(urls_I).replace(",", ".")},{" | ".join(files_I)}\n')#,{finds_I}\n')
                if count_J > 0:
                    permissionsV1 = checkPermissions(MANIFEST_NT, v1, 'newTab') + '|' + checkPermissions(MANIFEST_SP, v1, 'searchProv')
                    permissionsV2 = checkPermissions(MANIFEST_NT, v2, 'newTab') + '|' + checkPermissions(MANIFEST_SP, v2, 'searchProv')
                    appendContent(OUT_J_PATH, f'{ext_ID},{Query_J},{v1},{v2},{count_J},{versions},{lastUpdate},{state},{condition},{linesV1},{linesV2},{downloadsV1},{downloadsV2},{permissionsV1},{permissionsV2},{" | ".join(urls_J).replace(",", ".")},{" | ".join(files_J)}\n')#,{finds_J}\n')
                if count_R > 0:
                    permissionsV1 = checkPermissions(MANIFEST_WR, v1, 'webRequest')
                    permissionsV2 = checkPermissions(MANIFEST_WR, v2, 'webRequest')
                    appendContent(OUT_R_PATH, f'{ext_ID},{Query_R},{v1},{v2},{count_R},{versions},{lastUpdate},{state},{condition},{linesV1},{linesV2},{downloadsV1},{downloadsV2},{permissionsV1},{permissionsV2},{" | ".join(urls_R).replace(",", ".")},{" | ".join(files_R)}\n')#,{finds_R}\n')

endTime = datetime.now()

print(f'Done in {endTime - startTime} seconds.')
