# CODEX
### A Framework for Tracking Flows in Browser Extensions


---


## Overview

This is a command-line tool designed to apply CodeX queries to the CWS registry, with the aim of finding risky flows in extensions.
It provides functionality to extract extensions, build and scan databases, and compute the overall results.


## Installation

Before using this tool, ensure that the following is installed on your system.

* [GNU Parallel](https://www.gnu.org/software/parallel/)

* [CodeQL](https://codeql.github.com) (as **codeql** in `$PATH`)
  * *Where the executable needs to be in the same directory as its libraries.*

Now everything should be ready to use the tool.


## Usage

**The following assumes we are standing in ``/home/codex/``.**

The entry point of the tool is ``repository/scripts/main.sh``.

```shell
> ./repository/scripts/main.sh
CODEX | Select an action to perform...
1) Help
2) Exit
3) Setup
4) Delete
CODEX >
```

It is necessary to initialize the project before starting to work on it (a one-time procedure).

```shell
CODEX > 3
Setting up project...
mkdir: created directory '1_Extension/'
mkdir: created directory '1_Extension/CWS/'
mkdir: created directory '2_CodeBase/'
mkdir: created directory '2_CodeBase/CWS/'
mkdir: created directory '3_DataBase/'
mkdir: created directory '3_DataBase/CWS/'
mkdir: created directory '4_Query/'
mkdir: created directory '4_Query/CWS/'
mkdir: created directory 'log/'
mkdir: created directory 'log/1_unzip/'
mkdir: created directory 'log/2_build/'
mkdir: created directory 'log/3_clean/'
mkdir: created directory 'log/4_query/'
mkdir: created directory 'log/parallel/'
CODEX >
```

- ``(-u)`` To extract every extension from the CWS registry (a one-time procedure).
```shell
> nohup ./repository/scripts/main.sh -u <crx_extension_list>.txt > <log_file>.out &
```

- ``(-b)`` To build the database for every extension from the CWS registry (a one-time procedure).
```shell
> nohup ./repository/scripts/main.sh -b <codebase_extension_list>.txt > <log_file>.out &
```

- ``(-c)`` To compact the disk space used by the databases (a one-time procedure).
```shell
> nohup ./repository/scripts/main.sh -c <database_extension_list>.txt > <log_file>.out &
```

- ``(-q)`` To apply some queries to the databases (after applying all of the previous commands).
```shell
> nohup ./repository/scripts/main.sh -q <database_extension_list>.txt -q repository/queries/ > <log_file>.out &
```

- ``(-l)`` To see a pretty-print message with some log information (after applying any of the previous commands).
```shell
> nohup ./repository/scripts/main.sh -l experiment/log/parallel/<PARALLEL_FILE>.log > <log_file>.out &
```


## Organization

#### Snapshot (our experiment)
```shell
| 1_Extension/CWS/ # All the .crx extensions from our dataset
| 2_CodeBase/CWS/  # All the extracted extensions from our dataset
| 3_DataBase/CWS/  # All the generated databases from our dataset
| 4_Query/CWS/     # Results (.csv files) from applying CodeX queries to our dataset
| log/             # Output (.log files) for each individually executed process (useful for debugging)
--| 1_unzip/
--| 2_build/
--| 3_clean/
--| 4_query/
--| parallel/      # Our tool uses parallel to run multiple subprocesses at the same time (useful for debugging)
```
