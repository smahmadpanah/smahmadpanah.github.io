echo "Working with the snapshot of CWS..."


SCRIPT_FS="$SCRIPTS/utils_FS.sh"
SCRIPT_QL="$SCRIPTS/utils_QL.sh"

source $SCRIPT_FS
source $SCRIPT_QL

# ---------- #

<<doc
Unzip a single CWS extension.
doc
unzip_Extension()
{
    TimeStamp=$1
    CWS_Extension=$2

    Extension_Name=$(dirname $CWS_Extension);
    Extension_Version=$(basename $CWS_Extension $CRX_EXTENSION);

    # Where we store the compressed .crx
    DS_Path="$CODEX_DS_CWS/$CWS_Extension"
    # Where we want to store the source code
    CB_Path="$CODEX_CB_CWS/$Extension_Version"
    # Where we want to store log information
    LOG_UNZIP="$CODEX_LOG_Unzip/$TimeStamp/$Extension_Version$LOG_EXTENSION"

    # Check if already extracted this extension
    if [ -d $CB_Path ]; then exit $OMITTED_CODE; fi

    # Creating CodeBase
    UTILS_Create_CB $DS_Path $CB_Path $LOG_UNZIP
    UNZIP_CODE=$?
    if [ $UNZIP_CODE -ne 0 ] && [ $UNZIP_CODE -ne 1 ]; then rm -rf $CB_Path; exit $FAILURE_CODE_UNZIP; fi

    exit $SUCCESS_CODE;
}

<<doc
Unzip all the CWS extensions.
doc
unzip_CWS()
{
    EXT_LIST=$@
    if ! [ -f $EXT_LIST ]; then echo "Missing list!"; exit $OMITTED_CODE; fi

    TIMESTAMP=$(date +%s);
    mkdir -p "$CODEX_LOG_Unzip/$TIMESTAMP"

    # LOG for Parallel-Job
    JOB_Path="$CODEX_LOG_Parallel/unzip.$TIMESTAMP$LOG_EXTENSION"

    SECONDS=0

    export -f unzip_Extension
    # For each extension in CWS's Repository...
    parallel --eta              \
             --jobs 128         \
             --delay 0.001      \
             --joblog $JOB_Path \
             --resume           \
             unzip_Extension ::: $TIMESTAMP :::: $EXT_LIST

    echo "---> Done in $SECONDS seconds (TIMESTAMP $TIMESTAMP)"
}

# ---------- #

<<doc
Build a CodeQL's database for a single CWS extension.
doc
build_Extension()
{
    TimeStamp=$1
    CWS_CodeBase=$2

    # Only care for the extension's name and version
    Extension_ID=$(basename $CWS_CodeBase);

    # Where we store the source code
    CB_Path="$CODEX_CB_CWS/$CWS_CodeBase"
    # Where we want to store CodeQL's database
    DB_Path="$CODEX_DB_CWS/$Extension_ID"
    # Where we want to store log information
    LOG_BUILD="$CODEX_LOG_Build/$TimeStamp/$Extension_ID$LOG_EXTENSION"

    # Check if already built the DB for this package
    if [ -d $DB_Path ]; then exit $OMITTED_CODE; fi

    # Creating DataBase
    UTILS_Create_DB $CB_Path $DB_Path $LOG_BUILD
    if [ $? -ne 0 ]; then rm -rf $DB_Path; exit $FAILURE_CODE_BUILD; fi

    exit $SUCCESS_CODE;
}

<<doc
Build the CodeQL's database for each CWS's extension.
doc
build_CWS()
{
    EXT_LIST=$@
    if ! [ -f $EXT_LIST ]; then echo "Missing list!"; exit $OMITTED_CODE; fi

    TIMESTAMP=$(date +%s);
    mkdir -p "$CODEX_LOG_Build/$TIMESTAMP"

    # LOG for Parallel-Job
    JOB_Path="$CODEX_LOG_Parallel/build.$TIMESTAMP$LOG_EXTENSION"

    SECONDS=0

    export -f build_Extension
    # For each extracted extension of CWS's Repository...
    parallel --eta              \
             --jobs 64          \
             --delay 0.01       \
             --timeout 300      \
             --joblog $JOB_Path \
             --resume           \
             build_Extension ::: $TIMESTAMP :::: $EXT_LIST

    echo "---> Done in $SECONDS seconds (TIMESTAMP $TIMESTAMP)"
}

# ---------- #

<<doc
Clean a CodeQL's database for a single CWS extension.
doc
clean_Extension()
{
    TimeStamp=$1
    CWS_DataBase=$2

    # Only care for the extension's name and version
    Extension_ID=$(basename $CWS_DataBase);

    # Where we store CodeQL's database
    DB_Path="$CODEX_DB_CWS/$CWS_DataBase"
    # Where we want to store log information
    LOG_CLEAN="$CODEX_LOG_Clean/$TimeStamp/$Extension_ID$LOG_EXTENSION"

    # Cleaning DataBase
    UTILS_Clean_DB $DB_Path $LOG_CLEAN
    if [ $? -ne 0 ]; then exit $FAILURE_CODE_CLEAN; fi

    exit $SUCCESS_CODE;
}

<<doc
Clean the CodeQL's database for each CWS's extension.
doc
clean_CWS()
{
    EXT_LIST=$@
    if ! [ -f $EXT_LIST ]; then echo "Missing list!"; exit $OMITTED_CODE; fi

    TIMESTAMP=$(date +%s);
    mkdir -p "$CODEX_LOG_Clean/$TIMESTAMP"

    # LOG for Parallel-Job
    JOB_Path="$CODEX_LOG_Parallel/clean.$TIMESTAMP$LOG_EXTENSION"

    SECONDS=0

    export -f clean_Extension
    # For each built database from the CWS's Repository...
    parallel --eta              \
             --jobs 128         \
             --delay 0.001      \
             --joblog $JOB_Path \
             --resume           \
             clean_Extension ::: $TIMESTAMP :::: $EXT_LIST

    echo "---> Done in $SECONDS seconds (TIMESTAMP $TIMESTAMP)"
}

# ---------- #

<<doc
Query a CodeQL's database for a single CWS extension.
doc
query_Extension()
{
    TimeStamp=$1
    QUERY_Path=$2
    CWS_DataBase=$3

    # Only care for the extension's name and version
    Extension_ID=$(basename $CWS_DataBase);

    # Where we store CodeQL's database
    DB_Path="$CODEX_DB_CWS/$CWS_DataBase"
    # Where we want to store CodeQL's results
    OUT_Path="$CODEX_CQL_CWS/$TimeStamp/$Extension_ID$OUT_EXTENSION"
    # Where we want to store log information
    LOG_QUERY="$CODEX_LOG_Query/$TimeStamp/$Extension_ID$LOG_EXTENSION"

    # Querying DataBase
    UTILS_Query_DB $QUERY_Path $DB_Path $OUT_Path $LOG_QUERY
    if [ $? -ne 0 ]; then exit $FAILURE_CODE_QUERY; fi

    exit $SUCCESS_CODE;
}

<<doc
Query the CodeQL's database for each NPM's package.
doc
query_CWS()
{
    EXT_LIST=$1
    if ! [ -f $EXT_LIST ]; then echo "Missing list!"; exit $OMITTED_CODE; fi

    QUERY_Path=$2
    if ! [ -e $QUERY_Path ]; then echo "Missing path!"; exit $OMITTED_CODE; fi

    TIMESTAMP=$(date +%s);
    mkdir -p "$CODEX_CQL_CWS/$TIMESTAMP"
    mkdir -p "$CODEX_LOG_Query/$TIMESTAMP"

    # LOG for Parallel-Job
    JOB_Path="$CODEX_LOG_Parallel/query.$TIMESTAMP$LOG_EXTENSION"

    SECONDS=0

    export -f query_Extension
    # For each built database from the CWS's Repository...
    parallel --eta              \
             --jobs 32          \
             --delay 0.1        \
             --timeout 600      \
             --joblog $JOB_Path \
             --resume           \
             query_Extension ::: $TIMESTAMP ::: $QUERY_Path :::: $EXT_LIST

    echo "---> Done in $SECONDS seconds (TIMESTAMP $TIMESTAMP)"
}

# ---------- #

<<doc
A helper function to check process' progress while working with CWS.
doc
log_CWS()
{
    Parallel_LOG=$@

    # Counter for each KW
    UTILS_Count_CTR $Parallel_LOG

    # Some small log for debugging reasons...
    echo """
    ===== log =====
    ---> $CTR_TOTAL extensions considered
    ---> $CTR_UNZIP failures while unziping
    ---> $CTR_BUILD failures while building
    ---> $CTR_CLEAN failures while cleaning
    ---> $CTR_QUERY failures while querying
    ---> $CTR_TIMEOUT time-outs
    ---> $CTR_OMITTED omissions
    ---> $CTR_SUCCESS successes
    """
}

# ---------- #


while getopts 'u:b:c:q:l:' OPERATION; do
    case $OPERATION in
        u)
            echo "Unziping!"
            unzip_CWS $OPTARG;;
        b)
            echo "Building!"
            build_CWS $OPTARG;;
        c)
            echo "Cleaning!"
            clean_CWS $OPTARG;;
        q)
            ARRAYARG+=("$OPTARG");
            if [ ${#ARRAYARG[@]} -eq 2 ]; then
                echo "Querying!"
                query_CWS ${ARRAYARG[0]} ${ARRAYARG[1]}
            fi;;
        l)
            echo "Logging!"
            log_CWS $OPTARG;;
    esac
done
