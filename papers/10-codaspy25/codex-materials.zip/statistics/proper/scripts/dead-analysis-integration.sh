#!/bin/bash

all_dead_reasons_file="./all-dead-proper-exts-removal-reasons.txt"

for txt in ./dead-reasons/*; do
  ext=`basename -- "$txt" .txt`
  if [ "$ext" == "log" ]
    then continue
  fi
  content=`cat $txt`
  printf '%s\n' "$ext : [ $content ]" >> $all_dead_reasons_file
  done