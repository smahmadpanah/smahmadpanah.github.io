import requests
import os
import sys

if len(sys.argv) > 1:
    ext = sys.argv[1]
    url = f"https://clients2.google.com/service/update2/crx?os=win&arch=x64&os_arch=x86_64&nacl_arch=x86-64&prod=chromecrx&prodchannel=&prodversion=104.0.5112.81&lang=en-US&acceptformat=crx3&x=id%3D{ext}%26v%3D0.0.0.0%26installedby%3Dother%26uc%26ping%3Dr%253D-1%2526e%253D1"

    print("Scanning", url)
    print( requests.get(url).content )
    exit()