#!/bin/bash
prev=""
while read line; do
  [[ $prev =~ (.*)\. ]] && then="${BASH_REMATCH[1]}"
  [[ $line =~ (.*)\. ]] && now="${BASH_REMATCH[1]}"
  if [[ "$then" != "$now" ]]; then
  	echo $prev >> all-proper-extensions-latest-versions.txt
  fi
  prev=$line
done <all-proper-extensions.txt
echo $line >> all-proper-extensions-latest-versions.txt