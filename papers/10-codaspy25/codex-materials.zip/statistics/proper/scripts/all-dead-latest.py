all_ext = set(l.strip() for l in open('all-proper-extensions-latest-versions.txt'))

all_alive = set(l.strip() for l in open('all-alive-proper-extensions-latest-versions.txt'))

all_dead = all_ext.difference(all_alive)

with open('all-dead-proper-extensions-latest-versions.txt', 'w') as f:
    for line in all_dead:
        f.write(f"{line}\n")
