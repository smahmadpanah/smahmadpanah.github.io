import re

all_latest = {}
with open("all-proper-extensions-latest-versions.txt") as f:
   for line in f:
      arr = re.split(r'\.', line)
      all_latest[arr[0]] = line.strip()

alive = set(l.strip() for l in open('alive-all.txt'))

file = open("all-alive-proper-extensions-latest-versions.txt", "w")

for key, value in all_latest.items():
   if key in alive:
      file.write(value + "\n")
file.close()