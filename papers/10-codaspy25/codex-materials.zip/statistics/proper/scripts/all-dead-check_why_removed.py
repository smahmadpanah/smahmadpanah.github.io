import requests
import os
import sys
import re


file = open("dead/log.txt", "w")


with open("all-dead-proper-extensions-latest-versions.txt") as f:
   for line in f:
        arr = re.split(r'\.', line)
        ext = arr[0]

        if len(ext) > 1:
            url = f"https://clients2.google.com/service/update2/crx?os=win&arch=x64&os_arch=x86_64&nacl_arch=x86-64&prod=chromecrx&prodchannel=&prodversion=104.0.5112.81&lang=en-US&acceptformat=crx3&x=id%3D{ext}%26v%3D0.0.0.0%26installedby%3Dother%26uc%26ping%3Dr%253D-1%2526e%253D1"

            temp_file = open(f"dead/{ext}.txt", "w")
            file.write("Scanning" + url + "\n")
            response = requests.get(url)
            file.write(response.text + "\n")

            m = re.search('<updatecheck(.*)/>', response.text)
            if m:
                temp_file.write(m.group(1))
            temp_file.close()

            response.close()
            file.write("Connection closed \n ********** \n")

file.close()