# CODEX
### A Framework for Tracking Flows in Browser Extensions


---


## Overview

Some intermediate results from our experiments.


#### Main Analysis

The `proper/` directory has the following structure. 

```shell
| all_databases.txt                   # List of all items on the Store from March 2021 to March 2024
| alive-dead/                         # Results from checking which extensions are removed
| all-dead-removal-reasons-analysis/  # Removal labels extracted from the Google API
| all-exts-manifest-analysis/         # Results from analyzing extensions' manifests
| num-of-users/                       # Number of users for each extension, retrieved on April 4th, 2024
| proper/                             # List of proper extensions (not themes or apps)
| scripts/                            # Analysis scripts
| themes-apps/                        # List of themes or apps, excluded from the flow analysis
```


#### Differential Analysis

The `diff/` directory has the following structure. 

```shell
| EXT_with_updates.txt  # List of extensions with multiple versions in our dataset
| queries/              # Results from our differential analysis
| versions/             # Amount of versions per extension
```
