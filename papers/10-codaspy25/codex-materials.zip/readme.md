# CODEX
### A Framework for Tracking Flows in Browser Extensions


---


#### Disclaimer

The repository contains privacy-violating extensions that were uploaded to the CWS.
In ```examples/``` we include the extensions mentioned in the paper.
These were detected by our framework and deemed privacy-violating after manual verification.


## Overview

**CodeX** is a framework for *hardened taint tracking* of flows from browser-specific sensitive *sources* like cookies, browsing history, bookmarks, and search terms to network *sinks* through network requests.
It leverages the power of CodeQL while breaking away from the conservativeness of bug-finding flavors of the traditional CodeQL taint analysis.


## Organization

```shell
| README.md
| performance/   # Performance plots for CodeX analysis of CWS
| examples/      # Extensions mentioned in our paper as running examples (results and source code)
| queries/       # CodeX queries used to detect risky flows
| scripts/       # Scripts for running experiments, generate reports, and differential analysis
| statistics/    # Results of our analysis
| verification/  # Notes from our manual verification of results
```
