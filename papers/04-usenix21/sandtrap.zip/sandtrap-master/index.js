exports.SandTrap = require("./out/sandtrap.js").SandTrap;
exports.Policy = {};
exports.Policy.Basic = require("./out/policy/basic.js");
